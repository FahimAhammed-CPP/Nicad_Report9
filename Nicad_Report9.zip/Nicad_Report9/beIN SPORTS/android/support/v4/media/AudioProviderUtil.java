package android.support.v4.media;

import android.os.Bundle;
import android.support.v4.media.session.MediaControllerCompat;
import android.support.v4.media.session.MediaSessionCompat;
import com.sinyee.android.util.GsonUtils;
import com.sinyee.babybus.core.service.audio.bean.AudioBelongPlayQueueBean;
import com.sinyee.babybus.core.service.audio.bean.AudioDetailBean;

public class AudioProviderUtil {
  public static String createAudioBelongPlayQueueBeanString(String paramString1, String paramString2) {
    return createAudioBelongPlayQueueBeanString(paramString1, paramString2, -1L, false);
  }
  
  public static String createAudioBelongPlayQueueBeanString(String paramString1, String paramString2, long paramLong, boolean paramBoolean) {
    AudioBelongPlayQueueBean audioBelongPlayQueueBean = new AudioBelongPlayQueueBean();
    audioBelongPlayQueueBean.setAudioBelongPage(paramString1);
    audioBelongPlayQueueBean.setAudioSourceType(paramString2);
    audioBelongPlayQueueBean.setID(paramLong);
    audioBelongPlayQueueBean.setIsAlbumID(paramBoolean);
    return GsonUtils.toJson(audioBelongPlayQueueBean);
  }
  
  public static AudioDetailBean createAudioDetailBean(Bundle paramBundle) {
    return (paramBundle == null) ? null : (AudioDetailBean)GsonUtils.fromJson(paramBundle.getString("bundle_key_audio_detail"), AudioDetailBean.class);
  }
  
  public static AudioDetailBean createAudioDetailBean(Object paramObject) {
    if (paramObject == null)
      return null; 
    boolean bool = paramObject instanceof MediaMetadataCompat;
    return null;
  }
  
  public static AudioDetailBean createAudioDetailBeanFromQueueItem(MediaSessionCompat.QueueItem paramQueueItem) {
    return (paramQueueItem == null || paramQueueItem.getDescription() == null || paramQueueItem.getDescription().getExtras() == null) ? null : createAudioDetailBean(paramQueueItem.getDescription().getExtras());
  }
  
  public static MediaMetadataCompat createMediaMetadataCompat(AudioDetailBean paramAudioDetailBean) {
    if (paramAudioDetailBean == null)
      return null; 
    Bundle bundle = new Bundle();
    bundle.putString("android.media.metadata.MEDIA_ID", paramAudioDetailBean.getAudioToken());
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("");
    stringBuilder.append(paramAudioDetailBean.getAudioAlbumName());
    bundle.putString("android.media.metadata.ALBUM", stringBuilder.toString());
    stringBuilder = new StringBuilder();
    stringBuilder.append("");
    stringBuilder.append(paramAudioDetailBean.getAudioName());
    bundle.putString("android.media.metadata.TITLE", stringBuilder.toString());
    bundle.putLong("android.media.metadata.BT_FOLDER_TYPE", 1L);
    bundle.putString("bundle_key_audio_detail", GsonUtils.toJson(paramAudioDetailBean));
    MediaMetadataCompat mediaMetadataCompat = new MediaMetadataCompat(bundle);
    mediaMetadataCompat.getDescription().getExtras().putString("bundle_key_audio_detail", GsonUtils.toJson(paramAudioDetailBean));
    return mediaMetadataCompat;
  }
  
  public static AudioDetailBean getCurrentAudioDetailBean(MediaControllerCompat paramMediaControllerCompat) {
    AudioDetailBean audioDetailBean = null;
    if (paramMediaControllerCompat == null)
      return null; 
    if (paramMediaControllerCompat.getMetadata() != null)
      audioDetailBean = createAudioDetailBean(paramMediaControllerCompat.getMetadata().getBundle()); 
    return audioDetailBean;
  }
  
  public static int getCurrentAudioDetailBeanOfflineType(MediaControllerCompat paramMediaControllerCompat) {
    return (paramMediaControllerCompat == null) ? 0 : ((paramMediaControllerCompat.getMetadata() != null) ? createAudioDetailBean(paramMediaControllerCompat.getMetadata().getBundle()).getOfflineAlbumType() : 0);
  }
  
  public static int getCurrentAudioPlayBackState(MediaControllerCompat paramMediaControllerCompat) {
    return (paramMediaControllerCompat == null || paramMediaControllerCompat.getPlaybackState() == null) ? 0 : paramMediaControllerCompat.getPlaybackState().getState();
  }
  
  public static String getCurrentAudioTaken(MediaControllerCompat paramMediaControllerCompat) {
    String str2 = null;
    if (paramMediaControllerCompat == null)
      return null; 
    String str1 = str2;
    if (paramMediaControllerCompat.getMetadata() != null) {
      AudioDetailBean audioDetailBean = getCurrentAudioDetailBean(paramMediaControllerCompat);
      str1 = str2;
      if (audioDetailBean != null)
        str1 = audioDetailBean.getAudioToken(); 
    } 
    return str1;
  }
  
  public static boolean updateQueueItemAudioDetailBean(MediaSessionCompat.QueueItem paramQueueItem, AudioDetailBean paramAudioDetailBean) {
    if (paramQueueItem != null && paramQueueItem.getDescription() != null && paramQueueItem.getDescription().getExtras() != null && paramAudioDetailBean != null) {
      paramQueueItem.getDescription().getExtras().putString("bundle_key_audio_detail", GsonUtils.toJson(paramAudioDetailBean));
      return true;
    } 
    return false;
  }
}


/* Location:              C:\soft\dex2jar-2.0\BabyBus TV_Kids Videos & Games-dex2jar.jar!\android\support\v4\media\AudioProviderUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */