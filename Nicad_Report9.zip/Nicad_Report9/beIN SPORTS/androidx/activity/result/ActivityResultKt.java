package androidx.activity.result;

import android.content.Intent;
import kotlin.jvm.internal.j;

public final class ActivityResultKt {
  public static final int component1(ActivityResult paramActivityResult) {
    j.f(paramActivityResult, "$this$component1");
    return paramActivityResult.getResultCode();
  }
  
  public static final Intent component2(ActivityResult paramActivityResult) {
    j.f(paramActivityResult, "$this$component2");
    return paramActivityResult.getData();
  }
}


/* Location:              C:\soft\dex2jar-2.0\BabyBus TV_Kids Videos & Games-dex2jar.jar!\androidx\activity\result\ActivityResultKt.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */