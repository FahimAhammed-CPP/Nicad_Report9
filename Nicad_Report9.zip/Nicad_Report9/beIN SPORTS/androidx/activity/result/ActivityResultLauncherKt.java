package androidx.activity.result;

import androidx.core.app.ActivityOptionsCompat;
import kotlin.jvm.internal.j;
import zp.x;

public final class ActivityResultLauncherKt {
  public static final void launch(ActivityResultLauncher<Void> paramActivityResultLauncher, ActivityOptionsCompat paramActivityOptionsCompat) {
    j.f(paramActivityResultLauncher, "$this$launch");
    paramActivityResultLauncher.launch(null, paramActivityOptionsCompat);
  }
  
  public static final void launchUnit(ActivityResultLauncher<x> paramActivityResultLauncher, ActivityOptionsCompat paramActivityOptionsCompat) {
    j.f(paramActivityResultLauncher, "$this$launch");
    paramActivityResultLauncher.launch(x.a, paramActivityOptionsCompat);
  }
}


/* Location:              C:\soft\dex2jar-2.0\BabyBus TV_Kids Videos & Games-dex2jar.jar!\androidx\activity\result\ActivityResultLauncherKt.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */