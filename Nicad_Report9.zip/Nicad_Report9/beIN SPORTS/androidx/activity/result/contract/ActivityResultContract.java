package androidx.activity.result.contract;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

public abstract class ActivityResultContract<I, O> {
  @NonNull
  public abstract Intent createIntent(@NonNull Context paramContext, @SuppressLint({"UnknownNullness"}) I paramI);
  
  @Nullable
  public SynchronousResult<O> getSynchronousResult(@NonNull Context paramContext, @SuppressLint({"UnknownNullness"}) I paramI) {
    return null;
  }
  
  @SuppressLint({"UnknownNullness"})
  public abstract O parseResult(int paramInt, @Nullable Intent paramIntent);
  
  public static final class SynchronousResult<T> {
    @SuppressLint({"UnknownNullness"})
    private final T mValue;
    
    public SynchronousResult(@SuppressLint({"UnknownNullness"}) T param1T) {
      this.mValue = param1T;
    }
    
    @SuppressLint({"UnknownNullness"})
    public T getValue() {
      return this.mValue;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\BabyBus TV_Kids Videos & Games-dex2jar.jar!\androidx\activity\result\contract\ActivityResultContract.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */