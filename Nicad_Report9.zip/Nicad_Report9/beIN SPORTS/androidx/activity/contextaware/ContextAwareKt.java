package androidx.activity.contextaware;

import android.content.Context;
import fq.l;
import kotlin.coroutines.d;
import kotlin.coroutines.intrinsics.b;
import kotlin.coroutines.jvm.internal.h;
import kotlin.jvm.internal.i;
import kotlin.jvm.internal.j;
import kotlin.jvm.internal.k;
import kotlinx.coroutines.j;
import kotlinx.coroutines.k;
import zp.p;
import zp.x;

public final class ContextAwareKt {
  public static final <R> Object withContextAvailable(ContextAware paramContextAware, l<? super Context, ? extends R> paraml, d<? super R> paramd) {
    Context context = paramContextAware.peekAvailableContext();
    if (context != null)
      return paraml.invoke(context); 
    k k = new k(b.c(paramd), 1);
    k.u();
    ContextAwareKt$withContextAvailable$$inlined$suspendCancellableCoroutine$lambda$1 contextAwareKt$withContextAvailable$$inlined$suspendCancellableCoroutine$lambda$1 = new ContextAwareKt$withContextAvailable$$inlined$suspendCancellableCoroutine$lambda$1((j)k, paramContextAware, paraml);
    paramContextAware.addOnContextAvailableListener(contextAwareKt$withContextAvailable$$inlined$suspendCancellableCoroutine$lambda$1);
    k.a(new ContextAwareKt$withContextAvailable$$inlined$suspendCancellableCoroutine$lambda$2(contextAwareKt$withContextAvailable$$inlined$suspendCancellableCoroutine$lambda$1, paramContextAware, paraml));
    Object object = k.r();
    if (object == b.d())
      h.c(paramd); 
    return object;
  }
  
  private static final Object withContextAvailable$$forInline(ContextAware paramContextAware, l paraml, d paramd) {
    Context context = paramContextAware.peekAvailableContext();
    if (context != null)
      return paraml.invoke(context); 
    i.c(0);
    k k = new k(b.c(paramd), 1);
    k.u();
    ContextAwareKt$withContextAvailable$$inlined$suspendCancellableCoroutine$lambda$1 contextAwareKt$withContextAvailable$$inlined$suspendCancellableCoroutine$lambda$1 = new ContextAwareKt$withContextAvailable$$inlined$suspendCancellableCoroutine$lambda$1((j)k, paramContextAware, paraml);
    paramContextAware.addOnContextAvailableListener(contextAwareKt$withContextAvailable$$inlined$suspendCancellableCoroutine$lambda$1);
    k.a(new ContextAwareKt$withContextAvailable$$inlined$suspendCancellableCoroutine$lambda$2(contextAwareKt$withContextAvailable$$inlined$suspendCancellableCoroutine$lambda$1, paramContextAware, paraml));
    Object object = k.r();
    if (object == b.d())
      h.c(paramd); 
    i.c(1);
    return object;
  }
  
  public static final class ContextAwareKt$withContextAvailable$$inlined$suspendCancellableCoroutine$lambda$1 implements OnContextAvailableListener {
    public ContextAwareKt$withContextAvailable$$inlined$suspendCancellableCoroutine$lambda$1(j param1j, ContextAware param1ContextAware, l param1l) {}
    
    public void onContextAvailable(Context param1Context) {
      Object object;
      j.f(param1Context, "context");
      j j1 = this.$co;
      try {
        p.a a = p.Companion;
        object = p.constructor-impl(this.$onContextAvailable$inlined.invoke(param1Context));
      } finally {
        param1Context = null;
        p.a a = p.Companion;
      } 
    }
  }
  
  public static final class ContextAwareKt$withContextAvailable$$inlined$suspendCancellableCoroutine$lambda$2 extends k implements l<Throwable, x> {
    public ContextAwareKt$withContextAvailable$$inlined$suspendCancellableCoroutine$lambda$2(ContextAwareKt$withContextAvailable$$inlined$suspendCancellableCoroutine$lambda$1 param1ContextAwareKt$withContextAvailable$$inlined$suspendCancellableCoroutine$lambda$1, ContextAware param1ContextAware, l param1l) {
      super(1);
    }
    
    public final void invoke(Throwable param1Throwable) {
      this.$this_withContextAvailable$inlined.removeOnContextAvailableListener(this.$listener);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\BabyBus TV_Kids Videos & Games-dex2jar.jar!\androidx\activity\contextaware\ContextAwareKt.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */