package androidx.activity.contextaware;

import android.content.Context;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

public interface ContextAware {
  void addOnContextAvailableListener(@NonNull OnContextAvailableListener paramOnContextAvailableListener);
  
  @Nullable
  Context peekAvailableContext();
  
  void removeOnContextAvailableListener(@NonNull OnContextAvailableListener paramOnContextAvailableListener);
}


/* Location:              C:\soft\dex2jar-2.0\BabyBus TV_Kids Videos & Games-dex2jar.jar!\androidx\activity\contextaware\ContextAware.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */