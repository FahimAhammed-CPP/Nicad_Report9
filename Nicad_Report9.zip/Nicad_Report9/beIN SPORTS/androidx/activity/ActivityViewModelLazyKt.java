package androidx.activity;

import androidx.annotation.MainThread;
import androidx.lifecycle.ViewModel;
import androidx.lifecycle.ViewModelLazy;
import androidx.lifecycle.ViewModelProvider;
import androidx.lifecycle.ViewModelStore;
import fq.a;
import kotlin.jvm.internal.j;
import kotlin.jvm.internal.k;
import kotlin.jvm.internal.u;
import zp.i;

public final class ActivityViewModelLazyKt {
  public static final class ActivityViewModelLazyKt$viewModels$1 extends k implements a<ViewModelStore> {
    public ActivityViewModelLazyKt$viewModels$1(ComponentActivity param1ComponentActivity) {
      super(0);
    }
    
    public final ViewModelStore invoke() {
      ViewModelStore viewModelStore = this.$this_viewModels.getViewModelStore();
      j.e(viewModelStore, "viewModelStore");
      return viewModelStore;
    }
  }
  
  public static final class ActivityViewModelLazyKt$viewModels$factoryPromise$1 extends k implements a<ViewModelProvider.Factory> {
    public ActivityViewModelLazyKt$viewModels$factoryPromise$1(ComponentActivity param1ComponentActivity) {
      super(0);
    }
    
    public final ViewModelProvider.Factory invoke() {
      return this.$this_viewModels.getDefaultViewModelProviderFactory();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\BabyBus TV_Kids Videos & Games-dex2jar.jar!\androidx\activity\ActivityViewModelLazyKt.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */