package androidx.core.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.media.AudioAttributes;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.core.util.Preconditions;

public class NotificationChannelCompat {
  public static final String DEFAULT_CHANNEL_ID = "miscellaneous";
  
  private static final int DEFAULT_LIGHT_COLOR = 0;
  
  private static final boolean DEFAULT_SHOW_BADGE = true;
  
  AudioAttributes mAudioAttributes;
  
  private boolean mBypassDnd;
  
  private boolean mCanBubble;
  
  String mConversationId;
  
  String mDescription;
  
  String mGroupId;
  
  @NonNull
  final String mId;
  
  int mImportance;
  
  private boolean mImportantConversation;
  
  int mLightColor = 0;
  
  boolean mLights;
  
  private int mLockscreenVisibility;
  
  CharSequence mName;
  
  String mParentId;
  
  boolean mShowBadge = true;
  
  Uri mSound = Settings.System.DEFAULT_NOTIFICATION_URI;
  
  boolean mVibrationEnabled;
  
  long[] mVibrationPattern;
  
  @RequiresApi(26)
  NotificationChannelCompat(@NonNull NotificationChannel paramNotificationChannel) {
    this(paramNotificationChannel.getId(), paramNotificationChannel.getImportance());
    this.mName = paramNotificationChannel.getName();
    this.mDescription = paramNotificationChannel.getDescription();
    this.mGroupId = paramNotificationChannel.getGroup();
    this.mShowBadge = paramNotificationChannel.canShowBadge();
    this.mSound = paramNotificationChannel.getSound();
    this.mAudioAttributes = paramNotificationChannel.getAudioAttributes();
    this.mLights = paramNotificationChannel.shouldShowLights();
    this.mLightColor = paramNotificationChannel.getLightColor();
    this.mVibrationEnabled = paramNotificationChannel.shouldVibrate();
    this.mVibrationPattern = paramNotificationChannel.getVibrationPattern();
    int i = Build.VERSION.SDK_INT;
    if (i >= 30) {
      this.mParentId = paramNotificationChannel.getParentChannelId();
      this.mConversationId = paramNotificationChannel.getConversationId();
    } 
    this.mBypassDnd = paramNotificationChannel.canBypassDnd();
    this.mLockscreenVisibility = paramNotificationChannel.getLockscreenVisibility();
    if (i >= 29)
      this.mCanBubble = paramNotificationChannel.canBubble(); 
    if (i >= 30)
      this.mImportantConversation = paramNotificationChannel.isImportantConversation(); 
  }
  
  NotificationChannelCompat(@NonNull String paramString, int paramInt) {
    this.mId = (String)Preconditions.checkNotNull(paramString);
    this.mImportance = paramInt;
    this.mAudioAttributes = Notification.AUDIO_ATTRIBUTES_DEFAULT;
  }
  
  public boolean canBubble() {
    return this.mCanBubble;
  }
  
  public boolean canBypassDnd() {
    return this.mBypassDnd;
  }
  
  public boolean canShowBadge() {
    return this.mShowBadge;
  }
  
  @Nullable
  public AudioAttributes getAudioAttributes() {
    return this.mAudioAttributes;
  }
  
  @Nullable
  public String getConversationId() {
    return this.mConversationId;
  }
  
  @Nullable
  public String getDescription() {
    return this.mDescription;
  }
  
  @Nullable
  public String getGroup() {
    return this.mGroupId;
  }
  
  @NonNull
  public String getId() {
    return this.mId;
  }
  
  public int getImportance() {
    return this.mImportance;
  }
  
  public int getLightColor() {
    return this.mLightColor;
  }
  
  public int getLockscreenVisibility() {
    return this.mLockscreenVisibility;
  }
  
  @Nullable
  public CharSequence getName() {
    return this.mName;
  }
  
  NotificationChannel getNotificationChannel() {
    int i = Build.VERSION.SDK_INT;
    if (i < 26)
      return null; 
    NotificationChannel notificationChannel = new NotificationChannel(this.mId, this.mName, this.mImportance);
    notificationChannel.setDescription(this.mDescription);
    notificationChannel.setGroup(this.mGroupId);
    notificationChannel.setShowBadge(this.mShowBadge);
    notificationChannel.setSound(this.mSound, this.mAudioAttributes);
    notificationChannel.enableLights(this.mLights);
    notificationChannel.setLightColor(this.mLightColor);
    notificationChannel.setVibrationPattern(this.mVibrationPattern);
    notificationChannel.enableVibration(this.mVibrationEnabled);
    if (i >= 30) {
      String str = this.mParentId;
      if (str != null) {
        String str1 = this.mConversationId;
        if (str1 != null)
          notificationChannel.setConversationId(str, str1); 
      } 
    } 
    return notificationChannel;
  }
  
  @Nullable
  public String getParentChannelId() {
    return this.mParentId;
  }
  
  @Nullable
  public Uri getSound() {
    return this.mSound;
  }
  
  @Nullable
  public long[] getVibrationPattern() {
    return this.mVibrationPattern;
  }
  
  public boolean isImportantConversation() {
    return this.mImportantConversation;
  }
  
  public boolean shouldShowLights() {
    return this.mLights;
  }
  
  public boolean shouldVibrate() {
    return this.mVibrationEnabled;
  }
  
  @NonNull
  public Builder toBuilder() {
    return (new Builder(this.mId, this.mImportance)).setName(this.mName).setDescription(this.mDescription).setGroup(this.mGroupId).setShowBadge(this.mShowBadge).setSound(this.mSound, this.mAudioAttributes).setLightsEnabled(this.mLights).setLightColor(this.mLightColor).setVibrationEnabled(this.mVibrationEnabled).setVibrationPattern(this.mVibrationPattern).setConversationId(this.mParentId, this.mConversationId);
  }
  
  public static class Builder {
    private final NotificationChannelCompat mChannel;
    
    public Builder(@NonNull String param1String, int param1Int) {
      this.mChannel = new NotificationChannelCompat(param1String, param1Int);
    }
    
    @NonNull
    public NotificationChannelCompat build() {
      return this.mChannel;
    }
    
    @NonNull
    public Builder setConversationId(@NonNull String param1String1, @NonNull String param1String2) {
      if (Build.VERSION.SDK_INT >= 30) {
        NotificationChannelCompat notificationChannelCompat = this.mChannel;
        notificationChannelCompat.mParentId = param1String1;
        notificationChannelCompat.mConversationId = param1String2;
      } 
      return this;
    }
    
    @NonNull
    public Builder setDescription(@Nullable String param1String) {
      this.mChannel.mDescription = param1String;
      return this;
    }
    
    @NonNull
    public Builder setGroup(@Nullable String param1String) {
      this.mChannel.mGroupId = param1String;
      return this;
    }
    
    @NonNull
    public Builder setImportance(int param1Int) {
      this.mChannel.mImportance = param1Int;
      return this;
    }
    
    @NonNull
    public Builder setLightColor(int param1Int) {
      this.mChannel.mLightColor = param1Int;
      return this;
    }
    
    @NonNull
    public Builder setLightsEnabled(boolean param1Boolean) {
      this.mChannel.mLights = param1Boolean;
      return this;
    }
    
    @NonNull
    public Builder setName(@Nullable CharSequence param1CharSequence) {
      this.mChannel.mName = param1CharSequence;
      return this;
    }
    
    @NonNull
    public Builder setShowBadge(boolean param1Boolean) {
      this.mChannel.mShowBadge = param1Boolean;
      return this;
    }
    
    @NonNull
    public Builder setSound(@Nullable Uri param1Uri, @Nullable AudioAttributes param1AudioAttributes) {
      NotificationChannelCompat notificationChannelCompat = this.mChannel;
      notificationChannelCompat.mSound = param1Uri;
      notificationChannelCompat.mAudioAttributes = param1AudioAttributes;
      return this;
    }
    
    @NonNull
    public Builder setVibrationEnabled(boolean param1Boolean) {
      this.mChannel.mVibrationEnabled = param1Boolean;
      return this;
    }
    
    @NonNull
    public Builder setVibrationPattern(@Nullable long[] param1ArrayOflong) {
      boolean bool;
      NotificationChannelCompat notificationChannelCompat = this.mChannel;
      if (param1ArrayOflong != null && param1ArrayOflong.length > 0) {
        bool = true;
      } else {
        bool = false;
      } 
      notificationChannelCompat.mVibrationEnabled = bool;
      notificationChannelCompat.mVibrationPattern = param1ArrayOflong;
      return this;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\BabyBus TV_Kids Videos & Games-dex2jar.jar!\androidx\core\app\NotificationChannelCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */