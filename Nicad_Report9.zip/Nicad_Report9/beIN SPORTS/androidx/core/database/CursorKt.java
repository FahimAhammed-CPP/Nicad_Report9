package androidx.core.database;

import android.database.Cursor;
import kotlin.jvm.internal.j;

public final class CursorKt {
  public static final byte[] getBlobOrNull(Cursor paramCursor, int paramInt) {
    j.f(paramCursor, "$this$getBlobOrNull");
    return paramCursor.isNull(paramInt) ? null : paramCursor.getBlob(paramInt);
  }
  
  public static final Double getDoubleOrNull(Cursor paramCursor, int paramInt) {
    j.f(paramCursor, "$this$getDoubleOrNull");
    return paramCursor.isNull(paramInt) ? null : Double.valueOf(paramCursor.getDouble(paramInt));
  }
  
  public static final Float getFloatOrNull(Cursor paramCursor, int paramInt) {
    j.f(paramCursor, "$this$getFloatOrNull");
    return paramCursor.isNull(paramInt) ? null : Float.valueOf(paramCursor.getFloat(paramInt));
  }
  
  public static final Integer getIntOrNull(Cursor paramCursor, int paramInt) {
    j.f(paramCursor, "$this$getIntOrNull");
    return paramCursor.isNull(paramInt) ? null : Integer.valueOf(paramCursor.getInt(paramInt));
  }
  
  public static final Long getLongOrNull(Cursor paramCursor, int paramInt) {
    j.f(paramCursor, "$this$getLongOrNull");
    return paramCursor.isNull(paramInt) ? null : Long.valueOf(paramCursor.getLong(paramInt));
  }
  
  public static final Short getShortOrNull(Cursor paramCursor, int paramInt) {
    j.f(paramCursor, "$this$getShortOrNull");
    return paramCursor.isNull(paramInt) ? null : Short.valueOf(paramCursor.getShort(paramInt));
  }
  
  public static final String getStringOrNull(Cursor paramCursor, int paramInt) {
    j.f(paramCursor, "$this$getStringOrNull");
    return paramCursor.isNull(paramInt) ? null : paramCursor.getString(paramInt);
  }
}


/* Location:              C:\soft\dex2jar-2.0\BabyBus TV_Kids Videos & Games-dex2jar.jar!\androidx\core\database\CursorKt.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */