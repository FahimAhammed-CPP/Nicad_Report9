package androidx.core.database.sqlite;

import android.database.sqlite.SQLiteDatabase;
import fq.l;
import kotlin.jvm.internal.i;
import kotlin.jvm.internal.j;

public final class SQLiteDatabaseKt {
  public static final <T> T transaction(SQLiteDatabase paramSQLiteDatabase, boolean paramBoolean, l<? super SQLiteDatabase, ? extends T> paraml) {
    j.f(paramSQLiteDatabase, "$this$transaction");
    j.f(paraml, "body");
    if (paramBoolean) {
      paramSQLiteDatabase.beginTransaction();
    } else {
      paramSQLiteDatabase.beginTransactionNonExclusive();
    } 
    try {
      Object object = paraml.invoke(paramSQLiteDatabase);
      paramSQLiteDatabase.setTransactionSuccessful();
      return (T)object;
    } finally {
      i.b(1);
      paramSQLiteDatabase.endTransaction();
      i.a(1);
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\BabyBus TV_Kids Videos & Games-dex2jar.jar!\androidx\core\database\sqlite\SQLiteDatabaseKt.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */