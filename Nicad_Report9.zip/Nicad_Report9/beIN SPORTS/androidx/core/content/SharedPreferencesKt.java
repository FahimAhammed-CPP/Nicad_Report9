package androidx.core.content;

import android.annotation.SuppressLint;
import android.content.SharedPreferences;
import fq.l;
import kotlin.jvm.internal.j;
import zp.x;

public final class SharedPreferencesKt {
  @SuppressLint({"ApplySharedPref"})
  public static final void edit(SharedPreferences paramSharedPreferences, boolean paramBoolean, l<? super SharedPreferences.Editor, x> paraml) {
    j.f(paramSharedPreferences, "$this$edit");
    j.f(paraml, "action");
    SharedPreferences.Editor editor = paramSharedPreferences.edit();
    j.e(editor, "editor");
    paraml.invoke(editor);
    if (paramBoolean) {
      editor.commit();
      return;
    } 
    editor.apply();
  }
}


/* Location:              C:\soft\dex2jar-2.0\BabyBus TV_Kids Videos & Games-dex2jar.jar!\androidx\core\content\SharedPreferencesKt.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */