package androidx.core.content.pm;

import android.app.Person;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ShortcutInfo;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Parcelable;
import android.os.PersistableBundle;
import android.os.UserHandle;
import android.text.TextUtils;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.annotation.RestrictTo;
import androidx.annotation.VisibleForTesting;
import androidx.core.app.Person;
import androidx.core.content.LocusIdCompat;
import androidx.core.graphics.drawable.IconCompat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

public class ShortcutInfoCompat {
  private static final String EXTRA_LOCUS_ID = "extraLocusId";
  
  private static final String EXTRA_LONG_LIVED = "extraLongLived";
  
  private static final String EXTRA_PERSON_ = "extraPerson_";
  
  private static final String EXTRA_PERSON_COUNT = "extraPersonCount";
  
  ComponentName mActivity;
  
  Set<String> mCategories;
  
  Context mContext;
  
  CharSequence mDisabledMessage;
  
  int mDisabledReason;
  
  PersistableBundle mExtras;
  
  boolean mHasKeyFieldsOnly;
  
  IconCompat mIcon;
  
  String mId;
  
  Intent[] mIntents;
  
  boolean mIsAlwaysBadged;
  
  boolean mIsCached;
  
  boolean mIsDeclaredInManifest;
  
  boolean mIsDynamic;
  
  boolean mIsEnabled = true;
  
  boolean mIsImmutable;
  
  boolean mIsLongLived;
  
  boolean mIsPinned;
  
  CharSequence mLabel;
  
  long mLastChangedTimestamp;
  
  @Nullable
  LocusIdCompat mLocusId;
  
  CharSequence mLongLabel;
  
  String mPackageName;
  
  Person[] mPersons;
  
  int mRank;
  
  UserHandle mUser;
  
  @RequiresApi(22)
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP_PREFIX})
  private PersistableBundle buildLegacyExtrasBundle() {
    if (this.mExtras == null)
      this.mExtras = new PersistableBundle(); 
    Person[] arrayOfPerson = this.mPersons;
    if (arrayOfPerson != null && arrayOfPerson.length > 0) {
      this.mExtras.putInt("extraPersonCount", arrayOfPerson.length);
      for (int i = 0; i < this.mPersons.length; i = j) {
        PersistableBundle persistableBundle = this.mExtras;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("extraPerson_");
        int j = i + 1;
        stringBuilder.append(j);
        persistableBundle.putPersistableBundle(stringBuilder.toString(), this.mPersons[i].toPersistableBundle());
      } 
    } 
    LocusIdCompat locusIdCompat = this.mLocusId;
    if (locusIdCompat != null)
      this.mExtras.putString("extraLocusId", locusIdCompat.getId()); 
    this.mExtras.putBoolean("extraLongLived", this.mIsLongLived);
    return this.mExtras;
  }
  
  @RequiresApi(25)
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP_PREFIX})
  static List<ShortcutInfoCompat> fromShortcuts(@NonNull Context paramContext, @NonNull List<ShortcutInfo> paramList) {
    ArrayList<ShortcutInfoCompat> arrayList = new ArrayList(paramList.size());
    Iterator<ShortcutInfo> iterator = paramList.iterator();
    while (iterator.hasNext())
      arrayList.add((new Builder(paramContext, iterator.next())).build()); 
    return arrayList;
  }
  
  @Nullable
  @RequiresApi(25)
  static LocusIdCompat getLocusId(@NonNull ShortcutInfo paramShortcutInfo) {
    return (Build.VERSION.SDK_INT >= 29) ? ((paramShortcutInfo.getLocusId() == null) ? null : LocusIdCompat.toLocusIdCompat(paramShortcutInfo.getLocusId())) : getLocusIdFromExtra(paramShortcutInfo.getExtras());
  }
  
  @Nullable
  @RequiresApi(25)
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP_PREFIX})
  private static LocusIdCompat getLocusIdFromExtra(@Nullable PersistableBundle paramPersistableBundle) {
    if (paramPersistableBundle == null)
      return null; 
    String str = paramPersistableBundle.getString("extraLocusId");
    return (str == null) ? null : new LocusIdCompat(str);
  }
  
  @RequiresApi(25)
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP_PREFIX})
  @VisibleForTesting
  static boolean getLongLivedFromExtra(@Nullable PersistableBundle paramPersistableBundle) {
    return (paramPersistableBundle == null || !paramPersistableBundle.containsKey("extraLongLived")) ? false : paramPersistableBundle.getBoolean("extraLongLived");
  }
  
  @Nullable
  @RequiresApi(25)
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP_PREFIX})
  @VisibleForTesting
  static Person[] getPersonsFromExtra(@NonNull PersistableBundle paramPersistableBundle) {
    if (paramPersistableBundle == null || !paramPersistableBundle.containsKey("extraPersonCount"))
      return null; 
    int j = paramPersistableBundle.getInt("extraPersonCount");
    Person[] arrayOfPerson = new Person[j];
    for (int i = 0; i < j; i = k) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("extraPerson_");
      int k = i + 1;
      stringBuilder.append(k);
      arrayOfPerson[i] = Person.fromPersistableBundle(paramPersistableBundle.getPersistableBundle(stringBuilder.toString()));
    } 
    return arrayOfPerson;
  }
  
  Intent addToIntent(Intent paramIntent) {
    Intent[] arrayOfIntent = this.mIntents;
    paramIntent.putExtra("android.intent.extra.shortcut.INTENT", (Parcelable)arrayOfIntent[arrayOfIntent.length - 1]).putExtra("android.intent.extra.shortcut.NAME", this.mLabel.toString());
    if (this.mIcon != null) {
      Drawable drawable;
      ComponentName componentName = null;
      Intent[] arrayOfIntent1 = null;
      if (this.mIsAlwaysBadged) {
        Intent[] arrayOfIntent2;
        PackageManager packageManager = this.mContext.getPackageManager();
        componentName = this.mActivity;
        arrayOfIntent = arrayOfIntent1;
        if (componentName != null)
          try {
            Drawable drawable1 = packageManager.getActivityIcon(componentName);
          } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException) {
            arrayOfIntent2 = arrayOfIntent1;
          }  
        Intent[] arrayOfIntent3 = arrayOfIntent2;
        if (arrayOfIntent2 == null)
          drawable = this.mContext.getApplicationInfo().loadIcon(packageManager); 
      } 
      this.mIcon.addToShortcutIntent(paramIntent, drawable, this.mContext);
    } 
    return paramIntent;
  }
  
  @Nullable
  public ComponentName getActivity() {
    return this.mActivity;
  }
  
  @Nullable
  public Set<String> getCategories() {
    return this.mCategories;
  }
  
  @Nullable
  public CharSequence getDisabledMessage() {
    return this.mDisabledMessage;
  }
  
  public int getDisabledReason() {
    return this.mDisabledReason;
  }
  
  @Nullable
  public PersistableBundle getExtras() {
    return this.mExtras;
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP_PREFIX})
  public IconCompat getIcon() {
    return this.mIcon;
  }
  
  @NonNull
  public String getId() {
    return this.mId;
  }
  
  @NonNull
  public Intent getIntent() {
    Intent[] arrayOfIntent = this.mIntents;
    return arrayOfIntent[arrayOfIntent.length - 1];
  }
  
  @NonNull
  public Intent[] getIntents() {
    Intent[] arrayOfIntent = this.mIntents;
    return Arrays.<Intent>copyOf(arrayOfIntent, arrayOfIntent.length);
  }
  
  public long getLastChangedTimestamp() {
    return this.mLastChangedTimestamp;
  }
  
  @Nullable
  public LocusIdCompat getLocusId() {
    return this.mLocusId;
  }
  
  @Nullable
  public CharSequence getLongLabel() {
    return this.mLongLabel;
  }
  
  @NonNull
  public String getPackage() {
    return this.mPackageName;
  }
  
  public int getRank() {
    return this.mRank;
  }
  
  @NonNull
  public CharSequence getShortLabel() {
    return this.mLabel;
  }
  
  @Nullable
  public UserHandle getUserHandle() {
    return this.mUser;
  }
  
  public boolean hasKeyFieldsOnly() {
    return this.mHasKeyFieldsOnly;
  }
  
  public boolean isCached() {
    return this.mIsCached;
  }
  
  public boolean isDeclaredInManifest() {
    return this.mIsDeclaredInManifest;
  }
  
  public boolean isDynamic() {
    return this.mIsDynamic;
  }
  
  public boolean isEnabled() {
    return this.mIsEnabled;
  }
  
  public boolean isImmutable() {
    return this.mIsImmutable;
  }
  
  public boolean isPinned() {
    return this.mIsPinned;
  }
  
  @RequiresApi(25)
  public ShortcutInfo toShortcutInfo() {
    ShortcutInfo.Builder builder = (new ShortcutInfo.Builder(this.mContext, this.mId)).setShortLabel(this.mLabel).setIntents(this.mIntents);
    IconCompat iconCompat = this.mIcon;
    if (iconCompat != null)
      builder.setIcon(iconCompat.toIcon(this.mContext)); 
    if (!TextUtils.isEmpty(this.mLongLabel))
      builder.setLongLabel(this.mLongLabel); 
    if (!TextUtils.isEmpty(this.mDisabledMessage))
      builder.setDisabledMessage(this.mDisabledMessage); 
    ComponentName componentName = this.mActivity;
    if (componentName != null)
      builder.setActivity(componentName); 
    Set<String> set = this.mCategories;
    if (set != null)
      builder.setCategories(set); 
    builder.setRank(this.mRank);
    PersistableBundle persistableBundle = this.mExtras;
    if (persistableBundle != null)
      builder.setExtras(persistableBundle); 
    if (Build.VERSION.SDK_INT >= 29) {
      Person[] arrayOfPerson = this.mPersons;
      if (arrayOfPerson != null && arrayOfPerson.length > 0) {
        int j = arrayOfPerson.length;
        Person[] arrayOfPerson1 = new Person[j];
        for (int i = 0; i < j; i++)
          arrayOfPerson1[i] = this.mPersons[i].toAndroidPerson(); 
        builder.setPersons(arrayOfPerson1);
      } 
      LocusIdCompat locusIdCompat = this.mLocusId;
      if (locusIdCompat != null)
        builder.setLocusId(locusIdCompat.toLocusId()); 
      builder.setLongLived(this.mIsLongLived);
    } else {
      builder.setExtras(buildLegacyExtrasBundle());
    } 
    return builder.build();
  }
  
  public static class Builder {
    private final ShortcutInfoCompat mInfo;
    
    private boolean mIsConversation;
    
    @RequiresApi(25)
    @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP_PREFIX})
    public Builder(@NonNull Context param1Context, @NonNull ShortcutInfo param1ShortcutInfo) {
      ShortcutInfoCompat shortcutInfoCompat = new ShortcutInfoCompat();
      this.mInfo = shortcutInfoCompat;
      shortcutInfoCompat.mContext = param1Context;
      shortcutInfoCompat.mId = param1ShortcutInfo.getId();
      shortcutInfoCompat.mPackageName = param1ShortcutInfo.getPackage();
      Intent[] arrayOfIntent = param1ShortcutInfo.getIntents();
      shortcutInfoCompat.mIntents = Arrays.<Intent>copyOf(arrayOfIntent, arrayOfIntent.length);
      shortcutInfoCompat.mActivity = param1ShortcutInfo.getActivity();
      shortcutInfoCompat.mLabel = param1ShortcutInfo.getShortLabel();
      shortcutInfoCompat.mLongLabel = param1ShortcutInfo.getLongLabel();
      shortcutInfoCompat.mDisabledMessage = param1ShortcutInfo.getDisabledMessage();
      int i = Build.VERSION.SDK_INT;
      if (i >= 28) {
        shortcutInfoCompat.mDisabledReason = param1ShortcutInfo.getDisabledReason();
      } else {
        byte b;
        if (param1ShortcutInfo.isEnabled()) {
          b = 0;
        } else {
          b = 3;
        } 
        shortcutInfoCompat.mDisabledReason = b;
      } 
      shortcutInfoCompat.mCategories = param1ShortcutInfo.getCategories();
      shortcutInfoCompat.mPersons = ShortcutInfoCompat.getPersonsFromExtra(param1ShortcutInfo.getExtras());
      shortcutInfoCompat.mUser = param1ShortcutInfo.getUserHandle();
      shortcutInfoCompat.mLastChangedTimestamp = param1ShortcutInfo.getLastChangedTimestamp();
      if (i >= 30)
        shortcutInfoCompat.mIsCached = param1ShortcutInfo.isCached(); 
      shortcutInfoCompat.mIsDynamic = param1ShortcutInfo.isDynamic();
      shortcutInfoCompat.mIsPinned = param1ShortcutInfo.isPinned();
      shortcutInfoCompat.mIsDeclaredInManifest = param1ShortcutInfo.isDeclaredInManifest();
      shortcutInfoCompat.mIsImmutable = param1ShortcutInfo.isImmutable();
      shortcutInfoCompat.mIsEnabled = param1ShortcutInfo.isEnabled();
      shortcutInfoCompat.mHasKeyFieldsOnly = param1ShortcutInfo.hasKeyFieldsOnly();
      shortcutInfoCompat.mLocusId = ShortcutInfoCompat.getLocusId(param1ShortcutInfo);
      shortcutInfoCompat.mRank = param1ShortcutInfo.getRank();
      shortcutInfoCompat.mExtras = param1ShortcutInfo.getExtras();
    }
    
    public Builder(@NonNull Context param1Context, @NonNull String param1String) {
      ShortcutInfoCompat shortcutInfoCompat = new ShortcutInfoCompat();
      this.mInfo = shortcutInfoCompat;
      shortcutInfoCompat.mContext = param1Context;
      shortcutInfoCompat.mId = param1String;
    }
    
    @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP_PREFIX})
    public Builder(@NonNull ShortcutInfoCompat param1ShortcutInfoCompat) {
      ShortcutInfoCompat shortcutInfoCompat = new ShortcutInfoCompat();
      this.mInfo = shortcutInfoCompat;
      shortcutInfoCompat.mContext = param1ShortcutInfoCompat.mContext;
      shortcutInfoCompat.mId = param1ShortcutInfoCompat.mId;
      shortcutInfoCompat.mPackageName = param1ShortcutInfoCompat.mPackageName;
      Intent[] arrayOfIntent = param1ShortcutInfoCompat.mIntents;
      shortcutInfoCompat.mIntents = Arrays.<Intent>copyOf(arrayOfIntent, arrayOfIntent.length);
      shortcutInfoCompat.mActivity = param1ShortcutInfoCompat.mActivity;
      shortcutInfoCompat.mLabel = param1ShortcutInfoCompat.mLabel;
      shortcutInfoCompat.mLongLabel = param1ShortcutInfoCompat.mLongLabel;
      shortcutInfoCompat.mDisabledMessage = param1ShortcutInfoCompat.mDisabledMessage;
      shortcutInfoCompat.mDisabledReason = param1ShortcutInfoCompat.mDisabledReason;
      shortcutInfoCompat.mIcon = param1ShortcutInfoCompat.mIcon;
      shortcutInfoCompat.mIsAlwaysBadged = param1ShortcutInfoCompat.mIsAlwaysBadged;
      shortcutInfoCompat.mUser = param1ShortcutInfoCompat.mUser;
      shortcutInfoCompat.mLastChangedTimestamp = param1ShortcutInfoCompat.mLastChangedTimestamp;
      shortcutInfoCompat.mIsCached = param1ShortcutInfoCompat.mIsCached;
      shortcutInfoCompat.mIsDynamic = param1ShortcutInfoCompat.mIsDynamic;
      shortcutInfoCompat.mIsPinned = param1ShortcutInfoCompat.mIsPinned;
      shortcutInfoCompat.mIsDeclaredInManifest = param1ShortcutInfoCompat.mIsDeclaredInManifest;
      shortcutInfoCompat.mIsImmutable = param1ShortcutInfoCompat.mIsImmutable;
      shortcutInfoCompat.mIsEnabled = param1ShortcutInfoCompat.mIsEnabled;
      shortcutInfoCompat.mLocusId = param1ShortcutInfoCompat.mLocusId;
      shortcutInfoCompat.mIsLongLived = param1ShortcutInfoCompat.mIsLongLived;
      shortcutInfoCompat.mHasKeyFieldsOnly = param1ShortcutInfoCompat.mHasKeyFieldsOnly;
      shortcutInfoCompat.mRank = param1ShortcutInfoCompat.mRank;
      Person[] arrayOfPerson = param1ShortcutInfoCompat.mPersons;
      if (arrayOfPerson != null)
        shortcutInfoCompat.mPersons = Arrays.<Person>copyOf(arrayOfPerson, arrayOfPerson.length); 
      if (param1ShortcutInfoCompat.mCategories != null)
        shortcutInfoCompat.mCategories = new HashSet<String>(param1ShortcutInfoCompat.mCategories); 
      PersistableBundle persistableBundle = param1ShortcutInfoCompat.mExtras;
      if (persistableBundle != null)
        shortcutInfoCompat.mExtras = persistableBundle; 
    }
    
    @NonNull
    public ShortcutInfoCompat build() {
      if (!TextUtils.isEmpty(this.mInfo.mLabel)) {
        ShortcutInfoCompat shortcutInfoCompat = this.mInfo;
        Intent[] arrayOfIntent = shortcutInfoCompat.mIntents;
        if (arrayOfIntent != null && arrayOfIntent.length != 0) {
          if (this.mIsConversation) {
            if (shortcutInfoCompat.mLocusId == null)
              shortcutInfoCompat.mLocusId = new LocusIdCompat(shortcutInfoCompat.mId); 
            this.mInfo.mIsLongLived = true;
          } 
          return this.mInfo;
        } 
        throw new IllegalArgumentException("Shortcut must have an intent");
      } 
      throw new IllegalArgumentException("Shortcut must have a non-empty label");
    }
    
    @NonNull
    public Builder setActivity(@NonNull ComponentName param1ComponentName) {
      this.mInfo.mActivity = param1ComponentName;
      return this;
    }
    
    @NonNull
    public Builder setAlwaysBadged() {
      this.mInfo.mIsAlwaysBadged = true;
      return this;
    }
    
    @NonNull
    public Builder setCategories(@NonNull Set<String> param1Set) {
      this.mInfo.mCategories = param1Set;
      return this;
    }
    
    @NonNull
    public Builder setDisabledMessage(@NonNull CharSequence param1CharSequence) {
      this.mInfo.mDisabledMessage = param1CharSequence;
      return this;
    }
    
    @NonNull
    public Builder setExtras(@NonNull PersistableBundle param1PersistableBundle) {
      this.mInfo.mExtras = param1PersistableBundle;
      return this;
    }
    
    @NonNull
    public Builder setIcon(IconCompat param1IconCompat) {
      this.mInfo.mIcon = param1IconCompat;
      return this;
    }
    
    @NonNull
    public Builder setIntent(@NonNull Intent param1Intent) {
      return setIntents(new Intent[] { param1Intent });
    }
    
    @NonNull
    public Builder setIntents(@NonNull Intent[] param1ArrayOfIntent) {
      this.mInfo.mIntents = param1ArrayOfIntent;
      return this;
    }
    
    @NonNull
    public Builder setIsConversation() {
      this.mIsConversation = true;
      return this;
    }
    
    @NonNull
    public Builder setLocusId(@Nullable LocusIdCompat param1LocusIdCompat) {
      this.mInfo.mLocusId = param1LocusIdCompat;
      return this;
    }
    
    @NonNull
    public Builder setLongLabel(@NonNull CharSequence param1CharSequence) {
      this.mInfo.mLongLabel = param1CharSequence;
      return this;
    }
    
    @Deprecated
    @NonNull
    public Builder setLongLived() {
      this.mInfo.mIsLongLived = true;
      return this;
    }
    
    @NonNull
    public Builder setLongLived(boolean param1Boolean) {
      this.mInfo.mIsLongLived = param1Boolean;
      return this;
    }
    
    @NonNull
    public Builder setPerson(@NonNull Person param1Person) {
      return setPersons(new Person[] { param1Person });
    }
    
    @NonNull
    public Builder setPersons(@NonNull Person[] param1ArrayOfPerson) {
      this.mInfo.mPersons = param1ArrayOfPerson;
      return this;
    }
    
    @NonNull
    public Builder setRank(int param1Int) {
      this.mInfo.mRank = param1Int;
      return this;
    }
    
    @NonNull
    public Builder setShortLabel(@NonNull CharSequence param1CharSequence) {
      this.mInfo.mLabel = param1CharSequence;
      return this;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\BabyBus TV_Kids Videos & Games-dex2jar.jar!\androidx\core\content\pm\ShortcutInfoCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */