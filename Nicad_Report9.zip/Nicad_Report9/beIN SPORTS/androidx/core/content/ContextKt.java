package androidx.core.content;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import androidx.annotation.AttrRes;
import androidx.annotation.StyleRes;
import fq.l;
import kotlin.jvm.internal.j;
import zp.x;

public final class ContextKt {
  public static final void withStyledAttributes(Context paramContext, @StyleRes int paramInt, int[] paramArrayOfint, l<? super TypedArray, x> paraml) {
    j.f(paramContext, "$this$withStyledAttributes");
    j.f(paramArrayOfint, "attrs");
    j.f(paraml, "block");
    TypedArray typedArray = paramContext.obtainStyledAttributes(paramInt, paramArrayOfint);
    j.e(typedArray, "obtainStyledAttributes(resourceId, attrs)");
    paraml.invoke(typedArray);
    typedArray.recycle();
  }
  
  public static final void withStyledAttributes(Context paramContext, AttributeSet paramAttributeSet, int[] paramArrayOfint, @AttrRes int paramInt1, @StyleRes int paramInt2, l<? super TypedArray, x> paraml) {
    j.f(paramContext, "$this$withStyledAttributes");
    j.f(paramArrayOfint, "attrs");
    j.f(paraml, "block");
    TypedArray typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, paramArrayOfint, paramInt1, paramInt2);
    j.e(typedArray, "obtainStyledAttributes(s…efStyleAttr, defStyleRes)");
    paraml.invoke(typedArray);
    typedArray.recycle();
  }
}


/* Location:              C:\soft\dex2jar-2.0\BabyBus TV_Kids Videos & Games-dex2jar.jar!\androidx\core\content\ContextKt.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */