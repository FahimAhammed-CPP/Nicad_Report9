package androidx.core.content;

import android.content.ContentValues;
import kotlin.jvm.internal.j;
import zp.o;

public final class ContentValuesKt {
  public static final ContentValues contentValuesOf(o<String, ? extends Object>... paramVarArgs) {
    StringBuilder stringBuilder;
    j.f(paramVarArgs, "pairs");
    ContentValues contentValues = new ContentValues(paramVarArgs.length);
    int j = paramVarArgs.length;
    for (int i = 0; i < j; i++) {
      o<String, ? extends Object> o1 = paramVarArgs[i];
      String str = (String)o1.component1();
      Object object = o1.component2();
      if (object == null) {
        contentValues.putNull(str);
      } else if (object instanceof String) {
        contentValues.put(str, (String)object);
      } else if (object instanceof Integer) {
        contentValues.put(str, (Integer)object);
      } else if (object instanceof Long) {
        contentValues.put(str, (Long)object);
      } else if (object instanceof Boolean) {
        contentValues.put(str, (Boolean)object);
      } else if (object instanceof Float) {
        contentValues.put(str, (Float)object);
      } else if (object instanceof Double) {
        contentValues.put(str, (Double)object);
      } else if (object instanceof byte[]) {
        contentValues.put(str, (byte[])object);
      } else if (object instanceof Byte) {
        contentValues.put(str, (Byte)object);
      } else if (object instanceof Short) {
        contentValues.put(str, (Short)object);
      } else {
        String str1 = object.getClass().getCanonicalName();
        stringBuilder = new StringBuilder();
        stringBuilder.append("Illegal value type ");
        stringBuilder.append(str1);
        stringBuilder.append(" for key \"");
        stringBuilder.append(str);
        stringBuilder.append('"');
        throw new IllegalArgumentException(stringBuilder.toString());
      } 
    } 
    return (ContentValues)stringBuilder;
  }
}


/* Location:              C:\soft\dex2jar-2.0\BabyBus TV_Kids Videos & Games-dex2jar.jar!\androidx\core\content\ContentValuesKt.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */