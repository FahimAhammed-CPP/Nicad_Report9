package androidx.core.graphics;

import android.graphics.Bitmap;
import androidx.annotation.NonNull;

public final class BitmapCompat {
  public static int getAllocationByteCount(@NonNull Bitmap paramBitmap) {
    return paramBitmap.getAllocationByteCount();
  }
  
  public static boolean hasMipMap(@NonNull Bitmap paramBitmap) {
    return paramBitmap.hasMipMap();
  }
  
  public static void setHasMipMap(@NonNull Bitmap paramBitmap, boolean paramBoolean) {
    paramBitmap.setHasMipMap(paramBoolean);
  }
}


/* Location:              C:\soft\dex2jar-2.0\BabyBus TV_Kids Videos & Games-dex2jar.jar!\androidx\core\graphics\BitmapCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */