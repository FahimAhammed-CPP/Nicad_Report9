package androidx.core.graphics.drawable;

import android.graphics.Bitmap;
import android.graphics.drawable.Icon;
import android.net.Uri;
import androidx.annotation.RequiresApi;
import kotlin.jvm.internal.j;

public final class IconKt {
  @RequiresApi(26)
  public static final Icon toAdaptiveIcon(Bitmap paramBitmap) {
    j.f(paramBitmap, "$this$toAdaptiveIcon");
    Icon icon = Icon.createWithAdaptiveBitmap(paramBitmap);
    j.e(icon, "Icon.createWithAdaptiveBitmap(this)");
    return icon;
  }
  
  @RequiresApi(26)
  public static final Icon toIcon(Bitmap paramBitmap) {
    j.f(paramBitmap, "$this$toIcon");
    Icon icon = Icon.createWithBitmap(paramBitmap);
    j.e(icon, "Icon.createWithBitmap(this)");
    return icon;
  }
  
  @RequiresApi(26)
  public static final Icon toIcon(Uri paramUri) {
    j.f(paramUri, "$this$toIcon");
    Icon icon = Icon.createWithContentUri(paramUri);
    j.e(icon, "Icon.createWithContentUri(this)");
    return icon;
  }
  
  @RequiresApi(26)
  public static final Icon toIcon(byte[] paramArrayOfbyte) {
    j.f(paramArrayOfbyte, "$this$toIcon");
    Icon icon = Icon.createWithData(paramArrayOfbyte, 0, paramArrayOfbyte.length);
    j.e(icon, "Icon.createWithData(this, 0, size)");
    return icon;
  }
}


/* Location:              C:\soft\dex2jar-2.0\BabyBus TV_Kids Videos & Games-dex2jar.jar!\androidx\core\graphics\drawable\IconKt.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */