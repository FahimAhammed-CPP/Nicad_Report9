package androidx.core.graphics.drawable;

import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import kotlin.jvm.internal.j;

public final class BitmapDrawableKt {
  public static final BitmapDrawable toDrawable(Bitmap paramBitmap, Resources paramResources) {
    j.f(paramBitmap, "$this$toDrawable");
    j.f(paramResources, "resources");
    return new BitmapDrawable(paramResources, paramBitmap);
  }
}


/* Location:              C:\soft\dex2jar-2.0\BabyBus TV_Kids Videos & Games-dex2jar.jar!\androidx\core\graphics\drawable\BitmapDrawableKt.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */