package androidx.core.graphics;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.ColorSpace;
import android.graphics.Point;
import android.graphics.PointF;
import androidx.annotation.ColorInt;
import androidx.annotation.RequiresApi;
import fq.l;
import kotlin.jvm.internal.j;
import zp.x;

public final class BitmapKt {
  public static final Bitmap applyCanvas(Bitmap paramBitmap, l<? super Canvas, x> paraml) {
    j.f(paramBitmap, "$this$applyCanvas");
    j.f(paraml, "block");
    paraml.invoke(new Canvas(paramBitmap));
    return paramBitmap;
  }
  
  public static final boolean contains(Bitmap paramBitmap, Point paramPoint) {
    j.f(paramBitmap, "$this$contains");
    j.f(paramPoint, "p");
    int i = paramPoint.x;
    if (i >= 0 && i < paramBitmap.getWidth()) {
      i = paramPoint.y;
      if (i >= 0 && i < paramBitmap.getHeight())
        return true; 
    } 
    return false;
  }
  
  public static final boolean contains(Bitmap paramBitmap, PointF paramPointF) {
    j.f(paramBitmap, "$this$contains");
    j.f(paramPointF, "p");
    float f2 = paramPointF.x;
    boolean bool2 = false;
    float f1 = false;
    boolean bool1 = bool2;
    if (f2 >= f1) {
      bool1 = bool2;
      if (f2 < paramBitmap.getWidth()) {
        f2 = paramPointF.y;
        bool1 = bool2;
        if (f2 >= f1) {
          bool1 = bool2;
          if (f2 < paramBitmap.getHeight())
            bool1 = true; 
        } 
      } 
    } 
    return bool1;
  }
  
  public static final Bitmap createBitmap(int paramInt1, int paramInt2, Bitmap.Config paramConfig) {
    j.f(paramConfig, "config");
    Bitmap bitmap = Bitmap.createBitmap(paramInt1, paramInt2, paramConfig);
    j.e(bitmap, "Bitmap.createBitmap(width, height, config)");
    return bitmap;
  }
  
  @RequiresApi(26)
  public static final Bitmap createBitmap(int paramInt1, int paramInt2, Bitmap.Config paramConfig, boolean paramBoolean, ColorSpace paramColorSpace) {
    j.f(paramConfig, "config");
    j.f(paramColorSpace, "colorSpace");
    Bitmap bitmap = Bitmap.createBitmap(paramInt1, paramInt2, paramConfig, paramBoolean, paramColorSpace);
    j.e(bitmap, "Bitmap.createBitmap(widt…ig, hasAlpha, colorSpace)");
    return bitmap;
  }
  
  public static final int get(Bitmap paramBitmap, int paramInt1, int paramInt2) {
    j.f(paramBitmap, "$this$get");
    return paramBitmap.getPixel(paramInt1, paramInt2);
  }
  
  public static final Bitmap scale(Bitmap paramBitmap, int paramInt1, int paramInt2, boolean paramBoolean) {
    j.f(paramBitmap, "$this$scale");
    paramBitmap = Bitmap.createScaledBitmap(paramBitmap, paramInt1, paramInt2, paramBoolean);
    j.e(paramBitmap, "Bitmap.createScaledBitma…s, width, height, filter)");
    return paramBitmap;
  }
  
  public static final void set(Bitmap paramBitmap, int paramInt1, int paramInt2, @ColorInt int paramInt3) {
    j.f(paramBitmap, "$this$set");
    paramBitmap.setPixel(paramInt1, paramInt2, paramInt3);
  }
}


/* Location:              C:\soft\dex2jar-2.0\BabyBus TV_Kids Videos & Games-dex2jar.jar!\androidx\core\graphics\BitmapKt.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */