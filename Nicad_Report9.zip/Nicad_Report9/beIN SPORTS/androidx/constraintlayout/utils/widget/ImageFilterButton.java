package androidx.constraintlayout.utils.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Outline;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.LayerDrawable;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewOutlineProvider;
import android.widget.ImageView;
import androidx.annotation.RequiresApi;
import androidx.appcompat.widget.AppCompatImageButton;
import androidx.constraintlayout.widget.R;

public class ImageFilterButton extends AppCompatImageButton {
  private float mCrossfade = 0.0F;
  
  private ImageFilterView.ImageMatrix mImageMatrix = new ImageFilterView.ImageMatrix();
  
  LayerDrawable mLayer;
  
  Drawable[] mLayers;
  
  private boolean mOverlay = true;
  
  private Path mPath;
  
  RectF mRect;
  
  private float mRound = Float.NaN;
  
  private float mRoundPercent = 0.0F;
  
  ViewOutlineProvider mViewOutlineProvider;
  
  public ImageFilterButton(Context paramContext) {
    super(paramContext);
    init(paramContext, null);
  }
  
  public ImageFilterButton(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
    init(paramContext, paramAttributeSet);
  }
  
  public ImageFilterButton(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
    init(paramContext, paramAttributeSet);
  }
  
  private void init(Context paramContext, AttributeSet paramAttributeSet) {
    setPadding(0, 0, 0, 0);
    if (paramAttributeSet != null) {
      TypedArray typedArray = getContext().obtainStyledAttributes(paramAttributeSet, R.styleable.ImageFilterView);
      int j = typedArray.getIndexCount();
      Drawable drawable = typedArray.getDrawable(R.styleable.ImageFilterView_altSrc);
      for (int i = 0; i < j; i++) {
        int k = typedArray.getIndex(i);
        if (k == R.styleable.ImageFilterView_crossfade) {
          this.mCrossfade = typedArray.getFloat(k, 0.0F);
        } else if (k == R.styleable.ImageFilterView_warmth) {
          setWarmth(typedArray.getFloat(k, 0.0F));
        } else if (k == R.styleable.ImageFilterView_saturation) {
          setSaturation(typedArray.getFloat(k, 0.0F));
        } else if (k == R.styleable.ImageFilterView_contrast) {
          setContrast(typedArray.getFloat(k, 0.0F));
        } else if (k == R.styleable.ImageFilterView_round) {
          setRound(typedArray.getDimension(k, 0.0F));
        } else if (k == R.styleable.ImageFilterView_roundPercent) {
          setRoundPercent(typedArray.getFloat(k, 0.0F));
        } else if (k == R.styleable.ImageFilterView_overlay) {
          setOverlay(typedArray.getBoolean(k, this.mOverlay));
        } 
      } 
      typedArray.recycle();
      if (drawable != null) {
        Drawable[] arrayOfDrawable = new Drawable[2];
        this.mLayers = arrayOfDrawable;
        arrayOfDrawable[0] = getDrawable();
        this.mLayers[1] = drawable;
        LayerDrawable layerDrawable = new LayerDrawable(this.mLayers);
        this.mLayer = layerDrawable;
        layerDrawable.getDrawable(1).setAlpha((int)(this.mCrossfade * 255.0F));
        setImageDrawable((Drawable)this.mLayer);
      } 
    } 
  }
  
  private void setOverlay(boolean paramBoolean) {
    this.mOverlay = paramBoolean;
  }
  
  public void draw(Canvas paramCanvas) {
    super.draw(paramCanvas);
  }
  
  public float getContrast() {
    return this.mImageMatrix.mContrast;
  }
  
  public float getCrossfade() {
    return this.mCrossfade;
  }
  
  public float getRound() {
    return this.mRound;
  }
  
  public float getRoundPercent() {
    return this.mRoundPercent;
  }
  
  public float getSaturation() {
    return this.mImageMatrix.mSaturation;
  }
  
  public float getWarmth() {
    return this.mImageMatrix.mWarmth;
  }
  
  public void setBrightness(float paramFloat) {
    ImageFilterView.ImageMatrix imageMatrix = this.mImageMatrix;
    imageMatrix.mBrightness = paramFloat;
    imageMatrix.updateMatrix((ImageView)this);
  }
  
  public void setContrast(float paramFloat) {
    ImageFilterView.ImageMatrix imageMatrix = this.mImageMatrix;
    imageMatrix.mContrast = paramFloat;
    imageMatrix.updateMatrix((ImageView)this);
  }
  
  public void setCrossfade(float paramFloat) {
    this.mCrossfade = paramFloat;
    if (this.mLayers != null) {
      if (!this.mOverlay)
        this.mLayer.getDrawable(0).setAlpha((int)((1.0F - this.mCrossfade) * 255.0F)); 
      this.mLayer.getDrawable(1).setAlpha((int)(this.mCrossfade * 255.0F));
      setImageDrawable((Drawable)this.mLayer);
    } 
  }
  
  @RequiresApi(21)
  public void setRound(float paramFloat) {
    boolean bool;
    if (Float.isNaN(paramFloat)) {
      this.mRound = paramFloat;
      paramFloat = this.mRoundPercent;
      this.mRoundPercent = -1.0F;
      setRoundPercent(paramFloat);
      return;
    } 
    if (this.mRound != paramFloat) {
      bool = true;
    } else {
      bool = false;
    } 
    this.mRound = paramFloat;
    if (paramFloat != 0.0F) {
      if (this.mPath == null)
        this.mPath = new Path(); 
      if (this.mRect == null)
        this.mRect = new RectF(); 
      if (this.mViewOutlineProvider == null) {
        ViewOutlineProvider viewOutlineProvider = new ViewOutlineProvider() {
            public void getOutline(View param1View, Outline param1Outline) {
              param1Outline.setRoundRect(0, 0, ImageFilterButton.this.getWidth(), ImageFilterButton.this.getHeight(), ImageFilterButton.this.mRound);
            }
          };
        this.mViewOutlineProvider = viewOutlineProvider;
        setOutlineProvider(viewOutlineProvider);
      } 
      setClipToOutline(true);
      int i = getWidth();
      int j = getHeight();
      this.mRect.set(0.0F, 0.0F, i, j);
      this.mPath.reset();
      Path path = this.mPath;
      RectF rectF = this.mRect;
      paramFloat = this.mRound;
      path.addRoundRect(rectF, paramFloat, paramFloat, Path.Direction.CW);
    } else {
      setClipToOutline(false);
    } 
    if (bool)
      invalidateOutline(); 
  }
  
  @RequiresApi(21)
  public void setRoundPercent(float paramFloat) {
    boolean bool;
    if (this.mRoundPercent != paramFloat) {
      bool = true;
    } else {
      bool = false;
    } 
    this.mRoundPercent = paramFloat;
    if (paramFloat != 0.0F) {
      if (this.mPath == null)
        this.mPath = new Path(); 
      if (this.mRect == null)
        this.mRect = new RectF(); 
      if (this.mViewOutlineProvider == null) {
        ViewOutlineProvider viewOutlineProvider = new ViewOutlineProvider() {
            public void getOutline(View param1View, Outline param1Outline) {
              int i = ImageFilterButton.this.getWidth();
              int j = ImageFilterButton.this.getHeight();
              param1Outline.setRoundRect(0, 0, i, j, Math.min(i, j) * ImageFilterButton.this.mRoundPercent / 2.0F);
            }
          };
        this.mViewOutlineProvider = viewOutlineProvider;
        setOutlineProvider(viewOutlineProvider);
      } 
      setClipToOutline(true);
      int i = getWidth();
      int j = getHeight();
      paramFloat = Math.min(i, j) * this.mRoundPercent / 2.0F;
      this.mRect.set(0.0F, 0.0F, i, j);
      this.mPath.reset();
      this.mPath.addRoundRect(this.mRect, paramFloat, paramFloat, Path.Direction.CW);
    } else {
      setClipToOutline(false);
    } 
    if (bool)
      invalidateOutline(); 
  }
  
  public void setSaturation(float paramFloat) {
    ImageFilterView.ImageMatrix imageMatrix = this.mImageMatrix;
    imageMatrix.mSaturation = paramFloat;
    imageMatrix.updateMatrix((ImageView)this);
  }
  
  public void setWarmth(float paramFloat) {
    ImageFilterView.ImageMatrix imageMatrix = this.mImageMatrix;
    imageMatrix.mWarmth = paramFloat;
    imageMatrix.updateMatrix((ImageView)this);
  }
}


/* Location:              C:\soft\dex2jar-2.0\BabyBus TV_Kids Videos & Games-dex2jar.jar!\androidx\constraintlayou\\utils\widget\ImageFilterButton.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */