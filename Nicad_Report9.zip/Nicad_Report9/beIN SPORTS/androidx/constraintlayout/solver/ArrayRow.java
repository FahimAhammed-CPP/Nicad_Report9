package androidx.constraintlayout.solver;

import java.util.ArrayList;

public class ArrayRow implements LinearSystem.Row {
  private static final boolean DEBUG = false;
  
  private static final boolean FULL_NEW_CHECK = false;
  
  float constantValue = 0.0F;
  
  boolean isSimpleDefinition = false;
  
  boolean used = false;
  
  SolverVariable variable = null;
  
  public ArrayRowVariables variables;
  
  ArrayList<SolverVariable> variablesToUpdate = new ArrayList<SolverVariable>();
  
  public ArrayRow() {}
  
  public ArrayRow(Cache paramCache) {
    this.variables = new ArrayLinkedVariables(this, paramCache);
  }
  
  private boolean isNew(SolverVariable paramSolverVariable, LinearSystem paramLinearSystem) {
    return (paramSolverVariable.usageInRowCount <= 1);
  }
  
  private SolverVariable pickPivotInVariables(boolean[] paramArrayOfboolean, SolverVariable paramSolverVariable) {
    // Byte code:
    //   0: aload_0
    //   1: getfield variables : Landroidx/constraintlayout/solver/ArrayRow$ArrayRowVariables;
    //   4: invokeinterface getCurrentSize : ()I
    //   9: istore #7
    //   11: aconst_null
    //   12: astore #8
    //   14: iconst_0
    //   15: istore #6
    //   17: fconst_0
    //   18: fstore_3
    //   19: iload #6
    //   21: iload #7
    //   23: if_icmpge -> 168
    //   26: aload_0
    //   27: getfield variables : Landroidx/constraintlayout/solver/ArrayRow$ArrayRowVariables;
    //   30: iload #6
    //   32: invokeinterface getVariableValue : (I)F
    //   37: fstore #5
    //   39: aload #8
    //   41: astore #9
    //   43: fload_3
    //   44: fstore #4
    //   46: fload #5
    //   48: fconst_0
    //   49: fcmpg
    //   50: ifge -> 152
    //   53: aload_0
    //   54: getfield variables : Landroidx/constraintlayout/solver/ArrayRow$ArrayRowVariables;
    //   57: iload #6
    //   59: invokeinterface getVariable : (I)Landroidx/constraintlayout/solver/SolverVariable;
    //   64: astore #10
    //   66: aload_1
    //   67: ifnull -> 87
    //   70: aload #8
    //   72: astore #9
    //   74: fload_3
    //   75: fstore #4
    //   77: aload_1
    //   78: aload #10
    //   80: getfield id : I
    //   83: baload
    //   84: ifne -> 152
    //   87: aload #8
    //   89: astore #9
    //   91: fload_3
    //   92: fstore #4
    //   94: aload #10
    //   96: aload_2
    //   97: if_acmpeq -> 152
    //   100: aload #10
    //   102: getfield mType : Landroidx/constraintlayout/solver/SolverVariable$Type;
    //   105: astore #11
    //   107: aload #11
    //   109: getstatic androidx/constraintlayout/solver/SolverVariable$Type.SLACK : Landroidx/constraintlayout/solver/SolverVariable$Type;
    //   112: if_acmpeq -> 130
    //   115: aload #8
    //   117: astore #9
    //   119: fload_3
    //   120: fstore #4
    //   122: aload #11
    //   124: getstatic androidx/constraintlayout/solver/SolverVariable$Type.ERROR : Landroidx/constraintlayout/solver/SolverVariable$Type;
    //   127: if_acmpne -> 152
    //   130: aload #8
    //   132: astore #9
    //   134: fload_3
    //   135: fstore #4
    //   137: fload #5
    //   139: fload_3
    //   140: fcmpg
    //   141: ifge -> 152
    //   144: fload #5
    //   146: fstore #4
    //   148: aload #10
    //   150: astore #9
    //   152: iload #6
    //   154: iconst_1
    //   155: iadd
    //   156: istore #6
    //   158: aload #9
    //   160: astore #8
    //   162: fload #4
    //   164: fstore_3
    //   165: goto -> 19
    //   168: aload #8
    //   170: areturn
  }
  
  public ArrayRow addError(LinearSystem paramLinearSystem, int paramInt) {
    this.variables.put(paramLinearSystem.createErrorVariable(paramInt, "ep"), 1.0F);
    this.variables.put(paramLinearSystem.createErrorVariable(paramInt, "em"), -1.0F);
    return this;
  }
  
  public void addError(SolverVariable paramSolverVariable) {
    int i = paramSolverVariable.strength;
    float f = 1.0F;
    if (i != 1)
      if (i == 2) {
        f = 1000.0F;
      } else if (i == 3) {
        f = 1000000.0F;
      } else if (i == 4) {
        f = 1.0E9F;
      } else if (i == 5) {
        f = 1.0E12F;
      }  
    this.variables.put(paramSolverVariable, f);
  }
  
  ArrayRow addSingleError(SolverVariable paramSolverVariable, int paramInt) {
    this.variables.put(paramSolverVariable, paramInt);
    return this;
  }
  
  boolean chooseSubject(LinearSystem paramLinearSystem) {
    boolean bool;
    SolverVariable solverVariable = chooseSubjectInVariables(paramLinearSystem);
    if (solverVariable == null) {
      bool = true;
    } else {
      pivot(solverVariable);
      bool = false;
    } 
    if (this.variables.getCurrentSize() == 0)
      this.isSimpleDefinition = true; 
    return bool;
  }
  
  SolverVariable chooseSubjectInVariables(LinearSystem paramLinearSystem) {
    int j = this.variables.getCurrentSize();
    SolverVariable solverVariable2 = null;
    SolverVariable solverVariable1 = null;
    int i = 0;
    boolean bool2 = false;
    boolean bool1 = false;
    float f2 = 0.0F;
    float f1;
    for (f1 = 0.0F;; f1 = f4) {
      float f3;
      float f4;
      boolean bool3;
      boolean bool4;
      SolverVariable solverVariable3;
      SolverVariable solverVariable4;
      if (i < j) {
        float f = this.variables.getVariableValue(i);
        SolverVariable solverVariable = this.variables.getVariable(i);
        if (solverVariable.mType == SolverVariable.Type.UNRESTRICTED) {
          if (solverVariable2 == null) {
            bool3 = isNew(solverVariable, paramLinearSystem);
          } else if (f2 > f) {
            bool3 = isNew(solverVariable, paramLinearSystem);
          } else {
            SolverVariable solverVariable5 = solverVariable2;
            SolverVariable solverVariable6 = solverVariable1;
            bool3 = bool2;
            boolean bool = bool1;
            float f5 = f2;
            float f6 = f1;
            if (!bool2) {
              solverVariable5 = solverVariable2;
              solverVariable6 = solverVariable1;
              bool3 = bool2;
              bool = bool1;
              f5 = f2;
              f6 = f1;
              if (isNew(solverVariable, paramLinearSystem)) {
                bool3 = true;
                solverVariable5 = solverVariable;
                solverVariable6 = solverVariable1;
                bool = bool1;
                f5 = f;
                f6 = f1;
              } 
            } 
            i++;
            solverVariable2 = solverVariable5;
            solverVariable1 = solverVariable6;
            bool2 = bool3;
            bool1 = bool;
            f2 = f5;
            f1 = f6;
          } 
          solverVariable3 = solverVariable;
          solverVariable4 = solverVariable1;
          bool4 = bool1;
          f3 = f;
          f4 = f1;
        } else {
          solverVariable3 = solverVariable2;
          solverVariable4 = solverVariable1;
          bool3 = bool2;
          bool4 = bool1;
          f3 = f2;
          f4 = f1;
          if (solverVariable2 == null) {
            solverVariable3 = solverVariable2;
            solverVariable4 = solverVariable1;
            bool3 = bool2;
            bool4 = bool1;
            f3 = f2;
            f4 = f1;
            if (f < 0.0F) {
              if (solverVariable1 == null) {
                bool3 = isNew(solverVariable, paramLinearSystem);
              } else if (f1 > f) {
                bool3 = isNew(solverVariable, paramLinearSystem);
              } else {
                solverVariable3 = solverVariable2;
                solverVariable4 = solverVariable1;
                bool3 = bool2;
                bool4 = bool1;
                f3 = f2;
                f4 = f1;
                if (!bool1) {
                  solverVariable3 = solverVariable2;
                  solverVariable4 = solverVariable1;
                  bool3 = bool2;
                  bool4 = bool1;
                  f3 = f2;
                  f4 = f1;
                  if (isNew(solverVariable, paramLinearSystem)) {
                    bool4 = true;
                    f4 = f;
                    f3 = f2;
                    bool3 = bool2;
                    solverVariable4 = solverVariable;
                    solverVariable3 = solverVariable2;
                  } 
                } 
                i++;
                solverVariable2 = solverVariable3;
                solverVariable1 = solverVariable4;
                bool2 = bool3;
                bool1 = bool4;
                f2 = f3;
                f1 = f4;
              } 
              bool4 = bool3;
              solverVariable3 = solverVariable2;
              solverVariable4 = solverVariable;
              bool3 = bool2;
              f3 = f2;
              f4 = f;
            } 
          } 
        } 
      } else {
        break;
      } 
      i++;
      solverVariable2 = solverVariable3;
      solverVariable1 = solverVariable4;
      bool2 = bool3;
      bool1 = bool4;
      f2 = f3;
    } 
    return (solverVariable2 != null) ? solverVariable2 : solverVariable1;
  }
  
  public void clear() {
    this.variables.clear();
    this.variable = null;
    this.constantValue = 0.0F;
  }
  
  ArrayRow createRowCentering(SolverVariable paramSolverVariable1, SolverVariable paramSolverVariable2, int paramInt1, float paramFloat, SolverVariable paramSolverVariable3, SolverVariable paramSolverVariable4, int paramInt2) {
    if (paramSolverVariable2 == paramSolverVariable3) {
      this.variables.put(paramSolverVariable1, 1.0F);
      this.variables.put(paramSolverVariable4, 1.0F);
      this.variables.put(paramSolverVariable2, -2.0F);
      return this;
    } 
    if (paramFloat == 0.5F) {
      this.variables.put(paramSolverVariable1, 1.0F);
      this.variables.put(paramSolverVariable2, -1.0F);
      this.variables.put(paramSolverVariable3, -1.0F);
      this.variables.put(paramSolverVariable4, 1.0F);
      if (paramInt1 > 0 || paramInt2 > 0) {
        this.constantValue = (-paramInt1 + paramInt2);
        return this;
      } 
    } else {
      if (paramFloat <= 0.0F) {
        this.variables.put(paramSolverVariable1, -1.0F);
        this.variables.put(paramSolverVariable2, 1.0F);
        this.constantValue = paramInt1;
        return this;
      } 
      if (paramFloat >= 1.0F) {
        this.variables.put(paramSolverVariable4, -1.0F);
        this.variables.put(paramSolverVariable3, 1.0F);
        this.constantValue = -paramInt2;
        return this;
      } 
      ArrayRowVariables arrayRowVariables = this.variables;
      float f = 1.0F - paramFloat;
      arrayRowVariables.put(paramSolverVariable1, f * 1.0F);
      this.variables.put(paramSolverVariable2, f * -1.0F);
      this.variables.put(paramSolverVariable3, -1.0F * paramFloat);
      this.variables.put(paramSolverVariable4, 1.0F * paramFloat);
      if (paramInt1 > 0 || paramInt2 > 0)
        this.constantValue = -paramInt1 * f + paramInt2 * paramFloat; 
    } 
    return this;
  }
  
  ArrayRow createRowDefinition(SolverVariable paramSolverVariable, int paramInt) {
    this.variable = paramSolverVariable;
    float f = paramInt;
    paramSolverVariable.computedValue = f;
    this.constantValue = f;
    this.isSimpleDefinition = true;
    return this;
  }
  
  ArrayRow createRowDimensionPercent(SolverVariable paramSolverVariable1, SolverVariable paramSolverVariable2, float paramFloat) {
    this.variables.put(paramSolverVariable1, -1.0F);
    this.variables.put(paramSolverVariable2, paramFloat);
    return this;
  }
  
  public ArrayRow createRowDimensionRatio(SolverVariable paramSolverVariable1, SolverVariable paramSolverVariable2, SolverVariable paramSolverVariable3, SolverVariable paramSolverVariable4, float paramFloat) {
    this.variables.put(paramSolverVariable1, -1.0F);
    this.variables.put(paramSolverVariable2, 1.0F);
    this.variables.put(paramSolverVariable3, paramFloat);
    this.variables.put(paramSolverVariable4, -paramFloat);
    return this;
  }
  
  public ArrayRow createRowEqualDimension(float paramFloat1, float paramFloat2, float paramFloat3, SolverVariable paramSolverVariable1, int paramInt1, SolverVariable paramSolverVariable2, int paramInt2, SolverVariable paramSolverVariable3, int paramInt3, SolverVariable paramSolverVariable4, int paramInt4) {
    if (paramFloat2 == 0.0F || paramFloat1 == paramFloat3) {
      this.constantValue = (-paramInt1 - paramInt2 + paramInt3 + paramInt4);
      this.variables.put(paramSolverVariable1, 1.0F);
      this.variables.put(paramSolverVariable2, -1.0F);
      this.variables.put(paramSolverVariable4, 1.0F);
      this.variables.put(paramSolverVariable3, -1.0F);
      return this;
    } 
    paramFloat1 = paramFloat1 / paramFloat2 / paramFloat3 / paramFloat2;
    this.constantValue = (-paramInt1 - paramInt2) + paramInt3 * paramFloat1 + paramInt4 * paramFloat1;
    this.variables.put(paramSolverVariable1, 1.0F);
    this.variables.put(paramSolverVariable2, -1.0F);
    this.variables.put(paramSolverVariable4, paramFloat1);
    this.variables.put(paramSolverVariable3, -paramFloat1);
    return this;
  }
  
  public ArrayRow createRowEqualMatchDimensions(float paramFloat1, float paramFloat2, float paramFloat3, SolverVariable paramSolverVariable1, SolverVariable paramSolverVariable2, SolverVariable paramSolverVariable3, SolverVariable paramSolverVariable4) {
    this.constantValue = 0.0F;
    if (paramFloat2 == 0.0F || paramFloat1 == paramFloat3) {
      this.variables.put(paramSolverVariable1, 1.0F);
      this.variables.put(paramSolverVariable2, -1.0F);
      this.variables.put(paramSolverVariable4, 1.0F);
      this.variables.put(paramSolverVariable3, -1.0F);
      return this;
    } 
    if (paramFloat1 == 0.0F) {
      this.variables.put(paramSolverVariable1, 1.0F);
      this.variables.put(paramSolverVariable2, -1.0F);
      return this;
    } 
    if (paramFloat3 == 0.0F) {
      this.variables.put(paramSolverVariable3, 1.0F);
      this.variables.put(paramSolverVariable4, -1.0F);
      return this;
    } 
    paramFloat1 = paramFloat1 / paramFloat2 / paramFloat3 / paramFloat2;
    this.variables.put(paramSolverVariable1, 1.0F);
    this.variables.put(paramSolverVariable2, -1.0F);
    this.variables.put(paramSolverVariable4, paramFloat1);
    this.variables.put(paramSolverVariable3, -paramFloat1);
    return this;
  }
  
  public ArrayRow createRowEquals(SolverVariable paramSolverVariable, int paramInt) {
    if (paramInt < 0) {
      this.constantValue = (paramInt * -1);
      this.variables.put(paramSolverVariable, 1.0F);
      return this;
    } 
    this.constantValue = paramInt;
    this.variables.put(paramSolverVariable, -1.0F);
    return this;
  }
  
  public ArrayRow createRowEquals(SolverVariable paramSolverVariable1, SolverVariable paramSolverVariable2, int paramInt) {
    int i = 0;
    int j = 0;
    if (paramInt != 0) {
      i = j;
      j = paramInt;
      if (paramInt < 0) {
        j = paramInt * -1;
        i = 1;
      } 
      this.constantValue = j;
    } 
    if (i == 0) {
      this.variables.put(paramSolverVariable1, -1.0F);
      this.variables.put(paramSolverVariable2, 1.0F);
      return this;
    } 
    this.variables.put(paramSolverVariable1, 1.0F);
    this.variables.put(paramSolverVariable2, -1.0F);
    return this;
  }
  
  public ArrayRow createRowGreaterThan(SolverVariable paramSolverVariable1, int paramInt, SolverVariable paramSolverVariable2) {
    this.constantValue = paramInt;
    this.variables.put(paramSolverVariable1, -1.0F);
    return this;
  }
  
  public ArrayRow createRowGreaterThan(SolverVariable paramSolverVariable1, SolverVariable paramSolverVariable2, SolverVariable paramSolverVariable3, int paramInt) {
    int i = 0;
    int j = 0;
    if (paramInt != 0) {
      i = j;
      j = paramInt;
      if (paramInt < 0) {
        j = paramInt * -1;
        i = 1;
      } 
      this.constantValue = j;
    } 
    if (i == 0) {
      this.variables.put(paramSolverVariable1, -1.0F);
      this.variables.put(paramSolverVariable2, 1.0F);
      this.variables.put(paramSolverVariable3, 1.0F);
      return this;
    } 
    this.variables.put(paramSolverVariable1, 1.0F);
    this.variables.put(paramSolverVariable2, -1.0F);
    this.variables.put(paramSolverVariable3, -1.0F);
    return this;
  }
  
  public ArrayRow createRowLowerThan(SolverVariable paramSolverVariable1, SolverVariable paramSolverVariable2, SolverVariable paramSolverVariable3, int paramInt) {
    int i = 0;
    int j = 0;
    if (paramInt != 0) {
      i = j;
      j = paramInt;
      if (paramInt < 0) {
        j = paramInt * -1;
        i = 1;
      } 
      this.constantValue = j;
    } 
    if (i == 0) {
      this.variables.put(paramSolverVariable1, -1.0F);
      this.variables.put(paramSolverVariable2, 1.0F);
      this.variables.put(paramSolverVariable3, -1.0F);
      return this;
    } 
    this.variables.put(paramSolverVariable1, 1.0F);
    this.variables.put(paramSolverVariable2, -1.0F);
    this.variables.put(paramSolverVariable3, 1.0F);
    return this;
  }
  
  public ArrayRow createRowWithAngle(SolverVariable paramSolverVariable1, SolverVariable paramSolverVariable2, SolverVariable paramSolverVariable3, SolverVariable paramSolverVariable4, float paramFloat) {
    this.variables.put(paramSolverVariable3, 0.5F);
    this.variables.put(paramSolverVariable4, 0.5F);
    this.variables.put(paramSolverVariable1, -0.5F);
    this.variables.put(paramSolverVariable2, -0.5F);
    this.constantValue = -paramFloat;
    return this;
  }
  
  void ensurePositiveConstant() {
    float f = this.constantValue;
    if (f < 0.0F) {
      this.constantValue = f * -1.0F;
      this.variables.invert();
    } 
  }
  
  public SolverVariable getKey() {
    return this.variable;
  }
  
  public SolverVariable getPivotCandidate(LinearSystem paramLinearSystem, boolean[] paramArrayOfboolean) {
    return pickPivotInVariables(paramArrayOfboolean, null);
  }
  
  boolean hasKeyVariable() {
    SolverVariable solverVariable = this.variable;
    return (solverVariable != null && (solverVariable.mType == SolverVariable.Type.UNRESTRICTED || this.constantValue >= 0.0F));
  }
  
  boolean hasVariable(SolverVariable paramSolverVariable) {
    return this.variables.contains(paramSolverVariable);
  }
  
  public void initFromRow(LinearSystem.Row paramRow) {
    if (paramRow instanceof ArrayRow) {
      paramRow = paramRow;
      this.variable = null;
      this.variables.clear();
      for (int i = 0; i < ((ArrayRow)paramRow).variables.getCurrentSize(); i++) {
        SolverVariable solverVariable = ((ArrayRow)paramRow).variables.getVariable(i);
        float f = ((ArrayRow)paramRow).variables.getVariableValue(i);
        this.variables.add(solverVariable, f, true);
      } 
    } 
  }
  
  public boolean isEmpty() {
    return (this.variable == null && this.constantValue == 0.0F && this.variables.getCurrentSize() == 0);
  }
  
  public SolverVariable pickPivot(SolverVariable paramSolverVariable) {
    return pickPivotInVariables(null, paramSolverVariable);
  }
  
  void pivot(SolverVariable paramSolverVariable) {
    SolverVariable solverVariable = this.variable;
    if (solverVariable != null) {
      this.variables.put(solverVariable, -1.0F);
      this.variable.definitionId = -1;
      this.variable = null;
    } 
    float f = this.variables.remove(paramSolverVariable, true) * -1.0F;
    this.variable = paramSolverVariable;
    if (f == 1.0F)
      return; 
    this.constantValue /= f;
    this.variables.divideByAmount(f);
  }
  
  public void reset() {
    this.variable = null;
    this.variables.clear();
    this.constantValue = 0.0F;
    this.isSimpleDefinition = false;
  }
  
  int sizeInBytes() {
    byte b;
    if (this.variable != null) {
      b = 4;
    } else {
      b = 0;
    } 
    return b + 4 + 4 + this.variables.sizeInBytes();
  }
  
  String toReadableString() {
    // Byte code:
    //   0: aload_0
    //   1: getfield variable : Landroidx/constraintlayout/solver/SolverVariable;
    //   4: ifnonnull -> 42
    //   7: new java/lang/StringBuilder
    //   10: dup
    //   11: invokespecial <init> : ()V
    //   14: astore #7
    //   16: aload #7
    //   18: ldc ''
    //   20: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   23: pop
    //   24: aload #7
    //   26: ldc '0'
    //   28: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   31: pop
    //   32: aload #7
    //   34: invokevirtual toString : ()Ljava/lang/String;
    //   37: astore #7
    //   39: goto -> 76
    //   42: new java/lang/StringBuilder
    //   45: dup
    //   46: invokespecial <init> : ()V
    //   49: astore #7
    //   51: aload #7
    //   53: ldc ''
    //   55: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   58: pop
    //   59: aload #7
    //   61: aload_0
    //   62: getfield variable : Landroidx/constraintlayout/solver/SolverVariable;
    //   65: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   68: pop
    //   69: aload #7
    //   71: invokevirtual toString : ()Ljava/lang/String;
    //   74: astore #7
    //   76: new java/lang/StringBuilder
    //   79: dup
    //   80: invokespecial <init> : ()V
    //   83: astore #8
    //   85: aload #8
    //   87: aload #7
    //   89: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   92: pop
    //   93: aload #8
    //   95: ldc ' = '
    //   97: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   100: pop
    //   101: aload #8
    //   103: invokevirtual toString : ()Ljava/lang/String;
    //   106: astore #7
    //   108: aload_0
    //   109: getfield constantValue : F
    //   112: fstore_1
    //   113: iconst_0
    //   114: istore #4
    //   116: fload_1
    //   117: fconst_0
    //   118: fcmpl
    //   119: ifeq -> 161
    //   122: new java/lang/StringBuilder
    //   125: dup
    //   126: invokespecial <init> : ()V
    //   129: astore #8
    //   131: aload #8
    //   133: aload #7
    //   135: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   138: pop
    //   139: aload #8
    //   141: aload_0
    //   142: getfield constantValue : F
    //   145: invokevirtual append : (F)Ljava/lang/StringBuilder;
    //   148: pop
    //   149: aload #8
    //   151: invokevirtual toString : ()Ljava/lang/String;
    //   154: astore #7
    //   156: iconst_1
    //   157: istore_3
    //   158: goto -> 163
    //   161: iconst_0
    //   162: istore_3
    //   163: aload_0
    //   164: getfield variables : Landroidx/constraintlayout/solver/ArrayRow$ArrayRowVariables;
    //   167: invokeinterface getCurrentSize : ()I
    //   172: istore #5
    //   174: iload #4
    //   176: iload #5
    //   178: if_icmpge -> 463
    //   181: aload_0
    //   182: getfield variables : Landroidx/constraintlayout/solver/ArrayRow$ArrayRowVariables;
    //   185: iload #4
    //   187: invokeinterface getVariable : (I)Landroidx/constraintlayout/solver/SolverVariable;
    //   192: astore #8
    //   194: aload #8
    //   196: ifnonnull -> 202
    //   199: goto -> 454
    //   202: aload_0
    //   203: getfield variables : Landroidx/constraintlayout/solver/ArrayRow$ArrayRowVariables;
    //   206: iload #4
    //   208: invokeinterface getVariableValue : (I)F
    //   213: fstore_2
    //   214: fload_2
    //   215: fconst_0
    //   216: fcmpl
    //   217: istore #6
    //   219: iload #6
    //   221: ifne -> 227
    //   224: goto -> 454
    //   227: aload #8
    //   229: invokevirtual toString : ()Ljava/lang/String;
    //   232: astore #9
    //   234: iload_3
    //   235: ifne -> 285
    //   238: aload #7
    //   240: astore #8
    //   242: fload_2
    //   243: fstore_1
    //   244: fload_2
    //   245: fconst_0
    //   246: fcmpg
    //   247: ifge -> 364
    //   250: new java/lang/StringBuilder
    //   253: dup
    //   254: invokespecial <init> : ()V
    //   257: astore #8
    //   259: aload #8
    //   261: aload #7
    //   263: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   266: pop
    //   267: aload #8
    //   269: ldc '- '
    //   271: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   274: pop
    //   275: aload #8
    //   277: invokevirtual toString : ()Ljava/lang/String;
    //   280: astore #8
    //   282: goto -> 359
    //   285: iload #6
    //   287: ifle -> 327
    //   290: new java/lang/StringBuilder
    //   293: dup
    //   294: invokespecial <init> : ()V
    //   297: astore #8
    //   299: aload #8
    //   301: aload #7
    //   303: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   306: pop
    //   307: aload #8
    //   309: ldc ' + '
    //   311: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   314: pop
    //   315: aload #8
    //   317: invokevirtual toString : ()Ljava/lang/String;
    //   320: astore #8
    //   322: fload_2
    //   323: fstore_1
    //   324: goto -> 364
    //   327: new java/lang/StringBuilder
    //   330: dup
    //   331: invokespecial <init> : ()V
    //   334: astore #8
    //   336: aload #8
    //   338: aload #7
    //   340: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   343: pop
    //   344: aload #8
    //   346: ldc ' - '
    //   348: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   351: pop
    //   352: aload #8
    //   354: invokevirtual toString : ()Ljava/lang/String;
    //   357: astore #8
    //   359: fload_2
    //   360: ldc -1.0
    //   362: fmul
    //   363: fstore_1
    //   364: fload_1
    //   365: fconst_1
    //   366: fcmpl
    //   367: ifne -> 405
    //   370: new java/lang/StringBuilder
    //   373: dup
    //   374: invokespecial <init> : ()V
    //   377: astore #7
    //   379: aload #7
    //   381: aload #8
    //   383: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   386: pop
    //   387: aload #7
    //   389: aload #9
    //   391: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   394: pop
    //   395: aload #7
    //   397: invokevirtual toString : ()Ljava/lang/String;
    //   400: astore #7
    //   402: goto -> 452
    //   405: new java/lang/StringBuilder
    //   408: dup
    //   409: invokespecial <init> : ()V
    //   412: astore #7
    //   414: aload #7
    //   416: aload #8
    //   418: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   421: pop
    //   422: aload #7
    //   424: fload_1
    //   425: invokevirtual append : (F)Ljava/lang/StringBuilder;
    //   428: pop
    //   429: aload #7
    //   431: ldc ' '
    //   433: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   436: pop
    //   437: aload #7
    //   439: aload #9
    //   441: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   444: pop
    //   445: aload #7
    //   447: invokevirtual toString : ()Ljava/lang/String;
    //   450: astore #7
    //   452: iconst_1
    //   453: istore_3
    //   454: iload #4
    //   456: iconst_1
    //   457: iadd
    //   458: istore #4
    //   460: goto -> 174
    //   463: aload #7
    //   465: astore #8
    //   467: iload_3
    //   468: ifne -> 503
    //   471: new java/lang/StringBuilder
    //   474: dup
    //   475: invokespecial <init> : ()V
    //   478: astore #8
    //   480: aload #8
    //   482: aload #7
    //   484: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   487: pop
    //   488: aload #8
    //   490: ldc '0.0'
    //   492: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   495: pop
    //   496: aload #8
    //   498: invokevirtual toString : ()Ljava/lang/String;
    //   501: astore #8
    //   503: aload #8
    //   505: areturn
  }
  
  public String toString() {
    return toReadableString();
  }
  
  public void updateFromFinalVariable(LinearSystem paramLinearSystem, SolverVariable paramSolverVariable, boolean paramBoolean) {
    if (!paramSolverVariable.isFinalValue)
      return; 
    float f = this.variables.get(paramSolverVariable);
    this.constantValue += paramSolverVariable.computedValue * f;
    this.variables.remove(paramSolverVariable, paramBoolean);
    if (paramBoolean)
      paramSolverVariable.removeFromRow(this); 
    if (LinearSystem.SIMPLIFY_SYNONYMS && this.variables.getCurrentSize() == 0) {
      this.isSimpleDefinition = true;
      paramLinearSystem.hasSimpleDefinition = true;
    } 
  }
  
  public void updateFromRow(LinearSystem paramLinearSystem, ArrayRow paramArrayRow, boolean paramBoolean) {
    float f = this.variables.use(paramArrayRow, paramBoolean);
    this.constantValue += paramArrayRow.constantValue * f;
    if (paramBoolean)
      paramArrayRow.variable.removeFromRow(this); 
    if (LinearSystem.SIMPLIFY_SYNONYMS && this.variable != null && this.variables.getCurrentSize() == 0) {
      this.isSimpleDefinition = true;
      paramLinearSystem.hasSimpleDefinition = true;
    } 
  }
  
  public void updateFromSynonymVariable(LinearSystem paramLinearSystem, SolverVariable paramSolverVariable, boolean paramBoolean) {
    if (!paramSolverVariable.isSynonym)
      return; 
    float f = this.variables.get(paramSolverVariable);
    this.constantValue += paramSolverVariable.synonymDelta * f;
    this.variables.remove(paramSolverVariable, paramBoolean);
    if (paramBoolean)
      paramSolverVariable.removeFromRow(this); 
    this.variables.add(paramLinearSystem.mCache.mIndexedVariables[paramSolverVariable.synonym], f, paramBoolean);
    if (LinearSystem.SIMPLIFY_SYNONYMS && this.variables.getCurrentSize() == 0) {
      this.isSimpleDefinition = true;
      paramLinearSystem.hasSimpleDefinition = true;
    } 
  }
  
  public void updateFromSystem(LinearSystem paramLinearSystem) {
    if (paramLinearSystem.mRows.length == 0)
      return; 
    for (boolean bool = false; !bool; bool = true) {
      int j = this.variables.getCurrentSize();
      int i;
      for (i = 0; i < j; i++) {
        SolverVariable solverVariable = this.variables.getVariable(i);
        if (solverVariable.definitionId != -1 || solverVariable.isFinalValue || solverVariable.isSynonym)
          this.variablesToUpdate.add(solverVariable); 
      } 
      j = this.variablesToUpdate.size();
      if (j > 0) {
        for (i = 0; i < j; i++) {
          SolverVariable solverVariable = this.variablesToUpdate.get(i);
          if (solverVariable.isFinalValue) {
            updateFromFinalVariable(paramLinearSystem, solverVariable, true);
          } else if (solverVariable.isSynonym) {
            updateFromSynonymVariable(paramLinearSystem, solverVariable, true);
          } else {
            updateFromRow(paramLinearSystem, paramLinearSystem.mRows[solverVariable.definitionId], true);
          } 
        } 
        this.variablesToUpdate.clear();
        continue;
      } 
    } 
    if (LinearSystem.SIMPLIFY_SYNONYMS && this.variable != null && this.variables.getCurrentSize() == 0) {
      this.isSimpleDefinition = true;
      paramLinearSystem.hasSimpleDefinition = true;
    } 
  }
  
  public static interface ArrayRowVariables {
    void add(SolverVariable param1SolverVariable, float param1Float, boolean param1Boolean);
    
    void clear();
    
    boolean contains(SolverVariable param1SolverVariable);
    
    void display();
    
    void divideByAmount(float param1Float);
    
    float get(SolverVariable param1SolverVariable);
    
    int getCurrentSize();
    
    SolverVariable getVariable(int param1Int);
    
    float getVariableValue(int param1Int);
    
    int indexOf(SolverVariable param1SolverVariable);
    
    void invert();
    
    void put(SolverVariable param1SolverVariable, float param1Float);
    
    float remove(SolverVariable param1SolverVariable, boolean param1Boolean);
    
    int sizeInBytes();
    
    float use(ArrayRow param1ArrayRow, boolean param1Boolean);
  }
}


/* Location:              C:\soft\dex2jar-2.0\BabyBus TV_Kids Videos & Games-dex2jar.jar!\androidx\constraintlayout\solver\ArrayRow.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */