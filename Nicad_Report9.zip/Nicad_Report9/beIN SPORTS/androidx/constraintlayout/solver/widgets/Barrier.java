package androidx.constraintlayout.solver.widgets;

import androidx.constraintlayout.solver.LinearSystem;
import java.util.HashMap;

public class Barrier extends HelperWidget {
  public static final int BOTTOM = 3;
  
  public static final int LEFT = 0;
  
  public static final int RIGHT = 1;
  
  public static final int TOP = 2;
  
  private static final boolean USE_RELAX_GONE = false;
  
  private static final boolean USE_RESOLUTION = true;
  
  private boolean mAllowsGoneWidget = true;
  
  private int mBarrierType = 0;
  
  private int mMargin = 0;
  
  boolean resolved = false;
  
  public Barrier() {}
  
  public Barrier(String paramString) {
    setDebugName(paramString);
  }
  
  public void addToSolver(LinearSystem paramLinearSystem, boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   4: astore #7
    //   6: aload #7
    //   8: iconst_0
    //   9: aload_0
    //   10: getfield mLeft : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   13: aastore
    //   14: aload #7
    //   16: iconst_2
    //   17: aload_0
    //   18: getfield mTop : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   21: aastore
    //   22: aload #7
    //   24: iconst_1
    //   25: aload_0
    //   26: getfield mRight : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   29: aastore
    //   30: aload #7
    //   32: iconst_3
    //   33: aload_0
    //   34: getfield mBottom : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   37: aastore
    //   38: iconst_0
    //   39: istore_3
    //   40: aload_0
    //   41: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   44: astore #7
    //   46: iload_3
    //   47: aload #7
    //   49: arraylength
    //   50: if_icmpge -> 75
    //   53: aload #7
    //   55: iload_3
    //   56: aaload
    //   57: aload_1
    //   58: aload #7
    //   60: iload_3
    //   61: aaload
    //   62: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/solver/SolverVariable;
    //   65: putfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   68: iload_3
    //   69: iconst_1
    //   70: iadd
    //   71: istore_3
    //   72: goto -> 40
    //   75: aload_0
    //   76: getfield mBarrierType : I
    //   79: istore_3
    //   80: iload_3
    //   81: iflt -> 1006
    //   84: iload_3
    //   85: iconst_4
    //   86: if_icmpge -> 1006
    //   89: aload #7
    //   91: iload_3
    //   92: aaload
    //   93: astore #7
    //   95: aload_0
    //   96: getfield resolved : Z
    //   99: ifne -> 107
    //   102: aload_0
    //   103: invokevirtual allSolved : ()Z
    //   106: pop
    //   107: aload_0
    //   108: getfield resolved : Z
    //   111: ifeq -> 208
    //   114: aload_0
    //   115: iconst_0
    //   116: putfield resolved : Z
    //   119: aload_0
    //   120: getfield mBarrierType : I
    //   123: istore_3
    //   124: iload_3
    //   125: ifeq -> 177
    //   128: iload_3
    //   129: iconst_1
    //   130: if_icmpne -> 136
    //   133: goto -> 177
    //   136: iload_3
    //   137: iconst_2
    //   138: if_icmpeq -> 146
    //   141: iload_3
    //   142: iconst_3
    //   143: if_icmpne -> 207
    //   146: aload_1
    //   147: aload_0
    //   148: getfield mTop : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   151: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   154: aload_0
    //   155: getfield mY : I
    //   158: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;I)V
    //   161: aload_1
    //   162: aload_0
    //   163: getfield mBottom : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   166: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   169: aload_0
    //   170: getfield mY : I
    //   173: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;I)V
    //   176: return
    //   177: aload_1
    //   178: aload_0
    //   179: getfield mLeft : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   182: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   185: aload_0
    //   186: getfield mX : I
    //   189: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;I)V
    //   192: aload_1
    //   193: aload_0
    //   194: getfield mRight : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   197: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   200: aload_0
    //   201: getfield mX : I
    //   204: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;I)V
    //   207: return
    //   208: iconst_0
    //   209: istore_3
    //   210: iload_3
    //   211: aload_0
    //   212: getfield mWidgetsCount : I
    //   215: if_icmpge -> 360
    //   218: aload_0
    //   219: getfield mWidgets : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   222: iload_3
    //   223: aaload
    //   224: astore #8
    //   226: aload_0
    //   227: getfield mAllowsGoneWidget : Z
    //   230: ifne -> 244
    //   233: aload #8
    //   235: invokevirtual allowedInBarrier : ()Z
    //   238: ifne -> 244
    //   241: goto -> 353
    //   244: aload_0
    //   245: getfield mBarrierType : I
    //   248: istore #4
    //   250: iload #4
    //   252: ifeq -> 261
    //   255: iload #4
    //   257: iconst_1
    //   258: if_icmpne -> 299
    //   261: aload #8
    //   263: invokevirtual getHorizontalDimensionBehaviour : ()Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   266: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   269: if_acmpne -> 299
    //   272: aload #8
    //   274: getfield mLeft : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   277: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   280: ifnull -> 299
    //   283: aload #8
    //   285: getfield mRight : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   288: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   291: ifnull -> 299
    //   294: iconst_1
    //   295: istore_2
    //   296: goto -> 362
    //   299: aload_0
    //   300: getfield mBarrierType : I
    //   303: istore #4
    //   305: iload #4
    //   307: iconst_2
    //   308: if_icmpeq -> 317
    //   311: iload #4
    //   313: iconst_3
    //   314: if_icmpne -> 353
    //   317: aload #8
    //   319: invokevirtual getVerticalDimensionBehaviour : ()Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   322: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   325: if_acmpne -> 353
    //   328: aload #8
    //   330: getfield mTop : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   333: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   336: ifnull -> 353
    //   339: aload #8
    //   341: getfield mBottom : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   344: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   347: ifnull -> 353
    //   350: goto -> 294
    //   353: iload_3
    //   354: iconst_1
    //   355: iadd
    //   356: istore_3
    //   357: goto -> 210
    //   360: iconst_0
    //   361: istore_2
    //   362: aload_0
    //   363: getfield mLeft : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   366: invokevirtual hasCenteredDependents : ()Z
    //   369: ifne -> 390
    //   372: aload_0
    //   373: getfield mRight : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   376: invokevirtual hasCenteredDependents : ()Z
    //   379: ifeq -> 385
    //   382: goto -> 390
    //   385: iconst_0
    //   386: istore_3
    //   387: goto -> 392
    //   390: iconst_1
    //   391: istore_3
    //   392: aload_0
    //   393: getfield mTop : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   396: invokevirtual hasCenteredDependents : ()Z
    //   399: ifne -> 421
    //   402: aload_0
    //   403: getfield mBottom : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   406: invokevirtual hasCenteredDependents : ()Z
    //   409: ifeq -> 415
    //   412: goto -> 421
    //   415: iconst_0
    //   416: istore #4
    //   418: goto -> 424
    //   421: iconst_1
    //   422: istore #4
    //   424: iload_2
    //   425: ifne -> 481
    //   428: aload_0
    //   429: getfield mBarrierType : I
    //   432: istore #5
    //   434: iload #5
    //   436: ifne -> 443
    //   439: iload_3
    //   440: ifne -> 475
    //   443: iload #5
    //   445: iconst_2
    //   446: if_icmpne -> 454
    //   449: iload #4
    //   451: ifne -> 475
    //   454: iload #5
    //   456: iconst_1
    //   457: if_icmpne -> 464
    //   460: iload_3
    //   461: ifne -> 475
    //   464: iload #5
    //   466: iconst_3
    //   467: if_icmpne -> 481
    //   470: iload #4
    //   472: ifeq -> 481
    //   475: iconst_1
    //   476: istore #4
    //   478: goto -> 484
    //   481: iconst_0
    //   482: istore #4
    //   484: iconst_5
    //   485: istore_3
    //   486: iload #4
    //   488: ifne -> 493
    //   491: iconst_4
    //   492: istore_3
    //   493: iconst_0
    //   494: istore #4
    //   496: iload #4
    //   498: aload_0
    //   499: getfield mWidgetsCount : I
    //   502: if_icmpge -> 699
    //   505: aload_0
    //   506: getfield mWidgets : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   509: iload #4
    //   511: aaload
    //   512: astore #9
    //   514: aload_0
    //   515: getfield mAllowsGoneWidget : Z
    //   518: ifne -> 532
    //   521: aload #9
    //   523: invokevirtual allowedInBarrier : ()Z
    //   526: ifne -> 532
    //   529: goto -> 690
    //   532: aload_1
    //   533: aload #9
    //   535: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   538: aload_0
    //   539: getfield mBarrierType : I
    //   542: aaload
    //   543: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/solver/SolverVariable;
    //   546: astore #8
    //   548: aload #9
    //   550: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   553: astore #9
    //   555: aload_0
    //   556: getfield mBarrierType : I
    //   559: istore #6
    //   561: aload #9
    //   563: iload #6
    //   565: aaload
    //   566: aload #8
    //   568: putfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   571: aload #9
    //   573: iload #6
    //   575: aaload
    //   576: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   579: ifnull -> 612
    //   582: aload #9
    //   584: iload #6
    //   586: aaload
    //   587: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   590: getfield mOwner : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   593: aload_0
    //   594: if_acmpne -> 612
    //   597: aload #9
    //   599: iload #6
    //   601: aaload
    //   602: getfield mMargin : I
    //   605: iconst_0
    //   606: iadd
    //   607: istore #5
    //   609: goto -> 615
    //   612: iconst_0
    //   613: istore #5
    //   615: iload #6
    //   617: ifeq -> 651
    //   620: iload #6
    //   622: iconst_2
    //   623: if_icmpne -> 629
    //   626: goto -> 651
    //   629: aload_1
    //   630: aload #7
    //   632: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   635: aload #8
    //   637: aload_0
    //   638: getfield mMargin : I
    //   641: iload #5
    //   643: iadd
    //   644: iload_2
    //   645: invokevirtual addGreaterBarrier : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;IZ)V
    //   648: goto -> 670
    //   651: aload_1
    //   652: aload #7
    //   654: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   657: aload #8
    //   659: aload_0
    //   660: getfield mMargin : I
    //   663: iload #5
    //   665: isub
    //   666: iload_2
    //   667: invokevirtual addLowerBarrier : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;IZ)V
    //   670: aload_1
    //   671: aload #7
    //   673: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   676: aload #8
    //   678: aload_0
    //   679: getfield mMargin : I
    //   682: iload #5
    //   684: iadd
    //   685: iload_3
    //   686: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)Landroidx/constraintlayout/solver/ArrayRow;
    //   689: pop
    //   690: iload #4
    //   692: iconst_1
    //   693: iadd
    //   694: istore #4
    //   696: goto -> 496
    //   699: aload_0
    //   700: getfield mBarrierType : I
    //   703: istore_3
    //   704: iload_3
    //   705: ifne -> 779
    //   708: aload_1
    //   709: aload_0
    //   710: getfield mRight : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   713: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   716: aload_0
    //   717: getfield mLeft : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   720: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   723: iconst_0
    //   724: bipush #8
    //   726: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)Landroidx/constraintlayout/solver/ArrayRow;
    //   729: pop
    //   730: aload_1
    //   731: aload_0
    //   732: getfield mLeft : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   735: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   738: aload_0
    //   739: getfield mParent : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   742: getfield mRight : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   745: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   748: iconst_0
    //   749: iconst_4
    //   750: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)Landroidx/constraintlayout/solver/ArrayRow;
    //   753: pop
    //   754: aload_1
    //   755: aload_0
    //   756: getfield mLeft : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   759: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   762: aload_0
    //   763: getfield mParent : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   766: getfield mLeft : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   769: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   772: iconst_0
    //   773: iconst_0
    //   774: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)Landroidx/constraintlayout/solver/ArrayRow;
    //   777: pop
    //   778: return
    //   779: iload_3
    //   780: iconst_1
    //   781: if_icmpne -> 855
    //   784: aload_1
    //   785: aload_0
    //   786: getfield mLeft : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   789: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   792: aload_0
    //   793: getfield mRight : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   796: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   799: iconst_0
    //   800: bipush #8
    //   802: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)Landroidx/constraintlayout/solver/ArrayRow;
    //   805: pop
    //   806: aload_1
    //   807: aload_0
    //   808: getfield mLeft : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   811: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   814: aload_0
    //   815: getfield mParent : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   818: getfield mLeft : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   821: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   824: iconst_0
    //   825: iconst_4
    //   826: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)Landroidx/constraintlayout/solver/ArrayRow;
    //   829: pop
    //   830: aload_1
    //   831: aload_0
    //   832: getfield mLeft : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   835: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   838: aload_0
    //   839: getfield mParent : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   842: getfield mRight : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   845: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   848: iconst_0
    //   849: iconst_0
    //   850: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)Landroidx/constraintlayout/solver/ArrayRow;
    //   853: pop
    //   854: return
    //   855: iload_3
    //   856: iconst_2
    //   857: if_icmpne -> 931
    //   860: aload_1
    //   861: aload_0
    //   862: getfield mBottom : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   865: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   868: aload_0
    //   869: getfield mTop : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   872: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   875: iconst_0
    //   876: bipush #8
    //   878: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)Landroidx/constraintlayout/solver/ArrayRow;
    //   881: pop
    //   882: aload_1
    //   883: aload_0
    //   884: getfield mTop : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   887: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   890: aload_0
    //   891: getfield mParent : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   894: getfield mBottom : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   897: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   900: iconst_0
    //   901: iconst_4
    //   902: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)Landroidx/constraintlayout/solver/ArrayRow;
    //   905: pop
    //   906: aload_1
    //   907: aload_0
    //   908: getfield mTop : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   911: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   914: aload_0
    //   915: getfield mParent : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   918: getfield mTop : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   921: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   924: iconst_0
    //   925: iconst_0
    //   926: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)Landroidx/constraintlayout/solver/ArrayRow;
    //   929: pop
    //   930: return
    //   931: iload_3
    //   932: iconst_3
    //   933: if_icmpne -> 1006
    //   936: aload_1
    //   937: aload_0
    //   938: getfield mTop : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   941: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   944: aload_0
    //   945: getfield mBottom : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   948: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   951: iconst_0
    //   952: bipush #8
    //   954: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)Landroidx/constraintlayout/solver/ArrayRow;
    //   957: pop
    //   958: aload_1
    //   959: aload_0
    //   960: getfield mTop : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   963: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   966: aload_0
    //   967: getfield mParent : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   970: getfield mTop : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   973: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   976: iconst_0
    //   977: iconst_4
    //   978: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)Landroidx/constraintlayout/solver/ArrayRow;
    //   981: pop
    //   982: aload_1
    //   983: aload_0
    //   984: getfield mTop : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   987: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   990: aload_0
    //   991: getfield mParent : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   994: getfield mBottom : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   997: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   1000: iconst_0
    //   1001: iconst_0
    //   1002: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)Landroidx/constraintlayout/solver/ArrayRow;
    //   1005: pop
    //   1006: return
  }
  
  public boolean allSolved() {
    // Byte code:
    //   0: iconst_0
    //   1: istore #5
    //   3: iconst_0
    //   4: istore_1
    //   5: iconst_1
    //   6: istore_2
    //   7: aload_0
    //   8: getfield mWidgetsCount : I
    //   11: istore_3
    //   12: iload_1
    //   13: iload_3
    //   14: if_icmpge -> 114
    //   17: aload_0
    //   18: getfield mWidgets : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   21: iload_1
    //   22: aaload
    //   23: astore #7
    //   25: aload_0
    //   26: getfield mAllowsGoneWidget : Z
    //   29: ifne -> 45
    //   32: aload #7
    //   34: invokevirtual allowedInBarrier : ()Z
    //   37: ifne -> 45
    //   40: iload_2
    //   41: istore_3
    //   42: goto -> 105
    //   45: aload_0
    //   46: getfield mBarrierType : I
    //   49: istore_3
    //   50: iload_3
    //   51: ifeq -> 59
    //   54: iload_3
    //   55: iconst_1
    //   56: if_icmpne -> 72
    //   59: aload #7
    //   61: invokevirtual isResolvedHorizontally : ()Z
    //   64: ifne -> 72
    //   67: iconst_0
    //   68: istore_3
    //   69: goto -> 105
    //   72: aload_0
    //   73: getfield mBarrierType : I
    //   76: istore #4
    //   78: iload #4
    //   80: iconst_2
    //   81: if_icmpeq -> 92
    //   84: iload_2
    //   85: istore_3
    //   86: iload #4
    //   88: iconst_3
    //   89: if_icmpne -> 105
    //   92: iload_2
    //   93: istore_3
    //   94: aload #7
    //   96: invokevirtual isResolvedVertically : ()Z
    //   99: ifne -> 105
    //   102: goto -> 67
    //   105: iload_1
    //   106: iconst_1
    //   107: iadd
    //   108: istore_1
    //   109: iload_3
    //   110: istore_2
    //   111: goto -> 7
    //   114: iload_2
    //   115: ifeq -> 431
    //   118: iload_3
    //   119: ifle -> 431
    //   122: iconst_0
    //   123: istore_1
    //   124: iconst_0
    //   125: istore_3
    //   126: iload #5
    //   128: aload_0
    //   129: getfield mWidgetsCount : I
    //   132: if_icmpge -> 385
    //   135: aload_0
    //   136: getfield mWidgets : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   139: iload #5
    //   141: aaload
    //   142: astore #7
    //   144: aload_0
    //   145: getfield mAllowsGoneWidget : Z
    //   148: ifne -> 162
    //   151: aload #7
    //   153: invokevirtual allowedInBarrier : ()Z
    //   156: ifne -> 162
    //   159: goto -> 376
    //   162: iload_1
    //   163: istore #4
    //   165: iload_3
    //   166: istore_2
    //   167: iload_3
    //   168: ifne -> 257
    //   171: aload_0
    //   172: getfield mBarrierType : I
    //   175: istore_2
    //   176: iload_2
    //   177: ifne -> 195
    //   180: aload #7
    //   182: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.LEFT : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   185: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   188: invokevirtual getFinalValue : ()I
    //   191: istore_1
    //   192: goto -> 252
    //   195: iload_2
    //   196: iconst_1
    //   197: if_icmpne -> 215
    //   200: aload #7
    //   202: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.RIGHT : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   205: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   208: invokevirtual getFinalValue : ()I
    //   211: istore_1
    //   212: goto -> 252
    //   215: iload_2
    //   216: iconst_2
    //   217: if_icmpne -> 235
    //   220: aload #7
    //   222: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.TOP : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   225: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   228: invokevirtual getFinalValue : ()I
    //   231: istore_1
    //   232: goto -> 252
    //   235: iload_2
    //   236: iconst_3
    //   237: if_icmpne -> 252
    //   240: aload #7
    //   242: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.BOTTOM : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   245: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   248: invokevirtual getFinalValue : ()I
    //   251: istore_1
    //   252: iconst_1
    //   253: istore_2
    //   254: iload_1
    //   255: istore #4
    //   257: aload_0
    //   258: getfield mBarrierType : I
    //   261: istore #6
    //   263: iload #6
    //   265: ifne -> 290
    //   268: iload #4
    //   270: aload #7
    //   272: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.LEFT : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   275: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   278: invokevirtual getFinalValue : ()I
    //   281: invokestatic min : (II)I
    //   284: istore_1
    //   285: iload_2
    //   286: istore_3
    //   287: goto -> 376
    //   290: iload #6
    //   292: iconst_1
    //   293: if_icmpne -> 318
    //   296: iload #4
    //   298: aload #7
    //   300: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.RIGHT : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   303: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   306: invokevirtual getFinalValue : ()I
    //   309: invokestatic max : (II)I
    //   312: istore_1
    //   313: iload_2
    //   314: istore_3
    //   315: goto -> 376
    //   318: iload #6
    //   320: iconst_2
    //   321: if_icmpne -> 346
    //   324: iload #4
    //   326: aload #7
    //   328: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.TOP : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   331: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   334: invokevirtual getFinalValue : ()I
    //   337: invokestatic min : (II)I
    //   340: istore_1
    //   341: iload_2
    //   342: istore_3
    //   343: goto -> 376
    //   346: iload #4
    //   348: istore_1
    //   349: iload_2
    //   350: istore_3
    //   351: iload #6
    //   353: iconst_3
    //   354: if_icmpne -> 376
    //   357: iload #4
    //   359: aload #7
    //   361: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.BOTTOM : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   364: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   367: invokevirtual getFinalValue : ()I
    //   370: invokestatic max : (II)I
    //   373: istore_1
    //   374: iload_2
    //   375: istore_3
    //   376: iload #5
    //   378: iconst_1
    //   379: iadd
    //   380: istore #5
    //   382: goto -> 126
    //   385: iload_1
    //   386: aload_0
    //   387: getfield mMargin : I
    //   390: iadd
    //   391: istore_1
    //   392: aload_0
    //   393: getfield mBarrierType : I
    //   396: istore_2
    //   397: iload_2
    //   398: ifeq -> 418
    //   401: iload_2
    //   402: iconst_1
    //   403: if_icmpne -> 409
    //   406: goto -> 418
    //   409: aload_0
    //   410: iload_1
    //   411: iload_1
    //   412: invokevirtual setFinalVertical : (II)V
    //   415: goto -> 424
    //   418: aload_0
    //   419: iload_1
    //   420: iload_1
    //   421: invokevirtual setFinalHorizontal : (II)V
    //   424: aload_0
    //   425: iconst_1
    //   426: putfield resolved : Z
    //   429: iconst_1
    //   430: ireturn
    //   431: iconst_0
    //   432: ireturn
  }
  
  public boolean allowedInBarrier() {
    return true;
  }
  
  public boolean allowsGoneWidget() {
    return this.mAllowsGoneWidget;
  }
  
  public void copy(ConstraintWidget paramConstraintWidget, HashMap<ConstraintWidget, ConstraintWidget> paramHashMap) {
    super.copy(paramConstraintWidget, paramHashMap);
    paramConstraintWidget = paramConstraintWidget;
    this.mBarrierType = ((Barrier)paramConstraintWidget).mBarrierType;
    this.mAllowsGoneWidget = ((Barrier)paramConstraintWidget).mAllowsGoneWidget;
    this.mMargin = ((Barrier)paramConstraintWidget).mMargin;
  }
  
  public int getBarrierType() {
    return this.mBarrierType;
  }
  
  public int getMargin() {
    return this.mMargin;
  }
  
  public int getOrientation() {
    int i = this.mBarrierType;
    return (i != 0 && i != 1) ? ((i != 2 && i != 3) ? -1 : 1) : 0;
  }
  
  public boolean isResolvedHorizontally() {
    return this.resolved;
  }
  
  public boolean isResolvedVertically() {
    return this.resolved;
  }
  
  protected void markWidgets() {
    for (int i = 0; i < this.mWidgetsCount; i++) {
      ConstraintWidget constraintWidget = this.mWidgets[i];
      int j = this.mBarrierType;
      if (j == 0 || j == 1) {
        constraintWidget.setInBarrier(0, true);
      } else if (j == 2 || j == 3) {
        constraintWidget.setInBarrier(1, true);
      } 
    } 
  }
  
  public void setAllowsGoneWidget(boolean paramBoolean) {
    this.mAllowsGoneWidget = paramBoolean;
  }
  
  public void setBarrierType(int paramInt) {
    this.mBarrierType = paramInt;
  }
  
  public void setMargin(int paramInt) {
    this.mMargin = paramInt;
  }
  
  public String toString() {
    StringBuilder stringBuilder1 = new StringBuilder();
    stringBuilder1.append("[Barrier] ");
    stringBuilder1.append(getDebugName());
    stringBuilder1.append(" {");
    String str = stringBuilder1.toString();
    for (int i = 0; i < this.mWidgetsCount; i++) {
      ConstraintWidget constraintWidget = this.mWidgets[i];
      String str1 = str;
      if (i > 0) {
        StringBuilder stringBuilder3 = new StringBuilder();
        stringBuilder3.append(str);
        stringBuilder3.append(", ");
        str1 = stringBuilder3.toString();
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(str1);
      stringBuilder.append(constraintWidget.getDebugName());
      str = stringBuilder.toString();
    } 
    StringBuilder stringBuilder2 = new StringBuilder();
    stringBuilder2.append(str);
    stringBuilder2.append("}");
    return stringBuilder2.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\BabyBus TV_Kids Videos & Games-dex2jar.jar!\androidx\constraintlayout\solver\widgets\Barrier.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */