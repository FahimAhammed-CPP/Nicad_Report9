package androidx.constraintlayout.solver.widgets.analyzer;

import androidx.constraintlayout.solver.widgets.ConstraintAnchor;
import androidx.constraintlayout.solver.widgets.ConstraintWidget;
import androidx.constraintlayout.solver.widgets.ConstraintWidgetContainer;
import androidx.constraintlayout.solver.widgets.Guideline;
import androidx.constraintlayout.solver.widgets.HelperWidget;
import java.util.ArrayList;

public class Grouping {
  private static final boolean DEBUG = false;
  
  private static final boolean DEBUG_GROUPING = false;
  
  public static WidgetGroup findDependents(ConstraintWidget paramConstraintWidget, int paramInt, ArrayList<WidgetGroup> paramArrayList, WidgetGroup paramWidgetGroup) {
    int i;
    WidgetGroup widgetGroup;
    if (paramInt == 0) {
      i = paramConstraintWidget.horizontalGroup;
    } else {
      i = paramConstraintWidget.verticalGroup;
    } 
    boolean bool = false;
    if (i != -1 && (paramWidgetGroup == null || i != paramWidgetGroup.id)) {
      int j = 0;
      while (true) {
        widgetGroup = paramWidgetGroup;
        if (j < paramArrayList.size()) {
          widgetGroup = paramArrayList.get(j);
          if (widgetGroup.getId() == i) {
            if (paramWidgetGroup != null) {
              paramWidgetGroup.moveTo(paramInt, widgetGroup);
              paramArrayList.remove(paramWidgetGroup);
            } 
            break;
          } 
          j++;
          continue;
        } 
        break;
      } 
    } else {
      widgetGroup = paramWidgetGroup;
      if (i != -1)
        return paramWidgetGroup; 
    } 
    paramWidgetGroup = widgetGroup;
    if (widgetGroup == null) {
      paramWidgetGroup = widgetGroup;
      if (paramConstraintWidget instanceof HelperWidget) {
        int j = ((HelperWidget)paramConstraintWidget).findGroupInDependents(paramInt);
        paramWidgetGroup = widgetGroup;
        if (j != -1) {
          i = 0;
          while (true) {
            paramWidgetGroup = widgetGroup;
            if (i < paramArrayList.size()) {
              paramWidgetGroup = paramArrayList.get(i);
              if (paramWidgetGroup.getId() == j)
                break; 
              i++;
              continue;
            } 
            break;
          } 
        } 
      } 
      widgetGroup = paramWidgetGroup;
      if (paramWidgetGroup == null)
        widgetGroup = new WidgetGroup(paramInt); 
      paramArrayList.add(widgetGroup);
      paramWidgetGroup = widgetGroup;
    } 
    if (paramWidgetGroup.add(paramConstraintWidget)) {
      if (paramConstraintWidget instanceof Guideline) {
        Guideline guideline = (Guideline)paramConstraintWidget;
        ConstraintAnchor constraintAnchor = guideline.getAnchor();
        i = bool;
        if (guideline.getOrientation() == 0)
          i = 1; 
        constraintAnchor.findDependents(i, paramArrayList, paramWidgetGroup);
      } 
      if (paramInt == 0) {
        paramConstraintWidget.horizontalGroup = paramWidgetGroup.getId();
        paramConstraintWidget.mLeft.findDependents(paramInt, paramArrayList, paramWidgetGroup);
        paramConstraintWidget.mRight.findDependents(paramInt, paramArrayList, paramWidgetGroup);
      } else {
        paramConstraintWidget.verticalGroup = paramWidgetGroup.getId();
        paramConstraintWidget.mTop.findDependents(paramInt, paramArrayList, paramWidgetGroup);
        paramConstraintWidget.mBaseline.findDependents(paramInt, paramArrayList, paramWidgetGroup);
        paramConstraintWidget.mBottom.findDependents(paramInt, paramArrayList, paramWidgetGroup);
      } 
      paramConstraintWidget.mCenter.findDependents(paramInt, paramArrayList, paramWidgetGroup);
    } 
    return paramWidgetGroup;
  }
  
  private static WidgetGroup findGroup(ArrayList<WidgetGroup> paramArrayList, int paramInt) {
    int j = paramArrayList.size();
    for (int i = 0; i < j; i++) {
      WidgetGroup widgetGroup = paramArrayList.get(i);
      if (paramInt == widgetGroup.id)
        return widgetGroup; 
    } 
    return null;
  }
  
  public static boolean simpleSolvingPass(ConstraintWidgetContainer paramConstraintWidgetContainer, BasicMeasure.Measurer paramMeasurer) {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual getChildren : ()Ljava/util/ArrayList;
    //   4: astore #16
    //   6: aload #16
    //   8: invokevirtual size : ()I
    //   11: istore_3
    //   12: iconst_0
    //   13: istore_2
    //   14: iload_2
    //   15: iload_3
    //   16: if_icmpge -> 73
    //   19: aload #16
    //   21: iload_2
    //   22: invokevirtual get : (I)Ljava/lang/Object;
    //   25: checkcast androidx/constraintlayout/solver/widgets/ConstraintWidget
    //   28: astore #5
    //   30: aload_0
    //   31: invokevirtual getHorizontalDimensionBehaviour : ()Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   34: aload_0
    //   35: invokevirtual getVerticalDimensionBehaviour : ()Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   38: aload #5
    //   40: invokevirtual getHorizontalDimensionBehaviour : ()Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   43: aload #5
    //   45: invokevirtual getVerticalDimensionBehaviour : ()Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   48: invokestatic validInGroup : (Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;)Z
    //   51: ifne -> 56
    //   54: iconst_0
    //   55: ireturn
    //   56: aload #5
    //   58: instanceof androidx/constraintlayout/solver/widgets/Flow
    //   61: ifeq -> 66
    //   64: iconst_0
    //   65: ireturn
    //   66: iload_2
    //   67: iconst_1
    //   68: iadd
    //   69: istore_2
    //   70: goto -> 14
    //   73: aload_0
    //   74: getfield mMetrics : Landroidx/constraintlayout/solver/Metrics;
    //   77: astore #5
    //   79: aload #5
    //   81: ifnull -> 96
    //   84: aload #5
    //   86: aload #5
    //   88: getfield grouping : J
    //   91: lconst_1
    //   92: ladd
    //   93: putfield grouping : J
    //   96: iconst_0
    //   97: istore_2
    //   98: aconst_null
    //   99: astore #11
    //   101: aconst_null
    //   102: astore #5
    //   104: aconst_null
    //   105: astore #7
    //   107: aconst_null
    //   108: astore #6
    //   110: aconst_null
    //   111: astore #9
    //   113: aconst_null
    //   114: astore #8
    //   116: iload_2
    //   117: iload_3
    //   118: if_icmpge -> 675
    //   121: aload #16
    //   123: iload_2
    //   124: invokevirtual get : (I)Ljava/lang/Object;
    //   127: checkcast androidx/constraintlayout/solver/widgets/ConstraintWidget
    //   130: astore #17
    //   132: aload_0
    //   133: invokevirtual getHorizontalDimensionBehaviour : ()Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   136: aload_0
    //   137: invokevirtual getVerticalDimensionBehaviour : ()Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   140: aload #17
    //   142: invokevirtual getHorizontalDimensionBehaviour : ()Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   145: aload #17
    //   147: invokevirtual getVerticalDimensionBehaviour : ()Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   150: invokestatic validInGroup : (Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;)Z
    //   153: ifne -> 173
    //   156: aload #17
    //   158: aload_1
    //   159: aload_0
    //   160: getfield mMeasure : Landroidx/constraintlayout/solver/widgets/analyzer/BasicMeasure$Measure;
    //   163: getstatic androidx/constraintlayout/solver/widgets/analyzer/BasicMeasure$Measure.SELF_DIMENSIONS : I
    //   166: invokestatic measure : (Landroidx/constraintlayout/solver/widgets/ConstraintWidget;Landroidx/constraintlayout/solver/widgets/analyzer/BasicMeasure$Measurer;Landroidx/constraintlayout/solver/widgets/analyzer/BasicMeasure$Measure;I)Z
    //   169: pop
    //   170: goto -> 173
    //   173: aload #17
    //   175: instanceof androidx/constraintlayout/solver/widgets/Guideline
    //   178: istore #4
    //   180: aload #11
    //   182: astore #13
    //   184: aload #7
    //   186: astore #12
    //   188: iload #4
    //   190: ifeq -> 289
    //   193: aload #17
    //   195: checkcast androidx/constraintlayout/solver/widgets/Guideline
    //   198: astore #14
    //   200: aload #7
    //   202: astore #10
    //   204: aload #14
    //   206: invokevirtual getOrientation : ()I
    //   209: ifne -> 238
    //   212: aload #7
    //   214: astore #10
    //   216: aload #7
    //   218: ifnonnull -> 230
    //   221: new java/util/ArrayList
    //   224: dup
    //   225: invokespecial <init> : ()V
    //   228: astore #10
    //   230: aload #10
    //   232: aload #14
    //   234: invokevirtual add : (Ljava/lang/Object;)Z
    //   237: pop
    //   238: aload #11
    //   240: astore #13
    //   242: aload #10
    //   244: astore #12
    //   246: aload #14
    //   248: invokevirtual getOrientation : ()I
    //   251: iconst_1
    //   252: if_icmpne -> 289
    //   255: aload #11
    //   257: astore #7
    //   259: aload #11
    //   261: ifnonnull -> 273
    //   264: new java/util/ArrayList
    //   267: dup
    //   268: invokespecial <init> : ()V
    //   271: astore #7
    //   273: aload #7
    //   275: aload #14
    //   277: invokevirtual add : (Ljava/lang/Object;)Z
    //   280: pop
    //   281: aload #10
    //   283: astore #12
    //   285: aload #7
    //   287: astore #13
    //   289: aload #5
    //   291: astore #7
    //   293: aload #6
    //   295: astore #10
    //   297: aload #17
    //   299: instanceof androidx/constraintlayout/solver/widgets/HelperWidget
    //   302: ifeq -> 467
    //   305: aload #17
    //   307: instanceof androidx/constraintlayout/solver/widgets/Barrier
    //   310: ifeq -> 408
    //   313: aload #17
    //   315: checkcast androidx/constraintlayout/solver/widgets/Barrier
    //   318: astore #14
    //   320: aload #5
    //   322: astore #11
    //   324: aload #14
    //   326: invokevirtual getOrientation : ()I
    //   329: ifne -> 358
    //   332: aload #5
    //   334: astore #11
    //   336: aload #5
    //   338: ifnonnull -> 350
    //   341: new java/util/ArrayList
    //   344: dup
    //   345: invokespecial <init> : ()V
    //   348: astore #11
    //   350: aload #11
    //   352: aload #14
    //   354: invokevirtual add : (Ljava/lang/Object;)Z
    //   357: pop
    //   358: aload #11
    //   360: astore #7
    //   362: aload #6
    //   364: astore #10
    //   366: aload #14
    //   368: invokevirtual getOrientation : ()I
    //   371: iconst_1
    //   372: if_icmpne -> 467
    //   375: aload #6
    //   377: astore #10
    //   379: aload #6
    //   381: ifnonnull -> 393
    //   384: new java/util/ArrayList
    //   387: dup
    //   388: invokespecial <init> : ()V
    //   391: astore #10
    //   393: aload #10
    //   395: aload #14
    //   397: invokevirtual add : (Ljava/lang/Object;)Z
    //   400: pop
    //   401: aload #11
    //   403: astore #7
    //   405: goto -> 467
    //   408: aload #17
    //   410: checkcast androidx/constraintlayout/solver/widgets/HelperWidget
    //   413: astore #11
    //   415: aload #5
    //   417: astore #7
    //   419: aload #5
    //   421: ifnonnull -> 433
    //   424: new java/util/ArrayList
    //   427: dup
    //   428: invokespecial <init> : ()V
    //   431: astore #7
    //   433: aload #7
    //   435: aload #11
    //   437: invokevirtual add : (Ljava/lang/Object;)Z
    //   440: pop
    //   441: aload #6
    //   443: astore #10
    //   445: aload #6
    //   447: ifnonnull -> 459
    //   450: new java/util/ArrayList
    //   453: dup
    //   454: invokespecial <init> : ()V
    //   457: astore #10
    //   459: aload #10
    //   461: aload #11
    //   463: invokevirtual add : (Ljava/lang/Object;)Z
    //   466: pop
    //   467: aload #9
    //   469: astore #14
    //   471: aload #17
    //   473: getfield mLeft : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   476: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   479: ifnonnull -> 548
    //   482: aload #9
    //   484: astore #14
    //   486: aload #17
    //   488: getfield mRight : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   491: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   494: ifnonnull -> 548
    //   497: aload #9
    //   499: astore #14
    //   501: iload #4
    //   503: ifne -> 548
    //   506: aload #9
    //   508: astore #14
    //   510: aload #17
    //   512: instanceof androidx/constraintlayout/solver/widgets/Barrier
    //   515: ifne -> 548
    //   518: aload #9
    //   520: astore #5
    //   522: aload #9
    //   524: ifnonnull -> 536
    //   527: new java/util/ArrayList
    //   530: dup
    //   531: invokespecial <init> : ()V
    //   534: astore #5
    //   536: aload #5
    //   538: aload #17
    //   540: invokevirtual add : (Ljava/lang/Object;)Z
    //   543: pop
    //   544: aload #5
    //   546: astore #14
    //   548: aload #8
    //   550: astore #15
    //   552: aload #17
    //   554: getfield mTop : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   557: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   560: ifnonnull -> 644
    //   563: aload #8
    //   565: astore #15
    //   567: aload #17
    //   569: getfield mBottom : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   572: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   575: ifnonnull -> 644
    //   578: aload #8
    //   580: astore #15
    //   582: aload #17
    //   584: getfield mBaseline : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   587: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   590: ifnonnull -> 644
    //   593: aload #8
    //   595: astore #15
    //   597: iload #4
    //   599: ifne -> 644
    //   602: aload #8
    //   604: astore #15
    //   606: aload #17
    //   608: instanceof androidx/constraintlayout/solver/widgets/Barrier
    //   611: ifne -> 644
    //   614: aload #8
    //   616: astore #5
    //   618: aload #8
    //   620: ifnonnull -> 632
    //   623: new java/util/ArrayList
    //   626: dup
    //   627: invokespecial <init> : ()V
    //   630: astore #5
    //   632: aload #5
    //   634: aload #17
    //   636: invokevirtual add : (Ljava/lang/Object;)Z
    //   639: pop
    //   640: aload #5
    //   642: astore #15
    //   644: iload_2
    //   645: iconst_1
    //   646: iadd
    //   647: istore_2
    //   648: aload #13
    //   650: astore #11
    //   652: aload #7
    //   654: astore #5
    //   656: aload #12
    //   658: astore #7
    //   660: aload #10
    //   662: astore #6
    //   664: aload #14
    //   666: astore #9
    //   668: aload #15
    //   670: astore #8
    //   672: goto -> 116
    //   675: new java/util/ArrayList
    //   678: dup
    //   679: invokespecial <init> : ()V
    //   682: astore #10
    //   684: aload #11
    //   686: ifnull -> 724
    //   689: aload #11
    //   691: invokevirtual iterator : ()Ljava/util/Iterator;
    //   694: astore_1
    //   695: aload_1
    //   696: invokeinterface hasNext : ()Z
    //   701: ifeq -> 724
    //   704: aload_1
    //   705: invokeinterface next : ()Ljava/lang/Object;
    //   710: checkcast androidx/constraintlayout/solver/widgets/Guideline
    //   713: iconst_0
    //   714: aload #10
    //   716: aconst_null
    //   717: invokestatic findDependents : (Landroidx/constraintlayout/solver/widgets/ConstraintWidget;ILjava/util/ArrayList;Landroidx/constraintlayout/solver/widgets/analyzer/WidgetGroup;)Landroidx/constraintlayout/solver/widgets/analyzer/WidgetGroup;
    //   720: pop
    //   721: goto -> 695
    //   724: aload #5
    //   726: ifnull -> 786
    //   729: aload #5
    //   731: invokevirtual iterator : ()Ljava/util/Iterator;
    //   734: astore_1
    //   735: aload_1
    //   736: invokeinterface hasNext : ()Z
    //   741: ifeq -> 786
    //   744: aload_1
    //   745: invokeinterface next : ()Ljava/lang/Object;
    //   750: checkcast androidx/constraintlayout/solver/widgets/HelperWidget
    //   753: astore #5
    //   755: aload #5
    //   757: iconst_0
    //   758: aload #10
    //   760: aconst_null
    //   761: invokestatic findDependents : (Landroidx/constraintlayout/solver/widgets/ConstraintWidget;ILjava/util/ArrayList;Landroidx/constraintlayout/solver/widgets/analyzer/WidgetGroup;)Landroidx/constraintlayout/solver/widgets/analyzer/WidgetGroup;
    //   764: astore #11
    //   766: aload #5
    //   768: aload #10
    //   770: iconst_0
    //   771: aload #11
    //   773: invokevirtual addDependents : (Ljava/util/ArrayList;ILandroidx/constraintlayout/solver/widgets/analyzer/WidgetGroup;)V
    //   776: aload #11
    //   778: aload #10
    //   780: invokevirtual cleanup : (Ljava/util/ArrayList;)V
    //   783: goto -> 735
    //   786: aload_0
    //   787: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.LEFT : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   790: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   793: astore_1
    //   794: aload_1
    //   795: invokevirtual getDependents : ()Ljava/util/HashSet;
    //   798: ifnull -> 841
    //   801: aload_1
    //   802: invokevirtual getDependents : ()Ljava/util/HashSet;
    //   805: invokevirtual iterator : ()Ljava/util/Iterator;
    //   808: astore_1
    //   809: aload_1
    //   810: invokeinterface hasNext : ()Z
    //   815: ifeq -> 841
    //   818: aload_1
    //   819: invokeinterface next : ()Ljava/lang/Object;
    //   824: checkcast androidx/constraintlayout/solver/widgets/ConstraintAnchor
    //   827: getfield mOwner : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   830: iconst_0
    //   831: aload #10
    //   833: aconst_null
    //   834: invokestatic findDependents : (Landroidx/constraintlayout/solver/widgets/ConstraintWidget;ILjava/util/ArrayList;Landroidx/constraintlayout/solver/widgets/analyzer/WidgetGroup;)Landroidx/constraintlayout/solver/widgets/analyzer/WidgetGroup;
    //   837: pop
    //   838: goto -> 809
    //   841: aload_0
    //   842: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.RIGHT : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   845: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   848: astore_1
    //   849: aload_1
    //   850: invokevirtual getDependents : ()Ljava/util/HashSet;
    //   853: ifnull -> 896
    //   856: aload_1
    //   857: invokevirtual getDependents : ()Ljava/util/HashSet;
    //   860: invokevirtual iterator : ()Ljava/util/Iterator;
    //   863: astore_1
    //   864: aload_1
    //   865: invokeinterface hasNext : ()Z
    //   870: ifeq -> 896
    //   873: aload_1
    //   874: invokeinterface next : ()Ljava/lang/Object;
    //   879: checkcast androidx/constraintlayout/solver/widgets/ConstraintAnchor
    //   882: getfield mOwner : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   885: iconst_0
    //   886: aload #10
    //   888: aconst_null
    //   889: invokestatic findDependents : (Landroidx/constraintlayout/solver/widgets/ConstraintWidget;ILjava/util/ArrayList;Landroidx/constraintlayout/solver/widgets/analyzer/WidgetGroup;)Landroidx/constraintlayout/solver/widgets/analyzer/WidgetGroup;
    //   892: pop
    //   893: goto -> 864
    //   896: aload_0
    //   897: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.CENTER : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   900: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   903: astore_1
    //   904: aload_1
    //   905: invokevirtual getDependents : ()Ljava/util/HashSet;
    //   908: ifnull -> 951
    //   911: aload_1
    //   912: invokevirtual getDependents : ()Ljava/util/HashSet;
    //   915: invokevirtual iterator : ()Ljava/util/Iterator;
    //   918: astore_1
    //   919: aload_1
    //   920: invokeinterface hasNext : ()Z
    //   925: ifeq -> 951
    //   928: aload_1
    //   929: invokeinterface next : ()Ljava/lang/Object;
    //   934: checkcast androidx/constraintlayout/solver/widgets/ConstraintAnchor
    //   937: getfield mOwner : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   940: iconst_0
    //   941: aload #10
    //   943: aconst_null
    //   944: invokestatic findDependents : (Landroidx/constraintlayout/solver/widgets/ConstraintWidget;ILjava/util/ArrayList;Landroidx/constraintlayout/solver/widgets/analyzer/WidgetGroup;)Landroidx/constraintlayout/solver/widgets/analyzer/WidgetGroup;
    //   947: pop
    //   948: goto -> 919
    //   951: aload #9
    //   953: ifnull -> 991
    //   956: aload #9
    //   958: invokevirtual iterator : ()Ljava/util/Iterator;
    //   961: astore_1
    //   962: aload_1
    //   963: invokeinterface hasNext : ()Z
    //   968: ifeq -> 991
    //   971: aload_1
    //   972: invokeinterface next : ()Ljava/lang/Object;
    //   977: checkcast androidx/constraintlayout/solver/widgets/ConstraintWidget
    //   980: iconst_0
    //   981: aload #10
    //   983: aconst_null
    //   984: invokestatic findDependents : (Landroidx/constraintlayout/solver/widgets/ConstraintWidget;ILjava/util/ArrayList;Landroidx/constraintlayout/solver/widgets/analyzer/WidgetGroup;)Landroidx/constraintlayout/solver/widgets/analyzer/WidgetGroup;
    //   987: pop
    //   988: goto -> 962
    //   991: aload #7
    //   993: ifnull -> 1031
    //   996: aload #7
    //   998: invokevirtual iterator : ()Ljava/util/Iterator;
    //   1001: astore_1
    //   1002: aload_1
    //   1003: invokeinterface hasNext : ()Z
    //   1008: ifeq -> 1031
    //   1011: aload_1
    //   1012: invokeinterface next : ()Ljava/lang/Object;
    //   1017: checkcast androidx/constraintlayout/solver/widgets/Guideline
    //   1020: iconst_1
    //   1021: aload #10
    //   1023: aconst_null
    //   1024: invokestatic findDependents : (Landroidx/constraintlayout/solver/widgets/ConstraintWidget;ILjava/util/ArrayList;Landroidx/constraintlayout/solver/widgets/analyzer/WidgetGroup;)Landroidx/constraintlayout/solver/widgets/analyzer/WidgetGroup;
    //   1027: pop
    //   1028: goto -> 1002
    //   1031: aload #6
    //   1033: ifnull -> 1093
    //   1036: aload #6
    //   1038: invokevirtual iterator : ()Ljava/util/Iterator;
    //   1041: astore_1
    //   1042: aload_1
    //   1043: invokeinterface hasNext : ()Z
    //   1048: ifeq -> 1093
    //   1051: aload_1
    //   1052: invokeinterface next : ()Ljava/lang/Object;
    //   1057: checkcast androidx/constraintlayout/solver/widgets/HelperWidget
    //   1060: astore #5
    //   1062: aload #5
    //   1064: iconst_1
    //   1065: aload #10
    //   1067: aconst_null
    //   1068: invokestatic findDependents : (Landroidx/constraintlayout/solver/widgets/ConstraintWidget;ILjava/util/ArrayList;Landroidx/constraintlayout/solver/widgets/analyzer/WidgetGroup;)Landroidx/constraintlayout/solver/widgets/analyzer/WidgetGroup;
    //   1071: astore #6
    //   1073: aload #5
    //   1075: aload #10
    //   1077: iconst_1
    //   1078: aload #6
    //   1080: invokevirtual addDependents : (Ljava/util/ArrayList;ILandroidx/constraintlayout/solver/widgets/analyzer/WidgetGroup;)V
    //   1083: aload #6
    //   1085: aload #10
    //   1087: invokevirtual cleanup : (Ljava/util/ArrayList;)V
    //   1090: goto -> 1042
    //   1093: aload_0
    //   1094: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.TOP : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   1097: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1100: astore_1
    //   1101: aload_1
    //   1102: invokevirtual getDependents : ()Ljava/util/HashSet;
    //   1105: ifnull -> 1148
    //   1108: aload_1
    //   1109: invokevirtual getDependents : ()Ljava/util/HashSet;
    //   1112: invokevirtual iterator : ()Ljava/util/Iterator;
    //   1115: astore_1
    //   1116: aload_1
    //   1117: invokeinterface hasNext : ()Z
    //   1122: ifeq -> 1148
    //   1125: aload_1
    //   1126: invokeinterface next : ()Ljava/lang/Object;
    //   1131: checkcast androidx/constraintlayout/solver/widgets/ConstraintAnchor
    //   1134: getfield mOwner : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   1137: iconst_1
    //   1138: aload #10
    //   1140: aconst_null
    //   1141: invokestatic findDependents : (Landroidx/constraintlayout/solver/widgets/ConstraintWidget;ILjava/util/ArrayList;Landroidx/constraintlayout/solver/widgets/analyzer/WidgetGroup;)Landroidx/constraintlayout/solver/widgets/analyzer/WidgetGroup;
    //   1144: pop
    //   1145: goto -> 1116
    //   1148: aload_0
    //   1149: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.BASELINE : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   1152: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1155: astore_1
    //   1156: aload_1
    //   1157: invokevirtual getDependents : ()Ljava/util/HashSet;
    //   1160: ifnull -> 1203
    //   1163: aload_1
    //   1164: invokevirtual getDependents : ()Ljava/util/HashSet;
    //   1167: invokevirtual iterator : ()Ljava/util/Iterator;
    //   1170: astore_1
    //   1171: aload_1
    //   1172: invokeinterface hasNext : ()Z
    //   1177: ifeq -> 1203
    //   1180: aload_1
    //   1181: invokeinterface next : ()Ljava/lang/Object;
    //   1186: checkcast androidx/constraintlayout/solver/widgets/ConstraintAnchor
    //   1189: getfield mOwner : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   1192: iconst_1
    //   1193: aload #10
    //   1195: aconst_null
    //   1196: invokestatic findDependents : (Landroidx/constraintlayout/solver/widgets/ConstraintWidget;ILjava/util/ArrayList;Landroidx/constraintlayout/solver/widgets/analyzer/WidgetGroup;)Landroidx/constraintlayout/solver/widgets/analyzer/WidgetGroup;
    //   1199: pop
    //   1200: goto -> 1171
    //   1203: aload_0
    //   1204: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.BOTTOM : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   1207: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1210: astore_1
    //   1211: aload_1
    //   1212: invokevirtual getDependents : ()Ljava/util/HashSet;
    //   1215: ifnull -> 1258
    //   1218: aload_1
    //   1219: invokevirtual getDependents : ()Ljava/util/HashSet;
    //   1222: invokevirtual iterator : ()Ljava/util/Iterator;
    //   1225: astore_1
    //   1226: aload_1
    //   1227: invokeinterface hasNext : ()Z
    //   1232: ifeq -> 1258
    //   1235: aload_1
    //   1236: invokeinterface next : ()Ljava/lang/Object;
    //   1241: checkcast androidx/constraintlayout/solver/widgets/ConstraintAnchor
    //   1244: getfield mOwner : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   1247: iconst_1
    //   1248: aload #10
    //   1250: aconst_null
    //   1251: invokestatic findDependents : (Landroidx/constraintlayout/solver/widgets/ConstraintWidget;ILjava/util/ArrayList;Landroidx/constraintlayout/solver/widgets/analyzer/WidgetGroup;)Landroidx/constraintlayout/solver/widgets/analyzer/WidgetGroup;
    //   1254: pop
    //   1255: goto -> 1226
    //   1258: aload_0
    //   1259: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.CENTER : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   1262: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1265: astore_1
    //   1266: aload_1
    //   1267: invokevirtual getDependents : ()Ljava/util/HashSet;
    //   1270: ifnull -> 1313
    //   1273: aload_1
    //   1274: invokevirtual getDependents : ()Ljava/util/HashSet;
    //   1277: invokevirtual iterator : ()Ljava/util/Iterator;
    //   1280: astore_1
    //   1281: aload_1
    //   1282: invokeinterface hasNext : ()Z
    //   1287: ifeq -> 1313
    //   1290: aload_1
    //   1291: invokeinterface next : ()Ljava/lang/Object;
    //   1296: checkcast androidx/constraintlayout/solver/widgets/ConstraintAnchor
    //   1299: getfield mOwner : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   1302: iconst_1
    //   1303: aload #10
    //   1305: aconst_null
    //   1306: invokestatic findDependents : (Landroidx/constraintlayout/solver/widgets/ConstraintWidget;ILjava/util/ArrayList;Landroidx/constraintlayout/solver/widgets/analyzer/WidgetGroup;)Landroidx/constraintlayout/solver/widgets/analyzer/WidgetGroup;
    //   1309: pop
    //   1310: goto -> 1281
    //   1313: aload #8
    //   1315: ifnull -> 1353
    //   1318: aload #8
    //   1320: invokevirtual iterator : ()Ljava/util/Iterator;
    //   1323: astore_1
    //   1324: aload_1
    //   1325: invokeinterface hasNext : ()Z
    //   1330: ifeq -> 1353
    //   1333: aload_1
    //   1334: invokeinterface next : ()Ljava/lang/Object;
    //   1339: checkcast androidx/constraintlayout/solver/widgets/ConstraintWidget
    //   1342: iconst_1
    //   1343: aload #10
    //   1345: aconst_null
    //   1346: invokestatic findDependents : (Landroidx/constraintlayout/solver/widgets/ConstraintWidget;ILjava/util/ArrayList;Landroidx/constraintlayout/solver/widgets/analyzer/WidgetGroup;)Landroidx/constraintlayout/solver/widgets/analyzer/WidgetGroup;
    //   1349: pop
    //   1350: goto -> 1324
    //   1353: iconst_0
    //   1354: istore_2
    //   1355: iload_2
    //   1356: iload_3
    //   1357: if_icmpge -> 1438
    //   1360: aload #16
    //   1362: iload_2
    //   1363: invokevirtual get : (I)Ljava/lang/Object;
    //   1366: checkcast androidx/constraintlayout/solver/widgets/ConstraintWidget
    //   1369: astore #5
    //   1371: aload #5
    //   1373: invokevirtual oppositeDimensionsTied : ()Z
    //   1376: ifeq -> 1431
    //   1379: aload #10
    //   1381: aload #5
    //   1383: getfield horizontalGroup : I
    //   1386: invokestatic findGroup : (Ljava/util/ArrayList;I)Landroidx/constraintlayout/solver/widgets/analyzer/WidgetGroup;
    //   1389: astore_1
    //   1390: aload #10
    //   1392: aload #5
    //   1394: getfield verticalGroup : I
    //   1397: invokestatic findGroup : (Ljava/util/ArrayList;I)Landroidx/constraintlayout/solver/widgets/analyzer/WidgetGroup;
    //   1400: astore #5
    //   1402: aload_1
    //   1403: ifnull -> 1431
    //   1406: aload #5
    //   1408: ifnull -> 1431
    //   1411: aload_1
    //   1412: iconst_0
    //   1413: aload #5
    //   1415: invokevirtual moveTo : (ILandroidx/constraintlayout/solver/widgets/analyzer/WidgetGroup;)V
    //   1418: aload #5
    //   1420: iconst_2
    //   1421: invokevirtual setOrientation : (I)V
    //   1424: aload #10
    //   1426: aload_1
    //   1427: invokevirtual remove : (Ljava/lang/Object;)Z
    //   1430: pop
    //   1431: iload_2
    //   1432: iconst_1
    //   1433: iadd
    //   1434: istore_2
    //   1435: goto -> 1355
    //   1438: aload #10
    //   1440: invokevirtual size : ()I
    //   1443: iconst_1
    //   1444: if_icmpgt -> 1449
    //   1447: iconst_0
    //   1448: ireturn
    //   1449: aload_0
    //   1450: invokevirtual getHorizontalDimensionBehaviour : ()Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   1453: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   1456: if_acmpne -> 1561
    //   1459: aload #10
    //   1461: invokevirtual iterator : ()Ljava/util/Iterator;
    //   1464: astore #6
    //   1466: aconst_null
    //   1467: astore_1
    //   1468: iconst_0
    //   1469: istore_2
    //   1470: aload #6
    //   1472: invokeinterface hasNext : ()Z
    //   1477: ifeq -> 1534
    //   1480: aload #6
    //   1482: invokeinterface next : ()Ljava/lang/Object;
    //   1487: checkcast androidx/constraintlayout/solver/widgets/analyzer/WidgetGroup
    //   1490: astore #5
    //   1492: aload #5
    //   1494: invokevirtual getOrientation : ()I
    //   1497: iconst_1
    //   1498: if_icmpne -> 1504
    //   1501: goto -> 1470
    //   1504: aload #5
    //   1506: iconst_0
    //   1507: invokevirtual setAuthoritative : (Z)V
    //   1510: aload #5
    //   1512: aload_0
    //   1513: invokevirtual getSystem : ()Landroidx/constraintlayout/solver/LinearSystem;
    //   1516: iconst_0
    //   1517: invokevirtual measureWrap : (Landroidx/constraintlayout/solver/LinearSystem;I)I
    //   1520: istore_3
    //   1521: iload_3
    //   1522: iload_2
    //   1523: if_icmple -> 1470
    //   1526: aload #5
    //   1528: astore_1
    //   1529: iload_3
    //   1530: istore_2
    //   1531: goto -> 1470
    //   1534: aload_1
    //   1535: ifnull -> 1561
    //   1538: aload_0
    //   1539: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.FIXED : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   1542: invokevirtual setHorizontalDimensionBehaviour : (Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;)V
    //   1545: aload_0
    //   1546: iload_2
    //   1547: invokevirtual setWidth : (I)V
    //   1550: aload_1
    //   1551: iconst_1
    //   1552: invokevirtual setAuthoritative : (Z)V
    //   1555: aload_1
    //   1556: astore #5
    //   1558: goto -> 1564
    //   1561: aconst_null
    //   1562: astore #5
    //   1564: aload_0
    //   1565: invokevirtual getVerticalDimensionBehaviour : ()Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   1568: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   1571: if_acmpne -> 1672
    //   1574: aload #10
    //   1576: invokevirtual iterator : ()Ljava/util/Iterator;
    //   1579: astore #7
    //   1581: aconst_null
    //   1582: astore_1
    //   1583: iconst_0
    //   1584: istore_2
    //   1585: aload #7
    //   1587: invokeinterface hasNext : ()Z
    //   1592: ifeq -> 1648
    //   1595: aload #7
    //   1597: invokeinterface next : ()Ljava/lang/Object;
    //   1602: checkcast androidx/constraintlayout/solver/widgets/analyzer/WidgetGroup
    //   1605: astore #6
    //   1607: aload #6
    //   1609: invokevirtual getOrientation : ()I
    //   1612: ifne -> 1618
    //   1615: goto -> 1585
    //   1618: aload #6
    //   1620: iconst_0
    //   1621: invokevirtual setAuthoritative : (Z)V
    //   1624: aload #6
    //   1626: aload_0
    //   1627: invokevirtual getSystem : ()Landroidx/constraintlayout/solver/LinearSystem;
    //   1630: iconst_1
    //   1631: invokevirtual measureWrap : (Landroidx/constraintlayout/solver/LinearSystem;I)I
    //   1634: istore_3
    //   1635: iload_3
    //   1636: iload_2
    //   1637: if_icmple -> 1585
    //   1640: aload #6
    //   1642: astore_1
    //   1643: iload_3
    //   1644: istore_2
    //   1645: goto -> 1585
    //   1648: aload_1
    //   1649: ifnull -> 1672
    //   1652: aload_0
    //   1653: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.FIXED : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   1656: invokevirtual setVerticalDimensionBehaviour : (Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;)V
    //   1659: aload_0
    //   1660: iload_2
    //   1661: invokevirtual setHeight : (I)V
    //   1664: aload_1
    //   1665: iconst_1
    //   1666: invokevirtual setAuthoritative : (Z)V
    //   1669: goto -> 1674
    //   1672: aconst_null
    //   1673: astore_1
    //   1674: aload #5
    //   1676: ifnonnull -> 1688
    //   1679: aload_1
    //   1680: ifnull -> 1686
    //   1683: goto -> 1688
    //   1686: iconst_0
    //   1687: ireturn
    //   1688: iconst_1
    //   1689: ireturn
  }
  
  public static boolean validInGroup(ConstraintWidget.DimensionBehaviour paramDimensionBehaviour1, ConstraintWidget.DimensionBehaviour paramDimensionBehaviour2, ConstraintWidget.DimensionBehaviour paramDimensionBehaviour3, ConstraintWidget.DimensionBehaviour paramDimensionBehaviour4) {
    // Byte code:
    //   0: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.FIXED : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   3: astore #6
    //   5: aload_2
    //   6: aload #6
    //   8: if_acmpeq -> 44
    //   11: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   14: astore #7
    //   16: aload_2
    //   17: aload #7
    //   19: if_acmpeq -> 44
    //   22: aload_2
    //   23: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.MATCH_PARENT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   26: if_acmpne -> 38
    //   29: aload_0
    //   30: aload #7
    //   32: if_acmpeq -> 38
    //   35: goto -> 44
    //   38: iconst_0
    //   39: istore #4
    //   41: goto -> 47
    //   44: iconst_1
    //   45: istore #4
    //   47: aload_3
    //   48: aload #6
    //   50: if_acmpeq -> 83
    //   53: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   56: astore_0
    //   57: aload_3
    //   58: aload_0
    //   59: if_acmpeq -> 83
    //   62: aload_3
    //   63: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.MATCH_PARENT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   66: if_acmpne -> 77
    //   69: aload_1
    //   70: aload_0
    //   71: if_acmpeq -> 77
    //   74: goto -> 83
    //   77: iconst_0
    //   78: istore #5
    //   80: goto -> 86
    //   83: iconst_1
    //   84: istore #5
    //   86: iload #4
    //   88: ifne -> 100
    //   91: iload #5
    //   93: ifeq -> 98
    //   96: iconst_1
    //   97: ireturn
    //   98: iconst_0
    //   99: ireturn
    //   100: iconst_1
    //   101: ireturn
  }
}


/* Location:              C:\soft\dex2jar-2.0\BabyBus TV_Kids Videos & Games-dex2jar.jar!\androidx\constraintlayout\solver\widgets\analyzer\Grouping.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */