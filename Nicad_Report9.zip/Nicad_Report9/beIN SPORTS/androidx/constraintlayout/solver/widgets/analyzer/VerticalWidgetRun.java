package androidx.constraintlayout.solver.widgets.analyzer;

import androidx.constraintlayout.solver.widgets.ConstraintAnchor;
import androidx.constraintlayout.solver.widgets.ConstraintWidget;

public class VerticalWidgetRun extends WidgetRun {
  public DependencyNode baseline;
  
  DimensionDependency baselineDimension;
  
  public VerticalWidgetRun(ConstraintWidget paramConstraintWidget) {
    super(paramConstraintWidget);
    DependencyNode dependencyNode = new DependencyNode(this);
    this.baseline = dependencyNode;
    this.baselineDimension = null;
    this.start.type = DependencyNode.Type.TOP;
    this.end.type = DependencyNode.Type.BOTTOM;
    dependencyNode.type = DependencyNode.Type.BASELINE;
    this.orientation = 1;
  }
  
  void apply() {
    DependencyNode dependencyNode;
    ConstraintWidget constraintWidget = this.widget;
    if (constraintWidget.measured)
      this.dimension.resolve(constraintWidget.getHeight()); 
    if (!this.dimension.resolved) {
      this.dimensionBehavior = this.widget.getVerticalDimensionBehaviour();
      if (this.widget.hasBaseline())
        this.baselineDimension = new BaselineDimensionDependency(this); 
      ConstraintWidget.DimensionBehaviour dimensionBehaviour = this.dimensionBehavior;
      if (dimensionBehaviour != ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT) {
        if (dimensionBehaviour == ConstraintWidget.DimensionBehaviour.MATCH_PARENT) {
          ConstraintWidget constraintWidget1 = this.widget.getParent();
          if (constraintWidget1 != null && constraintWidget1.getVerticalDimensionBehaviour() == ConstraintWidget.DimensionBehaviour.FIXED) {
            int i = constraintWidget1.getHeight();
            int j = this.widget.mTop.getMargin();
            int k = this.widget.mBottom.getMargin();
            addTarget(this.start, constraintWidget1.verticalRun.start, this.widget.mTop.getMargin());
            addTarget(this.end, constraintWidget1.verticalRun.end, -this.widget.mBottom.getMargin());
            this.dimension.resolve(i - j - k);
            return;
          } 
        } 
        if (this.dimensionBehavior == ConstraintWidget.DimensionBehaviour.FIXED)
          this.dimension.resolve(this.widget.getHeight()); 
      } 
    } else if (this.dimensionBehavior == ConstraintWidget.DimensionBehaviour.MATCH_PARENT) {
      constraintWidget = this.widget.getParent();
      if (constraintWidget != null && constraintWidget.getVerticalDimensionBehaviour() == ConstraintWidget.DimensionBehaviour.FIXED) {
        addTarget(this.start, constraintWidget.verticalRun.start, this.widget.mTop.getMargin());
        addTarget(this.end, constraintWidget.verticalRun.end, -this.widget.mBottom.getMargin());
        return;
      } 
    } 
    DimensionDependency dimensionDependency = this.dimension;
    boolean bool = dimensionDependency.resolved;
    if (bool) {
      constraintWidget = this.widget;
      if (constraintWidget.measured) {
        arrayOfConstraintAnchor = constraintWidget.mListAnchors;
        if ((arrayOfConstraintAnchor[2]).mTarget != null && (arrayOfConstraintAnchor[3]).mTarget != null) {
          if (constraintWidget.isInVerticalChain()) {
            this.start.margin = this.widget.mListAnchors[2].getMargin();
            this.end.margin = -this.widget.mListAnchors[3].getMargin();
          } else {
            DependencyNode dependencyNode1 = getTarget(this.widget.mListAnchors[2]);
            if (dependencyNode1 != null)
              addTarget(this.start, dependencyNode1, this.widget.mListAnchors[2].getMargin()); 
            dependencyNode1 = getTarget(this.widget.mListAnchors[3]);
            if (dependencyNode1 != null)
              addTarget(this.end, dependencyNode1, -this.widget.mListAnchors[3].getMargin()); 
            this.start.delegateToWidgetRun = true;
            this.end.delegateToWidgetRun = true;
          } 
          if (this.widget.hasBaseline()) {
            addTarget(this.baseline, this.start, this.widget.getBaselineDistance());
            return;
          } 
        } else if ((arrayOfConstraintAnchor[2]).mTarget != null) {
          DependencyNode dependencyNode1 = getTarget(arrayOfConstraintAnchor[2]);
          if (dependencyNode1 != null) {
            addTarget(this.start, dependencyNode1, this.widget.mListAnchors[2].getMargin());
            addTarget(this.end, this.start, this.dimension.value);
            if (this.widget.hasBaseline()) {
              addTarget(this.baseline, this.start, this.widget.getBaselineDistance());
              return;
            } 
          } 
        } else if ((arrayOfConstraintAnchor[3]).mTarget != null) {
          DependencyNode dependencyNode1 = getTarget(arrayOfConstraintAnchor[3]);
          if (dependencyNode1 != null) {
            addTarget(this.end, dependencyNode1, -this.widget.mListAnchors[3].getMargin());
            addTarget(this.start, this.end, -this.dimension.value);
          } 
          if (this.widget.hasBaseline()) {
            addTarget(this.baseline, this.start, this.widget.getBaselineDistance());
            return;
          } 
        } else {
          DependencyNode dependencyNode1;
          if ((arrayOfConstraintAnchor[4]).mTarget != null) {
            dependencyNode1 = getTarget(arrayOfConstraintAnchor[4]);
            if (dependencyNode1 != null) {
              addTarget(this.baseline, dependencyNode1, 0);
              addTarget(this.start, this.baseline, -this.widget.getBaselineDistance());
              addTarget(this.end, this.start, this.dimension.value);
              return;
            } 
          } else if (!(dependencyNode1 instanceof androidx.constraintlayout.solver.widgets.Helper) && dependencyNode1.getParent() != null && (this.widget.getAnchor(ConstraintAnchor.Type.CENTER)).mTarget == null) {
            dependencyNode1 = (this.widget.getParent()).verticalRun.start;
            addTarget(this.start, dependencyNode1, this.widget.getY());
            addTarget(this.end, this.start, this.dimension.value);
            if (this.widget.hasBaseline()) {
              addTarget(this.baseline, this.start, this.widget.getBaselineDistance());
              return;
            } 
          } 
        } 
        return;
      } 
    } 
    if (!bool && this.dimensionBehavior == ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT) {
      DimensionDependency dimensionDependency1;
      constraintWidget = this.widget;
      int i = constraintWidget.mMatchConstraintDefaultHeight;
      if (i != 2) {
        if (i == 3 && !constraintWidget.isInVerticalChain()) {
          constraintWidget = this.widget;
          if (constraintWidget.mMatchConstraintDefaultWidth != 3) {
            dimensionDependency1 = constraintWidget.horizontalRun.dimension;
            this.dimension.targets.add(dimensionDependency1);
            dimensionDependency1.dependencies.add(this.dimension);
            dimensionDependency1 = this.dimension;
            dimensionDependency1.delegateToWidgetRun = true;
            dimensionDependency1.dependencies.add(this.start);
            this.dimension.dependencies.add(this.end);
          } 
        } 
      } else {
        ConstraintWidget constraintWidget1 = dimensionDependency1.getParent();
        if (constraintWidget1 != null) {
          DimensionDependency dimensionDependency2 = constraintWidget1.verticalRun.dimension;
          this.dimension.targets.add(dimensionDependency2);
          dimensionDependency2.dependencies.add(this.dimension);
          dimensionDependency2 = this.dimension;
          dimensionDependency2.delegateToWidgetRun = true;
          dimensionDependency2.dependencies.add(this.start);
          this.dimension.dependencies.add(this.end);
        } 
      } 
    } else {
      arrayOfConstraintAnchor.addDependency(this);
    } 
    constraintWidget = this.widget;
    ConstraintAnchor[] arrayOfConstraintAnchor = constraintWidget.mListAnchors;
    if ((arrayOfConstraintAnchor[2]).mTarget != null && (arrayOfConstraintAnchor[3]).mTarget != null) {
      if (constraintWidget.isInVerticalChain()) {
        this.start.margin = this.widget.mListAnchors[2].getMargin();
        this.end.margin = -this.widget.mListAnchors[3].getMargin();
      } else {
        DependencyNode dependencyNode1 = getTarget(this.widget.mListAnchors[2]);
        dependencyNode = getTarget(this.widget.mListAnchors[3]);
        dependencyNode1.addDependency(this);
        dependencyNode.addDependency(this);
        this.mRunType = WidgetRun.RunType.CENTER;
      } 
      if (this.widget.hasBaseline())
        addTarget(this.baseline, this.start, 1, this.baselineDimension); 
    } else {
      HorizontalWidgetRun horizontalWidgetRun;
      if (((ConstraintAnchor)dependencyNode[2]).mTarget != null) {
        DependencyNode dependencyNode1 = getTarget((ConstraintAnchor)dependencyNode[2]);
        if (dependencyNode1 != null) {
          addTarget(this.start, dependencyNode1, this.widget.mListAnchors[2].getMargin());
          addTarget(this.end, this.start, 1, this.dimension);
          if (this.widget.hasBaseline())
            addTarget(this.baseline, this.start, 1, this.baselineDimension); 
          ConstraintWidget.DimensionBehaviour dimensionBehaviour2 = this.dimensionBehavior;
          ConstraintWidget.DimensionBehaviour dimensionBehaviour1 = ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT;
          if (dimensionBehaviour2 == dimensionBehaviour1 && this.widget.getDimensionRatio() > 0.0F) {
            horizontalWidgetRun = this.widget.horizontalRun;
            if (horizontalWidgetRun.dimensionBehavior == dimensionBehaviour1) {
              horizontalWidgetRun.dimension.dependencies.add(this.dimension);
              this.dimension.targets.add(this.widget.horizontalRun.dimension);
              this.dimension.updateDelegate = this;
            } 
          } 
        } 
      } else if (((ConstraintAnchor)horizontalWidgetRun[3]).mTarget != null) {
        DependencyNode dependencyNode1 = getTarget((ConstraintAnchor)horizontalWidgetRun[3]);
        if (dependencyNode1 != null) {
          addTarget(this.end, dependencyNode1, -this.widget.mListAnchors[3].getMargin());
          addTarget(this.start, this.end, -1, this.dimension);
          if (this.widget.hasBaseline())
            addTarget(this.baseline, this.start, 1, this.baselineDimension); 
        } 
      } else {
        DependencyNode dependencyNode1;
        if (((ConstraintAnchor)horizontalWidgetRun[4]).mTarget != null) {
          dependencyNode1 = getTarget((ConstraintAnchor)horizontalWidgetRun[4]);
          if (dependencyNode1 != null) {
            addTarget(this.baseline, dependencyNode1, 0);
            addTarget(this.start, this.baseline, -1, this.baselineDimension);
            addTarget(this.end, this.start, 1, this.dimension);
          } 
        } else if (!(dependencyNode1 instanceof androidx.constraintlayout.solver.widgets.Helper) && dependencyNode1.getParent() != null) {
          dependencyNode1 = (this.widget.getParent()).verticalRun.start;
          addTarget(this.start, dependencyNode1, this.widget.getY());
          addTarget(this.end, this.start, 1, this.dimension);
          if (this.widget.hasBaseline())
            addTarget(this.baseline, this.start, 1, this.baselineDimension); 
          ConstraintWidget.DimensionBehaviour dimensionBehaviour2 = this.dimensionBehavior;
          ConstraintWidget.DimensionBehaviour dimensionBehaviour1 = ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT;
          if (dimensionBehaviour2 == dimensionBehaviour1 && this.widget.getDimensionRatio() > 0.0F) {
            HorizontalWidgetRun horizontalWidgetRun1 = this.widget.horizontalRun;
            if (horizontalWidgetRun1.dimensionBehavior == dimensionBehaviour1) {
              horizontalWidgetRun1.dimension.dependencies.add(this.dimension);
              this.dimension.targets.add(this.widget.horizontalRun.dimension);
              this.dimension.updateDelegate = this;
            } 
          } 
        } 
      } 
    } 
    if (this.dimension.targets.size() == 0)
      this.dimension.readyToSolve = true; 
  }
  
  public void applyToWidget() {
    DependencyNode dependencyNode = this.start;
    if (dependencyNode.resolved)
      this.widget.setY(dependencyNode.value); 
  }
  
  void clear() {
    this.runGroup = null;
    this.start.clear();
    this.end.clear();
    this.baseline.clear();
    this.dimension.clear();
    this.resolved = false;
  }
  
  void reset() {
    this.resolved = false;
    this.start.clear();
    this.start.resolved = false;
    this.end.clear();
    this.end.resolved = false;
    this.baseline.clear();
    this.baseline.resolved = false;
    this.dimension.resolved = false;
  }
  
  boolean supportsWrapComputation() {
    return (this.dimensionBehavior == ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT) ? ((this.widget.mMatchConstraintDefaultHeight == 0)) : true;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("VerticalRun ");
    stringBuilder.append(this.widget.getDebugName());
    return stringBuilder.toString();
  }
  
  public void update(Dependency paramDependency) {
    int i = null.$SwitchMap$androidx$constraintlayout$solver$widgets$analyzer$WidgetRun$RunType[this.mRunType.ordinal()];
    if (i != 1) {
      if (i != 2) {
        if (i == 3) {
          ConstraintWidget constraintWidget = this.widget;
          updateRunCenter(paramDependency, constraintWidget.mTop, constraintWidget.mBottom, 1);
          return;
        } 
      } else {
        updateRunEnd(paramDependency);
      } 
    } else {
      updateRunStart(paramDependency);
    } 
    paramDependency = this.dimension;
    if (((DependencyNode)paramDependency).readyToSolve && !((DependencyNode)paramDependency).resolved && this.dimensionBehavior == ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT) {
      ConstraintWidget constraintWidget = this.widget;
      i = constraintWidget.mMatchConstraintDefaultHeight;
      if (i != 2) {
        if (i == 3 && constraintWidget.horizontalRun.dimension.resolved) {
          i = constraintWidget.getDimensionRatioSide();
          if (i != -1) {
            if (i != 0) {
              if (i != 1) {
                i = 0;
              } else {
                constraintWidget = this.widget;
                float f1 = constraintWidget.horizontalRun.dimension.value;
                float f2 = constraintWidget.getDimensionRatio();
                f1 /= f2;
              } 
            } else {
              constraintWidget = this.widget;
              float f = constraintWidget.horizontalRun.dimension.value * constraintWidget.getDimensionRatio();
              i = (int)(f + 0.5F);
            } 
          } else {
            constraintWidget = this.widget;
            float f1 = constraintWidget.horizontalRun.dimension.value;
            float f2 = constraintWidget.getDimensionRatio();
            f1 /= f2;
          } 
          this.dimension.resolve(i);
        } 
      } else {
        constraintWidget = constraintWidget.getParent();
        if (constraintWidget != null) {
          DimensionDependency dimensionDependency = constraintWidget.verticalRun.dimension;
          if (dimensionDependency.resolved) {
            float f = this.widget.mMatchConstraintPercentHeight;
            i = (int)(dimensionDependency.value * f + 0.5F);
            this.dimension.resolve(i);
          } 
        } 
      } 
    } 
    paramDependency = this.start;
    if (((DependencyNode)paramDependency).readyToSolve) {
      DependencyNode dependencyNode = this.end;
      if (!dependencyNode.readyToSolve)
        return; 
      if (((DependencyNode)paramDependency).resolved && dependencyNode.resolved && this.dimension.resolved)
        return; 
      if (!this.dimension.resolved && this.dimensionBehavior == ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT) {
        ConstraintWidget constraintWidget = this.widget;
        if (constraintWidget.mMatchConstraintDefaultWidth == 0 && !constraintWidget.isInVerticalChain()) {
          dependencyNode = this.start.targets.get(0);
          DependencyNode dependencyNode1 = this.end.targets.get(0);
          i = dependencyNode.value;
          dependencyNode = this.start;
          i += dependencyNode.margin;
          int j = dependencyNode1.value + this.end.margin;
          dependencyNode.resolve(i);
          this.end.resolve(j);
          this.dimension.resolve(j - i);
          return;
        } 
      } 
      if (!this.dimension.resolved && this.dimensionBehavior == ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT && this.matchConstraintsType == 1 && this.start.targets.size() > 0 && this.end.targets.size() > 0) {
        paramDependency = this.start.targets.get(0);
        dependencyNode = this.end.targets.get(0);
        i = ((DependencyNode)paramDependency).value;
        int j = this.start.margin;
        i = dependencyNode.value + this.end.margin - i + j;
        paramDependency = this.dimension;
        j = ((DimensionDependency)paramDependency).wrapValue;
        if (i < j) {
          paramDependency.resolve(i);
        } else {
          paramDependency.resolve(j);
        } 
      } 
      if (!this.dimension.resolved)
        return; 
      if (this.start.targets.size() > 0 && this.end.targets.size() > 0) {
        paramDependency = this.start.targets.get(0);
        dependencyNode = this.end.targets.get(0);
        i = ((DependencyNode)paramDependency).value + this.start.margin;
        int j = dependencyNode.value + this.end.margin;
        float f = this.widget.getVerticalBiasPercent();
        if (paramDependency == dependencyNode) {
          i = ((DependencyNode)paramDependency).value;
          j = dependencyNode.value;
          f = 0.5F;
        } 
        int k = this.dimension.value;
        this.start.resolve((int)(i + 0.5F + (j - i - k) * f));
        this.end.resolve(this.start.value + this.dimension.value);
      } 
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\BabyBus TV_Kids Videos & Games-dex2jar.jar!\androidx\constraintlayout\solver\widgets\analyzer\VerticalWidgetRun.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */