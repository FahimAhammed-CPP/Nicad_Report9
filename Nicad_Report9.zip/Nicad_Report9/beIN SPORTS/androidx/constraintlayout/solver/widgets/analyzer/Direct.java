package androidx.constraintlayout.solver.widgets.analyzer;

import androidx.constraintlayout.solver.LinearSystem;
import androidx.constraintlayout.solver.widgets.Barrier;
import androidx.constraintlayout.solver.widgets.ChainHead;
import androidx.constraintlayout.solver.widgets.ConstraintAnchor;
import androidx.constraintlayout.solver.widgets.ConstraintWidget;
import androidx.constraintlayout.solver.widgets.ConstraintWidgetContainer;
import androidx.constraintlayout.solver.widgets.Guideline;
import java.util.ArrayList;

public class Direct {
  private static final boolean APPLY_MATCH_PARENT = false;
  
  private static final boolean DEBUG = false;
  
  private static BasicMeasure.Measure measure = new BasicMeasure.Measure();
  
  private static boolean canMeasure(ConstraintWidget paramConstraintWidget) {
    boolean bool1;
    boolean bool2;
    ConstraintWidget constraintWidget;
    ConstraintWidget.DimensionBehaviour dimensionBehaviour2 = paramConstraintWidget.getHorizontalDimensionBehaviour();
    ConstraintWidget.DimensionBehaviour dimensionBehaviour3 = paramConstraintWidget.getVerticalDimensionBehaviour();
    if (paramConstraintWidget.getParent() != null) {
      constraintWidget = paramConstraintWidget.getParent();
    } else {
      constraintWidget = null;
    } 
    if (constraintWidget != null) {
      constraintWidget.getHorizontalDimensionBehaviour();
      ConstraintWidget.DimensionBehaviour dimensionBehaviour = ConstraintWidget.DimensionBehaviour.FIXED;
    } 
    if (constraintWidget != null) {
      constraintWidget.getVerticalDimensionBehaviour();
      ConstraintWidget.DimensionBehaviour dimensionBehaviour = ConstraintWidget.DimensionBehaviour.FIXED;
    } 
    ConstraintWidget.DimensionBehaviour dimensionBehaviour1 = ConstraintWidget.DimensionBehaviour.FIXED;
    boolean bool4 = false;
    if (dimensionBehaviour2 == dimensionBehaviour1 || dimensionBehaviour2 == ConstraintWidget.DimensionBehaviour.WRAP_CONTENT || (dimensionBehaviour2 == ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT && paramConstraintWidget.mMatchConstraintDefaultWidth == 0 && paramConstraintWidget.mDimensionRatio == 0.0F && paramConstraintWidget.hasDanglingDimension(0)) || paramConstraintWidget.isResolvedHorizontally()) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    if (dimensionBehaviour3 == dimensionBehaviour1 || dimensionBehaviour3 == ConstraintWidget.DimensionBehaviour.WRAP_CONTENT || (dimensionBehaviour3 == ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT && paramConstraintWidget.mMatchConstraintDefaultHeight == 0 && paramConstraintWidget.mDimensionRatio == 0.0F && paramConstraintWidget.hasDanglingDimension(1)) || paramConstraintWidget.isResolvedVertically()) {
      bool2 = true;
    } else {
      bool2 = false;
    } 
    if (paramConstraintWidget.mDimensionRatio > 0.0F && (bool1 || bool2))
      return true; 
    boolean bool3 = bool4;
    if (bool1) {
      bool3 = bool4;
      if (bool2)
        bool3 = true; 
    } 
    return bool3;
  }
  
  private static void horizontalSolvingPass(ConstraintWidget paramConstraintWidget, BasicMeasure.Measurer paramMeasurer, boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: instanceof androidx/constraintlayout/solver/widgets/ConstraintWidgetContainer
    //   4: ifne -> 37
    //   7: aload_0
    //   8: invokevirtual isMeasureRequested : ()Z
    //   11: ifeq -> 37
    //   14: aload_0
    //   15: invokestatic canMeasure : (Landroidx/constraintlayout/solver/widgets/ConstraintWidget;)Z
    //   18: ifeq -> 37
    //   21: aload_0
    //   22: aload_1
    //   23: new androidx/constraintlayout/solver/widgets/analyzer/BasicMeasure$Measure
    //   26: dup
    //   27: invokespecial <init> : ()V
    //   30: getstatic androidx/constraintlayout/solver/widgets/analyzer/BasicMeasure$Measure.SELF_DIMENSIONS : I
    //   33: invokestatic measure : (Landroidx/constraintlayout/solver/widgets/ConstraintWidget;Landroidx/constraintlayout/solver/widgets/analyzer/BasicMeasure$Measurer;Landroidx/constraintlayout/solver/widgets/analyzer/BasicMeasure$Measure;I)Z
    //   36: pop
    //   37: aload_0
    //   38: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.LEFT : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   41: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   44: astore #8
    //   46: aload_0
    //   47: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.RIGHT : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   50: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   53: astore #7
    //   55: aload #8
    //   57: invokevirtual getFinalValue : ()I
    //   60: istore #5
    //   62: aload #7
    //   64: invokevirtual getFinalValue : ()I
    //   67: istore #4
    //   69: aload #8
    //   71: invokevirtual getDependents : ()Ljava/util/HashSet;
    //   74: ifnull -> 521
    //   77: aload #8
    //   79: invokevirtual hasFinalValue : ()Z
    //   82: ifeq -> 521
    //   85: aload #8
    //   87: invokevirtual getDependents : ()Ljava/util/HashSet;
    //   90: invokevirtual iterator : ()Ljava/util/Iterator;
    //   93: astore #8
    //   95: aload #8
    //   97: invokeinterface hasNext : ()Z
    //   102: ifeq -> 521
    //   105: aload #8
    //   107: invokeinterface next : ()Ljava/lang/Object;
    //   112: checkcast androidx/constraintlayout/solver/widgets/ConstraintAnchor
    //   115: astore #10
    //   117: aload #10
    //   119: getfield mOwner : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   122: astore #9
    //   124: aload #9
    //   126: invokestatic canMeasure : (Landroidx/constraintlayout/solver/widgets/ConstraintWidget;)Z
    //   129: istore #6
    //   131: aload #9
    //   133: invokevirtual isMeasureRequested : ()Z
    //   136: ifeq -> 161
    //   139: iload #6
    //   141: ifeq -> 161
    //   144: aload #9
    //   146: aload_1
    //   147: new androidx/constraintlayout/solver/widgets/analyzer/BasicMeasure$Measure
    //   150: dup
    //   151: invokespecial <init> : ()V
    //   154: getstatic androidx/constraintlayout/solver/widgets/analyzer/BasicMeasure$Measure.SELF_DIMENSIONS : I
    //   157: invokestatic measure : (Landroidx/constraintlayout/solver/widgets/ConstraintWidget;Landroidx/constraintlayout/solver/widgets/analyzer/BasicMeasure$Measurer;Landroidx/constraintlayout/solver/widgets/analyzer/BasicMeasure$Measure;I)Z
    //   160: pop
    //   161: aload #9
    //   163: invokevirtual getHorizontalDimensionBehaviour : ()Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   166: astore #11
    //   168: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   171: astore #12
    //   173: aload #11
    //   175: aload #12
    //   177: if_acmpne -> 354
    //   180: iload #6
    //   182: ifeq -> 188
    //   185: goto -> 354
    //   188: aload #9
    //   190: invokevirtual getHorizontalDimensionBehaviour : ()Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   193: aload #12
    //   195: if_acmpne -> 95
    //   198: aload #9
    //   200: getfield mMatchConstraintMaxWidth : I
    //   203: iflt -> 95
    //   206: aload #9
    //   208: getfield mMatchConstraintMinWidth : I
    //   211: iflt -> 95
    //   214: aload #9
    //   216: invokevirtual getVisibility : ()I
    //   219: bipush #8
    //   221: if_icmpeq -> 242
    //   224: aload #9
    //   226: getfield mMatchConstraintDefaultWidth : I
    //   229: ifne -> 95
    //   232: aload #9
    //   234: invokevirtual getDimensionRatio : ()F
    //   237: fconst_0
    //   238: fcmpl
    //   239: ifne -> 95
    //   242: aload #9
    //   244: invokevirtual isInHorizontalChain : ()Z
    //   247: ifne -> 95
    //   250: aload #9
    //   252: invokevirtual isInVirtualLayout : ()Z
    //   255: ifne -> 95
    //   258: aload #10
    //   260: aload #9
    //   262: getfield mLeft : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   265: if_acmpne -> 291
    //   268: aload #9
    //   270: getfield mRight : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   273: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   276: astore #11
    //   278: aload #11
    //   280: ifnull -> 291
    //   283: aload #11
    //   285: invokevirtual hasFinalValue : ()Z
    //   288: ifne -> 324
    //   291: aload #10
    //   293: aload #9
    //   295: getfield mRight : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   298: if_acmpne -> 329
    //   301: aload #9
    //   303: getfield mLeft : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   306: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   309: astore #10
    //   311: aload #10
    //   313: ifnull -> 329
    //   316: aload #10
    //   318: invokevirtual hasFinalValue : ()Z
    //   321: ifeq -> 329
    //   324: iconst_1
    //   325: istore_3
    //   326: goto -> 331
    //   329: iconst_0
    //   330: istore_3
    //   331: iload_3
    //   332: ifeq -> 95
    //   335: aload #9
    //   337: invokevirtual isInHorizontalChain : ()Z
    //   340: ifne -> 95
    //   343: aload_0
    //   344: aload_1
    //   345: aload #9
    //   347: iload_2
    //   348: invokestatic solveHorizontalMatchConstraint : (Landroidx/constraintlayout/solver/widgets/ConstraintWidget;Landroidx/constraintlayout/solver/widgets/analyzer/BasicMeasure$Measurer;Landroidx/constraintlayout/solver/widgets/ConstraintWidget;Z)V
    //   351: goto -> 95
    //   354: aload #9
    //   356: invokevirtual isMeasureRequested : ()Z
    //   359: ifeq -> 365
    //   362: goto -> 95
    //   365: aload #9
    //   367: getfield mLeft : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   370: astore #11
    //   372: aload #10
    //   374: aload #11
    //   376: if_acmpne -> 422
    //   379: aload #9
    //   381: getfield mRight : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   384: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   387: ifnonnull -> 422
    //   390: aload #11
    //   392: invokevirtual getMargin : ()I
    //   395: iload #5
    //   397: iadd
    //   398: istore_3
    //   399: aload #9
    //   401: iload_3
    //   402: aload #9
    //   404: invokevirtual getWidth : ()I
    //   407: iload_3
    //   408: iadd
    //   409: invokevirtual setFinalHorizontal : (II)V
    //   412: aload #9
    //   414: aload_1
    //   415: iload_2
    //   416: invokestatic horizontalSolvingPass : (Landroidx/constraintlayout/solver/widgets/ConstraintWidget;Landroidx/constraintlayout/solver/widgets/analyzer/BasicMeasure$Measurer;Z)V
    //   419: goto -> 95
    //   422: aload #9
    //   424: getfield mRight : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   427: astore #12
    //   429: aload #10
    //   431: aload #12
    //   433: if_acmpne -> 476
    //   436: aload #11
    //   438: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   441: ifnonnull -> 476
    //   444: iload #5
    //   446: aload #12
    //   448: invokevirtual getMargin : ()I
    //   451: isub
    //   452: istore_3
    //   453: aload #9
    //   455: iload_3
    //   456: aload #9
    //   458: invokevirtual getWidth : ()I
    //   461: isub
    //   462: iload_3
    //   463: invokevirtual setFinalHorizontal : (II)V
    //   466: aload #9
    //   468: aload_1
    //   469: iload_2
    //   470: invokestatic horizontalSolvingPass : (Landroidx/constraintlayout/solver/widgets/ConstraintWidget;Landroidx/constraintlayout/solver/widgets/analyzer/BasicMeasure$Measurer;Z)V
    //   473: goto -> 95
    //   476: aload #10
    //   478: aload #11
    //   480: if_acmpne -> 95
    //   483: aload #12
    //   485: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   488: astore #10
    //   490: aload #10
    //   492: ifnull -> 95
    //   495: aload #10
    //   497: invokevirtual hasFinalValue : ()Z
    //   500: ifeq -> 95
    //   503: aload #9
    //   505: invokevirtual isInHorizontalChain : ()Z
    //   508: ifne -> 95
    //   511: aload_1
    //   512: aload #9
    //   514: iload_2
    //   515: invokestatic solveHorizontalCenterConstraints : (Landroidx/constraintlayout/solver/widgets/analyzer/BasicMeasure$Measurer;Landroidx/constraintlayout/solver/widgets/ConstraintWidget;Z)V
    //   518: goto -> 95
    //   521: aload_0
    //   522: instanceof androidx/constraintlayout/solver/widgets/Guideline
    //   525: ifeq -> 529
    //   528: return
    //   529: aload #7
    //   531: invokevirtual getDependents : ()Ljava/util/HashSet;
    //   534: ifnull -> 958
    //   537: aload #7
    //   539: invokevirtual hasFinalValue : ()Z
    //   542: ifeq -> 958
    //   545: aload #7
    //   547: invokevirtual getDependents : ()Ljava/util/HashSet;
    //   550: invokevirtual iterator : ()Ljava/util/Iterator;
    //   553: astore #7
    //   555: aload #7
    //   557: invokeinterface hasNext : ()Z
    //   562: ifeq -> 958
    //   565: aload #7
    //   567: invokeinterface next : ()Ljava/lang/Object;
    //   572: checkcast androidx/constraintlayout/solver/widgets/ConstraintAnchor
    //   575: astore #8
    //   577: aload #8
    //   579: getfield mOwner : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   582: astore #9
    //   584: aload #9
    //   586: invokestatic canMeasure : (Landroidx/constraintlayout/solver/widgets/ConstraintWidget;)Z
    //   589: istore #6
    //   591: aload #9
    //   593: invokevirtual isMeasureRequested : ()Z
    //   596: ifeq -> 621
    //   599: iload #6
    //   601: ifeq -> 621
    //   604: aload #9
    //   606: aload_1
    //   607: new androidx/constraintlayout/solver/widgets/analyzer/BasicMeasure$Measure
    //   610: dup
    //   611: invokespecial <init> : ()V
    //   614: getstatic androidx/constraintlayout/solver/widgets/analyzer/BasicMeasure$Measure.SELF_DIMENSIONS : I
    //   617: invokestatic measure : (Landroidx/constraintlayout/solver/widgets/ConstraintWidget;Landroidx/constraintlayout/solver/widgets/analyzer/BasicMeasure$Measurer;Landroidx/constraintlayout/solver/widgets/analyzer/BasicMeasure$Measure;I)Z
    //   620: pop
    //   621: aload #8
    //   623: aload #9
    //   625: getfield mLeft : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   628: if_acmpne -> 654
    //   631: aload #9
    //   633: getfield mRight : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   636: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   639: astore #10
    //   641: aload #10
    //   643: ifnull -> 654
    //   646: aload #10
    //   648: invokevirtual hasFinalValue : ()Z
    //   651: ifne -> 687
    //   654: aload #8
    //   656: aload #9
    //   658: getfield mRight : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   661: if_acmpne -> 692
    //   664: aload #9
    //   666: getfield mLeft : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   669: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   672: astore #10
    //   674: aload #10
    //   676: ifnull -> 692
    //   679: aload #10
    //   681: invokevirtual hasFinalValue : ()Z
    //   684: ifeq -> 692
    //   687: iconst_1
    //   688: istore_3
    //   689: goto -> 694
    //   692: iconst_0
    //   693: istore_3
    //   694: aload #9
    //   696: invokevirtual getHorizontalDimensionBehaviour : ()Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   699: astore #10
    //   701: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   704: astore #11
    //   706: aload #10
    //   708: aload #11
    //   710: if_acmpne -> 814
    //   713: iload #6
    //   715: ifeq -> 721
    //   718: goto -> 814
    //   721: aload #9
    //   723: invokevirtual getHorizontalDimensionBehaviour : ()Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   726: aload #11
    //   728: if_acmpne -> 555
    //   731: aload #9
    //   733: getfield mMatchConstraintMaxWidth : I
    //   736: iflt -> 555
    //   739: aload #9
    //   741: getfield mMatchConstraintMinWidth : I
    //   744: iflt -> 555
    //   747: aload #9
    //   749: invokevirtual getVisibility : ()I
    //   752: bipush #8
    //   754: if_icmpeq -> 775
    //   757: aload #9
    //   759: getfield mMatchConstraintDefaultWidth : I
    //   762: ifne -> 555
    //   765: aload #9
    //   767: invokevirtual getDimensionRatio : ()F
    //   770: fconst_0
    //   771: fcmpl
    //   772: ifne -> 555
    //   775: aload #9
    //   777: invokevirtual isInHorizontalChain : ()Z
    //   780: ifne -> 555
    //   783: aload #9
    //   785: invokevirtual isInVirtualLayout : ()Z
    //   788: ifne -> 555
    //   791: iload_3
    //   792: ifeq -> 555
    //   795: aload #9
    //   797: invokevirtual isInHorizontalChain : ()Z
    //   800: ifne -> 555
    //   803: aload_0
    //   804: aload_1
    //   805: aload #9
    //   807: iload_2
    //   808: invokestatic solveHorizontalMatchConstraint : (Landroidx/constraintlayout/solver/widgets/ConstraintWidget;Landroidx/constraintlayout/solver/widgets/analyzer/BasicMeasure$Measurer;Landroidx/constraintlayout/solver/widgets/ConstraintWidget;Z)V
    //   811: goto -> 555
    //   814: aload #9
    //   816: invokevirtual isMeasureRequested : ()Z
    //   819: ifeq -> 825
    //   822: goto -> 555
    //   825: aload #9
    //   827: getfield mLeft : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   830: astore #10
    //   832: aload #8
    //   834: aload #10
    //   836: if_acmpne -> 882
    //   839: aload #9
    //   841: getfield mRight : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   844: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   847: ifnonnull -> 882
    //   850: aload #10
    //   852: invokevirtual getMargin : ()I
    //   855: iload #4
    //   857: iadd
    //   858: istore_3
    //   859: aload #9
    //   861: iload_3
    //   862: aload #9
    //   864: invokevirtual getWidth : ()I
    //   867: iload_3
    //   868: iadd
    //   869: invokevirtual setFinalHorizontal : (II)V
    //   872: aload #9
    //   874: aload_1
    //   875: iload_2
    //   876: invokestatic horizontalSolvingPass : (Landroidx/constraintlayout/solver/widgets/ConstraintWidget;Landroidx/constraintlayout/solver/widgets/analyzer/BasicMeasure$Measurer;Z)V
    //   879: goto -> 555
    //   882: aload #9
    //   884: getfield mRight : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   887: astore #11
    //   889: aload #8
    //   891: aload #11
    //   893: if_acmpne -> 936
    //   896: aload #10
    //   898: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   901: ifnonnull -> 936
    //   904: iload #4
    //   906: aload #11
    //   908: invokevirtual getMargin : ()I
    //   911: isub
    //   912: istore_3
    //   913: aload #9
    //   915: iload_3
    //   916: aload #9
    //   918: invokevirtual getWidth : ()I
    //   921: isub
    //   922: iload_3
    //   923: invokevirtual setFinalHorizontal : (II)V
    //   926: aload #9
    //   928: aload_1
    //   929: iload_2
    //   930: invokestatic horizontalSolvingPass : (Landroidx/constraintlayout/solver/widgets/ConstraintWidget;Landroidx/constraintlayout/solver/widgets/analyzer/BasicMeasure$Measurer;Z)V
    //   933: goto -> 555
    //   936: iload_3
    //   937: ifeq -> 555
    //   940: aload #9
    //   942: invokevirtual isInHorizontalChain : ()Z
    //   945: ifne -> 555
    //   948: aload_1
    //   949: aload #9
    //   951: iload_2
    //   952: invokestatic solveHorizontalCenterConstraints : (Landroidx/constraintlayout/solver/widgets/analyzer/BasicMeasure$Measurer;Landroidx/constraintlayout/solver/widgets/ConstraintWidget;Z)V
    //   955: goto -> 555
    //   958: return
  }
  
  private static void solveBarrier(Barrier paramBarrier, BasicMeasure.Measurer paramMeasurer, int paramInt, boolean paramBoolean) {
    if (paramBarrier.allSolved()) {
      if (paramInt == 0) {
        horizontalSolvingPass((ConstraintWidget)paramBarrier, paramMeasurer, paramBoolean);
        return;
      } 
      verticalSolvingPass((ConstraintWidget)paramBarrier, paramMeasurer);
    } 
  }
  
  public static boolean solveChain(ConstraintWidgetContainer paramConstraintWidgetContainer, LinearSystem paramLinearSystem, int paramInt1, int paramInt2, ChainHead paramChainHead, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3) {
    boolean bool = false;
    if (paramBoolean3)
      return false; 
    if (paramInt1 == 0) {
      if (!paramConstraintWidgetContainer.isResolvedHorizontally())
        return false; 
    } else if (!paramConstraintWidgetContainer.isResolvedVertically()) {
      return false;
    } 
    boolean bool1 = paramConstraintWidgetContainer.isRtl();
    ConstraintWidget constraintWidget1 = paramChainHead.getFirst();
    ConstraintWidget constraintWidget2 = paramChainHead.getLast();
    ConstraintWidget constraintWidget3 = paramChainHead.getFirstVisibleWidget();
    ConstraintWidget constraintWidget4 = paramChainHead.getLastVisibleWidget();
    ConstraintWidget constraintWidget5 = paramChainHead.getHead();
    ConstraintAnchor constraintAnchor1 = constraintWidget1.mListAnchors[paramInt2];
    ConstraintAnchor[] arrayOfConstraintAnchor = constraintWidget2.mListAnchors;
    int i = paramInt2 + 1;
    ConstraintAnchor constraintAnchor2 = arrayOfConstraintAnchor[i];
    ConstraintAnchor constraintAnchor3 = constraintAnchor1.mTarget;
    paramBoolean3 = bool;
    if (constraintAnchor3 != null) {
      if (constraintAnchor2.mTarget == null)
        return false; 
      paramBoolean3 = bool;
      if (constraintAnchor3.hasFinalValue()) {
        if (!constraintAnchor2.mTarget.hasFinalValue())
          return false; 
        paramBoolean3 = bool;
        if (constraintWidget3 != null) {
          Object object;
          if (constraintWidget4 == null)
            return false; 
          int m = constraintAnchor1.mTarget.getFinalValue() + constraintWidget3.mListAnchors[paramInt2].getMargin();
          int n = constraintAnchor2.mTarget.getFinalValue() - constraintWidget4.mListAnchors[i].getMargin();
          int i1 = n - m;
          if (i1 <= 0)
            return false; 
          BasicMeasure.Measure measure = new BasicMeasure.Measure();
          ConstraintWidget constraintWidget7 = constraintWidget1;
          int j = 0;
          byte b1 = 0;
          byte b2 = 0;
          int k = 0;
          ConstraintWidget constraintWidget6 = constraintWidget1;
          while (true) {
            constraintAnchor3 = null;
            if (!j) {
              ConstraintWidget constraintWidget;
              ConstraintAnchor constraintAnchor4 = constraintWidget7.mListAnchors[paramInt2];
              if (!canMeasure(constraintWidget7))
                return false; 
              if (constraintWidget7.mListDimensionBehaviors[paramInt1] == ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT)
                return false; 
              if (constraintWidget7.isMeasureRequested())
                ConstraintWidgetContainer.measure(constraintWidget7, paramConstraintWidgetContainer.getMeasurer(), measure, BasicMeasure.Measure.SELF_DIMENSIONS); 
              int i4 = constraintWidget7.mListAnchors[paramInt2].getMargin();
              if (paramInt1 == 0) {
                i3 = constraintWidget7.getWidth();
              } else {
                i3 = constraintWidget7.getHeight();
              } 
              k = k + i4 + i3 + constraintWidget7.mListAnchors[i].getMargin();
              int i3 = object + 1;
              i2 = b1;
              if (constraintWidget7.getVisibility() != 8)
                i2 = b1 + 1; 
              ConstraintAnchor constraintAnchor5 = (constraintWidget7.mListAnchors[i]).mTarget;
              constraintAnchor4 = constraintAnchor3;
              if (constraintAnchor5 != null) {
                ConstraintWidget constraintWidget8 = constraintAnchor5.mOwner;
                ConstraintAnchor[] arrayOfConstraintAnchor1 = constraintWidget8.mListAnchors;
                constraintAnchor4 = constraintAnchor3;
                if ((arrayOfConstraintAnchor1[paramInt2]).mTarget != null)
                  if ((arrayOfConstraintAnchor1[paramInt2]).mTarget.mOwner != constraintWidget7) {
                    constraintAnchor4 = constraintAnchor3;
                  } else {
                    constraintWidget = constraintWidget8;
                  }  
              } 
              if (constraintWidget != null) {
                constraintWidget7 = constraintWidget;
              } else {
                j = 1;
              } 
              continue;
            } 
            if (b1 == 0)
              return false; 
            if (b1 != i2)
              return false; 
            if (i1 < k)
              return false; 
            int i2 = i1 - k;
            if (paramBoolean1) {
              j = i2 / (b1 + 1);
            } else {
              j = i2;
              if (paramBoolean2) {
                j = i2;
                if (b1 > 2)
                  j = i2 / b1 - 1; 
              } 
            } 
            if (b1 == 1) {
              float f;
              if (paramInt1 == 0) {
                f = constraintWidget5.getHorizontalBiasPercent();
              } else {
                f = constraintWidget5.getVerticalBiasPercent();
              } 
              paramInt2 = (int)(m + 0.5F + j * f);
              if (paramInt1 == 0) {
                constraintWidget3.setFinalHorizontal(paramInt2, constraintWidget3.getWidth() + paramInt2);
              } else {
                constraintWidget3.setFinalVertical(paramInt2, constraintWidget3.getHeight() + paramInt2);
              } 
              horizontalSolvingPass(constraintWidget3, paramConstraintWidgetContainer.getMeasurer(), bool1);
              return true;
            } 
            if (paramBoolean1) {
              i2 = m + j;
              b1 = 0;
              constraintWidget1 = constraintWidget6;
              while (true)
                constraintWidget1 = constraintWidget6; 
            } else if (paramBoolean2) {
              if (b1 == 2) {
                if (paramInt1 == 0) {
                  constraintWidget3.setFinalHorizontal(m, constraintWidget3.getWidth() + m);
                  constraintWidget4.setFinalHorizontal(n - constraintWidget4.getWidth(), n);
                  horizontalSolvingPass(constraintWidget3, paramConstraintWidgetContainer.getMeasurer(), bool1);
                  horizontalSolvingPass(constraintWidget4, paramConstraintWidgetContainer.getMeasurer(), bool1);
                } else {
                  constraintWidget3.setFinalVertical(m, constraintWidget3.getHeight() + m);
                  constraintWidget4.setFinalVertical(n - constraintWidget4.getHeight(), n);
                  verticalSolvingPass(constraintWidget3, paramConstraintWidgetContainer.getMeasurer());
                  verticalSolvingPass(constraintWidget4, paramConstraintWidgetContainer.getMeasurer());
                } 
                return true;
              } 
              return false;
            } 
            paramBoolean3 = true;
            break;
            b1 = b2;
            object = SYNTHETIC_LOCAL_VARIABLE_13;
          } 
        } 
      } 
    } 
    return paramBoolean3;
  }
  
  private static void solveHorizontalCenterConstraints(BasicMeasure.Measurer paramMeasurer, ConstraintWidget paramConstraintWidget, boolean paramBoolean) {
    float f = paramConstraintWidget.getHorizontalBiasPercent();
    int i = paramConstraintWidget.mLeft.mTarget.getFinalValue();
    int j = paramConstraintWidget.mRight.mTarget.getFinalValue();
    int m = paramConstraintWidget.mLeft.getMargin();
    int k = paramConstraintWidget.mRight.getMargin();
    if (i == j) {
      f = 0.5F;
    } else {
      i = m + i;
      j -= k;
    } 
    m = paramConstraintWidget.getWidth();
    k = j - i - m;
    if (i > j)
      k = i - j - m; 
    int n = (int)(f * k + 0.5F) + i;
    k = n + m;
    if (i > j)
      k = n - m; 
    paramConstraintWidget.setFinalHorizontal(n, k);
    horizontalSolvingPass(paramConstraintWidget, paramMeasurer, paramBoolean);
  }
  
  private static void solveHorizontalMatchConstraint(ConstraintWidget paramConstraintWidget1, BasicMeasure.Measurer paramMeasurer, ConstraintWidget paramConstraintWidget2, boolean paramBoolean) {
    float f = paramConstraintWidget2.getHorizontalBiasPercent();
    int i = paramConstraintWidget2.mLeft.mTarget.getFinalValue() + paramConstraintWidget2.mLeft.getMargin();
    int j = paramConstraintWidget2.mRight.mTarget.getFinalValue() - paramConstraintWidget2.mRight.getMargin();
    if (j >= i) {
      int m = paramConstraintWidget2.getWidth();
      int k = m;
      if (paramConstraintWidget2.getVisibility() != 8) {
        int n = paramConstraintWidget2.mMatchConstraintDefaultWidth;
        if (n == 2) {
          if (paramConstraintWidget1 instanceof ConstraintWidgetContainer) {
            k = paramConstraintWidget1.getWidth();
          } else {
            k = paramConstraintWidget1.getParent().getWidth();
          } 
          k = (int)(paramConstraintWidget2.getHorizontalBiasPercent() * 0.5F * k);
        } else {
          k = m;
          if (n == 0)
            k = j - i; 
        } 
        m = Math.max(paramConstraintWidget2.mMatchConstraintMinWidth, k);
        n = paramConstraintWidget2.mMatchConstraintMaxWidth;
        k = m;
        if (n > 0)
          k = Math.min(n, m); 
      } 
      m = i + (int)(f * (j - i - k) + 0.5F);
      paramConstraintWidget2.setFinalHorizontal(m, k + m);
      horizontalSolvingPass(paramConstraintWidget2, paramMeasurer, paramBoolean);
    } 
  }
  
  private static void solveVerticalCenterConstraints(BasicMeasure.Measurer paramMeasurer, ConstraintWidget paramConstraintWidget) {
    float f = paramConstraintWidget.getVerticalBiasPercent();
    int i = paramConstraintWidget.mTop.mTarget.getFinalValue();
    int j = paramConstraintWidget.mBottom.mTarget.getFinalValue();
    int m = paramConstraintWidget.mTop.getMargin();
    int k = paramConstraintWidget.mBottom.getMargin();
    if (i == j) {
      f = 0.5F;
    } else {
      i = m + i;
      j -= k;
    } 
    int n = paramConstraintWidget.getHeight();
    k = j - i - n;
    if (i > j)
      k = i - j - n; 
    int i1 = (int)(f * k + 0.5F);
    k = i + i1;
    m = k + n;
    if (i > j) {
      k = i - i1;
      m = k - n;
    } 
    paramConstraintWidget.setFinalVertical(k, m);
    verticalSolvingPass(paramConstraintWidget, paramMeasurer);
  }
  
  private static void solveVerticalMatchConstraint(ConstraintWidget paramConstraintWidget1, BasicMeasure.Measurer paramMeasurer, ConstraintWidget paramConstraintWidget2) {
    float f = paramConstraintWidget2.getVerticalBiasPercent();
    int i = paramConstraintWidget2.mTop.mTarget.getFinalValue() + paramConstraintWidget2.mTop.getMargin();
    int j = paramConstraintWidget2.mBottom.mTarget.getFinalValue() - paramConstraintWidget2.mBottom.getMargin();
    if (j >= i) {
      int m = paramConstraintWidget2.getHeight();
      int k = m;
      if (paramConstraintWidget2.getVisibility() != 8) {
        int n = paramConstraintWidget2.mMatchConstraintDefaultHeight;
        if (n == 2) {
          if (paramConstraintWidget1 instanceof ConstraintWidgetContainer) {
            k = paramConstraintWidget1.getHeight();
          } else {
            k = paramConstraintWidget1.getParent().getHeight();
          } 
          k = (int)(f * 0.5F * k);
        } else {
          k = m;
          if (n == 0)
            k = j - i; 
        } 
        m = Math.max(paramConstraintWidget2.mMatchConstraintMinHeight, k);
        n = paramConstraintWidget2.mMatchConstraintMaxHeight;
        k = m;
        if (n > 0)
          k = Math.min(n, m); 
      } 
      m = i + (int)(f * (j - i - k) + 0.5F);
      paramConstraintWidget2.setFinalVertical(m, k + m);
      verticalSolvingPass(paramConstraintWidget2, paramMeasurer);
    } 
  }
  
  public static void solvingPass(ConstraintWidgetContainer paramConstraintWidgetContainer, BasicMeasure.Measurer paramMeasurer) {
    ConstraintWidget.DimensionBehaviour dimensionBehaviour2 = paramConstraintWidgetContainer.getHorizontalDimensionBehaviour();
    ConstraintWidget.DimensionBehaviour dimensionBehaviour1 = paramConstraintWidgetContainer.getVerticalDimensionBehaviour();
    paramConstraintWidgetContainer.resetFinalResolution();
    ArrayList<ConstraintWidget> arrayList = paramConstraintWidgetContainer.getChildren();
    int k = arrayList.size();
    boolean bool2 = false;
    int i;
    for (i = 0; i < k; i++)
      ((ConstraintWidget)arrayList.get(i)).resetFinalResolution(); 
    boolean bool = paramConstraintWidgetContainer.isRtl();
    if (dimensionBehaviour2 == ConstraintWidget.DimensionBehaviour.FIXED) {
      paramConstraintWidgetContainer.setFinalHorizontal(0, paramConstraintWidgetContainer.getWidth());
    } else {
      paramConstraintWidgetContainer.setFinalLeft(0);
    } 
    int j = 0;
    boolean bool1 = false;
    for (i = 0; j < k; i = m) {
      boolean bool3;
      int m;
      Guideline guideline;
      ConstraintWidget constraintWidget = arrayList.get(j);
      if (constraintWidget instanceof Guideline) {
        guideline = (Guideline)constraintWidget;
        bool3 = bool1;
        m = i;
        if (guideline.getOrientation() == 1) {
          if (guideline.getRelativeBegin() != -1) {
            guideline.setFinalValue(guideline.getRelativeBegin());
          } else if (guideline.getRelativeEnd() != -1 && paramConstraintWidgetContainer.isResolvedHorizontally()) {
            guideline.setFinalValue(paramConstraintWidgetContainer.getWidth() - guideline.getRelativeEnd());
          } else if (paramConstraintWidgetContainer.isResolvedHorizontally()) {
            guideline.setFinalValue((int)(guideline.getRelativePercent() * paramConstraintWidgetContainer.getWidth() + 0.5F));
          } 
          bool3 = true;
          m = i;
        } 
      } else {
        bool3 = bool1;
        m = i;
        if (guideline instanceof Barrier) {
          bool3 = bool1;
          m = i;
          if (((Barrier)guideline).getOrientation() == 0) {
            m = 1;
            bool3 = bool1;
          } 
        } 
      } 
      j++;
      bool1 = bool3;
    } 
    if (bool1)
      for (j = 0; j < k; j++) {
        ConstraintWidget constraintWidget = arrayList.get(j);
        if (constraintWidget instanceof Guideline) {
          Guideline guideline = (Guideline)constraintWidget;
          if (guideline.getOrientation() == 1)
            horizontalSolvingPass((ConstraintWidget)guideline, paramMeasurer, bool); 
        } 
      }  
    horizontalSolvingPass((ConstraintWidget)paramConstraintWidgetContainer, paramMeasurer, bool);
    if (i != 0)
      for (i = 0; i < k; i++) {
        ConstraintWidget constraintWidget = arrayList.get(i);
        if (constraintWidget instanceof Barrier) {
          Barrier barrier = (Barrier)constraintWidget;
          if (barrier.getOrientation() == 0)
            solveBarrier(barrier, paramMeasurer, 0, bool); 
        } 
      }  
    if (dimensionBehaviour1 == ConstraintWidget.DimensionBehaviour.FIXED) {
      paramConstraintWidgetContainer.setFinalVertical(0, paramConstraintWidgetContainer.getHeight());
    } else {
      paramConstraintWidgetContainer.setFinalTop(0);
    } 
    j = 0;
    bool1 = false;
    for (i = 0; j < k; i = m) {
      boolean bool3;
      int m;
      Guideline guideline;
      ConstraintWidget constraintWidget = arrayList.get(j);
      if (constraintWidget instanceof Guideline) {
        guideline = (Guideline)constraintWidget;
        bool3 = bool1;
        m = i;
        if (guideline.getOrientation() == 0) {
          if (guideline.getRelativeBegin() != -1) {
            guideline.setFinalValue(guideline.getRelativeBegin());
          } else if (guideline.getRelativeEnd() != -1 && paramConstraintWidgetContainer.isResolvedVertically()) {
            guideline.setFinalValue(paramConstraintWidgetContainer.getHeight() - guideline.getRelativeEnd());
          } else if (paramConstraintWidgetContainer.isResolvedVertically()) {
            guideline.setFinalValue((int)(guideline.getRelativePercent() * paramConstraintWidgetContainer.getHeight() + 0.5F));
          } 
          bool3 = true;
          m = i;
        } 
      } else {
        bool3 = bool1;
        m = i;
        if (guideline instanceof Barrier) {
          bool3 = bool1;
          m = i;
          if (((Barrier)guideline).getOrientation() == 1) {
            m = 1;
            bool3 = bool1;
          } 
        } 
      } 
      j++;
      bool1 = bool3;
    } 
    if (bool1)
      for (j = 0; j < k; j++) {
        ConstraintWidget constraintWidget = arrayList.get(j);
        if (constraintWidget instanceof Guideline) {
          Guideline guideline = (Guideline)constraintWidget;
          if (guideline.getOrientation() == 0)
            verticalSolvingPass((ConstraintWidget)guideline, paramMeasurer); 
        } 
      }  
    verticalSolvingPass((ConstraintWidget)paramConstraintWidgetContainer, paramMeasurer);
    j = bool2;
    if (i != 0) {
      i = 0;
      while (true) {
        j = bool2;
        if (i < k) {
          ConstraintWidget constraintWidget = arrayList.get(i);
          if (constraintWidget instanceof Barrier) {
            Barrier barrier = (Barrier)constraintWidget;
            if (barrier.getOrientation() == 1)
              solveBarrier(barrier, paramMeasurer, 1, bool); 
          } 
          i++;
          continue;
        } 
        break;
      } 
    } 
    while (j < k) {
      ConstraintWidget constraintWidget = arrayList.get(j);
      if (constraintWidget.isMeasureRequested() && canMeasure(constraintWidget)) {
        ConstraintWidgetContainer.measure(constraintWidget, paramMeasurer, measure, BasicMeasure.Measure.SELF_DIMENSIONS);
        horizontalSolvingPass(constraintWidget, paramMeasurer, bool);
        verticalSolvingPass(constraintWidget, paramMeasurer);
      } 
      j++;
    } 
  }
  
  private static void verticalSolvingPass(ConstraintWidget paramConstraintWidget, BasicMeasure.Measurer paramMeasurer) {
    // Byte code:
    //   0: aload_0
    //   1: instanceof androidx/constraintlayout/solver/widgets/ConstraintWidgetContainer
    //   4: ifne -> 37
    //   7: aload_0
    //   8: invokevirtual isMeasureRequested : ()Z
    //   11: ifeq -> 37
    //   14: aload_0
    //   15: invokestatic canMeasure : (Landroidx/constraintlayout/solver/widgets/ConstraintWidget;)Z
    //   18: ifeq -> 37
    //   21: aload_0
    //   22: aload_1
    //   23: new androidx/constraintlayout/solver/widgets/analyzer/BasicMeasure$Measure
    //   26: dup
    //   27: invokespecial <init> : ()V
    //   30: getstatic androidx/constraintlayout/solver/widgets/analyzer/BasicMeasure$Measure.SELF_DIMENSIONS : I
    //   33: invokestatic measure : (Landroidx/constraintlayout/solver/widgets/ConstraintWidget;Landroidx/constraintlayout/solver/widgets/analyzer/BasicMeasure$Measurer;Landroidx/constraintlayout/solver/widgets/analyzer/BasicMeasure$Measure;I)Z
    //   36: pop
    //   37: aload_0
    //   38: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.TOP : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   41: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   44: astore #7
    //   46: aload_0
    //   47: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.BOTTOM : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   50: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   53: astore #6
    //   55: aload #7
    //   57: invokevirtual getFinalValue : ()I
    //   60: istore #4
    //   62: aload #6
    //   64: invokevirtual getFinalValue : ()I
    //   67: istore_3
    //   68: aload #7
    //   70: invokevirtual getDependents : ()Ljava/util/HashSet;
    //   73: ifnull -> 508
    //   76: aload #7
    //   78: invokevirtual hasFinalValue : ()Z
    //   81: ifeq -> 508
    //   84: aload #7
    //   86: invokevirtual getDependents : ()Ljava/util/HashSet;
    //   89: invokevirtual iterator : ()Ljava/util/Iterator;
    //   92: astore #7
    //   94: aload #7
    //   96: invokeinterface hasNext : ()Z
    //   101: ifeq -> 508
    //   104: aload #7
    //   106: invokeinterface next : ()Ljava/lang/Object;
    //   111: checkcast androidx/constraintlayout/solver/widgets/ConstraintAnchor
    //   114: astore #9
    //   116: aload #9
    //   118: getfield mOwner : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   121: astore #8
    //   123: aload #8
    //   125: invokestatic canMeasure : (Landroidx/constraintlayout/solver/widgets/ConstraintWidget;)Z
    //   128: istore #5
    //   130: aload #8
    //   132: invokevirtual isMeasureRequested : ()Z
    //   135: ifeq -> 160
    //   138: iload #5
    //   140: ifeq -> 160
    //   143: aload #8
    //   145: aload_1
    //   146: new androidx/constraintlayout/solver/widgets/analyzer/BasicMeasure$Measure
    //   149: dup
    //   150: invokespecial <init> : ()V
    //   153: getstatic androidx/constraintlayout/solver/widgets/analyzer/BasicMeasure$Measure.SELF_DIMENSIONS : I
    //   156: invokestatic measure : (Landroidx/constraintlayout/solver/widgets/ConstraintWidget;Landroidx/constraintlayout/solver/widgets/analyzer/BasicMeasure$Measurer;Landroidx/constraintlayout/solver/widgets/analyzer/BasicMeasure$Measure;I)Z
    //   159: pop
    //   160: aload #8
    //   162: invokevirtual getVerticalDimensionBehaviour : ()Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   165: astore #10
    //   167: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   170: astore #11
    //   172: aload #10
    //   174: aload #11
    //   176: if_acmpne -> 352
    //   179: iload #5
    //   181: ifeq -> 187
    //   184: goto -> 352
    //   187: aload #8
    //   189: invokevirtual getVerticalDimensionBehaviour : ()Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   192: aload #11
    //   194: if_acmpne -> 94
    //   197: aload #8
    //   199: getfield mMatchConstraintMaxHeight : I
    //   202: iflt -> 94
    //   205: aload #8
    //   207: getfield mMatchConstraintMinHeight : I
    //   210: iflt -> 94
    //   213: aload #8
    //   215: invokevirtual getVisibility : ()I
    //   218: bipush #8
    //   220: if_icmpeq -> 241
    //   223: aload #8
    //   225: getfield mMatchConstraintDefaultHeight : I
    //   228: ifne -> 94
    //   231: aload #8
    //   233: invokevirtual getDimensionRatio : ()F
    //   236: fconst_0
    //   237: fcmpl
    //   238: ifne -> 94
    //   241: aload #8
    //   243: invokevirtual isInVerticalChain : ()Z
    //   246: ifne -> 94
    //   249: aload #8
    //   251: invokevirtual isInVirtualLayout : ()Z
    //   254: ifne -> 94
    //   257: aload #9
    //   259: aload #8
    //   261: getfield mTop : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   264: if_acmpne -> 290
    //   267: aload #8
    //   269: getfield mBottom : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   272: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   275: astore #10
    //   277: aload #10
    //   279: ifnull -> 290
    //   282: aload #10
    //   284: invokevirtual hasFinalValue : ()Z
    //   287: ifne -> 323
    //   290: aload #9
    //   292: aload #8
    //   294: getfield mBottom : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   297: if_acmpne -> 328
    //   300: aload #8
    //   302: getfield mTop : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   305: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   308: astore #9
    //   310: aload #9
    //   312: ifnull -> 328
    //   315: aload #9
    //   317: invokevirtual hasFinalValue : ()Z
    //   320: ifeq -> 328
    //   323: iconst_1
    //   324: istore_2
    //   325: goto -> 330
    //   328: iconst_0
    //   329: istore_2
    //   330: iload_2
    //   331: ifeq -> 94
    //   334: aload #8
    //   336: invokevirtual isInVerticalChain : ()Z
    //   339: ifne -> 94
    //   342: aload_0
    //   343: aload_1
    //   344: aload #8
    //   346: invokestatic solveVerticalMatchConstraint : (Landroidx/constraintlayout/solver/widgets/ConstraintWidget;Landroidx/constraintlayout/solver/widgets/analyzer/BasicMeasure$Measurer;Landroidx/constraintlayout/solver/widgets/ConstraintWidget;)V
    //   349: goto -> 94
    //   352: aload #8
    //   354: invokevirtual isMeasureRequested : ()Z
    //   357: ifeq -> 363
    //   360: goto -> 94
    //   363: aload #8
    //   365: getfield mTop : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   368: astore #10
    //   370: aload #9
    //   372: aload #10
    //   374: if_acmpne -> 419
    //   377: aload #8
    //   379: getfield mBottom : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   382: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   385: ifnonnull -> 419
    //   388: aload #10
    //   390: invokevirtual getMargin : ()I
    //   393: iload #4
    //   395: iadd
    //   396: istore_2
    //   397: aload #8
    //   399: iload_2
    //   400: aload #8
    //   402: invokevirtual getHeight : ()I
    //   405: iload_2
    //   406: iadd
    //   407: invokevirtual setFinalVertical : (II)V
    //   410: aload #8
    //   412: aload_1
    //   413: invokestatic verticalSolvingPass : (Landroidx/constraintlayout/solver/widgets/ConstraintWidget;Landroidx/constraintlayout/solver/widgets/analyzer/BasicMeasure$Measurer;)V
    //   416: goto -> 94
    //   419: aload #8
    //   421: getfield mBottom : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   424: astore #11
    //   426: aload #9
    //   428: aload #11
    //   430: if_acmpne -> 472
    //   433: aload #11
    //   435: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   438: ifnonnull -> 472
    //   441: iload #4
    //   443: aload #11
    //   445: invokevirtual getMargin : ()I
    //   448: isub
    //   449: istore_2
    //   450: aload #8
    //   452: iload_2
    //   453: aload #8
    //   455: invokevirtual getHeight : ()I
    //   458: isub
    //   459: iload_2
    //   460: invokevirtual setFinalVertical : (II)V
    //   463: aload #8
    //   465: aload_1
    //   466: invokestatic verticalSolvingPass : (Landroidx/constraintlayout/solver/widgets/ConstraintWidget;Landroidx/constraintlayout/solver/widgets/analyzer/BasicMeasure$Measurer;)V
    //   469: goto -> 94
    //   472: aload #9
    //   474: aload #10
    //   476: if_acmpne -> 94
    //   479: aload #11
    //   481: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   484: astore #9
    //   486: aload #9
    //   488: ifnull -> 94
    //   491: aload #9
    //   493: invokevirtual hasFinalValue : ()Z
    //   496: ifeq -> 94
    //   499: aload_1
    //   500: aload #8
    //   502: invokestatic solveVerticalCenterConstraints : (Landroidx/constraintlayout/solver/widgets/analyzer/BasicMeasure$Measurer;Landroidx/constraintlayout/solver/widgets/ConstraintWidget;)V
    //   505: goto -> 94
    //   508: aload_0
    //   509: instanceof androidx/constraintlayout/solver/widgets/Guideline
    //   512: ifeq -> 516
    //   515: return
    //   516: aload #6
    //   518: invokevirtual getDependents : ()Ljava/util/HashSet;
    //   521: ifnull -> 939
    //   524: aload #6
    //   526: invokevirtual hasFinalValue : ()Z
    //   529: ifeq -> 939
    //   532: aload #6
    //   534: invokevirtual getDependents : ()Ljava/util/HashSet;
    //   537: invokevirtual iterator : ()Ljava/util/Iterator;
    //   540: astore #6
    //   542: aload #6
    //   544: invokeinterface hasNext : ()Z
    //   549: ifeq -> 939
    //   552: aload #6
    //   554: invokeinterface next : ()Ljava/lang/Object;
    //   559: checkcast androidx/constraintlayout/solver/widgets/ConstraintAnchor
    //   562: astore #7
    //   564: aload #7
    //   566: getfield mOwner : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   569: astore #8
    //   571: aload #8
    //   573: invokestatic canMeasure : (Landroidx/constraintlayout/solver/widgets/ConstraintWidget;)Z
    //   576: istore #5
    //   578: aload #8
    //   580: invokevirtual isMeasureRequested : ()Z
    //   583: ifeq -> 608
    //   586: iload #5
    //   588: ifeq -> 608
    //   591: aload #8
    //   593: aload_1
    //   594: new androidx/constraintlayout/solver/widgets/analyzer/BasicMeasure$Measure
    //   597: dup
    //   598: invokespecial <init> : ()V
    //   601: getstatic androidx/constraintlayout/solver/widgets/analyzer/BasicMeasure$Measure.SELF_DIMENSIONS : I
    //   604: invokestatic measure : (Landroidx/constraintlayout/solver/widgets/ConstraintWidget;Landroidx/constraintlayout/solver/widgets/analyzer/BasicMeasure$Measurer;Landroidx/constraintlayout/solver/widgets/analyzer/BasicMeasure$Measure;I)Z
    //   607: pop
    //   608: aload #7
    //   610: aload #8
    //   612: getfield mTop : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   615: if_acmpne -> 641
    //   618: aload #8
    //   620: getfield mBottom : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   623: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   626: astore #9
    //   628: aload #9
    //   630: ifnull -> 641
    //   633: aload #9
    //   635: invokevirtual hasFinalValue : ()Z
    //   638: ifne -> 674
    //   641: aload #7
    //   643: aload #8
    //   645: getfield mBottom : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   648: if_acmpne -> 679
    //   651: aload #8
    //   653: getfield mTop : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   656: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   659: astore #9
    //   661: aload #9
    //   663: ifnull -> 679
    //   666: aload #9
    //   668: invokevirtual hasFinalValue : ()Z
    //   671: ifeq -> 679
    //   674: iconst_1
    //   675: istore_2
    //   676: goto -> 681
    //   679: iconst_0
    //   680: istore_2
    //   681: aload #8
    //   683: invokevirtual getVerticalDimensionBehaviour : ()Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   686: astore #9
    //   688: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   691: astore #10
    //   693: aload #9
    //   695: aload #10
    //   697: if_acmpne -> 800
    //   700: iload #5
    //   702: ifeq -> 708
    //   705: goto -> 800
    //   708: aload #8
    //   710: invokevirtual getVerticalDimensionBehaviour : ()Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   713: aload #10
    //   715: if_acmpne -> 542
    //   718: aload #8
    //   720: getfield mMatchConstraintMaxHeight : I
    //   723: iflt -> 542
    //   726: aload #8
    //   728: getfield mMatchConstraintMinHeight : I
    //   731: iflt -> 542
    //   734: aload #8
    //   736: invokevirtual getVisibility : ()I
    //   739: bipush #8
    //   741: if_icmpeq -> 762
    //   744: aload #8
    //   746: getfield mMatchConstraintDefaultHeight : I
    //   749: ifne -> 542
    //   752: aload #8
    //   754: invokevirtual getDimensionRatio : ()F
    //   757: fconst_0
    //   758: fcmpl
    //   759: ifne -> 542
    //   762: aload #8
    //   764: invokevirtual isInVerticalChain : ()Z
    //   767: ifne -> 542
    //   770: aload #8
    //   772: invokevirtual isInVirtualLayout : ()Z
    //   775: ifne -> 542
    //   778: iload_2
    //   779: ifeq -> 542
    //   782: aload #8
    //   784: invokevirtual isInVerticalChain : ()Z
    //   787: ifne -> 542
    //   790: aload_0
    //   791: aload_1
    //   792: aload #8
    //   794: invokestatic solveVerticalMatchConstraint : (Landroidx/constraintlayout/solver/widgets/ConstraintWidget;Landroidx/constraintlayout/solver/widgets/analyzer/BasicMeasure$Measurer;Landroidx/constraintlayout/solver/widgets/ConstraintWidget;)V
    //   797: goto -> 542
    //   800: aload #8
    //   802: invokevirtual isMeasureRequested : ()Z
    //   805: ifeq -> 811
    //   808: goto -> 542
    //   811: aload #8
    //   813: getfield mTop : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   816: astore #9
    //   818: aload #7
    //   820: aload #9
    //   822: if_acmpne -> 866
    //   825: aload #8
    //   827: getfield mBottom : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   830: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   833: ifnonnull -> 866
    //   836: aload #9
    //   838: invokevirtual getMargin : ()I
    //   841: iload_3
    //   842: iadd
    //   843: istore_2
    //   844: aload #8
    //   846: iload_2
    //   847: aload #8
    //   849: invokevirtual getHeight : ()I
    //   852: iload_2
    //   853: iadd
    //   854: invokevirtual setFinalVertical : (II)V
    //   857: aload #8
    //   859: aload_1
    //   860: invokestatic verticalSolvingPass : (Landroidx/constraintlayout/solver/widgets/ConstraintWidget;Landroidx/constraintlayout/solver/widgets/analyzer/BasicMeasure$Measurer;)V
    //   863: goto -> 542
    //   866: aload #8
    //   868: getfield mBottom : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   871: astore #10
    //   873: aload #7
    //   875: aload #10
    //   877: if_acmpne -> 918
    //   880: aload #9
    //   882: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   885: ifnonnull -> 918
    //   888: iload_3
    //   889: aload #10
    //   891: invokevirtual getMargin : ()I
    //   894: isub
    //   895: istore_2
    //   896: aload #8
    //   898: iload_2
    //   899: aload #8
    //   901: invokevirtual getHeight : ()I
    //   904: isub
    //   905: iload_2
    //   906: invokevirtual setFinalVertical : (II)V
    //   909: aload #8
    //   911: aload_1
    //   912: invokestatic verticalSolvingPass : (Landroidx/constraintlayout/solver/widgets/ConstraintWidget;Landroidx/constraintlayout/solver/widgets/analyzer/BasicMeasure$Measurer;)V
    //   915: goto -> 542
    //   918: iload_2
    //   919: ifeq -> 542
    //   922: aload #8
    //   924: invokevirtual isInVerticalChain : ()Z
    //   927: ifne -> 542
    //   930: aload_1
    //   931: aload #8
    //   933: invokestatic solveVerticalCenterConstraints : (Landroidx/constraintlayout/solver/widgets/analyzer/BasicMeasure$Measurer;Landroidx/constraintlayout/solver/widgets/ConstraintWidget;)V
    //   936: goto -> 542
    //   939: aload_0
    //   940: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.BASELINE : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   943: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   946: astore_0
    //   947: aload_0
    //   948: invokevirtual getDependents : ()Ljava/util/HashSet;
    //   951: ifnull -> 1090
    //   954: aload_0
    //   955: invokevirtual hasFinalValue : ()Z
    //   958: ifeq -> 1090
    //   961: aload_0
    //   962: invokevirtual getFinalValue : ()I
    //   965: istore_2
    //   966: aload_0
    //   967: invokevirtual getDependents : ()Ljava/util/HashSet;
    //   970: invokevirtual iterator : ()Ljava/util/Iterator;
    //   973: astore_0
    //   974: aload_0
    //   975: invokeinterface hasNext : ()Z
    //   980: ifeq -> 1090
    //   983: aload_0
    //   984: invokeinterface next : ()Ljava/lang/Object;
    //   989: checkcast androidx/constraintlayout/solver/widgets/ConstraintAnchor
    //   992: astore #6
    //   994: aload #6
    //   996: getfield mOwner : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   999: astore #7
    //   1001: aload #7
    //   1003: invokestatic canMeasure : (Landroidx/constraintlayout/solver/widgets/ConstraintWidget;)Z
    //   1006: istore #5
    //   1008: aload #7
    //   1010: invokevirtual isMeasureRequested : ()Z
    //   1013: ifeq -> 1038
    //   1016: iload #5
    //   1018: ifeq -> 1038
    //   1021: aload #7
    //   1023: aload_1
    //   1024: new androidx/constraintlayout/solver/widgets/analyzer/BasicMeasure$Measure
    //   1027: dup
    //   1028: invokespecial <init> : ()V
    //   1031: getstatic androidx/constraintlayout/solver/widgets/analyzer/BasicMeasure$Measure.SELF_DIMENSIONS : I
    //   1034: invokestatic measure : (Landroidx/constraintlayout/solver/widgets/ConstraintWidget;Landroidx/constraintlayout/solver/widgets/analyzer/BasicMeasure$Measurer;Landroidx/constraintlayout/solver/widgets/analyzer/BasicMeasure$Measure;I)Z
    //   1037: pop
    //   1038: aload #7
    //   1040: invokevirtual getVerticalDimensionBehaviour : ()Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   1043: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   1046: if_acmpne -> 1054
    //   1049: iload #5
    //   1051: ifeq -> 974
    //   1054: aload #7
    //   1056: invokevirtual isMeasureRequested : ()Z
    //   1059: ifeq -> 1065
    //   1062: goto -> 974
    //   1065: aload #6
    //   1067: aload #7
    //   1069: getfield mBaseline : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1072: if_acmpne -> 974
    //   1075: aload #7
    //   1077: iload_2
    //   1078: invokevirtual setFinalBaseline : (I)V
    //   1081: aload #7
    //   1083: aload_1
    //   1084: invokestatic verticalSolvingPass : (Landroidx/constraintlayout/solver/widgets/ConstraintWidget;Landroidx/constraintlayout/solver/widgets/analyzer/BasicMeasure$Measurer;)V
    //   1087: goto -> 974
    //   1090: return
    //   1091: astore_0
    //   1092: aload_0
    //   1093: athrow
    // Exception table:
    //   from	to	target	type
    //   1081	1087	1091	finally
  }
}


/* Location:              C:\soft\dex2jar-2.0\BabyBus TV_Kids Videos & Games-dex2jar.jar!\androidx\constraintlayout\solver\widgets\analyzer\Direct.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */