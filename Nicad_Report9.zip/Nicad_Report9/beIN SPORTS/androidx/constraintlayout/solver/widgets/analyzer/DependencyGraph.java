package androidx.constraintlayout.solver.widgets.analyzer;

import androidx.constraintlayout.solver.widgets.ConstraintWidget;
import androidx.constraintlayout.solver.widgets.ConstraintWidgetContainer;
import androidx.constraintlayout.solver.widgets.WidgetContainer;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;

public class DependencyGraph {
  private static final boolean USE_GROUPS = true;
  
  private ConstraintWidgetContainer container;
  
  private ConstraintWidgetContainer mContainer;
  
  ArrayList<RunGroup> mGroups = new ArrayList<RunGroup>();
  
  private BasicMeasure.Measure mMeasure = new BasicMeasure.Measure();
  
  private BasicMeasure.Measurer mMeasurer = null;
  
  private boolean mNeedBuildGraph = true;
  
  private boolean mNeedRedoMeasures = true;
  
  private ArrayList<WidgetRun> mRuns = new ArrayList<WidgetRun>();
  
  private ArrayList<RunGroup> runGroups = new ArrayList<RunGroup>();
  
  public DependencyGraph(ConstraintWidgetContainer paramConstraintWidgetContainer) {
    this.container = paramConstraintWidgetContainer;
    this.mContainer = paramConstraintWidgetContainer;
  }
  
  private void applyGroup(DependencyNode paramDependencyNode1, int paramInt1, int paramInt2, DependencyNode paramDependencyNode2, ArrayList<RunGroup> paramArrayList, RunGroup paramRunGroup) {
    WidgetRun widgetRun = paramDependencyNode1.run;
    if (widgetRun.runGroup == null) {
      ConstraintWidgetContainer constraintWidgetContainer = this.container;
      if (widgetRun != ((ConstraintWidget)constraintWidgetContainer).horizontalRun) {
        if (widgetRun == ((ConstraintWidget)constraintWidgetContainer).verticalRun)
          return; 
        RunGroup runGroup = paramRunGroup;
        if (paramRunGroup == null) {
          runGroup = new RunGroup(widgetRun, paramInt2);
          paramArrayList.add(runGroup);
        } 
        widgetRun.runGroup = runGroup;
        runGroup.add(widgetRun);
        for (Dependency dependency : widgetRun.start.dependencies) {
          if (dependency instanceof DependencyNode)
            applyGroup((DependencyNode)dependency, paramInt1, 0, paramDependencyNode2, paramArrayList, runGroup); 
        } 
        for (Dependency dependency : widgetRun.end.dependencies) {
          if (dependency instanceof DependencyNode)
            applyGroup((DependencyNode)dependency, paramInt1, 1, paramDependencyNode2, paramArrayList, runGroup); 
        } 
        if (paramInt1 == 1 && widgetRun instanceof VerticalWidgetRun)
          for (Dependency dependency : ((VerticalWidgetRun)widgetRun).baseline.dependencies) {
            if (dependency instanceof DependencyNode)
              applyGroup((DependencyNode)dependency, paramInt1, 2, paramDependencyNode2, paramArrayList, runGroup); 
          }  
        for (DependencyNode dependencyNode : widgetRun.start.targets) {
          if (dependencyNode == paramDependencyNode2)
            runGroup.dual = true; 
          applyGroup(dependencyNode, paramInt1, 0, paramDependencyNode2, paramArrayList, runGroup);
        } 
        for (DependencyNode dependencyNode : widgetRun.end.targets) {
          if (dependencyNode == paramDependencyNode2)
            runGroup.dual = true; 
          applyGroup(dependencyNode, paramInt1, 1, paramDependencyNode2, paramArrayList, runGroup);
        } 
        if (paramInt1 == 1 && widgetRun instanceof VerticalWidgetRun) {
          Iterator<DependencyNode> iterator = ((VerticalWidgetRun)widgetRun).baseline.targets.iterator();
          while (true) {
            if (iterator.hasNext()) {
              DependencyNode dependencyNode = iterator.next();
              try {
                applyGroup(dependencyNode, paramInt1, 2, paramDependencyNode2, paramArrayList, runGroup);
              } finally {}
              continue;
            } 
            return;
          } 
        } 
      } 
    } 
  }
  
  private boolean basicMeasureWidgets(ConstraintWidgetContainer paramConstraintWidgetContainer) {
    // Byte code:
    //   0: aload_1
    //   1: getfield mChildren : Ljava/util/ArrayList;
    //   4: invokevirtual iterator : ()Ljava/util/Iterator;
    //   7: astore #11
    //   9: aload #11
    //   11: invokeinterface hasNext : ()Z
    //   16: ifeq -> 1604
    //   19: aload #11
    //   21: invokeinterface next : ()Ljava/lang/Object;
    //   26: checkcast androidx/constraintlayout/solver/widgets/ConstraintWidget
    //   29: astore #12
    //   31: aload #12
    //   33: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   36: astore #9
    //   38: aload #9
    //   40: iconst_0
    //   41: aaload
    //   42: astore #8
    //   44: aload #9
    //   46: iconst_1
    //   47: aaload
    //   48: astore #10
    //   50: aload #12
    //   52: invokevirtual getVisibility : ()I
    //   55: bipush #8
    //   57: if_icmpne -> 69
    //   60: aload #12
    //   62: iconst_1
    //   63: putfield measured : Z
    //   66: goto -> 9
    //   69: aload #12
    //   71: getfield mMatchConstraintPercentWidth : F
    //   74: fconst_1
    //   75: fcmpg
    //   76: ifge -> 93
    //   79: aload #8
    //   81: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   84: if_acmpne -> 93
    //   87: aload #12
    //   89: iconst_2
    //   90: putfield mMatchConstraintDefaultWidth : I
    //   93: aload #12
    //   95: getfield mMatchConstraintPercentHeight : F
    //   98: fconst_1
    //   99: fcmpg
    //   100: ifge -> 117
    //   103: aload #10
    //   105: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   108: if_acmpne -> 117
    //   111: aload #12
    //   113: iconst_2
    //   114: putfield mMatchConstraintDefaultHeight : I
    //   117: aload #12
    //   119: invokevirtual getDimensionRatio : ()F
    //   122: fconst_0
    //   123: fcmpl
    //   124: ifle -> 238
    //   127: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   130: astore #9
    //   132: aload #8
    //   134: aload #9
    //   136: if_acmpne -> 164
    //   139: aload #10
    //   141: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   144: if_acmpeq -> 155
    //   147: aload #10
    //   149: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.FIXED : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   152: if_acmpne -> 164
    //   155: aload #12
    //   157: iconst_3
    //   158: putfield mMatchConstraintDefaultWidth : I
    //   161: goto -> 238
    //   164: aload #10
    //   166: aload #9
    //   168: if_acmpne -> 196
    //   171: aload #8
    //   173: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   176: if_acmpeq -> 187
    //   179: aload #8
    //   181: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.FIXED : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   184: if_acmpne -> 196
    //   187: aload #12
    //   189: iconst_3
    //   190: putfield mMatchConstraintDefaultHeight : I
    //   193: goto -> 238
    //   196: aload #8
    //   198: aload #9
    //   200: if_acmpne -> 238
    //   203: aload #10
    //   205: aload #9
    //   207: if_acmpne -> 238
    //   210: aload #12
    //   212: getfield mMatchConstraintDefaultWidth : I
    //   215: ifne -> 224
    //   218: aload #12
    //   220: iconst_3
    //   221: putfield mMatchConstraintDefaultWidth : I
    //   224: aload #12
    //   226: getfield mMatchConstraintDefaultHeight : I
    //   229: ifne -> 238
    //   232: aload #12
    //   234: iconst_3
    //   235: putfield mMatchConstraintDefaultHeight : I
    //   238: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   241: astore #13
    //   243: aload #8
    //   245: astore #9
    //   247: aload #8
    //   249: aload #13
    //   251: if_acmpne -> 298
    //   254: aload #8
    //   256: astore #9
    //   258: aload #12
    //   260: getfield mMatchConstraintDefaultWidth : I
    //   263: iconst_1
    //   264: if_icmpne -> 298
    //   267: aload #12
    //   269: getfield mLeft : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   272: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   275: ifnull -> 293
    //   278: aload #8
    //   280: astore #9
    //   282: aload #12
    //   284: getfield mRight : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   287: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   290: ifnonnull -> 298
    //   293: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   296: astore #9
    //   298: aload #10
    //   300: astore #8
    //   302: aload #10
    //   304: aload #13
    //   306: if_acmpne -> 353
    //   309: aload #10
    //   311: astore #8
    //   313: aload #12
    //   315: getfield mMatchConstraintDefaultHeight : I
    //   318: iconst_1
    //   319: if_icmpne -> 353
    //   322: aload #12
    //   324: getfield mTop : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   327: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   330: ifnull -> 348
    //   333: aload #10
    //   335: astore #8
    //   337: aload #12
    //   339: getfield mBottom : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   342: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   345: ifnonnull -> 353
    //   348: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   351: astore #8
    //   353: aload #12
    //   355: getfield horizontalRun : Landroidx/constraintlayout/solver/widgets/analyzer/HorizontalWidgetRun;
    //   358: astore #10
    //   360: aload #10
    //   362: aload #9
    //   364: putfield dimensionBehavior : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   367: aload #12
    //   369: getfield mMatchConstraintDefaultWidth : I
    //   372: istore #4
    //   374: aload #10
    //   376: iload #4
    //   378: putfield matchConstraintsType : I
    //   381: aload #12
    //   383: getfield verticalRun : Landroidx/constraintlayout/solver/widgets/analyzer/VerticalWidgetRun;
    //   386: astore #10
    //   388: aload #10
    //   390: aload #8
    //   392: putfield dimensionBehavior : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   395: aload #12
    //   397: getfield mMatchConstraintDefaultHeight : I
    //   400: istore #5
    //   402: aload #10
    //   404: iload #5
    //   406: putfield matchConstraintsType : I
    //   409: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.MATCH_PARENT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   412: astore #10
    //   414: aload #9
    //   416: aload #10
    //   418: if_acmpeq -> 437
    //   421: aload #9
    //   423: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.FIXED : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   426: if_acmpeq -> 437
    //   429: aload #9
    //   431: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   434: if_acmpne -> 463
    //   437: aload #8
    //   439: aload #10
    //   441: if_acmpeq -> 1433
    //   444: aload #8
    //   446: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.FIXED : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   449: if_acmpeq -> 1433
    //   452: aload #8
    //   454: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   457: if_acmpne -> 463
    //   460: goto -> 1433
    //   463: aload #9
    //   465: aload #13
    //   467: if_acmpne -> 824
    //   470: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   473: astore #14
    //   475: aload #8
    //   477: aload #14
    //   479: if_acmpeq -> 490
    //   482: aload #8
    //   484: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.FIXED : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   487: if_acmpne -> 824
    //   490: iload #4
    //   492: iconst_3
    //   493: if_icmpne -> 597
    //   496: aload #8
    //   498: aload #14
    //   500: if_acmpne -> 515
    //   503: aload_0
    //   504: aload #12
    //   506: aload #14
    //   508: iconst_0
    //   509: aload #14
    //   511: iconst_0
    //   512: invokespecial measure : (Landroidx/constraintlayout/solver/widgets/ConstraintWidget;Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;ILandroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;I)V
    //   515: aload #12
    //   517: invokevirtual getHeight : ()I
    //   520: istore #4
    //   522: iload #4
    //   524: i2f
    //   525: aload #12
    //   527: getfield mDimensionRatio : F
    //   530: fmul
    //   531: ldc 0.5
    //   533: fadd
    //   534: f2i
    //   535: istore #5
    //   537: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.FIXED : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   540: astore #8
    //   542: aload_0
    //   543: aload #12
    //   545: aload #8
    //   547: iload #5
    //   549: aload #8
    //   551: iload #4
    //   553: invokespecial measure : (Landroidx/constraintlayout/solver/widgets/ConstraintWidget;Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;ILandroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;I)V
    //   556: aload #12
    //   558: getfield horizontalRun : Landroidx/constraintlayout/solver/widgets/analyzer/HorizontalWidgetRun;
    //   561: getfield dimension : Landroidx/constraintlayout/solver/widgets/analyzer/DimensionDependency;
    //   564: aload #12
    //   566: invokevirtual getWidth : ()I
    //   569: invokevirtual resolve : (I)V
    //   572: aload #12
    //   574: getfield verticalRun : Landroidx/constraintlayout/solver/widgets/analyzer/VerticalWidgetRun;
    //   577: getfield dimension : Landroidx/constraintlayout/solver/widgets/analyzer/DimensionDependency;
    //   580: aload #12
    //   582: invokevirtual getHeight : ()I
    //   585: invokevirtual resolve : (I)V
    //   588: aload #12
    //   590: iconst_1
    //   591: putfield measured : Z
    //   594: goto -> 9
    //   597: iload #4
    //   599: iconst_1
    //   600: if_icmpne -> 634
    //   603: aload_0
    //   604: aload #12
    //   606: aload #14
    //   608: iconst_0
    //   609: aload #8
    //   611: iconst_0
    //   612: invokespecial measure : (Landroidx/constraintlayout/solver/widgets/ConstraintWidget;Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;ILandroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;I)V
    //   615: aload #12
    //   617: getfield horizontalRun : Landroidx/constraintlayout/solver/widgets/analyzer/HorizontalWidgetRun;
    //   620: getfield dimension : Landroidx/constraintlayout/solver/widgets/analyzer/DimensionDependency;
    //   623: aload #12
    //   625: invokevirtual getWidth : ()I
    //   628: putfield wrapValue : I
    //   631: goto -> 9
    //   634: iload #4
    //   636: iconst_2
    //   637: if_icmpne -> 744
    //   640: aload_1
    //   641: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   644: astore #14
    //   646: aload #14
    //   648: iconst_0
    //   649: aaload
    //   650: astore #15
    //   652: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.FIXED : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   655: astore #16
    //   657: aload #15
    //   659: aload #16
    //   661: if_acmpeq -> 673
    //   664: aload #14
    //   666: iconst_0
    //   667: aaload
    //   668: aload #10
    //   670: if_acmpne -> 824
    //   673: aload_0
    //   674: aload #12
    //   676: aload #16
    //   678: aload #12
    //   680: getfield mMatchConstraintPercentWidth : F
    //   683: aload_1
    //   684: invokevirtual getWidth : ()I
    //   687: i2f
    //   688: fmul
    //   689: ldc 0.5
    //   691: fadd
    //   692: f2i
    //   693: aload #8
    //   695: aload #12
    //   697: invokevirtual getHeight : ()I
    //   700: invokespecial measure : (Landroidx/constraintlayout/solver/widgets/ConstraintWidget;Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;ILandroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;I)V
    //   703: aload #12
    //   705: getfield horizontalRun : Landroidx/constraintlayout/solver/widgets/analyzer/HorizontalWidgetRun;
    //   708: getfield dimension : Landroidx/constraintlayout/solver/widgets/analyzer/DimensionDependency;
    //   711: aload #12
    //   713: invokevirtual getWidth : ()I
    //   716: invokevirtual resolve : (I)V
    //   719: aload #12
    //   721: getfield verticalRun : Landroidx/constraintlayout/solver/widgets/analyzer/VerticalWidgetRun;
    //   724: getfield dimension : Landroidx/constraintlayout/solver/widgets/analyzer/DimensionDependency;
    //   727: aload #12
    //   729: invokevirtual getHeight : ()I
    //   732: invokevirtual resolve : (I)V
    //   735: aload #12
    //   737: iconst_1
    //   738: putfield measured : Z
    //   741: goto -> 9
    //   744: aload #12
    //   746: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   749: astore #15
    //   751: aload #15
    //   753: iconst_0
    //   754: aaload
    //   755: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   758: ifnull -> 771
    //   761: aload #15
    //   763: iconst_1
    //   764: aaload
    //   765: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   768: ifnonnull -> 824
    //   771: aload_0
    //   772: aload #12
    //   774: aload #14
    //   776: iconst_0
    //   777: aload #8
    //   779: iconst_0
    //   780: invokespecial measure : (Landroidx/constraintlayout/solver/widgets/ConstraintWidget;Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;ILandroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;I)V
    //   783: aload #12
    //   785: getfield horizontalRun : Landroidx/constraintlayout/solver/widgets/analyzer/HorizontalWidgetRun;
    //   788: getfield dimension : Landroidx/constraintlayout/solver/widgets/analyzer/DimensionDependency;
    //   791: aload #12
    //   793: invokevirtual getWidth : ()I
    //   796: invokevirtual resolve : (I)V
    //   799: aload #12
    //   801: getfield verticalRun : Landroidx/constraintlayout/solver/widgets/analyzer/VerticalWidgetRun;
    //   804: getfield dimension : Landroidx/constraintlayout/solver/widgets/analyzer/DimensionDependency;
    //   807: aload #12
    //   809: invokevirtual getHeight : ()I
    //   812: invokevirtual resolve : (I)V
    //   815: aload #12
    //   817: iconst_1
    //   818: putfield measured : Z
    //   821: goto -> 9
    //   824: aload #8
    //   826: aload #13
    //   828: if_acmpne -> 1204
    //   831: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   834: astore #14
    //   836: aload #9
    //   838: aload #14
    //   840: if_acmpeq -> 851
    //   843: aload #9
    //   845: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.FIXED : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   848: if_acmpne -> 1204
    //   851: iload #5
    //   853: iconst_3
    //   854: if_icmpne -> 975
    //   857: aload #9
    //   859: aload #14
    //   861: if_acmpne -> 876
    //   864: aload_0
    //   865: aload #12
    //   867: aload #14
    //   869: iconst_0
    //   870: aload #14
    //   872: iconst_0
    //   873: invokespecial measure : (Landroidx/constraintlayout/solver/widgets/ConstraintWidget;Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;ILandroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;I)V
    //   876: aload #12
    //   878: invokevirtual getWidth : ()I
    //   881: istore #4
    //   883: aload #12
    //   885: getfield mDimensionRatio : F
    //   888: fstore_3
    //   889: fload_3
    //   890: fstore_2
    //   891: aload #12
    //   893: invokevirtual getDimensionRatioSide : ()I
    //   896: iconst_m1
    //   897: if_icmpne -> 904
    //   900: fconst_1
    //   901: fload_3
    //   902: fdiv
    //   903: fstore_2
    //   904: iload #4
    //   906: i2f
    //   907: fload_2
    //   908: fmul
    //   909: ldc 0.5
    //   911: fadd
    //   912: f2i
    //   913: istore #5
    //   915: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.FIXED : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   918: astore #8
    //   920: aload_0
    //   921: aload #12
    //   923: aload #8
    //   925: iload #4
    //   927: aload #8
    //   929: iload #5
    //   931: invokespecial measure : (Landroidx/constraintlayout/solver/widgets/ConstraintWidget;Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;ILandroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;I)V
    //   934: aload #12
    //   936: getfield horizontalRun : Landroidx/constraintlayout/solver/widgets/analyzer/HorizontalWidgetRun;
    //   939: getfield dimension : Landroidx/constraintlayout/solver/widgets/analyzer/DimensionDependency;
    //   942: aload #12
    //   944: invokevirtual getWidth : ()I
    //   947: invokevirtual resolve : (I)V
    //   950: aload #12
    //   952: getfield verticalRun : Landroidx/constraintlayout/solver/widgets/analyzer/VerticalWidgetRun;
    //   955: getfield dimension : Landroidx/constraintlayout/solver/widgets/analyzer/DimensionDependency;
    //   958: aload #12
    //   960: invokevirtual getHeight : ()I
    //   963: invokevirtual resolve : (I)V
    //   966: aload #12
    //   968: iconst_1
    //   969: putfield measured : Z
    //   972: goto -> 9
    //   975: iload #5
    //   977: iconst_1
    //   978: if_icmpne -> 1012
    //   981: aload_0
    //   982: aload #12
    //   984: aload #9
    //   986: iconst_0
    //   987: aload #14
    //   989: iconst_0
    //   990: invokespecial measure : (Landroidx/constraintlayout/solver/widgets/ConstraintWidget;Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;ILandroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;I)V
    //   993: aload #12
    //   995: getfield verticalRun : Landroidx/constraintlayout/solver/widgets/analyzer/VerticalWidgetRun;
    //   998: getfield dimension : Landroidx/constraintlayout/solver/widgets/analyzer/DimensionDependency;
    //   1001: aload #12
    //   1003: invokevirtual getHeight : ()I
    //   1006: putfield wrapValue : I
    //   1009: goto -> 9
    //   1012: iload #5
    //   1014: iconst_2
    //   1015: if_icmpne -> 1124
    //   1018: aload_1
    //   1019: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   1022: astore #14
    //   1024: aload #14
    //   1026: iconst_1
    //   1027: aaload
    //   1028: astore #15
    //   1030: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.FIXED : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   1033: astore #16
    //   1035: aload #15
    //   1037: aload #16
    //   1039: if_acmpeq -> 1051
    //   1042: aload #14
    //   1044: iconst_1
    //   1045: aaload
    //   1046: aload #10
    //   1048: if_acmpne -> 1204
    //   1051: aload #12
    //   1053: getfield mMatchConstraintPercentHeight : F
    //   1056: fstore_2
    //   1057: aload_0
    //   1058: aload #12
    //   1060: aload #9
    //   1062: aload #12
    //   1064: invokevirtual getWidth : ()I
    //   1067: aload #16
    //   1069: fload_2
    //   1070: aload_1
    //   1071: invokevirtual getHeight : ()I
    //   1074: i2f
    //   1075: fmul
    //   1076: ldc 0.5
    //   1078: fadd
    //   1079: f2i
    //   1080: invokespecial measure : (Landroidx/constraintlayout/solver/widgets/ConstraintWidget;Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;ILandroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;I)V
    //   1083: aload #12
    //   1085: getfield horizontalRun : Landroidx/constraintlayout/solver/widgets/analyzer/HorizontalWidgetRun;
    //   1088: getfield dimension : Landroidx/constraintlayout/solver/widgets/analyzer/DimensionDependency;
    //   1091: aload #12
    //   1093: invokevirtual getWidth : ()I
    //   1096: invokevirtual resolve : (I)V
    //   1099: aload #12
    //   1101: getfield verticalRun : Landroidx/constraintlayout/solver/widgets/analyzer/VerticalWidgetRun;
    //   1104: getfield dimension : Landroidx/constraintlayout/solver/widgets/analyzer/DimensionDependency;
    //   1107: aload #12
    //   1109: invokevirtual getHeight : ()I
    //   1112: invokevirtual resolve : (I)V
    //   1115: aload #12
    //   1117: iconst_1
    //   1118: putfield measured : Z
    //   1121: goto -> 9
    //   1124: aload #12
    //   1126: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1129: astore #10
    //   1131: aload #10
    //   1133: iconst_2
    //   1134: aaload
    //   1135: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1138: ifnull -> 1151
    //   1141: aload #10
    //   1143: iconst_3
    //   1144: aaload
    //   1145: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1148: ifnonnull -> 1204
    //   1151: aload_0
    //   1152: aload #12
    //   1154: aload #14
    //   1156: iconst_0
    //   1157: aload #8
    //   1159: iconst_0
    //   1160: invokespecial measure : (Landroidx/constraintlayout/solver/widgets/ConstraintWidget;Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;ILandroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;I)V
    //   1163: aload #12
    //   1165: getfield horizontalRun : Landroidx/constraintlayout/solver/widgets/analyzer/HorizontalWidgetRun;
    //   1168: getfield dimension : Landroidx/constraintlayout/solver/widgets/analyzer/DimensionDependency;
    //   1171: aload #12
    //   1173: invokevirtual getWidth : ()I
    //   1176: invokevirtual resolve : (I)V
    //   1179: aload #12
    //   1181: getfield verticalRun : Landroidx/constraintlayout/solver/widgets/analyzer/VerticalWidgetRun;
    //   1184: getfield dimension : Landroidx/constraintlayout/solver/widgets/analyzer/DimensionDependency;
    //   1187: aload #12
    //   1189: invokevirtual getHeight : ()I
    //   1192: invokevirtual resolve : (I)V
    //   1195: aload #12
    //   1197: iconst_1
    //   1198: putfield measured : Z
    //   1201: goto -> 9
    //   1204: aload #9
    //   1206: aload #13
    //   1208: if_acmpne -> 9
    //   1211: aload #8
    //   1213: aload #13
    //   1215: if_acmpne -> 9
    //   1218: iload #4
    //   1220: iconst_1
    //   1221: if_icmpeq -> 1381
    //   1224: iload #5
    //   1226: iconst_1
    //   1227: if_icmpne -> 1233
    //   1230: goto -> 1381
    //   1233: iload #5
    //   1235: iconst_2
    //   1236: if_icmpne -> 9
    //   1239: iload #4
    //   1241: iconst_2
    //   1242: if_icmpne -> 9
    //   1245: aload_1
    //   1246: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   1249: astore #8
    //   1251: aload #8
    //   1253: iconst_0
    //   1254: aaload
    //   1255: astore #9
    //   1257: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.FIXED : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   1260: astore #10
    //   1262: aload #9
    //   1264: aload #10
    //   1266: if_acmpeq -> 1278
    //   1269: aload #8
    //   1271: iconst_0
    //   1272: aaload
    //   1273: aload #10
    //   1275: if_acmpne -> 9
    //   1278: aload #8
    //   1280: iconst_1
    //   1281: aaload
    //   1282: aload #10
    //   1284: if_acmpeq -> 1296
    //   1287: aload #8
    //   1289: iconst_1
    //   1290: aaload
    //   1291: aload #10
    //   1293: if_acmpne -> 9
    //   1296: aload #12
    //   1298: getfield mMatchConstraintPercentWidth : F
    //   1301: fstore_2
    //   1302: aload #12
    //   1304: getfield mMatchConstraintPercentHeight : F
    //   1307: fstore_3
    //   1308: aload_0
    //   1309: aload #12
    //   1311: aload #10
    //   1313: fload_2
    //   1314: aload_1
    //   1315: invokevirtual getWidth : ()I
    //   1318: i2f
    //   1319: fmul
    //   1320: ldc 0.5
    //   1322: fadd
    //   1323: f2i
    //   1324: aload #10
    //   1326: fload_3
    //   1327: aload_1
    //   1328: invokevirtual getHeight : ()I
    //   1331: i2f
    //   1332: fmul
    //   1333: ldc 0.5
    //   1335: fadd
    //   1336: f2i
    //   1337: invokespecial measure : (Landroidx/constraintlayout/solver/widgets/ConstraintWidget;Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;ILandroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;I)V
    //   1340: aload #12
    //   1342: getfield horizontalRun : Landroidx/constraintlayout/solver/widgets/analyzer/HorizontalWidgetRun;
    //   1345: getfield dimension : Landroidx/constraintlayout/solver/widgets/analyzer/DimensionDependency;
    //   1348: aload #12
    //   1350: invokevirtual getWidth : ()I
    //   1353: invokevirtual resolve : (I)V
    //   1356: aload #12
    //   1358: getfield verticalRun : Landroidx/constraintlayout/solver/widgets/analyzer/VerticalWidgetRun;
    //   1361: getfield dimension : Landroidx/constraintlayout/solver/widgets/analyzer/DimensionDependency;
    //   1364: aload #12
    //   1366: invokevirtual getHeight : ()I
    //   1369: invokevirtual resolve : (I)V
    //   1372: aload #12
    //   1374: iconst_1
    //   1375: putfield measured : Z
    //   1378: goto -> 9
    //   1381: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   1384: astore #8
    //   1386: aload_0
    //   1387: aload #12
    //   1389: aload #8
    //   1391: iconst_0
    //   1392: aload #8
    //   1394: iconst_0
    //   1395: invokespecial measure : (Landroidx/constraintlayout/solver/widgets/ConstraintWidget;Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;ILandroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;I)V
    //   1398: aload #12
    //   1400: getfield horizontalRun : Landroidx/constraintlayout/solver/widgets/analyzer/HorizontalWidgetRun;
    //   1403: getfield dimension : Landroidx/constraintlayout/solver/widgets/analyzer/DimensionDependency;
    //   1406: aload #12
    //   1408: invokevirtual getWidth : ()I
    //   1411: putfield wrapValue : I
    //   1414: aload #12
    //   1416: getfield verticalRun : Landroidx/constraintlayout/solver/widgets/analyzer/VerticalWidgetRun;
    //   1419: getfield dimension : Landroidx/constraintlayout/solver/widgets/analyzer/DimensionDependency;
    //   1422: aload #12
    //   1424: invokevirtual getHeight : ()I
    //   1427: putfield wrapValue : I
    //   1430: goto -> 9
    //   1433: aload #12
    //   1435: invokevirtual getWidth : ()I
    //   1438: istore #4
    //   1440: aload #9
    //   1442: aload #10
    //   1444: if_acmpne -> 1491
    //   1447: aload_1
    //   1448: invokevirtual getWidth : ()I
    //   1451: istore #4
    //   1453: aload #12
    //   1455: getfield mLeft : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1458: getfield mMargin : I
    //   1461: istore #5
    //   1463: aload #12
    //   1465: getfield mRight : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1468: getfield mMargin : I
    //   1471: istore #6
    //   1473: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.FIXED : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   1476: astore #9
    //   1478: iload #4
    //   1480: iload #5
    //   1482: isub
    //   1483: iload #6
    //   1485: isub
    //   1486: istore #4
    //   1488: goto -> 1491
    //   1491: aload #12
    //   1493: invokevirtual getHeight : ()I
    //   1496: istore #5
    //   1498: aload #8
    //   1500: aload #10
    //   1502: if_acmpne -> 1549
    //   1505: aload_1
    //   1506: invokevirtual getHeight : ()I
    //   1509: istore #5
    //   1511: aload #12
    //   1513: getfield mTop : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1516: getfield mMargin : I
    //   1519: istore #6
    //   1521: aload #12
    //   1523: getfield mBottom : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1526: getfield mMargin : I
    //   1529: istore #7
    //   1531: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.FIXED : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   1534: astore #8
    //   1536: iload #5
    //   1538: iload #6
    //   1540: isub
    //   1541: iload #7
    //   1543: isub
    //   1544: istore #5
    //   1546: goto -> 1549
    //   1549: aload_0
    //   1550: aload #12
    //   1552: aload #9
    //   1554: iload #4
    //   1556: aload #8
    //   1558: iload #5
    //   1560: invokespecial measure : (Landroidx/constraintlayout/solver/widgets/ConstraintWidget;Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;ILandroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;I)V
    //   1563: aload #12
    //   1565: getfield horizontalRun : Landroidx/constraintlayout/solver/widgets/analyzer/HorizontalWidgetRun;
    //   1568: getfield dimension : Landroidx/constraintlayout/solver/widgets/analyzer/DimensionDependency;
    //   1571: aload #12
    //   1573: invokevirtual getWidth : ()I
    //   1576: invokevirtual resolve : (I)V
    //   1579: aload #12
    //   1581: getfield verticalRun : Landroidx/constraintlayout/solver/widgets/analyzer/VerticalWidgetRun;
    //   1584: getfield dimension : Landroidx/constraintlayout/solver/widgets/analyzer/DimensionDependency;
    //   1587: aload #12
    //   1589: invokevirtual getHeight : ()I
    //   1592: invokevirtual resolve : (I)V
    //   1595: aload #12
    //   1597: iconst_1
    //   1598: putfield measured : Z
    //   1601: goto -> 9
    //   1604: iconst_0
    //   1605: ireturn
  }
  
  private int computeWrap(ConstraintWidgetContainer paramConstraintWidgetContainer, int paramInt) {
    int j = this.mGroups.size();
    long l = 0L;
    for (int i = 0; i < j; i++)
      l = Math.max(l, ((RunGroup)this.mGroups.get(i)).computeWrapSize(paramConstraintWidgetContainer, paramInt)); 
    return (int)l;
  }
  
  private void displayGraph() {
    Iterator<WidgetRun> iterator = this.mRuns.iterator();
    String str;
    for (str = "digraph {\n"; iterator.hasNext(); str = generateDisplayGraph(iterator.next(), str));
    StringBuilder stringBuilder1 = new StringBuilder();
    stringBuilder1.append(str);
    stringBuilder1.append("\n}\n");
    str = stringBuilder1.toString();
    PrintStream printStream = System.out;
    StringBuilder stringBuilder2 = new StringBuilder();
    stringBuilder2.append("content:<<\n");
    stringBuilder2.append(str);
    stringBuilder2.append("\n>>");
    printStream.println(stringBuilder2.toString());
  }
  
  private void findGroup(WidgetRun paramWidgetRun, int paramInt, ArrayList<RunGroup> paramArrayList) {
    for (Dependency dependency : paramWidgetRun.start.dependencies) {
      if (dependency instanceof DependencyNode) {
        applyGroup((DependencyNode)dependency, paramInt, 0, paramWidgetRun.end, paramArrayList, null);
        continue;
      } 
      if (dependency instanceof WidgetRun)
        applyGroup(((WidgetRun)dependency).start, paramInt, 0, paramWidgetRun.end, paramArrayList, null); 
    } 
    for (Dependency dependency : paramWidgetRun.end.dependencies) {
      if (dependency instanceof DependencyNode) {
        applyGroup((DependencyNode)dependency, paramInt, 1, paramWidgetRun.start, paramArrayList, null);
        continue;
      } 
      if (dependency instanceof WidgetRun)
        applyGroup(((WidgetRun)dependency).end, paramInt, 1, paramWidgetRun.start, paramArrayList, null); 
    } 
    if (paramInt == 1)
      for (Dependency dependency : ((VerticalWidgetRun)paramWidgetRun).baseline.dependencies) {
        if (dependency instanceof DependencyNode)
          applyGroup((DependencyNode)dependency, paramInt, 2, null, paramArrayList, null); 
      }  
  }
  
  private String generateChainDisplayGraph(ChainRun paramChainRun, String paramString) {
    int i = paramChainRun.orientation;
    StringBuilder stringBuilder1 = new StringBuilder();
    stringBuilder1.append("cluster_");
    stringBuilder1.append(paramChainRun.widget.getDebugName());
    String str2 = stringBuilder1.toString();
    if (i == 0) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(str2);
      stringBuilder.append("_h");
      str2 = stringBuilder.toString();
    } else {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(str2);
      stringBuilder.append("_v");
      str2 = stringBuilder.toString();
    } 
    StringBuilder stringBuilder2 = new StringBuilder();
    stringBuilder2.append("subgraph ");
    stringBuilder2.append(str2);
    stringBuilder2.append(" {\n");
    str2 = stringBuilder2.toString();
    Iterator<WidgetRun> iterator = paramChainRun.widgets.iterator();
    String str1;
    for (str1 = ""; iterator.hasNext(); str1 = generateDisplayGraph(widgetRun, str1)) {
      WidgetRun widgetRun = iterator.next();
      String str = widgetRun.widget.getDebugName();
      if (i == 0) {
        StringBuilder stringBuilder3 = new StringBuilder();
        stringBuilder3.append(str);
        stringBuilder3.append("_HORIZONTAL");
        str = stringBuilder3.toString();
      } else {
        StringBuilder stringBuilder3 = new StringBuilder();
        stringBuilder3.append(str);
        stringBuilder3.append("_VERTICAL");
        str = stringBuilder3.toString();
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(str2);
      stringBuilder.append(str);
      stringBuilder.append(";\n");
      str2 = stringBuilder.toString();
    } 
    stringBuilder2 = new StringBuilder();
    stringBuilder2.append(str2);
    stringBuilder2.append("}\n");
    str2 = stringBuilder2.toString();
    stringBuilder2 = new StringBuilder();
    stringBuilder2.append(paramString);
    stringBuilder2.append(str1);
    stringBuilder2.append(str2);
    return stringBuilder2.toString();
  }
  
  private String generateDisplayGraph(WidgetRun paramWidgetRun, String paramString) {
    // Byte code:
    //   0: aload_1
    //   1: getfield start : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   4: astore #6
    //   6: aload_1
    //   7: getfield end : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   10: astore #7
    //   12: aload_1
    //   13: instanceof androidx/constraintlayout/solver/widgets/analyzer/HelperReferences
    //   16: ifne -> 71
    //   19: aload #6
    //   21: getfield dependencies : Ljava/util/List;
    //   24: invokeinterface isEmpty : ()Z
    //   29: ifeq -> 71
    //   32: aload #7
    //   34: getfield dependencies : Ljava/util/List;
    //   37: invokeinterface isEmpty : ()Z
    //   42: aload #6
    //   44: getfield targets : Ljava/util/List;
    //   47: invokeinterface isEmpty : ()Z
    //   52: iand
    //   53: ifeq -> 71
    //   56: aload #7
    //   58: getfield targets : Ljava/util/List;
    //   61: invokeinterface isEmpty : ()Z
    //   66: ifeq -> 71
    //   69: aload_2
    //   70: areturn
    //   71: new java/lang/StringBuilder
    //   74: dup
    //   75: invokespecial <init> : ()V
    //   78: astore #5
    //   80: aload #5
    //   82: aload_2
    //   83: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   86: pop
    //   87: aload #5
    //   89: aload_0
    //   90: aload_1
    //   91: invokespecial nodeDefinition : (Landroidx/constraintlayout/solver/widgets/analyzer/WidgetRun;)Ljava/lang/String;
    //   94: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   97: pop
    //   98: aload #5
    //   100: invokevirtual toString : ()Ljava/lang/String;
    //   103: astore_2
    //   104: aload_0
    //   105: aload #6
    //   107: aload #7
    //   109: invokespecial isCenteredConnection : (Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;)Z
    //   112: istore #4
    //   114: aload_0
    //   115: aload #7
    //   117: iload #4
    //   119: aload_0
    //   120: aload #6
    //   122: iload #4
    //   124: aload_2
    //   125: invokespecial generateDisplayNode : (Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;ZLjava/lang/String;)Ljava/lang/String;
    //   128: invokespecial generateDisplayNode : (Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;ZLjava/lang/String;)Ljava/lang/String;
    //   131: astore_2
    //   132: aload_1
    //   133: instanceof androidx/constraintlayout/solver/widgets/analyzer/VerticalWidgetRun
    //   136: istore_3
    //   137: aload_2
    //   138: astore #5
    //   140: iload_3
    //   141: ifeq -> 160
    //   144: aload_0
    //   145: aload_1
    //   146: checkcast androidx/constraintlayout/solver/widgets/analyzer/VerticalWidgetRun
    //   149: getfield baseline : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   152: iload #4
    //   154: aload_2
    //   155: invokespecial generateDisplayNode : (Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;ZLjava/lang/String;)Ljava/lang/String;
    //   158: astore #5
    //   160: aload_1
    //   161: instanceof androidx/constraintlayout/solver/widgets/analyzer/HorizontalWidgetRun
    //   164: ifne -> 523
    //   167: aload_1
    //   168: instanceof androidx/constraintlayout/solver/widgets/analyzer/ChainRun
    //   171: istore #4
    //   173: iload #4
    //   175: ifeq -> 191
    //   178: aload_1
    //   179: checkcast androidx/constraintlayout/solver/widgets/analyzer/ChainRun
    //   182: getfield orientation : I
    //   185: ifne -> 191
    //   188: goto -> 523
    //   191: iload_3
    //   192: ifne -> 217
    //   195: aload #5
    //   197: astore_2
    //   198: iload #4
    //   200: ifeq -> 826
    //   203: aload #5
    //   205: astore_2
    //   206: aload_1
    //   207: checkcast androidx/constraintlayout/solver/widgets/analyzer/ChainRun
    //   210: getfield orientation : I
    //   213: iconst_1
    //   214: if_icmpne -> 826
    //   217: aload_1
    //   218: getfield widget : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   221: invokevirtual getVerticalDimensionBehaviour : ()Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   224: astore #8
    //   226: aload #8
    //   228: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.FIXED : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   231: if_acmpeq -> 285
    //   234: aload #8
    //   236: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   239: if_acmpne -> 245
    //   242: goto -> 285
    //   245: aload #5
    //   247: astore_2
    //   248: aload #8
    //   250: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   253: if_acmpne -> 826
    //   256: aload #5
    //   258: astore_2
    //   259: aload_1
    //   260: getfield widget : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   263: invokevirtual getDimensionRatio : ()F
    //   266: fconst_0
    //   267: fcmpl
    //   268: ifle -> 826
    //   271: aload_1
    //   272: getfield widget : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   275: invokevirtual getDebugName : ()Ljava/lang/String;
    //   278: pop
    //   279: aload #5
    //   281: astore_2
    //   282: goto -> 826
    //   285: aload #6
    //   287: getfield targets : Ljava/util/List;
    //   290: invokeinterface isEmpty : ()Z
    //   295: ifne -> 401
    //   298: aload #7
    //   300: getfield targets : Ljava/util/List;
    //   303: invokeinterface isEmpty : ()Z
    //   308: ifeq -> 401
    //   311: new java/lang/StringBuilder
    //   314: dup
    //   315: invokespecial <init> : ()V
    //   318: astore_2
    //   319: aload_2
    //   320: ldc_w '\\n'
    //   323: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   326: pop
    //   327: aload_2
    //   328: aload #7
    //   330: invokevirtual name : ()Ljava/lang/String;
    //   333: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   336: pop
    //   337: aload_2
    //   338: ldc_w ' -> '
    //   341: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   344: pop
    //   345: aload_2
    //   346: aload #6
    //   348: invokevirtual name : ()Ljava/lang/String;
    //   351: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   354: pop
    //   355: aload_2
    //   356: ldc_w '\\n'
    //   359: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   362: pop
    //   363: aload_2
    //   364: invokevirtual toString : ()Ljava/lang/String;
    //   367: astore_2
    //   368: new java/lang/StringBuilder
    //   371: dup
    //   372: invokespecial <init> : ()V
    //   375: astore #6
    //   377: aload #6
    //   379: aload #5
    //   381: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   384: pop
    //   385: aload #6
    //   387: aload_2
    //   388: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   391: pop
    //   392: aload #6
    //   394: invokevirtual toString : ()Ljava/lang/String;
    //   397: astore_2
    //   398: goto -> 826
    //   401: aload #5
    //   403: astore_2
    //   404: aload #6
    //   406: getfield targets : Ljava/util/List;
    //   409: invokeinterface isEmpty : ()Z
    //   414: ifeq -> 826
    //   417: aload #5
    //   419: astore_2
    //   420: aload #7
    //   422: getfield targets : Ljava/util/List;
    //   425: invokeinterface isEmpty : ()Z
    //   430: ifne -> 826
    //   433: new java/lang/StringBuilder
    //   436: dup
    //   437: invokespecial <init> : ()V
    //   440: astore_2
    //   441: aload_2
    //   442: ldc_w '\\n'
    //   445: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   448: pop
    //   449: aload_2
    //   450: aload #6
    //   452: invokevirtual name : ()Ljava/lang/String;
    //   455: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   458: pop
    //   459: aload_2
    //   460: ldc_w ' -> '
    //   463: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   466: pop
    //   467: aload_2
    //   468: aload #7
    //   470: invokevirtual name : ()Ljava/lang/String;
    //   473: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   476: pop
    //   477: aload_2
    //   478: ldc_w '\\n'
    //   481: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   484: pop
    //   485: aload_2
    //   486: invokevirtual toString : ()Ljava/lang/String;
    //   489: astore_2
    //   490: new java/lang/StringBuilder
    //   493: dup
    //   494: invokespecial <init> : ()V
    //   497: astore #6
    //   499: aload #6
    //   501: aload #5
    //   503: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   506: pop
    //   507: aload #6
    //   509: aload_2
    //   510: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   513: pop
    //   514: aload #6
    //   516: invokevirtual toString : ()Ljava/lang/String;
    //   519: astore_2
    //   520: goto -> 826
    //   523: aload_1
    //   524: getfield widget : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   527: invokevirtual getHorizontalDimensionBehaviour : ()Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   530: astore #8
    //   532: aload #8
    //   534: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.FIXED : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   537: if_acmpeq -> 591
    //   540: aload #8
    //   542: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   545: if_acmpne -> 551
    //   548: goto -> 591
    //   551: aload #5
    //   553: astore_2
    //   554: aload #8
    //   556: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   559: if_acmpne -> 826
    //   562: aload #5
    //   564: astore_2
    //   565: aload_1
    //   566: getfield widget : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   569: invokevirtual getDimensionRatio : ()F
    //   572: fconst_0
    //   573: fcmpl
    //   574: ifle -> 826
    //   577: aload_1
    //   578: getfield widget : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   581: invokevirtual getDebugName : ()Ljava/lang/String;
    //   584: pop
    //   585: aload #5
    //   587: astore_2
    //   588: goto -> 826
    //   591: aload #6
    //   593: getfield targets : Ljava/util/List;
    //   596: invokeinterface isEmpty : ()Z
    //   601: ifne -> 707
    //   604: aload #7
    //   606: getfield targets : Ljava/util/List;
    //   609: invokeinterface isEmpty : ()Z
    //   614: ifeq -> 707
    //   617: new java/lang/StringBuilder
    //   620: dup
    //   621: invokespecial <init> : ()V
    //   624: astore_2
    //   625: aload_2
    //   626: ldc_w '\\n'
    //   629: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   632: pop
    //   633: aload_2
    //   634: aload #7
    //   636: invokevirtual name : ()Ljava/lang/String;
    //   639: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   642: pop
    //   643: aload_2
    //   644: ldc_w ' -> '
    //   647: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   650: pop
    //   651: aload_2
    //   652: aload #6
    //   654: invokevirtual name : ()Ljava/lang/String;
    //   657: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   660: pop
    //   661: aload_2
    //   662: ldc_w '\\n'
    //   665: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   668: pop
    //   669: aload_2
    //   670: invokevirtual toString : ()Ljava/lang/String;
    //   673: astore_2
    //   674: new java/lang/StringBuilder
    //   677: dup
    //   678: invokespecial <init> : ()V
    //   681: astore #6
    //   683: aload #6
    //   685: aload #5
    //   687: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   690: pop
    //   691: aload #6
    //   693: aload_2
    //   694: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   697: pop
    //   698: aload #6
    //   700: invokevirtual toString : ()Ljava/lang/String;
    //   703: astore_2
    //   704: goto -> 826
    //   707: aload #5
    //   709: astore_2
    //   710: aload #6
    //   712: getfield targets : Ljava/util/List;
    //   715: invokeinterface isEmpty : ()Z
    //   720: ifeq -> 826
    //   723: aload #5
    //   725: astore_2
    //   726: aload #7
    //   728: getfield targets : Ljava/util/List;
    //   731: invokeinterface isEmpty : ()Z
    //   736: ifne -> 826
    //   739: new java/lang/StringBuilder
    //   742: dup
    //   743: invokespecial <init> : ()V
    //   746: astore_2
    //   747: aload_2
    //   748: ldc_w '\\n'
    //   751: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   754: pop
    //   755: aload_2
    //   756: aload #6
    //   758: invokevirtual name : ()Ljava/lang/String;
    //   761: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   764: pop
    //   765: aload_2
    //   766: ldc_w ' -> '
    //   769: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   772: pop
    //   773: aload_2
    //   774: aload #7
    //   776: invokevirtual name : ()Ljava/lang/String;
    //   779: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   782: pop
    //   783: aload_2
    //   784: ldc_w '\\n'
    //   787: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   790: pop
    //   791: aload_2
    //   792: invokevirtual toString : ()Ljava/lang/String;
    //   795: astore_2
    //   796: new java/lang/StringBuilder
    //   799: dup
    //   800: invokespecial <init> : ()V
    //   803: astore #6
    //   805: aload #6
    //   807: aload #5
    //   809: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   812: pop
    //   813: aload #6
    //   815: aload_2
    //   816: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   819: pop
    //   820: aload #6
    //   822: invokevirtual toString : ()Ljava/lang/String;
    //   825: astore_2
    //   826: aload_1
    //   827: instanceof androidx/constraintlayout/solver/widgets/analyzer/ChainRun
    //   830: ifeq -> 843
    //   833: aload_0
    //   834: aload_1
    //   835: checkcast androidx/constraintlayout/solver/widgets/analyzer/ChainRun
    //   838: aload_2
    //   839: invokespecial generateChainDisplayGraph : (Landroidx/constraintlayout/solver/widgets/analyzer/ChainRun;Ljava/lang/String;)Ljava/lang/String;
    //   842: areturn
    //   843: aload_2
    //   844: areturn
  }
  
  private String generateDisplayNode(DependencyNode paramDependencyNode, boolean paramBoolean, String paramString) {
    // Byte code:
    //   0: aload_1
    //   1: getfield targets : Ljava/util/List;
    //   4: invokeinterface iterator : ()Ljava/util/Iterator;
    //   9: astore #6
    //   11: aload_3
    //   12: astore #5
    //   14: aload #6
    //   16: invokeinterface hasNext : ()Z
    //   21: ifeq -> 433
    //   24: aload #6
    //   26: invokeinterface next : ()Ljava/lang/Object;
    //   31: checkcast androidx/constraintlayout/solver/widgets/analyzer/DependencyNode
    //   34: astore_3
    //   35: new java/lang/StringBuilder
    //   38: dup
    //   39: invokespecial <init> : ()V
    //   42: astore #4
    //   44: aload #4
    //   46: ldc_w '\\n'
    //   49: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   52: pop
    //   53: aload #4
    //   55: aload_1
    //   56: invokevirtual name : ()Ljava/lang/String;
    //   59: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   62: pop
    //   63: aload #4
    //   65: invokevirtual toString : ()Ljava/lang/String;
    //   68: astore #4
    //   70: new java/lang/StringBuilder
    //   73: dup
    //   74: invokespecial <init> : ()V
    //   77: astore #7
    //   79: aload #7
    //   81: aload #4
    //   83: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   86: pop
    //   87: aload #7
    //   89: ldc_w ' -> '
    //   92: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   95: pop
    //   96: aload #7
    //   98: aload_3
    //   99: invokevirtual name : ()Ljava/lang/String;
    //   102: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   105: pop
    //   106: aload #7
    //   108: invokevirtual toString : ()Ljava/lang/String;
    //   111: astore #4
    //   113: aload_1
    //   114: getfield margin : I
    //   117: ifgt -> 137
    //   120: iload_2
    //   121: ifne -> 137
    //   124: aload #4
    //   126: astore_3
    //   127: aload_1
    //   128: getfield run : Landroidx/constraintlayout/solver/widgets/analyzer/WidgetRun;
    //   131: instanceof androidx/constraintlayout/solver/widgets/analyzer/HelperReferences
    //   134: ifeq -> 368
    //   137: new java/lang/StringBuilder
    //   140: dup
    //   141: invokespecial <init> : ()V
    //   144: astore_3
    //   145: aload_3
    //   146: aload #4
    //   148: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   151: pop
    //   152: aload_3
    //   153: ldc_w '['
    //   156: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   159: pop
    //   160: aload_3
    //   161: invokevirtual toString : ()Ljava/lang/String;
    //   164: astore #4
    //   166: aload #4
    //   168: astore_3
    //   169: aload_1
    //   170: getfield margin : I
    //   173: ifle -> 257
    //   176: new java/lang/StringBuilder
    //   179: dup
    //   180: invokespecial <init> : ()V
    //   183: astore_3
    //   184: aload_3
    //   185: aload #4
    //   187: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   190: pop
    //   191: aload_3
    //   192: ldc_w 'label="'
    //   195: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   198: pop
    //   199: aload_3
    //   200: aload_1
    //   201: getfield margin : I
    //   204: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   207: pop
    //   208: aload_3
    //   209: ldc_w '"'
    //   212: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   215: pop
    //   216: aload_3
    //   217: invokevirtual toString : ()Ljava/lang/String;
    //   220: astore #4
    //   222: aload #4
    //   224: astore_3
    //   225: iload_2
    //   226: ifeq -> 257
    //   229: new java/lang/StringBuilder
    //   232: dup
    //   233: invokespecial <init> : ()V
    //   236: astore_3
    //   237: aload_3
    //   238: aload #4
    //   240: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   243: pop
    //   244: aload_3
    //   245: ldc_w ','
    //   248: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   251: pop
    //   252: aload_3
    //   253: invokevirtual toString : ()Ljava/lang/String;
    //   256: astore_3
    //   257: aload_3
    //   258: astore #4
    //   260: iload_2
    //   261: ifeq -> 296
    //   264: new java/lang/StringBuilder
    //   267: dup
    //   268: invokespecial <init> : ()V
    //   271: astore #4
    //   273: aload #4
    //   275: aload_3
    //   276: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   279: pop
    //   280: aload #4
    //   282: ldc_w ' style=dashed '
    //   285: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   288: pop
    //   289: aload #4
    //   291: invokevirtual toString : ()Ljava/lang/String;
    //   294: astore #4
    //   296: aload #4
    //   298: astore_3
    //   299: aload_1
    //   300: getfield run : Landroidx/constraintlayout/solver/widgets/analyzer/WidgetRun;
    //   303: instanceof androidx/constraintlayout/solver/widgets/analyzer/HelperReferences
    //   306: ifeq -> 337
    //   309: new java/lang/StringBuilder
    //   312: dup
    //   313: invokespecial <init> : ()V
    //   316: astore_3
    //   317: aload_3
    //   318: aload #4
    //   320: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   323: pop
    //   324: aload_3
    //   325: ldc_w ' style=bold,color=gray '
    //   328: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   331: pop
    //   332: aload_3
    //   333: invokevirtual toString : ()Ljava/lang/String;
    //   336: astore_3
    //   337: new java/lang/StringBuilder
    //   340: dup
    //   341: invokespecial <init> : ()V
    //   344: astore #4
    //   346: aload #4
    //   348: aload_3
    //   349: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   352: pop
    //   353: aload #4
    //   355: ldc_w ']'
    //   358: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   361: pop
    //   362: aload #4
    //   364: invokevirtual toString : ()Ljava/lang/String;
    //   367: astore_3
    //   368: new java/lang/StringBuilder
    //   371: dup
    //   372: invokespecial <init> : ()V
    //   375: astore #4
    //   377: aload #4
    //   379: aload_3
    //   380: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   383: pop
    //   384: aload #4
    //   386: ldc_w '\\n'
    //   389: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   392: pop
    //   393: aload #4
    //   395: invokevirtual toString : ()Ljava/lang/String;
    //   398: astore_3
    //   399: new java/lang/StringBuilder
    //   402: dup
    //   403: invokespecial <init> : ()V
    //   406: astore #4
    //   408: aload #4
    //   410: aload #5
    //   412: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   415: pop
    //   416: aload #4
    //   418: aload_3
    //   419: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   422: pop
    //   423: aload #4
    //   425: invokevirtual toString : ()Ljava/lang/String;
    //   428: astore #5
    //   430: goto -> 14
    //   433: aload #5
    //   435: areturn
  }
  
  private boolean isCenteredConnection(DependencyNode paramDependencyNode1, DependencyNode paramDependencyNode2) {
    Iterator<DependencyNode> iterator2 = paramDependencyNode1.targets.iterator();
    boolean bool2 = false;
    int i = 0;
    while (iterator2.hasNext()) {
      if ((DependencyNode)iterator2.next() != paramDependencyNode2)
        i++; 
    } 
    Iterator<DependencyNode> iterator1 = paramDependencyNode2.targets.iterator();
    int j = 0;
    while (iterator1.hasNext()) {
      if ((DependencyNode)iterator1.next() != paramDependencyNode1)
        j++; 
    } 
    boolean bool1 = bool2;
    if (i > 0) {
      bool1 = bool2;
      if (j > 0)
        bool1 = true; 
    } 
    return bool1;
  }
  
  private void measure(ConstraintWidget paramConstraintWidget, ConstraintWidget.DimensionBehaviour paramDimensionBehaviour1, int paramInt1, ConstraintWidget.DimensionBehaviour paramDimensionBehaviour2, int paramInt2) {
    BasicMeasure.Measure measure = this.mMeasure;
    measure.horizontalBehavior = paramDimensionBehaviour1;
    measure.verticalBehavior = paramDimensionBehaviour2;
    measure.horizontalDimension = paramInt1;
    measure.verticalDimension = paramInt2;
    this.mMeasurer.measure(paramConstraintWidget, measure);
    paramConstraintWidget.setWidth(this.mMeasure.measuredWidth);
    paramConstraintWidget.setHeight(this.mMeasure.measuredHeight);
    paramConstraintWidget.setHasBaseline(this.mMeasure.measuredHasBaseline);
    paramConstraintWidget.setBaselineDistance(this.mMeasure.measuredBaseline);
  }
  
  private String nodeDefinition(WidgetRun paramWidgetRun) {
    ConstraintWidget.DimensionBehaviour dimensionBehaviour;
    boolean bool1 = paramWidgetRun instanceof VerticalWidgetRun;
    String str4 = paramWidgetRun.widget.getDebugName();
    ConstraintWidget constraintWidget = paramWidgetRun.widget;
    if (!bool1) {
      dimensionBehaviour = constraintWidget.getHorizontalDimensionBehaviour();
    } else {
      dimensionBehaviour = constraintWidget.getVerticalDimensionBehaviour();
    } 
    RunGroup runGroup = paramWidgetRun.runGroup;
    if (!bool1) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(str4);
      stringBuilder.append("_HORIZONTAL");
      str2 = stringBuilder.toString();
    } else {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(str4);
      stringBuilder.append("_VERTICAL");
      str2 = stringBuilder.toString();
    } 
    StringBuilder stringBuilder3 = new StringBuilder();
    stringBuilder3.append(str2);
    stringBuilder3.append(" [shape=none, label=<");
    String str2 = stringBuilder3.toString();
    stringBuilder3 = new StringBuilder();
    stringBuilder3.append(str2);
    stringBuilder3.append("<TABLE BORDER=\"0\" CELLSPACING=\"0\" CELLPADDING=\"2\">");
    str2 = stringBuilder3.toString();
    stringBuilder3 = new StringBuilder();
    stringBuilder3.append(str2);
    stringBuilder3.append("  <TR>");
    str2 = stringBuilder3.toString();
    if (!bool1) {
      stringBuilder3 = new StringBuilder();
      stringBuilder3.append(str2);
      stringBuilder3.append("    <TD ");
      String str = stringBuilder3.toString();
      str2 = str;
      if (paramWidgetRun.start.resolved) {
        StringBuilder stringBuilder4 = new StringBuilder();
        stringBuilder4.append(str);
        stringBuilder4.append(" BGCOLOR=\"green\"");
        str2 = stringBuilder4.toString();
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(str2);
      stringBuilder.append(" PORT=\"LEFT\" BORDER=\"1\">L</TD>");
      str2 = stringBuilder.toString();
    } else {
      stringBuilder3 = new StringBuilder();
      stringBuilder3.append(str2);
      stringBuilder3.append("    <TD ");
      String str = stringBuilder3.toString();
      str2 = str;
      if (paramWidgetRun.start.resolved) {
        StringBuilder stringBuilder4 = new StringBuilder();
        stringBuilder4.append(str);
        stringBuilder4.append(" BGCOLOR=\"green\"");
        str2 = stringBuilder4.toString();
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(str2);
      stringBuilder.append(" PORT=\"TOP\" BORDER=\"1\">T</TD>");
      str2 = stringBuilder.toString();
    } 
    stringBuilder3 = new StringBuilder();
    stringBuilder3.append(str2);
    stringBuilder3.append("    <TD BORDER=\"1\" ");
    String str3 = stringBuilder3.toString();
    boolean bool2 = paramWidgetRun.dimension.resolved;
    if (bool2 && !paramWidgetRun.widget.measured) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(str3);
      stringBuilder.append(" BGCOLOR=\"green\" ");
      String str = stringBuilder.toString();
    } else if (bool2 && paramWidgetRun.widget.measured) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(str3);
      stringBuilder.append(" BGCOLOR=\"lightgray\" ");
      String str = stringBuilder.toString();
    } else {
      str2 = str3;
      if (!bool2) {
        str2 = str3;
        if (paramWidgetRun.widget.measured) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append(str3);
          stringBuilder.append(" BGCOLOR=\"yellow\" ");
          str2 = stringBuilder.toString();
        } 
      } 
    } 
    str3 = str2;
    if (dimensionBehaviour == ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(str2);
      stringBuilder.append("style=\"dashed\"");
      str3 = stringBuilder.toString();
    } 
    if (runGroup != null) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(" [");
      stringBuilder.append(runGroup.groupIndex + 1);
      stringBuilder.append("/");
      stringBuilder.append(RunGroup.index);
      stringBuilder.append("]");
      String str = stringBuilder.toString();
    } else {
      str2 = "";
    } 
    StringBuilder stringBuilder2 = new StringBuilder();
    stringBuilder2.append(str3);
    stringBuilder2.append(">");
    stringBuilder2.append(str4);
    stringBuilder2.append(str2);
    stringBuilder2.append(" </TD>");
    str2 = stringBuilder2.toString();
    if (!bool1) {
      stringBuilder2 = new StringBuilder();
      stringBuilder2.append(str2);
      stringBuilder2.append("    <TD ");
      String str = stringBuilder2.toString();
      str2 = str;
      if (paramWidgetRun.end.resolved) {
        StringBuilder stringBuilder4 = new StringBuilder();
        stringBuilder4.append(str);
        stringBuilder4.append(" BGCOLOR=\"green\"");
        str2 = stringBuilder4.toString();
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(str2);
      stringBuilder.append(" PORT=\"RIGHT\" BORDER=\"1\">R</TD>");
      str1 = stringBuilder.toString();
    } else {
      stringBuilder2 = new StringBuilder();
      stringBuilder2.append(str2);
      stringBuilder2.append("    <TD ");
      String str7 = stringBuilder2.toString();
      str2 = str7;
      if (str1 instanceof VerticalWidgetRun) {
        str2 = str7;
        if (((VerticalWidgetRun)str1).baseline.resolved) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append(str7);
          stringBuilder.append(" BGCOLOR=\"green\"");
          str5 = stringBuilder.toString();
        } 
      } 
      StringBuilder stringBuilder5 = new StringBuilder();
      stringBuilder5.append(str5);
      stringBuilder5.append(" PORT=\"BASELINE\" BORDER=\"1\">b</TD>");
      String str5 = stringBuilder5.toString();
      stringBuilder5 = new StringBuilder();
      stringBuilder5.append(str5);
      stringBuilder5.append("    <TD ");
      String str6 = stringBuilder5.toString();
      str5 = str6;
      if (((WidgetRun)str1).end.resolved) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(str6);
        stringBuilder.append(" BGCOLOR=\"green\"");
        str5 = stringBuilder.toString();
      } 
      StringBuilder stringBuilder4 = new StringBuilder();
      stringBuilder4.append(str5);
      stringBuilder4.append(" PORT=\"BOTTOM\" BORDER=\"1\">B</TD>");
      str1 = stringBuilder4.toString();
    } 
    StringBuilder stringBuilder1 = new StringBuilder();
    stringBuilder1.append(str1);
    stringBuilder1.append("  </TR></TABLE>");
    String str1 = stringBuilder1.toString();
    stringBuilder1 = new StringBuilder();
    stringBuilder1.append(str1);
    stringBuilder1.append(">];\n");
    return stringBuilder1.toString();
  }
  
  public void buildGraph() {
    buildGraph(this.mRuns);
    this.mGroups.clear();
    RunGroup.index = 0;
    findGroup(((ConstraintWidget)this.container).horizontalRun, 0, this.mGroups);
    findGroup(((ConstraintWidget)this.container).verticalRun, 1, this.mGroups);
    this.mNeedBuildGraph = false;
  }
  
  public void buildGraph(ArrayList<WidgetRun> paramArrayList) {
    paramArrayList.clear();
    ((ConstraintWidget)this.mContainer).horizontalRun.clear();
    ((ConstraintWidget)this.mContainer).verticalRun.clear();
    paramArrayList.add(((ConstraintWidget)this.mContainer).horizontalRun);
    paramArrayList.add(((ConstraintWidget)this.mContainer).verticalRun);
    Iterator<ConstraintWidget> iterator1 = ((WidgetContainer)this.mContainer).mChildren.iterator();
    HashSet<ChainRun> hashSet = null;
    while (iterator1.hasNext()) {
      HashSet<ChainRun> hashSet1;
      ConstraintWidget constraintWidget = iterator1.next();
      if (constraintWidget instanceof androidx.constraintlayout.solver.widgets.Guideline) {
        paramArrayList.add(new GuidelineReference(constraintWidget));
        continue;
      } 
      if (constraintWidget.isInHorizontalChain()) {
        if (constraintWidget.horizontalChainRun == null)
          constraintWidget.horizontalChainRun = new ChainRun(constraintWidget, 0); 
        hashSet1 = hashSet;
        if (hashSet == null)
          hashSet1 = new HashSet(); 
        hashSet1.add(constraintWidget.horizontalChainRun);
        hashSet = hashSet1;
      } else {
        paramArrayList.add(constraintWidget.horizontalRun);
      } 
      if (constraintWidget.isInVerticalChain()) {
        if (constraintWidget.verticalChainRun == null)
          constraintWidget.verticalChainRun = new ChainRun(constraintWidget, 1); 
        hashSet1 = hashSet;
        if (hashSet == null)
          hashSet1 = new HashSet<ChainRun>(); 
        hashSet1.add(constraintWidget.verticalChainRun);
      } else {
        paramArrayList.add(constraintWidget.verticalRun);
        hashSet1 = hashSet;
      } 
      hashSet = hashSet1;
      if (constraintWidget instanceof androidx.constraintlayout.solver.widgets.HelperWidget) {
        paramArrayList.add(new HelperReferences(constraintWidget));
        hashSet = hashSet1;
      } 
    } 
    if (hashSet != null)
      paramArrayList.addAll((Collection)hashSet); 
    Iterator<WidgetRun> iterator = paramArrayList.iterator();
    while (iterator.hasNext())
      ((WidgetRun)iterator.next()).clear(); 
    for (WidgetRun widgetRun : paramArrayList) {
      if (widgetRun.widget == this.mContainer)
        continue; 
      widgetRun.apply();
    } 
  }
  
  public void defineTerminalWidgets(ConstraintWidget.DimensionBehaviour paramDimensionBehaviour1, ConstraintWidget.DimensionBehaviour paramDimensionBehaviour2) {
    if (this.mNeedBuildGraph) {
      buildGraph();
      Iterator<ConstraintWidget> iterator = ((WidgetContainer)this.container).mChildren.iterator();
      boolean bool = false;
      while (iterator.hasNext()) {
        ConstraintWidget constraintWidget = iterator.next();
        boolean[] arrayOfBoolean = constraintWidget.isTerminalWidget;
        arrayOfBoolean[0] = true;
        arrayOfBoolean[1] = true;
        if (constraintWidget instanceof androidx.constraintlayout.solver.widgets.Barrier)
          bool = true; 
      } 
      if (!bool)
        for (RunGroup runGroup : this.mGroups) {
          boolean bool1;
          boolean bool2;
          ConstraintWidget.DimensionBehaviour dimensionBehaviour = ConstraintWidget.DimensionBehaviour.WRAP_CONTENT;
          if (paramDimensionBehaviour1 == dimensionBehaviour) {
            bool1 = true;
          } else {
            bool1 = false;
          } 
          if (paramDimensionBehaviour2 == dimensionBehaviour) {
            bool2 = true;
          } else {
            bool2 = false;
          } 
          runGroup.defineTerminalWidgets(bool1, bool2);
        }  
    } 
  }
  
  public boolean directMeasure(boolean paramBoolean) {
    boolean bool1;
    boolean bool2 = true;
    int i = paramBoolean & true;
    if (this.mNeedBuildGraph || this.mNeedRedoMeasures) {
      for (ConstraintWidget constraintWidget : ((WidgetContainer)this.container).mChildren) {
        constraintWidget.ensureWidgetRuns();
        constraintWidget.measured = false;
        constraintWidget.horizontalRun.reset();
        constraintWidget.verticalRun.reset();
      } 
      this.container.ensureWidgetRuns();
      ConstraintWidgetContainer constraintWidgetContainer1 = this.container;
      ((ConstraintWidget)constraintWidgetContainer1).measured = false;
      ((ConstraintWidget)constraintWidgetContainer1).horizontalRun.reset();
      ((ConstraintWidget)this.container).verticalRun.reset();
      this.mNeedRedoMeasures = false;
    } 
    if (basicMeasureWidgets(this.mContainer))
      return false; 
    this.container.setX(0);
    this.container.setY(0);
    ConstraintWidget.DimensionBehaviour dimensionBehaviour1 = this.container.getDimensionBehaviour(0);
    ConstraintWidget.DimensionBehaviour dimensionBehaviour2 = this.container.getDimensionBehaviour(1);
    if (this.mNeedBuildGraph)
      buildGraph(); 
    int k = this.container.getX();
    int j = this.container.getY();
    ((ConstraintWidget)this.container).horizontalRun.start.resolve(k);
    ((ConstraintWidget)this.container).verticalRun.start.resolve(j);
    measureWidgets();
    ConstraintWidget.DimensionBehaviour dimensionBehaviour3 = ConstraintWidget.DimensionBehaviour.WRAP_CONTENT;
    if (dimensionBehaviour1 == dimensionBehaviour3 || dimensionBehaviour2 == dimensionBehaviour3) {
      bool1 = i;
      if (i != 0) {
        Iterator<WidgetRun> iterator1 = this.mRuns.iterator();
        while (true) {
          bool1 = i;
          if (iterator1.hasNext()) {
            if (!((WidgetRun)iterator1.next()).supportsWrapComputation()) {
              bool1 = false;
              break;
            } 
            continue;
          } 
          break;
        } 
      } 
      if (bool1 != 0 && dimensionBehaviour1 == ConstraintWidget.DimensionBehaviour.WRAP_CONTENT) {
        this.container.setHorizontalDimensionBehaviour(ConstraintWidget.DimensionBehaviour.FIXED);
        ConstraintWidgetContainer constraintWidgetContainer1 = this.container;
        constraintWidgetContainer1.setWidth(computeWrap(constraintWidgetContainer1, 0));
        constraintWidgetContainer1 = this.container;
        ((ConstraintWidget)constraintWidgetContainer1).horizontalRun.dimension.resolve(constraintWidgetContainer1.getWidth());
      } 
      if (bool1 != 0 && dimensionBehaviour2 == ConstraintWidget.DimensionBehaviour.WRAP_CONTENT) {
        this.container.setVerticalDimensionBehaviour(ConstraintWidget.DimensionBehaviour.FIXED);
        ConstraintWidgetContainer constraintWidgetContainer1 = this.container;
        constraintWidgetContainer1.setHeight(computeWrap(constraintWidgetContainer1, 1));
        constraintWidgetContainer1 = this.container;
        ((ConstraintWidget)constraintWidgetContainer1).verticalRun.dimension.resolve(constraintWidgetContainer1.getHeight());
      } 
    } 
    ConstraintWidgetContainer constraintWidgetContainer = this.container;
    ConstraintWidget.DimensionBehaviour[] arrayOfDimensionBehaviour = ((ConstraintWidget)constraintWidgetContainer).mListDimensionBehaviors;
    ConstraintWidget.DimensionBehaviour dimensionBehaviour4 = arrayOfDimensionBehaviour[0];
    dimensionBehaviour3 = ConstraintWidget.DimensionBehaviour.FIXED;
    if (dimensionBehaviour4 == dimensionBehaviour3 || arrayOfDimensionBehaviour[0] == ConstraintWidget.DimensionBehaviour.MATCH_PARENT) {
      bool1 = constraintWidgetContainer.getWidth() + k;
      ((ConstraintWidget)this.container).horizontalRun.end.resolve(bool1);
      ((ConstraintWidget)this.container).horizontalRun.dimension.resolve(bool1 - k);
      measureWidgets();
      constraintWidgetContainer = this.container;
      arrayOfDimensionBehaviour = ((ConstraintWidget)constraintWidgetContainer).mListDimensionBehaviors;
      if (arrayOfDimensionBehaviour[1] == dimensionBehaviour3 || arrayOfDimensionBehaviour[1] == ConstraintWidget.DimensionBehaviour.MATCH_PARENT) {
        bool1 = constraintWidgetContainer.getHeight() + j;
        ((ConstraintWidget)this.container).verticalRun.end.resolve(bool1);
        ((ConstraintWidget)this.container).verticalRun.dimension.resolve(bool1 - j);
      } 
      measureWidgets();
      bool1 = true;
    } else {
      bool1 = false;
    } 
    for (WidgetRun widgetRun : this.mRuns) {
      if (widgetRun.widget == this.container && !widgetRun.resolved)
        continue; 
      widgetRun.applyToWidget();
    } 
    Iterator<WidgetRun> iterator = this.mRuns.iterator();
    while (true) {
      paramBoolean = bool2;
      if (iterator.hasNext()) {
        WidgetRun widgetRun = iterator.next();
        if ((bool1 || widgetRun.widget != this.container) && (!widgetRun.start.resolved || (!widgetRun.end.resolved && !(widgetRun instanceof GuidelineReference)) || (!widgetRun.dimension.resolved && !(widgetRun instanceof ChainRun) && !(widgetRun instanceof GuidelineReference)))) {
          paramBoolean = false;
          break;
        } 
        continue;
      } 
      break;
    } 
    this.container.setHorizontalDimensionBehaviour(dimensionBehaviour1);
    this.container.setVerticalDimensionBehaviour(dimensionBehaviour2);
    return paramBoolean;
  }
  
  public boolean directMeasureSetup(boolean paramBoolean) {
    if (this.mNeedBuildGraph) {
      for (ConstraintWidget constraintWidget : ((WidgetContainer)this.container).mChildren) {
        constraintWidget.ensureWidgetRuns();
        constraintWidget.measured = false;
        HorizontalWidgetRun horizontalWidgetRun1 = constraintWidget.horizontalRun;
        horizontalWidgetRun1.dimension.resolved = false;
        horizontalWidgetRun1.resolved = false;
        horizontalWidgetRun1.reset();
        VerticalWidgetRun verticalWidgetRun1 = constraintWidget.verticalRun;
        verticalWidgetRun1.dimension.resolved = false;
        verticalWidgetRun1.resolved = false;
        verticalWidgetRun1.reset();
      } 
      this.container.ensureWidgetRuns();
      ConstraintWidgetContainer constraintWidgetContainer = this.container;
      ((ConstraintWidget)constraintWidgetContainer).measured = false;
      HorizontalWidgetRun horizontalWidgetRun = ((ConstraintWidget)constraintWidgetContainer).horizontalRun;
      horizontalWidgetRun.dimension.resolved = false;
      horizontalWidgetRun.resolved = false;
      horizontalWidgetRun.reset();
      VerticalWidgetRun verticalWidgetRun = ((ConstraintWidget)this.container).verticalRun;
      verticalWidgetRun.dimension.resolved = false;
      verticalWidgetRun.resolved = false;
      verticalWidgetRun.reset();
      buildGraph();
    } 
    if (basicMeasureWidgets(this.mContainer))
      return false; 
    this.container.setX(0);
    this.container.setY(0);
    ((ConstraintWidget)this.container).horizontalRun.start.resolve(0);
    ((ConstraintWidget)this.container).verticalRun.start.resolve(0);
    return true;
  }
  
  public boolean directMeasureWithOrientation(boolean paramBoolean, int paramInt) {
    // Byte code:
    //   0: iconst_1
    //   1: istore #7
    //   3: iload_1
    //   4: iconst_1
    //   5: iand
    //   6: istore #4
    //   8: aload_0
    //   9: getfield container : Landroidx/constraintlayout/solver/widgets/ConstraintWidgetContainer;
    //   12: iconst_0
    //   13: invokevirtual getDimensionBehaviour : (I)Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   16: astore #8
    //   18: aload_0
    //   19: getfield container : Landroidx/constraintlayout/solver/widgets/ConstraintWidgetContainer;
    //   22: iconst_1
    //   23: invokevirtual getDimensionBehaviour : (I)Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   26: astore #9
    //   28: aload_0
    //   29: getfield container : Landroidx/constraintlayout/solver/widgets/ConstraintWidgetContainer;
    //   32: invokevirtual getX : ()I
    //   35: istore #5
    //   37: aload_0
    //   38: getfield container : Landroidx/constraintlayout/solver/widgets/ConstraintWidgetContainer;
    //   41: invokevirtual getY : ()I
    //   44: istore #6
    //   46: iload #4
    //   48: ifeq -> 254
    //   51: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   54: astore #10
    //   56: aload #8
    //   58: aload #10
    //   60: if_acmpeq -> 70
    //   63: aload #9
    //   65: aload #10
    //   67: if_acmpne -> 254
    //   70: aload_0
    //   71: getfield mRuns : Ljava/util/ArrayList;
    //   74: invokevirtual iterator : ()Ljava/util/Iterator;
    //   77: astore #10
    //   79: iload #4
    //   81: istore_3
    //   82: aload #10
    //   84: invokeinterface hasNext : ()Z
    //   89: ifeq -> 123
    //   92: aload #10
    //   94: invokeinterface next : ()Ljava/lang/Object;
    //   99: checkcast androidx/constraintlayout/solver/widgets/analyzer/WidgetRun
    //   102: astore #11
    //   104: aload #11
    //   106: getfield orientation : I
    //   109: iload_2
    //   110: if_icmpne -> 79
    //   113: aload #11
    //   115: invokevirtual supportsWrapComputation : ()Z
    //   118: ifne -> 79
    //   121: iconst_0
    //   122: istore_3
    //   123: iload_2
    //   124: ifne -> 192
    //   127: iload_3
    //   128: ifeq -> 254
    //   131: aload #8
    //   133: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   136: if_acmpne -> 254
    //   139: aload_0
    //   140: getfield container : Landroidx/constraintlayout/solver/widgets/ConstraintWidgetContainer;
    //   143: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.FIXED : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   146: invokevirtual setHorizontalDimensionBehaviour : (Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;)V
    //   149: aload_0
    //   150: getfield container : Landroidx/constraintlayout/solver/widgets/ConstraintWidgetContainer;
    //   153: astore #10
    //   155: aload #10
    //   157: aload_0
    //   158: aload #10
    //   160: iconst_0
    //   161: invokespecial computeWrap : (Landroidx/constraintlayout/solver/widgets/ConstraintWidgetContainer;I)I
    //   164: invokevirtual setWidth : (I)V
    //   167: aload_0
    //   168: getfield container : Landroidx/constraintlayout/solver/widgets/ConstraintWidgetContainer;
    //   171: astore #10
    //   173: aload #10
    //   175: getfield horizontalRun : Landroidx/constraintlayout/solver/widgets/analyzer/HorizontalWidgetRun;
    //   178: getfield dimension : Landroidx/constraintlayout/solver/widgets/analyzer/DimensionDependency;
    //   181: aload #10
    //   183: invokevirtual getWidth : ()I
    //   186: invokevirtual resolve : (I)V
    //   189: goto -> 254
    //   192: iload_3
    //   193: ifeq -> 254
    //   196: aload #9
    //   198: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   201: if_acmpne -> 254
    //   204: aload_0
    //   205: getfield container : Landroidx/constraintlayout/solver/widgets/ConstraintWidgetContainer;
    //   208: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.FIXED : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   211: invokevirtual setVerticalDimensionBehaviour : (Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;)V
    //   214: aload_0
    //   215: getfield container : Landroidx/constraintlayout/solver/widgets/ConstraintWidgetContainer;
    //   218: astore #10
    //   220: aload #10
    //   222: aload_0
    //   223: aload #10
    //   225: iconst_1
    //   226: invokespecial computeWrap : (Landroidx/constraintlayout/solver/widgets/ConstraintWidgetContainer;I)I
    //   229: invokevirtual setHeight : (I)V
    //   232: aload_0
    //   233: getfield container : Landroidx/constraintlayout/solver/widgets/ConstraintWidgetContainer;
    //   236: astore #10
    //   238: aload #10
    //   240: getfield verticalRun : Landroidx/constraintlayout/solver/widgets/analyzer/VerticalWidgetRun;
    //   243: getfield dimension : Landroidx/constraintlayout/solver/widgets/analyzer/DimensionDependency;
    //   246: aload #10
    //   248: invokevirtual getHeight : ()I
    //   251: invokevirtual resolve : (I)V
    //   254: iload_2
    //   255: ifne -> 334
    //   258: aload_0
    //   259: getfield container : Landroidx/constraintlayout/solver/widgets/ConstraintWidgetContainer;
    //   262: astore #10
    //   264: aload #10
    //   266: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   269: astore #11
    //   271: aload #11
    //   273: iconst_0
    //   274: aaload
    //   275: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.FIXED : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   278: if_acmpeq -> 291
    //   281: aload #11
    //   283: iconst_0
    //   284: aaload
    //   285: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.MATCH_PARENT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   288: if_acmpne -> 370
    //   291: aload #10
    //   293: invokevirtual getWidth : ()I
    //   296: iload #5
    //   298: iadd
    //   299: istore_3
    //   300: aload_0
    //   301: getfield container : Landroidx/constraintlayout/solver/widgets/ConstraintWidgetContainer;
    //   304: getfield horizontalRun : Landroidx/constraintlayout/solver/widgets/analyzer/HorizontalWidgetRun;
    //   307: getfield end : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   310: iload_3
    //   311: invokevirtual resolve : (I)V
    //   314: aload_0
    //   315: getfield container : Landroidx/constraintlayout/solver/widgets/ConstraintWidgetContainer;
    //   318: getfield horizontalRun : Landroidx/constraintlayout/solver/widgets/analyzer/HorizontalWidgetRun;
    //   321: getfield dimension : Landroidx/constraintlayout/solver/widgets/analyzer/DimensionDependency;
    //   324: iload_3
    //   325: iload #5
    //   327: isub
    //   328: invokevirtual resolve : (I)V
    //   331: goto -> 415
    //   334: aload_0
    //   335: getfield container : Landroidx/constraintlayout/solver/widgets/ConstraintWidgetContainer;
    //   338: astore #10
    //   340: aload #10
    //   342: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   345: astore #11
    //   347: aload #11
    //   349: iconst_1
    //   350: aaload
    //   351: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.FIXED : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   354: if_acmpeq -> 375
    //   357: aload #11
    //   359: iconst_1
    //   360: aaload
    //   361: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.MATCH_PARENT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   364: if_acmpne -> 370
    //   367: goto -> 375
    //   370: iconst_0
    //   371: istore_3
    //   372: goto -> 417
    //   375: aload #10
    //   377: invokevirtual getHeight : ()I
    //   380: iload #6
    //   382: iadd
    //   383: istore_3
    //   384: aload_0
    //   385: getfield container : Landroidx/constraintlayout/solver/widgets/ConstraintWidgetContainer;
    //   388: getfield verticalRun : Landroidx/constraintlayout/solver/widgets/analyzer/VerticalWidgetRun;
    //   391: getfield end : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   394: iload_3
    //   395: invokevirtual resolve : (I)V
    //   398: aload_0
    //   399: getfield container : Landroidx/constraintlayout/solver/widgets/ConstraintWidgetContainer;
    //   402: getfield verticalRun : Landroidx/constraintlayout/solver/widgets/analyzer/VerticalWidgetRun;
    //   405: getfield dimension : Landroidx/constraintlayout/solver/widgets/analyzer/DimensionDependency;
    //   408: iload_3
    //   409: iload #6
    //   411: isub
    //   412: invokevirtual resolve : (I)V
    //   415: iconst_1
    //   416: istore_3
    //   417: aload_0
    //   418: invokevirtual measureWidgets : ()V
    //   421: aload_0
    //   422: getfield mRuns : Ljava/util/ArrayList;
    //   425: invokevirtual iterator : ()Ljava/util/Iterator;
    //   428: astore #10
    //   430: aload #10
    //   432: invokeinterface hasNext : ()Z
    //   437: ifeq -> 495
    //   440: aload #10
    //   442: invokeinterface next : ()Ljava/lang/Object;
    //   447: checkcast androidx/constraintlayout/solver/widgets/analyzer/WidgetRun
    //   450: astore #11
    //   452: aload #11
    //   454: getfield orientation : I
    //   457: iload_2
    //   458: if_icmpeq -> 464
    //   461: goto -> 430
    //   464: aload #11
    //   466: getfield widget : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   469: aload_0
    //   470: getfield container : Landroidx/constraintlayout/solver/widgets/ConstraintWidgetContainer;
    //   473: if_acmpne -> 487
    //   476: aload #11
    //   478: getfield resolved : Z
    //   481: ifne -> 487
    //   484: goto -> 430
    //   487: aload #11
    //   489: invokevirtual applyToWidget : ()V
    //   492: goto -> 430
    //   495: aload_0
    //   496: getfield mRuns : Ljava/util/ArrayList;
    //   499: invokevirtual iterator : ()Ljava/util/Iterator;
    //   502: astore #10
    //   504: iload #7
    //   506: istore_1
    //   507: aload #10
    //   509: invokeinterface hasNext : ()Z
    //   514: ifeq -> 612
    //   517: aload #10
    //   519: invokeinterface next : ()Ljava/lang/Object;
    //   524: checkcast androidx/constraintlayout/solver/widgets/analyzer/WidgetRun
    //   527: astore #11
    //   529: aload #11
    //   531: getfield orientation : I
    //   534: iload_2
    //   535: if_icmpeq -> 541
    //   538: goto -> 504
    //   541: iload_3
    //   542: ifne -> 560
    //   545: aload #11
    //   547: getfield widget : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   550: aload_0
    //   551: getfield container : Landroidx/constraintlayout/solver/widgets/ConstraintWidgetContainer;
    //   554: if_acmpne -> 560
    //   557: goto -> 504
    //   560: aload #11
    //   562: getfield start : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   565: getfield resolved : Z
    //   568: ifne -> 576
    //   571: iconst_0
    //   572: istore_1
    //   573: goto -> 612
    //   576: aload #11
    //   578: getfield end : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   581: getfield resolved : Z
    //   584: ifne -> 590
    //   587: goto -> 571
    //   590: aload #11
    //   592: instanceof androidx/constraintlayout/solver/widgets/analyzer/ChainRun
    //   595: ifne -> 504
    //   598: aload #11
    //   600: getfield dimension : Landroidx/constraintlayout/solver/widgets/analyzer/DimensionDependency;
    //   603: getfield resolved : Z
    //   606: ifne -> 504
    //   609: goto -> 571
    //   612: aload_0
    //   613: getfield container : Landroidx/constraintlayout/solver/widgets/ConstraintWidgetContainer;
    //   616: aload #8
    //   618: invokevirtual setHorizontalDimensionBehaviour : (Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;)V
    //   621: aload_0
    //   622: getfield container : Landroidx/constraintlayout/solver/widgets/ConstraintWidgetContainer;
    //   625: aload #9
    //   627: invokevirtual setVerticalDimensionBehaviour : (Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;)V
    //   630: iload_1
    //   631: ireturn
  }
  
  public void invalidateGraph() {
    this.mNeedBuildGraph = true;
  }
  
  public void invalidateMeasures() {
    this.mNeedRedoMeasures = true;
  }
  
  public void measureWidgets() {
    Iterator iterator = ((WidgetContainer)this.container).mChildren.iterator();
    while (true) {
      while (true)
        break; 
      if (((ConstraintWidget)SYNTHETIC_LOCAL_VARIABLE_8).measured) {
        DimensionDependency dimensionDependency = ((ConstraintWidget)SYNTHETIC_LOCAL_VARIABLE_8).verticalRun.baselineDimension;
        if (dimensionDependency != null)
          dimensionDependency.resolve(SYNTHETIC_LOCAL_VARIABLE_8.getBaselineDistance()); 
      } 
    } 
  }
  
  public void setMeasurer(BasicMeasure.Measurer paramMeasurer) {
    this.mMeasurer = paramMeasurer;
  }
}


/* Location:              C:\soft\dex2jar-2.0\BabyBus TV_Kids Videos & Games-dex2jar.jar!\androidx\constraintlayout\solver\widgets\analyzer\DependencyGraph.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */