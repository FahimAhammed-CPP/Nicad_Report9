package androidx.constraintlayout.solver.widgets.analyzer;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class DependencyNode implements Dependency {
  public boolean delegateToWidgetRun = false;
  
  List<Dependency> dependencies = new ArrayList<Dependency>();
  
  int margin;
  
  DimensionDependency marginDependency = null;
  
  int marginFactor = 1;
  
  public boolean readyToSolve = false;
  
  public boolean resolved = false;
  
  WidgetRun run;
  
  List<DependencyNode> targets = new ArrayList<DependencyNode>();
  
  Type type = Type.UNKNOWN;
  
  public Dependency updateDelegate = null;
  
  public int value;
  
  public DependencyNode(WidgetRun paramWidgetRun) {
    this.run = paramWidgetRun;
  }
  
  public void addDependency(Dependency paramDependency) {
    this.dependencies.add(paramDependency);
    if (this.resolved)
      paramDependency.update(paramDependency); 
  }
  
  public void clear() {
    this.targets.clear();
    this.dependencies.clear();
    this.resolved = false;
    this.value = 0;
    this.readyToSolve = false;
    this.delegateToWidgetRun = false;
  }
  
  public String name() {
    String str = this.run.widget.getDebugName();
    Type type = this.type;
    if (type == Type.LEFT || type == Type.RIGHT) {
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append(str);
      stringBuilder1.append("_HORIZONTAL");
      str = stringBuilder1.toString();
      stringBuilder1 = new StringBuilder();
      stringBuilder1.append(str);
      stringBuilder1.append(":");
      stringBuilder1.append(this.type.name());
      return stringBuilder1.toString();
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(str);
    stringBuilder.append("_VERTICAL");
    str = stringBuilder.toString();
    stringBuilder = new StringBuilder();
    stringBuilder.append(str);
    stringBuilder.append(":");
    stringBuilder.append(this.type.name());
    return stringBuilder.toString();
  }
  
  public void resolve(int paramInt) {
    if (this.resolved)
      return; 
    this.resolved = true;
    this.value = paramInt;
    for (Dependency dependency : this.dependencies)
      dependency.update(dependency); 
  }
  
  public String toString() {
    String str;
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(this.run.widget.getDebugName());
    stringBuilder.append(":");
    stringBuilder.append(this.type);
    stringBuilder.append("(");
    if (this.resolved) {
      Integer integer = Integer.valueOf(this.value);
    } else {
      str = "unresolved";
    } 
    stringBuilder.append(str);
    stringBuilder.append(") <t=");
    stringBuilder.append(this.targets.size());
    stringBuilder.append(":d=");
    stringBuilder.append(this.dependencies.size());
    stringBuilder.append(">");
    return stringBuilder.toString();
  }
  
  public void update(Dependency paramDependency) {
    Iterator<DependencyNode> iterator = this.targets.iterator();
    while (iterator.hasNext()) {
      if (!((DependencyNode)iterator.next()).resolved)
        return; 
    } 
    this.readyToSolve = true;
    Dependency dependency = this.updateDelegate;
    if (dependency != null)
      dependency.update(this); 
    if (this.delegateToWidgetRun) {
      this.run.update(this);
      return;
    } 
    dependency = null;
    int i = 0;
    for (DependencyNode dependencyNode : this.targets) {
      if (dependencyNode instanceof DimensionDependency)
        continue; 
      i++;
      dependency = dependencyNode;
    } 
    if (dependency != null && i == 1 && ((DependencyNode)dependency).resolved) {
      DimensionDependency dimensionDependency = this.marginDependency;
      if (dimensionDependency != null)
        if (dimensionDependency.resolved) {
          this.margin = this.marginFactor * dimensionDependency.value;
        } else {
          return;
        }  
      resolve(((DependencyNode)dependency).value + this.margin);
    } 
    dependency = this.updateDelegate;
    if (dependency != null)
      dependency.update(this); 
  }
  
  enum Type {
    BASELINE, BOTTOM, HORIZONTAL_DIMENSION, LEFT, RIGHT, TOP, UNKNOWN, VERTICAL_DIMENSION;
    
    static {
      Type type1 = new Type("UNKNOWN", 0);
      UNKNOWN = type1;
      Type type2 = new Type("HORIZONTAL_DIMENSION", 1);
      HORIZONTAL_DIMENSION = type2;
      Type type3 = new Type("VERTICAL_DIMENSION", 2);
      VERTICAL_DIMENSION = type3;
      Type type4 = new Type("LEFT", 3);
      LEFT = type4;
      Type type5 = new Type("RIGHT", 4);
      RIGHT = type5;
      Type type6 = new Type("TOP", 5);
      TOP = type6;
      Type type7 = new Type("BOTTOM", 6);
      BOTTOM = type7;
      Type type8 = new Type("BASELINE", 7);
      BASELINE = type8;
      $VALUES = new Type[] { type1, type2, type3, type4, type5, type6, type7, type8 };
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\BabyBus TV_Kids Videos & Games-dex2jar.jar!\androidx\constraintlayout\solver\widgets\analyzer\DependencyNode.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */