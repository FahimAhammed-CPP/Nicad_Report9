package androidx.constraintlayout.solver.widgets.analyzer;

import androidx.constraintlayout.solver.LinearSystem;
import androidx.constraintlayout.solver.Metrics;
import androidx.constraintlayout.solver.widgets.ConstraintAnchor;
import androidx.constraintlayout.solver.widgets.ConstraintWidget;
import androidx.constraintlayout.solver.widgets.ConstraintWidgetContainer;
import androidx.constraintlayout.solver.widgets.Optimizer;
import androidx.constraintlayout.solver.widgets.VirtualLayout;
import androidx.constraintlayout.solver.widgets.WidgetContainer;
import java.util.ArrayList;

public class BasicMeasure {
  public static final int AT_MOST = -2147483648;
  
  private static final boolean DEBUG = false;
  
  public static final int EXACTLY = 1073741824;
  
  public static final int FIXED = -3;
  
  public static final int MATCH_PARENT = -1;
  
  private static final int MODE_SHIFT = 30;
  
  public static final int UNSPECIFIED = 0;
  
  public static final int WRAP_CONTENT = -2;
  
  private ConstraintWidgetContainer constraintWidgetContainer;
  
  private Measure mMeasure = new Measure();
  
  private final ArrayList<ConstraintWidget> mVariableDimensionsWidgets = new ArrayList<ConstraintWidget>();
  
  public BasicMeasure(ConstraintWidgetContainer paramConstraintWidgetContainer) {
    this.constraintWidgetContainer = paramConstraintWidgetContainer;
  }
  
  private boolean measure(Measurer paramMeasurer, ConstraintWidget paramConstraintWidget, int paramInt) {
    boolean bool;
    this.mMeasure.horizontalBehavior = paramConstraintWidget.getHorizontalDimensionBehaviour();
    this.mMeasure.verticalBehavior = paramConstraintWidget.getVerticalDimensionBehaviour();
    this.mMeasure.horizontalDimension = paramConstraintWidget.getWidth();
    this.mMeasure.verticalDimension = paramConstraintWidget.getHeight();
    Measure measure2 = this.mMeasure;
    measure2.measuredNeedsSolverPass = false;
    measure2.measureStrategy = paramInt;
    ConstraintWidget.DimensionBehaviour dimensionBehaviour1 = measure2.horizontalBehavior;
    ConstraintWidget.DimensionBehaviour dimensionBehaviour2 = ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT;
    if (dimensionBehaviour1 == dimensionBehaviour2) {
      bool = true;
    } else {
      bool = false;
    } 
    if (measure2.verticalBehavior == dimensionBehaviour2) {
      paramInt = 1;
    } else {
      paramInt = 0;
    } 
    if (bool && paramConstraintWidget.mDimensionRatio > 0.0F) {
      bool = true;
    } else {
      bool = false;
    } 
    if (paramInt != 0 && paramConstraintWidget.mDimensionRatio > 0.0F) {
      paramInt = 1;
    } else {
      paramInt = 0;
    } 
    if (bool && paramConstraintWidget.mResolvedMatchConstraintDefault[0] == 4)
      measure2.horizontalBehavior = ConstraintWidget.DimensionBehaviour.FIXED; 
    if (paramInt != 0 && paramConstraintWidget.mResolvedMatchConstraintDefault[1] == 4)
      measure2.verticalBehavior = ConstraintWidget.DimensionBehaviour.FIXED; 
    paramMeasurer.measure(paramConstraintWidget, measure2);
    paramConstraintWidget.setWidth(this.mMeasure.measuredWidth);
    paramConstraintWidget.setHeight(this.mMeasure.measuredHeight);
    paramConstraintWidget.setHasBaseline(this.mMeasure.measuredHasBaseline);
    paramConstraintWidget.setBaselineDistance(this.mMeasure.measuredBaseline);
    Measure measure1 = this.mMeasure;
    measure1.measureStrategy = Measure.SELF_DIMENSIONS;
    return measure1.measuredNeedsSolverPass;
  }
  
  private void measureChildren(ConstraintWidgetContainer paramConstraintWidgetContainer) {
    // Byte code:
    //   0: aload_1
    //   1: getfield mChildren : Ljava/util/ArrayList;
    //   4: invokevirtual size : ()I
    //   7: istore #6
    //   9: aload_1
    //   10: bipush #64
    //   12: invokevirtual optimizeFor : (I)Z
    //   15: istore #7
    //   17: aload_1
    //   18: invokevirtual getMeasurer : ()Landroidx/constraintlayout/solver/widgets/analyzer/BasicMeasure$Measurer;
    //   21: astore #8
    //   23: iconst_0
    //   24: istore #4
    //   26: iload #4
    //   28: iload #6
    //   30: if_icmpge -> 388
    //   33: aload_1
    //   34: getfield mChildren : Ljava/util/ArrayList;
    //   37: iload #4
    //   39: invokevirtual get : (I)Ljava/lang/Object;
    //   42: checkcast androidx/constraintlayout/solver/widgets/ConstraintWidget
    //   45: astore #9
    //   47: aload #9
    //   49: instanceof androidx/constraintlayout/solver/widgets/Guideline
    //   52: ifeq -> 58
    //   55: goto -> 379
    //   58: aload #9
    //   60: instanceof androidx/constraintlayout/solver/widgets/Barrier
    //   63: ifeq -> 69
    //   66: goto -> 379
    //   69: aload #9
    //   71: invokevirtual isInVirtualLayout : ()Z
    //   74: ifeq -> 80
    //   77: goto -> 379
    //   80: iload #7
    //   82: ifeq -> 134
    //   85: aload #9
    //   87: getfield horizontalRun : Landroidx/constraintlayout/solver/widgets/analyzer/HorizontalWidgetRun;
    //   90: astore #10
    //   92: aload #10
    //   94: ifnull -> 134
    //   97: aload #9
    //   99: getfield verticalRun : Landroidx/constraintlayout/solver/widgets/analyzer/VerticalWidgetRun;
    //   102: astore #11
    //   104: aload #11
    //   106: ifnull -> 134
    //   109: aload #10
    //   111: getfield dimension : Landroidx/constraintlayout/solver/widgets/analyzer/DimensionDependency;
    //   114: getfield resolved : Z
    //   117: ifeq -> 134
    //   120: aload #11
    //   122: getfield dimension : Landroidx/constraintlayout/solver/widgets/analyzer/DimensionDependency;
    //   125: getfield resolved : Z
    //   128: ifeq -> 134
    //   131: goto -> 379
    //   134: aload #9
    //   136: iconst_0
    //   137: invokevirtual getDimensionBehaviour : (I)Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   140: astore #10
    //   142: iconst_1
    //   143: istore #5
    //   145: aload #9
    //   147: iconst_1
    //   148: invokevirtual getDimensionBehaviour : (I)Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   151: astore #11
    //   153: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   156: astore #12
    //   158: aload #10
    //   160: aload #12
    //   162: if_acmpne -> 195
    //   165: aload #9
    //   167: getfield mMatchConstraintDefaultWidth : I
    //   170: iconst_1
    //   171: if_icmpeq -> 195
    //   174: aload #11
    //   176: aload #12
    //   178: if_acmpne -> 195
    //   181: aload #9
    //   183: getfield mMatchConstraintDefaultHeight : I
    //   186: iconst_1
    //   187: if_icmpeq -> 195
    //   190: iconst_1
    //   191: istore_2
    //   192: goto -> 197
    //   195: iconst_0
    //   196: istore_2
    //   197: iload_2
    //   198: istore_3
    //   199: iload_2
    //   200: ifne -> 337
    //   203: iload_2
    //   204: istore_3
    //   205: aload_1
    //   206: iconst_1
    //   207: invokevirtual optimizeFor : (I)Z
    //   210: ifeq -> 337
    //   213: iload_2
    //   214: istore_3
    //   215: aload #9
    //   217: instanceof androidx/constraintlayout/solver/widgets/VirtualLayout
    //   220: ifne -> 337
    //   223: iload_2
    //   224: istore_3
    //   225: aload #10
    //   227: aload #12
    //   229: if_acmpne -> 263
    //   232: iload_2
    //   233: istore_3
    //   234: aload #9
    //   236: getfield mMatchConstraintDefaultWidth : I
    //   239: ifne -> 263
    //   242: iload_2
    //   243: istore_3
    //   244: aload #11
    //   246: aload #12
    //   248: if_acmpeq -> 263
    //   251: iload_2
    //   252: istore_3
    //   253: aload #9
    //   255: invokevirtual isInHorizontalChain : ()Z
    //   258: ifne -> 263
    //   261: iconst_1
    //   262: istore_3
    //   263: iload_3
    //   264: istore_2
    //   265: aload #11
    //   267: aload #12
    //   269: if_acmpne -> 303
    //   272: iload_3
    //   273: istore_2
    //   274: aload #9
    //   276: getfield mMatchConstraintDefaultHeight : I
    //   279: ifne -> 303
    //   282: iload_3
    //   283: istore_2
    //   284: aload #10
    //   286: aload #12
    //   288: if_acmpeq -> 303
    //   291: iload_3
    //   292: istore_2
    //   293: aload #9
    //   295: invokevirtual isInHorizontalChain : ()Z
    //   298: ifne -> 303
    //   301: iconst_1
    //   302: istore_2
    //   303: aload #10
    //   305: aload #12
    //   307: if_acmpeq -> 319
    //   310: iload_2
    //   311: istore_3
    //   312: aload #11
    //   314: aload #12
    //   316: if_acmpne -> 337
    //   319: iload_2
    //   320: istore_3
    //   321: aload #9
    //   323: getfield mDimensionRatio : F
    //   326: fconst_0
    //   327: fcmpl
    //   328: ifle -> 337
    //   331: iload #5
    //   333: istore_3
    //   334: goto -> 337
    //   337: iload_3
    //   338: ifeq -> 344
    //   341: goto -> 379
    //   344: aload_0
    //   345: aload #8
    //   347: aload #9
    //   349: getstatic androidx/constraintlayout/solver/widgets/analyzer/BasicMeasure$Measure.SELF_DIMENSIONS : I
    //   352: invokespecial measure : (Landroidx/constraintlayout/solver/widgets/analyzer/BasicMeasure$Measurer;Landroidx/constraintlayout/solver/widgets/ConstraintWidget;I)Z
    //   355: pop
    //   356: aload_1
    //   357: getfield mMetrics : Landroidx/constraintlayout/solver/Metrics;
    //   360: astore #9
    //   362: aload #9
    //   364: ifnull -> 379
    //   367: aload #9
    //   369: aload #9
    //   371: getfield measuredWidgets : J
    //   374: lconst_1
    //   375: ladd
    //   376: putfield measuredWidgets : J
    //   379: iload #4
    //   381: iconst_1
    //   382: iadd
    //   383: istore #4
    //   385: goto -> 26
    //   388: aload #8
    //   390: invokeinterface didMeasures : ()V
    //   395: return
  }
  
  private void solveLinearSystem(ConstraintWidgetContainer paramConstraintWidgetContainer, String paramString, int paramInt1, int paramInt2) {
    int i = paramConstraintWidgetContainer.getMinWidth();
    int j = paramConstraintWidgetContainer.getMinHeight();
    paramConstraintWidgetContainer.setMinWidth(0);
    paramConstraintWidgetContainer.setMinHeight(0);
    paramConstraintWidgetContainer.setWidth(paramInt1);
    paramConstraintWidgetContainer.setHeight(paramInt2);
    paramConstraintWidgetContainer.setMinWidth(i);
    paramConstraintWidgetContainer.setMinHeight(j);
    this.constraintWidgetContainer.layout();
  }
  
  public long solverMeasure(ConstraintWidgetContainer paramConstraintWidgetContainer, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9) {
    Measurer measurer = paramConstraintWidgetContainer.getMeasurer();
    paramInt9 = ((WidgetContainer)paramConstraintWidgetContainer).mChildren.size();
    int j = paramConstraintWidgetContainer.getWidth();
    int i = paramConstraintWidgetContainer.getHeight();
    boolean bool = Optimizer.enabled(paramInt1, 128);
    if (bool || Optimizer.enabled(paramInt1, 64)) {
      paramInt1 = 1;
    } else {
      paramInt1 = 0;
    } 
    paramInt3 = paramInt1;
    if (paramInt1 != 0) {
      paramInt2 = 0;
      while (true) {
        paramInt3 = paramInt1;
        if (paramInt2 < paramInt9) {
          ConstraintWidget constraintWidget = ((WidgetContainer)paramConstraintWidgetContainer).mChildren.get(paramInt2);
          ConstraintWidget.DimensionBehaviour dimensionBehaviour1 = constraintWidget.getHorizontalDimensionBehaviour();
          ConstraintWidget.DimensionBehaviour dimensionBehaviour2 = ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT;
          if (dimensionBehaviour1 == dimensionBehaviour2) {
            paramInt3 = 1;
          } else {
            paramInt3 = 0;
          } 
          if (constraintWidget.getVerticalDimensionBehaviour() == dimensionBehaviour2) {
            paramInt8 = 1;
          } else {
            paramInt8 = 0;
          } 
          if (paramInt3 != 0 && paramInt8 != 0 && constraintWidget.getDimensionRatio() > 0.0F) {
            paramInt3 = 1;
          } else {
            paramInt3 = 0;
          } 
          if ((constraintWidget.isInHorizontalChain() && paramInt3 != 0) || (constraintWidget.isInVerticalChain() && paramInt3 != 0) || constraintWidget instanceof VirtualLayout || constraintWidget.isInHorizontalChain() || constraintWidget.isInVerticalChain()) {
            paramInt3 = 0;
            break;
          } 
          paramInt2++;
          continue;
        } 
        break;
      } 
    } 
    if (paramInt3 != 0) {
      Metrics metrics = LinearSystem.sMetrics;
      if (metrics != null)
        metrics.measures++; 
    } 
    if ((paramInt4 == 1073741824 && paramInt6 == 1073741824) || bool) {
      paramInt1 = 1;
    } else {
      paramInt1 = 0;
    } 
    int k = paramInt3 & paramInt1;
    if (k != 0) {
      boolean bool1;
      paramInt1 = Math.min(paramConstraintWidgetContainer.getMaxWidth(), paramInt5);
      paramInt2 = Math.min(paramConstraintWidgetContainer.getMaxHeight(), paramInt7);
      if (paramInt4 == 1073741824 && paramConstraintWidgetContainer.getWidth() != paramInt1) {
        paramConstraintWidgetContainer.setWidth(paramInt1);
        paramConstraintWidgetContainer.invalidateGraph();
      } 
      if (paramInt6 == 1073741824 && paramConstraintWidgetContainer.getHeight() != paramInt2) {
        paramConstraintWidgetContainer.setHeight(paramInt2);
        paramConstraintWidgetContainer.invalidateGraph();
      } 
      if (paramInt4 == 1073741824 && paramInt6 == 1073741824) {
        bool1 = paramConstraintWidgetContainer.directMeasure(bool);
        paramInt1 = 2;
      } else {
        bool1 = paramConstraintWidgetContainer.directMeasureSetup(bool);
        if (paramInt4 == 1073741824) {
          bool1 &= paramConstraintWidgetContainer.directMeasureWithOrientation(bool, 0);
          paramInt1 = 1;
        } else {
          paramInt1 = 0;
        } 
        if (paramInt6 == 1073741824) {
          bool1 = paramConstraintWidgetContainer.directMeasureWithOrientation(bool, 1) & bool1;
          paramInt1++;
        } 
      } 
      bool = bool1;
      paramInt2 = paramInt1;
      if (bool1) {
        boolean bool2;
        if (paramInt4 == 1073741824) {
          bool = true;
        } else {
          bool = false;
        } 
        if (paramInt6 == 1073741824) {
          bool2 = true;
        } else {
          bool2 = false;
        } 
        paramConstraintWidgetContainer.updateFromRuns(bool, bool2);
        bool = bool1;
        paramInt2 = paramInt1;
      } 
    } else {
      bool = false;
      paramInt2 = 0;
    } 
    if (!bool || paramInt2 != 2) {
      paramInt4 = paramConstraintWidgetContainer.getOptimizationLevel();
      if (paramInt9 > 0)
        measureChildren(paramConstraintWidgetContainer); 
      updateHierarchy(paramConstraintWidgetContainer);
      paramInt7 = this.mVariableDimensionsWidgets.size();
      if (paramInt9 > 0)
        solveLinearSystem(paramConstraintWidgetContainer, "First pass", j, i); 
      if (paramInt7 > 0) {
        int m;
        boolean bool1;
        int i2;
        boolean bool2;
        ConstraintWidget.DimensionBehaviour dimensionBehaviour1 = paramConstraintWidgetContainer.getHorizontalDimensionBehaviour();
        ConstraintWidget.DimensionBehaviour dimensionBehaviour2 = ConstraintWidget.DimensionBehaviour.WRAP_CONTENT;
        if (dimensionBehaviour1 == dimensionBehaviour2) {
          paramInt8 = 1;
        } else {
          paramInt8 = 0;
        } 
        if (paramConstraintWidgetContainer.getVerticalDimensionBehaviour() == dimensionBehaviour2) {
          paramInt9 = 1;
        } else {
          paramInt9 = 0;
        } 
        paramInt2 = Math.max(paramConstraintWidgetContainer.getWidth(), this.constraintWidgetContainer.getMinWidth());
        paramInt1 = Math.max(paramConstraintWidgetContainer.getHeight(), this.constraintWidgetContainer.getMinHeight());
        paramInt6 = 0;
        paramInt3 = 0;
        while (paramInt6 < paramInt7) {
          boolean bool3;
          ConstraintWidget constraintWidget = this.mVariableDimensionsWidgets.get(paramInt6);
          if (!(constraintWidget instanceof VirtualLayout)) {
            paramInt5 = paramInt3;
          } else {
            int i3;
            paramInt5 = constraintWidget.getWidth();
            int i5 = constraintWidget.getHeight();
            int i7 = measure(measurer, constraintWidget, Measure.TRY_GIVEN_DIMENSIONS);
            Metrics metrics = paramConstraintWidgetContainer.mMetrics;
            if (metrics != null)
              metrics.measuredMatchWidgets++; 
            int i6 = constraintWidget.getWidth();
            i2 = constraintWidget.getHeight();
            if (i6 != paramInt5) {
              constraintWidget.setWidth(i6);
              paramInt3 = paramInt2;
              if (paramInt8 != 0) {
                paramInt3 = paramInt2;
                if (constraintWidget.getRight() > paramInt2)
                  paramInt3 = Math.max(paramInt2, constraintWidget.getRight() + constraintWidget.getAnchor(ConstraintAnchor.Type.RIGHT).getMargin()); 
              } 
              paramInt5 = 1;
              paramInt2 = paramInt3;
            } else {
              bool3 = i7 | paramInt3;
            } 
            int i4 = paramInt1;
            if (i2 != i5) {
              constraintWidget.setHeight(i2);
              int i8 = paramInt1;
              if (paramInt9 != 0) {
                int i9 = paramInt1;
                if (constraintWidget.getBottom() > paramInt1)
                  i3 = Math.max(paramInt1, constraintWidget.getBottom() + constraintWidget.getAnchor(ConstraintAnchor.Type.BOTTOM).getMargin()); 
              } 
              bool3 = true;
            } 
            bool3 |= ((VirtualLayout)constraintWidget).needSolverPass();
            m = i3;
          } 
          paramInt6++;
          bool1 = bool3;
        } 
        int i1 = 0;
        int n = k;
        while (true) {
          int i3 = paramInt2;
          k = m;
          bool2 = bool1;
          if (i1 < 2) {
            int i4;
            k = 0;
            boolean bool3 = bool1;
            int i5 = paramInt7;
            while (k < i5) {
              boolean bool4;
              int i6;
              ConstraintWidget constraintWidget = this.mVariableDimensionsWidgets.get(k);
              if ((constraintWidget instanceof androidx.constraintlayout.solver.widgets.Helper && !(constraintWidget instanceof VirtualLayout)) || constraintWidget instanceof androidx.constraintlayout.solver.widgets.Guideline || constraintWidget.getVisibility() == 8 || (n != 0 && constraintWidget.horizontalRun.dimension.resolved && constraintWidget.verticalRun.dimension.resolved) || constraintWidget instanceof VirtualLayout) {
                int i7 = paramInt2;
                bool4 = bool3;
              } else {
                int i8;
                int i12 = constraintWidget.getWidth();
                int i10 = constraintWidget.getHeight();
                i6 = constraintWidget.getBaselineDistance();
                paramInt7 = Measure.TRY_GIVEN_DIMENSIONS;
                if (i1 == 1)
                  paramInt7 = Measure.USE_GIVEN_DIMENSIONS; 
                bool4 = measure(measurer, constraintWidget, paramInt7) | bool3;
                Metrics metrics = paramConstraintWidgetContainer.mMetrics;
                if (metrics != null)
                  metrics.measuredMatchWidgets++; 
                int i13 = constraintWidget.getWidth();
                int i11 = constraintWidget.getHeight();
                int i9 = paramInt2;
                if (i13 != i12) {
                  constraintWidget.setWidth(i13);
                  int i14 = paramInt2;
                  if (paramInt8 != 0) {
                    int i15 = paramInt2;
                    if (constraintWidget.getRight() > paramInt2)
                      i8 = Math.max(paramInt2, constraintWidget.getRight() + constraintWidget.getAnchor(ConstraintAnchor.Type.RIGHT).getMargin()); 
                  } 
                  bool4 = true;
                } 
                int i7 = m;
                if (i11 != i10) {
                  constraintWidget.setHeight(i11);
                  i7 = m;
                  if (paramInt9 != 0) {
                    i7 = m;
                    if (constraintWidget.getBottom() > m)
                      i7 = Math.max(m, constraintWidget.getBottom() + constraintWidget.getAnchor(ConstraintAnchor.Type.BOTTOM).getMargin()); 
                  } 
                  bool4 = true;
                } 
                if (constraintWidget.hasBaseline() && i6 != constraintWidget.getBaselineDistance()) {
                  bool4 = true;
                  i6 = i8;
                  m = i7;
                } else {
                  m = i7;
                  i6 = i8;
                } 
              } 
              k++;
              i4 = i6;
              bool3 = bool4;
            } 
            i2 = i4;
            k = m;
            bool2 = bool3;
            if (bool3) {
              solveLinearSystem(paramConstraintWidgetContainer, "intermediate pass", j, i);
              i1++;
              bool3 = false;
              paramInt7 = i5;
              boolean bool4 = bool3;
              continue;
            } 
          } 
          break;
        } 
        if (bool2) {
          solveLinearSystem(paramConstraintWidgetContainer, "2nd pass", j, i);
          if (paramConstraintWidgetContainer.getWidth() < i2) {
            paramConstraintWidgetContainer.setWidth(i2);
            m = 1;
          } else {
            m = 0;
          } 
          if (paramConstraintWidgetContainer.getHeight() < k) {
            paramConstraintWidgetContainer.setHeight(k);
            m = 1;
          } 
          if (m != 0)
            solveLinearSystem(paramConstraintWidgetContainer, "3rd pass", j, i); 
        } 
      } 
      paramConstraintWidgetContainer.setOptimizationLevel(paramInt4);
    } 
    return 0L;
  }
  
  public void updateHierarchy(ConstraintWidgetContainer paramConstraintWidgetContainer) {
    this.mVariableDimensionsWidgets.clear();
    int j = ((WidgetContainer)paramConstraintWidgetContainer).mChildren.size();
    for (int i = 0; i < j; i++) {
      ConstraintWidget constraintWidget = ((WidgetContainer)paramConstraintWidgetContainer).mChildren.get(i);
      ConstraintWidget.DimensionBehaviour dimensionBehaviour1 = constraintWidget.getHorizontalDimensionBehaviour();
      ConstraintWidget.DimensionBehaviour dimensionBehaviour2 = ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT;
      if (dimensionBehaviour1 == dimensionBehaviour2 || constraintWidget.getVerticalDimensionBehaviour() == dimensionBehaviour2)
        this.mVariableDimensionsWidgets.add(constraintWidget); 
    } 
    paramConstraintWidgetContainer.invalidateGraph();
  }
  
  public static class Measure {
    public static int SELF_DIMENSIONS = 0;
    
    public static int TRY_GIVEN_DIMENSIONS = 1;
    
    public static int USE_GIVEN_DIMENSIONS = 2;
    
    public ConstraintWidget.DimensionBehaviour horizontalBehavior;
    
    public int horizontalDimension;
    
    public int measureStrategy;
    
    public int measuredBaseline;
    
    public boolean measuredHasBaseline;
    
    public int measuredHeight;
    
    public boolean measuredNeedsSolverPass;
    
    public int measuredWidth;
    
    public ConstraintWidget.DimensionBehaviour verticalBehavior;
    
    public int verticalDimension;
  }
  
  public static interface Measurer {
    void didMeasures();
    
    void measure(ConstraintWidget param1ConstraintWidget, BasicMeasure.Measure param1Measure);
  }
}


/* Location:              C:\soft\dex2jar-2.0\BabyBus TV_Kids Videos & Games-dex2jar.jar!\androidx\constraintlayout\solver\widgets\analyzer\BasicMeasure.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */