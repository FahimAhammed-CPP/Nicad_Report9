package androidx.constraintlayout.solver.widgets;

import androidx.constraintlayout.solver.LinearSystem;
import androidx.constraintlayout.solver.Metrics;
import androidx.constraintlayout.solver.SolverVariable;
import androidx.constraintlayout.solver.widgets.analyzer.BasicMeasure;
import androidx.constraintlayout.solver.widgets.analyzer.DependencyGraph;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;

public class ConstraintWidgetContainer extends WidgetContainer {
  private static final boolean DEBUG = false;
  
  static final boolean DEBUG_GRAPH = false;
  
  private static final boolean DEBUG_LAYOUT = false;
  
  private static final int MAX_ITERATIONS = 8;
  
  static int mycounter;
  
  private WeakReference<ConstraintAnchor> horizontalWrapMax = null;
  
  private WeakReference<ConstraintAnchor> horizontalWrapMin = null;
  
  BasicMeasure mBasicMeasureSolver = new BasicMeasure(this);
  
  int mDebugSolverPassCount = 0;
  
  public DependencyGraph mDependencyGraph = new DependencyGraph(this);
  
  public boolean mGroupsWrapOptimized = false;
  
  private boolean mHeightMeasuredTooSmall = false;
  
  ChainHead[] mHorizontalChainsArray = new ChainHead[4];
  
  public int mHorizontalChainsSize = 0;
  
  public boolean mHorizontalWrapOptimized = false;
  
  private boolean mIsRtl = false;
  
  public BasicMeasure.Measure mMeasure = new BasicMeasure.Measure();
  
  protected BasicMeasure.Measurer mMeasurer = null;
  
  public Metrics mMetrics;
  
  private int mOptimizationLevel = 257;
  
  int mPaddingBottom;
  
  int mPaddingLeft;
  
  int mPaddingRight;
  
  int mPaddingTop;
  
  public boolean mSkipSolver = false;
  
  protected LinearSystem mSystem = new LinearSystem();
  
  ChainHead[] mVerticalChainsArray = new ChainHead[4];
  
  public int mVerticalChainsSize = 0;
  
  public boolean mVerticalWrapOptimized = false;
  
  private boolean mWidthMeasuredTooSmall = false;
  
  public int mWrapFixedHeight = 0;
  
  public int mWrapFixedWidth = 0;
  
  private WeakReference<ConstraintAnchor> verticalWrapMax = null;
  
  private WeakReference<ConstraintAnchor> verticalWrapMin = null;
  
  public ConstraintWidgetContainer() {}
  
  public ConstraintWidgetContainer(int paramInt1, int paramInt2) {
    super(paramInt1, paramInt2);
  }
  
  public ConstraintWidgetContainer(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    super(paramInt1, paramInt2, paramInt3, paramInt4);
  }
  
  public ConstraintWidgetContainer(String paramString, int paramInt1, int paramInt2) {
    super(paramInt1, paramInt2);
    setDebugName(paramString);
  }
  
  private void addHorizontalChain(ConstraintWidget paramConstraintWidget) {
    int i = this.mHorizontalChainsSize;
    ChainHead[] arrayOfChainHead = this.mHorizontalChainsArray;
    if (i + 1 >= arrayOfChainHead.length)
      this.mHorizontalChainsArray = Arrays.<ChainHead>copyOf(arrayOfChainHead, arrayOfChainHead.length * 2); 
    this.mHorizontalChainsArray[this.mHorizontalChainsSize] = new ChainHead(paramConstraintWidget, 0, isRtl());
    this.mHorizontalChainsSize++;
  }
  
  private void addMaxWrap(ConstraintAnchor paramConstraintAnchor, SolverVariable paramSolverVariable) {
    SolverVariable solverVariable = this.mSystem.createObjectVariable(paramConstraintAnchor);
    this.mSystem.addGreaterThan(paramSolverVariable, solverVariable, 0, 5);
  }
  
  private void addMinWrap(ConstraintAnchor paramConstraintAnchor, SolverVariable paramSolverVariable) {
    SolverVariable solverVariable = this.mSystem.createObjectVariable(paramConstraintAnchor);
    this.mSystem.addGreaterThan(solverVariable, paramSolverVariable, 0, 5);
  }
  
  private void addVerticalChain(ConstraintWidget paramConstraintWidget) {
    int i = this.mVerticalChainsSize;
    ChainHead[] arrayOfChainHead = this.mVerticalChainsArray;
    if (i + 1 >= arrayOfChainHead.length)
      this.mVerticalChainsArray = Arrays.<ChainHead>copyOf(arrayOfChainHead, arrayOfChainHead.length * 2); 
    this.mVerticalChainsArray[this.mVerticalChainsSize] = new ChainHead(paramConstraintWidget, 1, isRtl());
    this.mVerticalChainsSize++;
  }
  
  public static boolean measure(ConstraintWidget paramConstraintWidget, BasicMeasure.Measurer paramMeasurer, BasicMeasure.Measure paramMeasure, int paramInt) {
    int i;
    boolean bool1;
    boolean bool2;
    if (paramMeasurer == null)
      return false; 
    paramMeasure.horizontalBehavior = paramConstraintWidget.getHorizontalDimensionBehaviour();
    paramMeasure.verticalBehavior = paramConstraintWidget.getVerticalDimensionBehaviour();
    paramMeasure.horizontalDimension = paramConstraintWidget.getWidth();
    paramMeasure.verticalDimension = paramConstraintWidget.getHeight();
    paramMeasure.measuredNeedsSolverPass = false;
    paramMeasure.measureStrategy = paramInt;
    ConstraintWidget.DimensionBehaviour dimensionBehaviour1 = paramMeasure.horizontalBehavior;
    ConstraintWidget.DimensionBehaviour dimensionBehaviour2 = ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT;
    if (dimensionBehaviour1 == dimensionBehaviour2) {
      paramInt = 1;
    } else {
      paramInt = 0;
    } 
    if (paramMeasure.verticalBehavior == dimensionBehaviour2) {
      i = 1;
    } else {
      i = 0;
    } 
    if (paramInt != 0 && paramConstraintWidget.mDimensionRatio > 0.0F) {
      bool2 = true;
    } else {
      bool2 = false;
    } 
    if (i && paramConstraintWidget.mDimensionRatio > 0.0F) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    int j = paramInt;
    if (paramInt != 0) {
      j = paramInt;
      if (paramConstraintWidget.hasDanglingDimension(0)) {
        j = paramInt;
        if (paramConstraintWidget.mMatchConstraintDefaultWidth == 0) {
          j = paramInt;
          if (!bool2) {
            paramMeasure.horizontalBehavior = ConstraintWidget.DimensionBehaviour.WRAP_CONTENT;
            if (i && paramConstraintWidget.mMatchConstraintDefaultHeight == 0)
              paramMeasure.horizontalBehavior = ConstraintWidget.DimensionBehaviour.FIXED; 
            j = 0;
          } 
        } 
      } 
    } 
    paramInt = i;
    if (i) {
      paramInt = i;
      if (paramConstraintWidget.hasDanglingDimension(1)) {
        paramInt = i;
        if (paramConstraintWidget.mMatchConstraintDefaultHeight == 0) {
          paramInt = i;
          if (!bool1) {
            paramMeasure.verticalBehavior = ConstraintWidget.DimensionBehaviour.WRAP_CONTENT;
            if (j != 0 && paramConstraintWidget.mMatchConstraintDefaultWidth == 0)
              paramMeasure.verticalBehavior = ConstraintWidget.DimensionBehaviour.FIXED; 
            paramInt = 0;
          } 
        } 
      } 
    } 
    if (paramConstraintWidget.isResolvedHorizontally()) {
      paramMeasure.horizontalBehavior = ConstraintWidget.DimensionBehaviour.FIXED;
      j = 0;
    } 
    if (paramConstraintWidget.isResolvedVertically()) {
      paramMeasure.verticalBehavior = ConstraintWidget.DimensionBehaviour.FIXED;
      paramInt = 0;
    } 
    if (bool2)
      if (paramConstraintWidget.mResolvedMatchConstraintDefault[0] == 4) {
        paramMeasure.horizontalBehavior = ConstraintWidget.DimensionBehaviour.FIXED;
      } else if (paramInt == 0) {
        dimensionBehaviour1 = paramMeasure.verticalBehavior;
        dimensionBehaviour2 = ConstraintWidget.DimensionBehaviour.FIXED;
        if (dimensionBehaviour1 == dimensionBehaviour2) {
          paramInt = paramMeasure.verticalDimension;
        } else {
          paramMeasure.horizontalBehavior = ConstraintWidget.DimensionBehaviour.WRAP_CONTENT;
          paramMeasurer.measure(paramConstraintWidget, paramMeasure);
          paramInt = paramMeasure.measuredHeight;
        } 
        paramMeasure.horizontalBehavior = dimensionBehaviour2;
        i = paramConstraintWidget.mDimensionRatioSide;
        if (i == 0 || i == -1) {
          paramMeasure.horizontalDimension = (int)(paramConstraintWidget.getDimensionRatio() * paramInt);
        } else {
          paramMeasure.horizontalDimension = (int)(paramConstraintWidget.getDimensionRatio() / paramInt);
        } 
      }  
    if (bool1)
      if (paramConstraintWidget.mResolvedMatchConstraintDefault[1] == 4) {
        paramMeasure.verticalBehavior = ConstraintWidget.DimensionBehaviour.FIXED;
      } else if (j == 0) {
        dimensionBehaviour1 = paramMeasure.horizontalBehavior;
        dimensionBehaviour2 = ConstraintWidget.DimensionBehaviour.FIXED;
        if (dimensionBehaviour1 == dimensionBehaviour2) {
          paramInt = paramMeasure.horizontalDimension;
        } else {
          paramMeasure.verticalBehavior = ConstraintWidget.DimensionBehaviour.WRAP_CONTENT;
          paramMeasurer.measure(paramConstraintWidget, paramMeasure);
          paramInt = paramMeasure.measuredWidth;
        } 
        paramMeasure.verticalBehavior = dimensionBehaviour2;
        i = paramConstraintWidget.mDimensionRatioSide;
        if (i == 0 || i == -1) {
          paramMeasure.verticalDimension = (int)(paramInt / paramConstraintWidget.getDimensionRatio());
          paramMeasurer.measure(paramConstraintWidget, paramMeasure);
          paramConstraintWidget.setWidth(paramMeasure.measuredWidth);
          paramConstraintWidget.setHeight(paramMeasure.measuredHeight);
          paramConstraintWidget.setHasBaseline(paramMeasure.measuredHasBaseline);
          paramConstraintWidget.setBaselineDistance(paramMeasure.measuredBaseline);
          paramMeasure.measureStrategy = BasicMeasure.Measure.SELF_DIMENSIONS;
          return paramMeasure.measuredNeedsSolverPass;
        } 
        paramMeasure.verticalDimension = (int)(paramInt * paramConstraintWidget.getDimensionRatio());
      }  
    paramMeasurer.measure(paramConstraintWidget, paramMeasure);
    paramConstraintWidget.setWidth(paramMeasure.measuredWidth);
    paramConstraintWidget.setHeight(paramMeasure.measuredHeight);
    paramConstraintWidget.setHasBaseline(paramMeasure.measuredHasBaseline);
    paramConstraintWidget.setBaselineDistance(paramMeasure.measuredBaseline);
    paramMeasure.measureStrategy = BasicMeasure.Measure.SELF_DIMENSIONS;
    return paramMeasure.measuredNeedsSolverPass;
  }
  
  private void resetChains() {
    this.mHorizontalChainsSize = 0;
    this.mVerticalChainsSize = 0;
  }
  
  void addChain(ConstraintWidget paramConstraintWidget, int paramInt) {
    if (paramInt == 0) {
      addHorizontalChain(paramConstraintWidget);
      return;
    } 
    if (paramInt == 1)
      addVerticalChain(paramConstraintWidget); 
  }
  
  public boolean addChildrenToSolver(LinearSystem paramLinearSystem) {
    boolean bool1 = optimizeFor(64);
    addToSolver(paramLinearSystem, bool1);
    int j = this.mChildren.size();
    int i = 0;
    boolean bool = false;
    while (i < j) {
      ConstraintWidget constraintWidget = this.mChildren.get(i);
      constraintWidget.setInBarrier(0, false);
      constraintWidget.setInBarrier(1, false);
      if (constraintWidget instanceof Barrier)
        bool = true; 
      i++;
    } 
    if (bool)
      for (i = 0; i < j; i++) {
        ConstraintWidget constraintWidget = this.mChildren.get(i);
        if (constraintWidget instanceof Barrier)
          ((Barrier)constraintWidget).markWidgets(); 
      }  
    for (i = 0; i < j; i++) {
      ConstraintWidget constraintWidget = this.mChildren.get(i);
      if (constraintWidget.addFirst())
        constraintWidget.addToSolver(paramLinearSystem, bool1); 
    } 
    if (LinearSystem.USE_DEPENDENCY_ORDERING) {
      HashSet<ConstraintWidget> hashSet = new HashSet();
      for (i = 0; i < j; i++) {
        ConstraintWidget constraintWidget = this.mChildren.get(i);
        if (!constraintWidget.addFirst())
          hashSet.add(constraintWidget); 
      } 
      if (getHorizontalDimensionBehaviour() == ConstraintWidget.DimensionBehaviour.WRAP_CONTENT) {
        i = 0;
      } else {
        i = 1;
      } 
      addChildrenToSolverByDependency(this, paramLinearSystem, hashSet, i, false);
      for (ConstraintWidget constraintWidget : hashSet) {
        Optimizer.checkMatchParent(this, paramLinearSystem, constraintWidget);
        constraintWidget.addToSolver(paramLinearSystem, bool1);
      } 
    } else {
      for (i = 0; i < j; i++) {
        ConstraintWidget constraintWidget = this.mChildren.get(i);
        if (constraintWidget instanceof ConstraintWidgetContainer) {
          ConstraintWidget.DimensionBehaviour[] arrayOfDimensionBehaviour = constraintWidget.mListDimensionBehaviors;
          ConstraintWidget.DimensionBehaviour dimensionBehaviour1 = arrayOfDimensionBehaviour[0];
          ConstraintWidget.DimensionBehaviour dimensionBehaviour2 = arrayOfDimensionBehaviour[1];
          ConstraintWidget.DimensionBehaviour dimensionBehaviour3 = ConstraintWidget.DimensionBehaviour.WRAP_CONTENT;
          if (dimensionBehaviour1 == dimensionBehaviour3)
            constraintWidget.setHorizontalDimensionBehaviour(ConstraintWidget.DimensionBehaviour.FIXED); 
          if (dimensionBehaviour2 == dimensionBehaviour3)
            constraintWidget.setVerticalDimensionBehaviour(ConstraintWidget.DimensionBehaviour.FIXED); 
          constraintWidget.addToSolver(paramLinearSystem, bool1);
          if (dimensionBehaviour1 == dimensionBehaviour3)
            constraintWidget.setHorizontalDimensionBehaviour(dimensionBehaviour1); 
          if (dimensionBehaviour2 == dimensionBehaviour3)
            constraintWidget.setVerticalDimensionBehaviour(dimensionBehaviour2); 
        } else {
          Optimizer.checkMatchParent(this, paramLinearSystem, constraintWidget);
          if (!constraintWidget.addFirst())
            constraintWidget.addToSolver(paramLinearSystem, bool1); 
        } 
      } 
    } 
    if (this.mHorizontalChainsSize > 0)
      Chain.applyChainConstraints(this, paramLinearSystem, null, 0); 
    if (this.mVerticalChainsSize > 0)
      Chain.applyChainConstraints(this, paramLinearSystem, null, 1); 
    return true;
  }
  
  public void addHorizontalWrapMaxVariable(ConstraintAnchor paramConstraintAnchor) {
    WeakReference<ConstraintAnchor> weakReference = this.horizontalWrapMax;
    if (weakReference == null || weakReference.get() == null || paramConstraintAnchor.getFinalValue() > ((ConstraintAnchor)this.horizontalWrapMax.get()).getFinalValue())
      this.horizontalWrapMax = new WeakReference<ConstraintAnchor>(paramConstraintAnchor); 
  }
  
  public void addHorizontalWrapMinVariable(ConstraintAnchor paramConstraintAnchor) {
    WeakReference<ConstraintAnchor> weakReference = this.horizontalWrapMin;
    if (weakReference == null || weakReference.get() == null || paramConstraintAnchor.getFinalValue() > ((ConstraintAnchor)this.horizontalWrapMin.get()).getFinalValue())
      this.horizontalWrapMin = new WeakReference<ConstraintAnchor>(paramConstraintAnchor); 
  }
  
  void addVerticalWrapMaxVariable(ConstraintAnchor paramConstraintAnchor) {
    WeakReference<ConstraintAnchor> weakReference = this.verticalWrapMax;
    if (weakReference == null || weakReference.get() == null || paramConstraintAnchor.getFinalValue() > ((ConstraintAnchor)this.verticalWrapMax.get()).getFinalValue())
      this.verticalWrapMax = new WeakReference<ConstraintAnchor>(paramConstraintAnchor); 
  }
  
  void addVerticalWrapMinVariable(ConstraintAnchor paramConstraintAnchor) {
    WeakReference<ConstraintAnchor> weakReference = this.verticalWrapMin;
    if (weakReference == null || weakReference.get() == null || paramConstraintAnchor.getFinalValue() > ((ConstraintAnchor)this.verticalWrapMin.get()).getFinalValue())
      this.verticalWrapMin = new WeakReference<ConstraintAnchor>(paramConstraintAnchor); 
  }
  
  public void defineTerminalWidgets() {
    this.mDependencyGraph.defineTerminalWidgets(getHorizontalDimensionBehaviour(), getVerticalDimensionBehaviour());
  }
  
  public boolean directMeasure(boolean paramBoolean) {
    return this.mDependencyGraph.directMeasure(paramBoolean);
  }
  
  public boolean directMeasureSetup(boolean paramBoolean) {
    return this.mDependencyGraph.directMeasureSetup(paramBoolean);
  }
  
  public boolean directMeasureWithOrientation(boolean paramBoolean, int paramInt) {
    return this.mDependencyGraph.directMeasureWithOrientation(paramBoolean, paramInt);
  }
  
  public void fillMetrics(Metrics paramMetrics) {
    this.mMetrics = paramMetrics;
    this.mSystem.fillMetrics(paramMetrics);
  }
  
  public ArrayList<Guideline> getHorizontalGuidelines() {
    ArrayList<ConstraintWidget> arrayList = new ArrayList();
    int j = this.mChildren.size();
    for (int i = 0; i < j; i++) {
      ConstraintWidget constraintWidget = this.mChildren.get(i);
      if (constraintWidget instanceof Guideline) {
        constraintWidget = constraintWidget;
        if (constraintWidget.getOrientation() == 0)
          arrayList.add(constraintWidget); 
      } 
    } 
    return (ArrayList)arrayList;
  }
  
  public BasicMeasure.Measurer getMeasurer() {
    return this.mMeasurer;
  }
  
  public int getOptimizationLevel() {
    return this.mOptimizationLevel;
  }
  
  public LinearSystem getSystem() {
    return this.mSystem;
  }
  
  public String getType() {
    return "ConstraintLayout";
  }
  
  public ArrayList<Guideline> getVerticalGuidelines() {
    ArrayList<ConstraintWidget> arrayList = new ArrayList();
    int j = this.mChildren.size();
    for (int i = 0; i < j; i++) {
      ConstraintWidget constraintWidget = this.mChildren.get(i);
      if (constraintWidget instanceof Guideline) {
        constraintWidget = constraintWidget;
        if (constraintWidget.getOrientation() == 1)
          arrayList.add(constraintWidget); 
      } 
    } 
    return (ArrayList)arrayList;
  }
  
  public boolean handlesInternalConstraints() {
    return false;
  }
  
  public void invalidateGraph() {
    this.mDependencyGraph.invalidateGraph();
  }
  
  public void invalidateMeasures() {
    this.mDependencyGraph.invalidateMeasures();
  }
  
  public boolean isHeightMeasuredTooSmall() {
    return this.mHeightMeasuredTooSmall;
  }
  
  public boolean isRtl() {
    return this.mIsRtl;
  }
  
  public boolean isWidthMeasuredTooSmall() {
    return this.mWidthMeasuredTooSmall;
  }
  
  public void layout() {
    // Byte code:
    //   0: aload_0
    //   1: iconst_0
    //   2: putfield mX : I
    //   5: aload_0
    //   6: iconst_0
    //   7: putfield mY : I
    //   10: aload_0
    //   11: iconst_0
    //   12: putfield mWidthMeasuredTooSmall : Z
    //   15: aload_0
    //   16: iconst_0
    //   17: putfield mHeightMeasuredTooSmall : Z
    //   20: aload_0
    //   21: getfield mChildren : Ljava/util/ArrayList;
    //   24: invokevirtual size : ()I
    //   27: istore #9
    //   29: iconst_0
    //   30: aload_0
    //   31: invokevirtual getWidth : ()I
    //   34: invokestatic max : (II)I
    //   37: istore_2
    //   38: iconst_0
    //   39: aload_0
    //   40: invokevirtual getHeight : ()I
    //   43: invokestatic max : (II)I
    //   46: istore_3
    //   47: aload_0
    //   48: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   51: astore #15
    //   53: aload #15
    //   55: iconst_1
    //   56: aaload
    //   57: astore #14
    //   59: aload #15
    //   61: iconst_0
    //   62: aaload
    //   63: astore #15
    //   65: aload_0
    //   66: getfield mMetrics : Landroidx/constraintlayout/solver/Metrics;
    //   69: astore #16
    //   71: aload #16
    //   73: ifnull -> 88
    //   76: aload #16
    //   78: aload #16
    //   80: getfield layouts : J
    //   83: lconst_1
    //   84: ladd
    //   85: putfield layouts : J
    //   88: aload_0
    //   89: getfield mOptimizationLevel : I
    //   92: iconst_1
    //   93: invokestatic enabled : (II)Z
    //   96: ifeq -> 266
    //   99: aload_0
    //   100: aload_0
    //   101: invokevirtual getMeasurer : ()Landroidx/constraintlayout/solver/widgets/analyzer/BasicMeasure$Measurer;
    //   104: invokestatic solvingPass : (Landroidx/constraintlayout/solver/widgets/ConstraintWidgetContainer;Landroidx/constraintlayout/solver/widgets/analyzer/BasicMeasure$Measurer;)V
    //   107: iconst_0
    //   108: istore_1
    //   109: iload_1
    //   110: iload #9
    //   112: if_icmpge -> 266
    //   115: aload_0
    //   116: getfield mChildren : Ljava/util/ArrayList;
    //   119: iload_1
    //   120: invokevirtual get : (I)Ljava/lang/Object;
    //   123: checkcast androidx/constraintlayout/solver/widgets/ConstraintWidget
    //   126: astore #16
    //   128: aload #16
    //   130: invokevirtual isMeasureRequested : ()Z
    //   133: ifeq -> 259
    //   136: aload #16
    //   138: instanceof androidx/constraintlayout/solver/widgets/Guideline
    //   141: ifne -> 259
    //   144: aload #16
    //   146: instanceof androidx/constraintlayout/solver/widgets/Barrier
    //   149: ifne -> 259
    //   152: aload #16
    //   154: instanceof androidx/constraintlayout/solver/widgets/VirtualLayout
    //   157: ifne -> 259
    //   160: aload #16
    //   162: invokevirtual isInVirtualLayout : ()Z
    //   165: ifne -> 259
    //   168: aload #16
    //   170: iconst_0
    //   171: invokevirtual getDimensionBehaviour : (I)Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   174: astore #17
    //   176: aload #16
    //   178: iconst_1
    //   179: invokevirtual getDimensionBehaviour : (I)Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   182: astore #18
    //   184: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   187: astore #19
    //   189: aload #17
    //   191: aload #19
    //   193: if_acmpne -> 227
    //   196: aload #16
    //   198: getfield mMatchConstraintDefaultWidth : I
    //   201: iconst_1
    //   202: if_icmpeq -> 227
    //   205: aload #18
    //   207: aload #19
    //   209: if_acmpne -> 227
    //   212: aload #16
    //   214: getfield mMatchConstraintDefaultHeight : I
    //   217: iconst_1
    //   218: if_icmpeq -> 227
    //   221: iconst_1
    //   222: istore #4
    //   224: goto -> 230
    //   227: iconst_0
    //   228: istore #4
    //   230: iload #4
    //   232: ifne -> 259
    //   235: new androidx/constraintlayout/solver/widgets/analyzer/BasicMeasure$Measure
    //   238: dup
    //   239: invokespecial <init> : ()V
    //   242: astore #17
    //   244: aload #16
    //   246: aload_0
    //   247: getfield mMeasurer : Landroidx/constraintlayout/solver/widgets/analyzer/BasicMeasure$Measurer;
    //   250: aload #17
    //   252: getstatic androidx/constraintlayout/solver/widgets/analyzer/BasicMeasure$Measure.SELF_DIMENSIONS : I
    //   255: invokestatic measure : (Landroidx/constraintlayout/solver/widgets/ConstraintWidget;Landroidx/constraintlayout/solver/widgets/analyzer/BasicMeasure$Measurer;Landroidx/constraintlayout/solver/widgets/analyzer/BasicMeasure$Measure;I)Z
    //   258: pop
    //   259: iload_1
    //   260: iconst_1
    //   261: iadd
    //   262: istore_1
    //   263: goto -> 109
    //   266: iload #9
    //   268: iconst_2
    //   269: if_icmple -> 408
    //   272: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   275: astore #16
    //   277: aload #15
    //   279: aload #16
    //   281: if_acmpeq -> 291
    //   284: aload #14
    //   286: aload #16
    //   288: if_acmpne -> 408
    //   291: aload_0
    //   292: getfield mOptimizationLevel : I
    //   295: sipush #1024
    //   298: invokestatic enabled : (II)Z
    //   301: ifeq -> 408
    //   304: aload_0
    //   305: aload_0
    //   306: invokevirtual getMeasurer : ()Landroidx/constraintlayout/solver/widgets/analyzer/BasicMeasure$Measurer;
    //   309: invokestatic simpleSolvingPass : (Landroidx/constraintlayout/solver/widgets/ConstraintWidgetContainer;Landroidx/constraintlayout/solver/widgets/analyzer/BasicMeasure$Measurer;)Z
    //   312: ifeq -> 408
    //   315: iload_2
    //   316: istore_1
    //   317: aload #15
    //   319: aload #16
    //   321: if_acmpne -> 356
    //   324: iload_2
    //   325: aload_0
    //   326: invokevirtual getWidth : ()I
    //   329: if_icmpge -> 351
    //   332: iload_2
    //   333: ifle -> 351
    //   336: aload_0
    //   337: iload_2
    //   338: invokevirtual setWidth : (I)V
    //   341: aload_0
    //   342: iconst_1
    //   343: putfield mWidthMeasuredTooSmall : Z
    //   346: iload_2
    //   347: istore_1
    //   348: goto -> 356
    //   351: aload_0
    //   352: invokevirtual getWidth : ()I
    //   355: istore_1
    //   356: iload_3
    //   357: istore_2
    //   358: aload #14
    //   360: aload #16
    //   362: if_acmpne -> 397
    //   365: iload_3
    //   366: aload_0
    //   367: invokevirtual getHeight : ()I
    //   370: if_icmpge -> 392
    //   373: iload_3
    //   374: ifle -> 392
    //   377: aload_0
    //   378: iload_3
    //   379: invokevirtual setHeight : (I)V
    //   382: aload_0
    //   383: iconst_1
    //   384: putfield mHeightMeasuredTooSmall : Z
    //   387: iload_3
    //   388: istore_2
    //   389: goto -> 397
    //   392: aload_0
    //   393: invokevirtual getHeight : ()I
    //   396: istore_2
    //   397: iload_1
    //   398: istore #4
    //   400: iconst_1
    //   401: istore_1
    //   402: iload_2
    //   403: istore #5
    //   405: goto -> 416
    //   408: iconst_0
    //   409: istore_1
    //   410: iload_3
    //   411: istore #5
    //   413: iload_2
    //   414: istore #4
    //   416: aload_0
    //   417: bipush #64
    //   419: invokevirtual optimizeFor : (I)Z
    //   422: ifne -> 443
    //   425: aload_0
    //   426: sipush #128
    //   429: invokevirtual optimizeFor : (I)Z
    //   432: ifeq -> 438
    //   435: goto -> 443
    //   438: iconst_0
    //   439: istore_2
    //   440: goto -> 445
    //   443: iconst_1
    //   444: istore_2
    //   445: aload_0
    //   446: getfield mSystem : Landroidx/constraintlayout/solver/LinearSystem;
    //   449: astore #16
    //   451: aload #16
    //   453: iconst_0
    //   454: putfield graphOptimizer : Z
    //   457: aload #16
    //   459: iconst_0
    //   460: putfield newgraphOptimizer : Z
    //   463: aload_0
    //   464: getfield mOptimizationLevel : I
    //   467: ifeq -> 480
    //   470: iload_2
    //   471: ifeq -> 480
    //   474: aload #16
    //   476: iconst_1
    //   477: putfield newgraphOptimizer : Z
    //   480: aload_0
    //   481: getfield mChildren : Ljava/util/ArrayList;
    //   484: astore #16
    //   486: aload_0
    //   487: invokevirtual getHorizontalDimensionBehaviour : ()Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   490: astore #17
    //   492: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   495: astore #18
    //   497: aload #17
    //   499: aload #18
    //   501: if_acmpeq -> 522
    //   504: aload_0
    //   505: invokevirtual getVerticalDimensionBehaviour : ()Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   508: aload #18
    //   510: if_acmpne -> 516
    //   513: goto -> 522
    //   516: iconst_0
    //   517: istore #6
    //   519: goto -> 525
    //   522: iconst_1
    //   523: istore #6
    //   525: aload_0
    //   526: invokespecial resetChains : ()V
    //   529: iconst_0
    //   530: istore_2
    //   531: iload_2
    //   532: iload #9
    //   534: if_icmpge -> 573
    //   537: aload_0
    //   538: getfield mChildren : Ljava/util/ArrayList;
    //   541: iload_2
    //   542: invokevirtual get : (I)Ljava/lang/Object;
    //   545: checkcast androidx/constraintlayout/solver/widgets/ConstraintWidget
    //   548: astore #17
    //   550: aload #17
    //   552: instanceof androidx/constraintlayout/solver/widgets/WidgetContainer
    //   555: ifeq -> 566
    //   558: aload #17
    //   560: checkcast androidx/constraintlayout/solver/widgets/WidgetContainer
    //   563: invokevirtual layout : ()V
    //   566: iload_2
    //   567: iconst_1
    //   568: iadd
    //   569: istore_2
    //   570: goto -> 531
    //   573: aload_0
    //   574: bipush #64
    //   576: invokevirtual optimizeFor : (I)Z
    //   579: istore #13
    //   581: iconst_0
    //   582: istore_2
    //   583: iconst_1
    //   584: istore #11
    //   586: iload #11
    //   588: ifeq -> 1534
    //   591: iload_2
    //   592: iconst_1
    //   593: iadd
    //   594: istore #8
    //   596: iload #11
    //   598: istore #10
    //   600: aload_0
    //   601: getfield mSystem : Landroidx/constraintlayout/solver/LinearSystem;
    //   604: invokevirtual reset : ()V
    //   607: iload #11
    //   609: istore #10
    //   611: aload_0
    //   612: invokespecial resetChains : ()V
    //   615: iload #11
    //   617: istore #10
    //   619: aload_0
    //   620: aload_0
    //   621: getfield mSystem : Landroidx/constraintlayout/solver/LinearSystem;
    //   624: invokevirtual createObjectVariables : (Landroidx/constraintlayout/solver/LinearSystem;)V
    //   627: iconst_0
    //   628: istore_2
    //   629: iload_2
    //   630: iload #9
    //   632: if_icmpge -> 664
    //   635: iload #11
    //   637: istore #10
    //   639: aload_0
    //   640: getfield mChildren : Ljava/util/ArrayList;
    //   643: iload_2
    //   644: invokevirtual get : (I)Ljava/lang/Object;
    //   647: checkcast androidx/constraintlayout/solver/widgets/ConstraintWidget
    //   650: aload_0
    //   651: getfield mSystem : Landroidx/constraintlayout/solver/LinearSystem;
    //   654: invokevirtual createObjectVariables : (Landroidx/constraintlayout/solver/LinearSystem;)V
    //   657: iload_2
    //   658: iconst_1
    //   659: iadd
    //   660: istore_2
    //   661: goto -> 629
    //   664: iload #11
    //   666: istore #10
    //   668: aload_0
    //   669: aload_0
    //   670: getfield mSystem : Landroidx/constraintlayout/solver/LinearSystem;
    //   673: invokevirtual addChildrenToSolver : (Landroidx/constraintlayout/solver/LinearSystem;)Z
    //   676: istore #11
    //   678: iload #11
    //   680: istore #10
    //   682: aload_0
    //   683: getfield verticalWrapMin : Ljava/lang/ref/WeakReference;
    //   686: astore #17
    //   688: aload #17
    //   690: ifnull -> 743
    //   693: iload #11
    //   695: istore #10
    //   697: aload #17
    //   699: invokevirtual get : ()Ljava/lang/Object;
    //   702: ifnull -> 743
    //   705: iload #11
    //   707: istore #10
    //   709: aload_0
    //   710: aload_0
    //   711: getfield verticalWrapMin : Ljava/lang/ref/WeakReference;
    //   714: invokevirtual get : ()Ljava/lang/Object;
    //   717: checkcast androidx/constraintlayout/solver/widgets/ConstraintAnchor
    //   720: aload_0
    //   721: getfield mSystem : Landroidx/constraintlayout/solver/LinearSystem;
    //   724: aload_0
    //   725: getfield mTop : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   728: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/solver/SolverVariable;
    //   731: invokespecial addMinWrap : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;Landroidx/constraintlayout/solver/SolverVariable;)V
    //   734: iload #11
    //   736: istore #10
    //   738: aload_0
    //   739: aconst_null
    //   740: putfield verticalWrapMin : Ljava/lang/ref/WeakReference;
    //   743: iload #11
    //   745: istore #10
    //   747: aload_0
    //   748: getfield verticalWrapMax : Ljava/lang/ref/WeakReference;
    //   751: astore #17
    //   753: aload #17
    //   755: ifnull -> 808
    //   758: iload #11
    //   760: istore #10
    //   762: aload #17
    //   764: invokevirtual get : ()Ljava/lang/Object;
    //   767: ifnull -> 808
    //   770: iload #11
    //   772: istore #10
    //   774: aload_0
    //   775: aload_0
    //   776: getfield verticalWrapMax : Ljava/lang/ref/WeakReference;
    //   779: invokevirtual get : ()Ljava/lang/Object;
    //   782: checkcast androidx/constraintlayout/solver/widgets/ConstraintAnchor
    //   785: aload_0
    //   786: getfield mSystem : Landroidx/constraintlayout/solver/LinearSystem;
    //   789: aload_0
    //   790: getfield mBottom : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   793: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/solver/SolverVariable;
    //   796: invokespecial addMaxWrap : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;Landroidx/constraintlayout/solver/SolverVariable;)V
    //   799: iload #11
    //   801: istore #10
    //   803: aload_0
    //   804: aconst_null
    //   805: putfield verticalWrapMax : Ljava/lang/ref/WeakReference;
    //   808: iload #11
    //   810: istore #10
    //   812: aload_0
    //   813: getfield horizontalWrapMin : Ljava/lang/ref/WeakReference;
    //   816: astore #17
    //   818: aload #17
    //   820: ifnull -> 873
    //   823: iload #11
    //   825: istore #10
    //   827: aload #17
    //   829: invokevirtual get : ()Ljava/lang/Object;
    //   832: ifnull -> 873
    //   835: iload #11
    //   837: istore #10
    //   839: aload_0
    //   840: aload_0
    //   841: getfield horizontalWrapMin : Ljava/lang/ref/WeakReference;
    //   844: invokevirtual get : ()Ljava/lang/Object;
    //   847: checkcast androidx/constraintlayout/solver/widgets/ConstraintAnchor
    //   850: aload_0
    //   851: getfield mSystem : Landroidx/constraintlayout/solver/LinearSystem;
    //   854: aload_0
    //   855: getfield mLeft : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   858: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/solver/SolverVariable;
    //   861: invokespecial addMinWrap : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;Landroidx/constraintlayout/solver/SolverVariable;)V
    //   864: iload #11
    //   866: istore #10
    //   868: aload_0
    //   869: aconst_null
    //   870: putfield horizontalWrapMin : Ljava/lang/ref/WeakReference;
    //   873: iload #11
    //   875: istore #10
    //   877: aload_0
    //   878: getfield horizontalWrapMax : Ljava/lang/ref/WeakReference;
    //   881: astore #17
    //   883: aload #17
    //   885: ifnull -> 938
    //   888: iload #11
    //   890: istore #10
    //   892: aload #17
    //   894: invokevirtual get : ()Ljava/lang/Object;
    //   897: ifnull -> 938
    //   900: iload #11
    //   902: istore #10
    //   904: aload_0
    //   905: aload_0
    //   906: getfield horizontalWrapMax : Ljava/lang/ref/WeakReference;
    //   909: invokevirtual get : ()Ljava/lang/Object;
    //   912: checkcast androidx/constraintlayout/solver/widgets/ConstraintAnchor
    //   915: aload_0
    //   916: getfield mSystem : Landroidx/constraintlayout/solver/LinearSystem;
    //   919: aload_0
    //   920: getfield mRight : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   923: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/solver/SolverVariable;
    //   926: invokespecial addMaxWrap : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;Landroidx/constraintlayout/solver/SolverVariable;)V
    //   929: iload #11
    //   931: istore #10
    //   933: aload_0
    //   934: aconst_null
    //   935: putfield horizontalWrapMax : Ljava/lang/ref/WeakReference;
    //   938: iload #11
    //   940: istore #10
    //   942: iload #11
    //   944: ifeq -> 1013
    //   947: iload #11
    //   949: istore #10
    //   951: aload_0
    //   952: getfield mSystem : Landroidx/constraintlayout/solver/LinearSystem;
    //   955: invokevirtual minimize : ()V
    //   958: iload #11
    //   960: istore #10
    //   962: goto -> 1013
    //   965: astore #17
    //   967: aload #17
    //   969: invokevirtual printStackTrace : ()V
    //   972: getstatic java/lang/System.out : Ljava/io/PrintStream;
    //   975: astore #18
    //   977: new java/lang/StringBuilder
    //   980: dup
    //   981: invokespecial <init> : ()V
    //   984: astore #19
    //   986: aload #19
    //   988: ldc_w 'EXCEPTION : '
    //   991: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   994: pop
    //   995: aload #19
    //   997: aload #17
    //   999: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   1002: pop
    //   1003: aload #18
    //   1005: aload #19
    //   1007: invokevirtual toString : ()Ljava/lang/String;
    //   1010: invokevirtual println : (Ljava/lang/String;)V
    //   1013: iload #10
    //   1015: ifeq -> 1032
    //   1018: aload_0
    //   1019: aload_0
    //   1020: getfield mSystem : Landroidx/constraintlayout/solver/LinearSystem;
    //   1023: getstatic androidx/constraintlayout/solver/widgets/Optimizer.flags : [Z
    //   1026: invokevirtual updateChildrenFromSolver : (Landroidx/constraintlayout/solver/LinearSystem;[Z)V
    //   1029: goto -> 1077
    //   1032: aload_0
    //   1033: aload_0
    //   1034: getfield mSystem : Landroidx/constraintlayout/solver/LinearSystem;
    //   1037: iload #13
    //   1039: invokevirtual updateFromSolver : (Landroidx/constraintlayout/solver/LinearSystem;Z)V
    //   1042: iconst_0
    //   1043: istore_2
    //   1044: iload_2
    //   1045: iload #9
    //   1047: if_icmpge -> 1077
    //   1050: aload_0
    //   1051: getfield mChildren : Ljava/util/ArrayList;
    //   1054: iload_2
    //   1055: invokevirtual get : (I)Ljava/lang/Object;
    //   1058: checkcast androidx/constraintlayout/solver/widgets/ConstraintWidget
    //   1061: aload_0
    //   1062: getfield mSystem : Landroidx/constraintlayout/solver/LinearSystem;
    //   1065: iload #13
    //   1067: invokevirtual updateFromSolver : (Landroidx/constraintlayout/solver/LinearSystem;Z)V
    //   1070: iload_2
    //   1071: iconst_1
    //   1072: iadd
    //   1073: istore_2
    //   1074: goto -> 1044
    //   1077: iload #6
    //   1079: ifeq -> 1280
    //   1082: iload #8
    //   1084: bipush #8
    //   1086: if_icmpge -> 1280
    //   1089: getstatic androidx/constraintlayout/solver/widgets/Optimizer.flags : [Z
    //   1092: iconst_2
    //   1093: baload
    //   1094: ifeq -> 1280
    //   1097: iconst_0
    //   1098: istore_3
    //   1099: iconst_0
    //   1100: istore #7
    //   1102: iconst_0
    //   1103: istore_2
    //   1104: iload_3
    //   1105: iload #9
    //   1107: if_icmpge -> 1164
    //   1110: aload_0
    //   1111: getfield mChildren : Ljava/util/ArrayList;
    //   1114: iload_3
    //   1115: invokevirtual get : (I)Ljava/lang/Object;
    //   1118: checkcast androidx/constraintlayout/solver/widgets/ConstraintWidget
    //   1121: astore #17
    //   1123: iload #7
    //   1125: aload #17
    //   1127: getfield mX : I
    //   1130: aload #17
    //   1132: invokevirtual getWidth : ()I
    //   1135: iadd
    //   1136: invokestatic max : (II)I
    //   1139: istore #7
    //   1141: iload_2
    //   1142: aload #17
    //   1144: getfield mY : I
    //   1147: aload #17
    //   1149: invokevirtual getHeight : ()I
    //   1152: iadd
    //   1153: invokestatic max : (II)I
    //   1156: istore_2
    //   1157: iload_3
    //   1158: iconst_1
    //   1159: iadd
    //   1160: istore_3
    //   1161: goto -> 1104
    //   1164: aload_0
    //   1165: getfield mMinWidth : I
    //   1168: iload #7
    //   1170: invokestatic max : (II)I
    //   1173: istore #7
    //   1175: aload_0
    //   1176: getfield mMinHeight : I
    //   1179: iload_2
    //   1180: invokestatic max : (II)I
    //   1183: istore_3
    //   1184: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   1187: astore #17
    //   1189: aload #15
    //   1191: aload #17
    //   1193: if_acmpne -> 1227
    //   1196: aload_0
    //   1197: invokevirtual getWidth : ()I
    //   1200: iload #7
    //   1202: if_icmpge -> 1227
    //   1205: aload_0
    //   1206: iload #7
    //   1208: invokevirtual setWidth : (I)V
    //   1211: aload_0
    //   1212: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   1215: iconst_0
    //   1216: aload #17
    //   1218: aastore
    //   1219: iconst_1
    //   1220: istore #11
    //   1222: iconst_1
    //   1223: istore_2
    //   1224: goto -> 1232
    //   1227: iconst_0
    //   1228: istore #11
    //   1230: iload_1
    //   1231: istore_2
    //   1232: iload #11
    //   1234: istore #10
    //   1236: iload_2
    //   1237: istore_1
    //   1238: aload #14
    //   1240: aload #17
    //   1242: if_acmpne -> 1283
    //   1245: iload #11
    //   1247: istore #10
    //   1249: iload_2
    //   1250: istore_1
    //   1251: aload_0
    //   1252: invokevirtual getHeight : ()I
    //   1255: iload_3
    //   1256: if_icmpge -> 1283
    //   1259: aload_0
    //   1260: iload_3
    //   1261: invokevirtual setHeight : (I)V
    //   1264: aload_0
    //   1265: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   1268: iconst_1
    //   1269: aload #17
    //   1271: aastore
    //   1272: iconst_1
    //   1273: istore #10
    //   1275: iconst_1
    //   1276: istore_1
    //   1277: goto -> 1283
    //   1280: iconst_0
    //   1281: istore #10
    //   1283: aload_0
    //   1284: getfield mMinWidth : I
    //   1287: aload_0
    //   1288: invokevirtual getWidth : ()I
    //   1291: invokestatic max : (II)I
    //   1294: istore_2
    //   1295: iload_2
    //   1296: aload_0
    //   1297: invokevirtual getWidth : ()I
    //   1300: if_icmple -> 1322
    //   1303: aload_0
    //   1304: iload_2
    //   1305: invokevirtual setWidth : (I)V
    //   1308: aload_0
    //   1309: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   1312: iconst_0
    //   1313: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.FIXED : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   1316: aastore
    //   1317: iconst_1
    //   1318: istore #10
    //   1320: iconst_1
    //   1321: istore_1
    //   1322: aload_0
    //   1323: getfield mMinHeight : I
    //   1326: aload_0
    //   1327: invokevirtual getHeight : ()I
    //   1330: invokestatic max : (II)I
    //   1333: istore_2
    //   1334: iload_2
    //   1335: aload_0
    //   1336: invokevirtual getHeight : ()I
    //   1339: if_icmple -> 1364
    //   1342: aload_0
    //   1343: iload_2
    //   1344: invokevirtual setHeight : (I)V
    //   1347: aload_0
    //   1348: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   1351: iconst_1
    //   1352: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.FIXED : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   1355: aastore
    //   1356: iconst_1
    //   1357: istore #10
    //   1359: iconst_1
    //   1360: istore_1
    //   1361: goto -> 1364
    //   1364: iload #10
    //   1366: istore #12
    //   1368: iload_1
    //   1369: istore_3
    //   1370: iload_1
    //   1371: ifne -> 1522
    //   1374: aload_0
    //   1375: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   1378: iconst_0
    //   1379: aaload
    //   1380: astore #17
    //   1382: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   1385: astore #18
    //   1387: iload #10
    //   1389: istore #11
    //   1391: iload_1
    //   1392: istore_2
    //   1393: aload #17
    //   1395: aload #18
    //   1397: if_acmpne -> 1451
    //   1400: iload #10
    //   1402: istore #11
    //   1404: iload_1
    //   1405: istore_2
    //   1406: iload #4
    //   1408: ifle -> 1451
    //   1411: iload #10
    //   1413: istore #11
    //   1415: iload_1
    //   1416: istore_2
    //   1417: aload_0
    //   1418: invokevirtual getWidth : ()I
    //   1421: iload #4
    //   1423: if_icmple -> 1451
    //   1426: aload_0
    //   1427: iconst_1
    //   1428: putfield mWidthMeasuredTooSmall : Z
    //   1431: aload_0
    //   1432: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   1435: iconst_0
    //   1436: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.FIXED : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   1439: aastore
    //   1440: aload_0
    //   1441: iload #4
    //   1443: invokevirtual setWidth : (I)V
    //   1446: iconst_1
    //   1447: istore #11
    //   1449: iconst_1
    //   1450: istore_2
    //   1451: iload #11
    //   1453: istore #12
    //   1455: iload_2
    //   1456: istore_3
    //   1457: aload_0
    //   1458: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   1461: iconst_1
    //   1462: aaload
    //   1463: aload #18
    //   1465: if_acmpne -> 1522
    //   1468: iload #11
    //   1470: istore #12
    //   1472: iload_2
    //   1473: istore_3
    //   1474: iload #5
    //   1476: ifle -> 1522
    //   1479: iload #11
    //   1481: istore #12
    //   1483: iload_2
    //   1484: istore_3
    //   1485: aload_0
    //   1486: invokevirtual getHeight : ()I
    //   1489: iload #5
    //   1491: if_icmple -> 1522
    //   1494: aload_0
    //   1495: iconst_1
    //   1496: putfield mHeightMeasuredTooSmall : Z
    //   1499: aload_0
    //   1500: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   1503: iconst_1
    //   1504: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.FIXED : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   1507: aastore
    //   1508: aload_0
    //   1509: iload #5
    //   1511: invokevirtual setHeight : (I)V
    //   1514: iconst_1
    //   1515: istore_1
    //   1516: iconst_1
    //   1517: istore #11
    //   1519: goto -> 1528
    //   1522: iload #12
    //   1524: istore #11
    //   1526: iload_3
    //   1527: istore_1
    //   1528: iload #8
    //   1530: istore_2
    //   1531: goto -> 586
    //   1534: aload_0
    //   1535: aload #16
    //   1537: putfield mChildren : Ljava/util/ArrayList;
    //   1540: iload_1
    //   1541: ifeq -> 1562
    //   1544: aload_0
    //   1545: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   1548: astore #16
    //   1550: aload #16
    //   1552: iconst_0
    //   1553: aload #15
    //   1555: aastore
    //   1556: aload #16
    //   1558: iconst_1
    //   1559: aload #14
    //   1561: aastore
    //   1562: aload_0
    //   1563: aload_0
    //   1564: getfield mSystem : Landroidx/constraintlayout/solver/LinearSystem;
    //   1567: invokevirtual getCache : ()Landroidx/constraintlayout/solver/Cache;
    //   1570: invokevirtual resetSolverVariables : (Landroidx/constraintlayout/solver/Cache;)V
    //   1573: return
    // Exception table:
    //   from	to	target	type
    //   600	607	965	java/lang/Exception
    //   611	615	965	java/lang/Exception
    //   619	627	965	java/lang/Exception
    //   639	657	965	java/lang/Exception
    //   668	678	965	java/lang/Exception
    //   682	688	965	java/lang/Exception
    //   697	705	965	java/lang/Exception
    //   709	734	965	java/lang/Exception
    //   738	743	965	java/lang/Exception
    //   747	753	965	java/lang/Exception
    //   762	770	965	java/lang/Exception
    //   774	799	965	java/lang/Exception
    //   803	808	965	java/lang/Exception
    //   812	818	965	java/lang/Exception
    //   827	835	965	java/lang/Exception
    //   839	864	965	java/lang/Exception
    //   868	873	965	java/lang/Exception
    //   877	883	965	java/lang/Exception
    //   892	900	965	java/lang/Exception
    //   904	929	965	java/lang/Exception
    //   933	938	965	java/lang/Exception
    //   951	958	965	java/lang/Exception
  }
  
  public long measure(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9) {
    this.mPaddingLeft = paramInt8;
    this.mPaddingTop = paramInt9;
    return this.mBasicMeasureSolver.solverMeasure(this, paramInt1, paramInt8, paramInt9, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7);
  }
  
  public boolean optimizeFor(int paramInt) {
    return ((this.mOptimizationLevel & paramInt) == paramInt);
  }
  
  public void reset() {
    this.mSystem.reset();
    this.mPaddingLeft = 0;
    this.mPaddingRight = 0;
    this.mPaddingTop = 0;
    this.mPaddingBottom = 0;
    this.mSkipSolver = false;
    super.reset();
  }
  
  public void setMeasurer(BasicMeasure.Measurer paramMeasurer) {
    this.mMeasurer = paramMeasurer;
    this.mDependencyGraph.setMeasurer(paramMeasurer);
  }
  
  public void setOptimizationLevel(int paramInt) {
    this.mOptimizationLevel = paramInt;
    LinearSystem.USE_DEPENDENCY_ORDERING = optimizeFor(512);
  }
  
  public void setPadding(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    this.mPaddingLeft = paramInt1;
    this.mPaddingTop = paramInt2;
    this.mPaddingRight = paramInt3;
    this.mPaddingBottom = paramInt4;
  }
  
  public void setRtl(boolean paramBoolean) {
    this.mIsRtl = paramBoolean;
  }
  
  public void updateChildrenFromSolver(LinearSystem paramLinearSystem, boolean[] paramArrayOfboolean) {
    int i = 0;
    paramArrayOfboolean[2] = false;
    boolean bool = optimizeFor(64);
    updateFromSolver(paramLinearSystem, bool);
    int j = this.mChildren.size();
    while (i < j) {
      ((ConstraintWidget)this.mChildren.get(i)).updateFromSolver(paramLinearSystem, bool);
      i++;
    } 
  }
  
  public void updateFromRuns(boolean paramBoolean1, boolean paramBoolean2) {
    super.updateFromRuns(paramBoolean1, paramBoolean2);
    int j = this.mChildren.size();
    for (int i = 0; i < j; i++)
      ((ConstraintWidget)this.mChildren.get(i)).updateFromRuns(paramBoolean1, paramBoolean2); 
  }
  
  public void updateHierarchy() {
    this.mBasicMeasureSolver.updateHierarchy(this);
  }
}


/* Location:              C:\soft\dex2jar-2.0\BabyBus TV_Kids Videos & Games-dex2jar.jar!\androidx\constraintlayout\solver\widgets\ConstraintWidgetContainer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */