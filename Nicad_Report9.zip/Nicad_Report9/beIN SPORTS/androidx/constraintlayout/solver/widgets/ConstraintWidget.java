package androidx.constraintlayout.solver.widgets;

import androidx.constraintlayout.solver.Cache;
import androidx.constraintlayout.solver.LinearSystem;
import androidx.constraintlayout.solver.SolverVariable;
import androidx.constraintlayout.solver.widgets.analyzer.ChainRun;
import androidx.constraintlayout.solver.widgets.analyzer.HorizontalWidgetRun;
import androidx.constraintlayout.solver.widgets.analyzer.VerticalWidgetRun;
import androidx.constraintlayout.solver.widgets.analyzer.WidgetRun;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;

public class ConstraintWidget {
  public static final int ANCHOR_BASELINE = 4;
  
  public static final int ANCHOR_BOTTOM = 3;
  
  public static final int ANCHOR_LEFT = 0;
  
  public static final int ANCHOR_RIGHT = 1;
  
  public static final int ANCHOR_TOP = 2;
  
  private static final boolean AUTOTAG_CENTER = false;
  
  public static final int BOTH = 2;
  
  public static final int CHAIN_PACKED = 2;
  
  public static final int CHAIN_SPREAD = 0;
  
  public static final int CHAIN_SPREAD_INSIDE = 1;
  
  public static float DEFAULT_BIAS = 0.5F;
  
  static final int DIMENSION_HORIZONTAL = 0;
  
  static final int DIMENSION_VERTICAL = 1;
  
  protected static final int DIRECT = 2;
  
  public static final int GONE = 8;
  
  public static final int HORIZONTAL = 0;
  
  public static final int INVISIBLE = 4;
  
  public static final int MATCH_CONSTRAINT_PERCENT = 2;
  
  public static final int MATCH_CONSTRAINT_RATIO = 3;
  
  public static final int MATCH_CONSTRAINT_RATIO_RESOLVED = 4;
  
  public static final int MATCH_CONSTRAINT_SPREAD = 0;
  
  public static final int MATCH_CONSTRAINT_WRAP = 1;
  
  protected static final int SOLVER = 1;
  
  public static final int UNKNOWN = -1;
  
  private static final boolean USE_WRAP_DIMENSION_FOR_SPREAD = false;
  
  public static final int VERTICAL = 1;
  
  public static final int VISIBLE = 0;
  
  private static final int WRAP = -2;
  
  private boolean OPTIMIZE_WRAP = false;
  
  private boolean OPTIMIZE_WRAP_ON_RESOLVED = true;
  
  private boolean hasBaseline = false;
  
  public ChainRun horizontalChainRun;
  
  public int horizontalGroup;
  
  public HorizontalWidgetRun horizontalRun = null;
  
  private boolean inPlaceholder;
  
  public boolean[] isTerminalWidget = new boolean[] { true, true };
  
  protected ArrayList<ConstraintAnchor> mAnchors;
  
  public ConstraintAnchor mBaseline = new ConstraintAnchor(this, ConstraintAnchor.Type.BASELINE);
  
  int mBaselineDistance;
  
  public ConstraintAnchor mBottom = new ConstraintAnchor(this, ConstraintAnchor.Type.BOTTOM);
  
  boolean mBottomHasCentered;
  
  public ConstraintAnchor mCenter;
  
  ConstraintAnchor mCenterX = new ConstraintAnchor(this, ConstraintAnchor.Type.CENTER_X);
  
  ConstraintAnchor mCenterY = new ConstraintAnchor(this, ConstraintAnchor.Type.CENTER_Y);
  
  private float mCircleConstraintAngle = 0.0F;
  
  private Object mCompanionWidget;
  
  private int mContainerItemSkip;
  
  private String mDebugName;
  
  public float mDimensionRatio;
  
  protected int mDimensionRatioSide;
  
  int mDistToBottom;
  
  int mDistToLeft;
  
  int mDistToRight;
  
  int mDistToTop;
  
  boolean mGroupsToSolver;
  
  int mHeight;
  
  float mHorizontalBiasPercent;
  
  boolean mHorizontalChainFixedPosition;
  
  int mHorizontalChainStyle;
  
  ConstraintWidget mHorizontalNextWidget;
  
  public int mHorizontalResolution = -1;
  
  boolean mHorizontalWrapVisited;
  
  private boolean mInVirtuaLayout = false;
  
  public boolean mIsHeightWrapContent;
  
  private boolean[] mIsInBarrier;
  
  public boolean mIsWidthWrapContent;
  
  private int mLastHorizontalMeasureSpec = 0;
  
  private int mLastVerticalMeasureSpec = 0;
  
  public ConstraintAnchor mLeft = new ConstraintAnchor(this, ConstraintAnchor.Type.LEFT);
  
  boolean mLeftHasCentered;
  
  public ConstraintAnchor[] mListAnchors;
  
  public DimensionBehaviour[] mListDimensionBehaviors;
  
  protected ConstraintWidget[] mListNextMatchConstraintsWidget;
  
  public int mMatchConstraintDefaultHeight = 0;
  
  public int mMatchConstraintDefaultWidth = 0;
  
  public int mMatchConstraintMaxHeight = 0;
  
  public int mMatchConstraintMaxWidth = 0;
  
  public int mMatchConstraintMinHeight = 0;
  
  public int mMatchConstraintMinWidth = 0;
  
  public float mMatchConstraintPercentHeight = 1.0F;
  
  public float mMatchConstraintPercentWidth = 1.0F;
  
  private int[] mMaxDimension = new int[] { Integer.MAX_VALUE, Integer.MAX_VALUE };
  
  private boolean mMeasureRequested = true;
  
  protected int mMinHeight;
  
  protected int mMinWidth;
  
  protected ConstraintWidget[] mNextChainWidget;
  
  protected int mOffsetX;
  
  protected int mOffsetY;
  
  public ConstraintWidget mParent;
  
  int mRelX;
  
  int mRelY;
  
  float mResolvedDimensionRatio = 1.0F;
  
  int mResolvedDimensionRatioSide = -1;
  
  boolean mResolvedHasRatio = false;
  
  public int[] mResolvedMatchConstraintDefault = new int[2];
  
  public ConstraintAnchor mRight = new ConstraintAnchor(this, ConstraintAnchor.Type.RIGHT);
  
  boolean mRightHasCentered;
  
  public ConstraintAnchor mTop = new ConstraintAnchor(this, ConstraintAnchor.Type.TOP);
  
  boolean mTopHasCentered;
  
  private String mType;
  
  float mVerticalBiasPercent;
  
  boolean mVerticalChainFixedPosition;
  
  int mVerticalChainStyle;
  
  ConstraintWidget mVerticalNextWidget;
  
  public int mVerticalResolution = -1;
  
  boolean mVerticalWrapVisited;
  
  private int mVisibility;
  
  public float[] mWeight;
  
  int mWidth;
  
  protected int mX;
  
  protected int mY;
  
  public boolean measured = false;
  
  private boolean resolvedHorizontal = false;
  
  private boolean resolvedVertical = false;
  
  public WidgetRun[] run = new WidgetRun[2];
  
  public ChainRun verticalChainRun;
  
  public int verticalGroup;
  
  public VerticalWidgetRun verticalRun = null;
  
  public ConstraintWidget() {
    ConstraintAnchor constraintAnchor = new ConstraintAnchor(this, ConstraintAnchor.Type.CENTER);
    this.mCenter = constraintAnchor;
    this.mListAnchors = new ConstraintAnchor[] { this.mLeft, this.mRight, this.mTop, this.mBottom, this.mBaseline, constraintAnchor };
    this.mAnchors = new ArrayList<ConstraintAnchor>();
    this.mIsInBarrier = new boolean[2];
    DimensionBehaviour dimensionBehaviour = DimensionBehaviour.FIXED;
    this.mListDimensionBehaviors = new DimensionBehaviour[] { dimensionBehaviour, dimensionBehaviour };
    this.mParent = null;
    this.mWidth = 0;
    this.mHeight = 0;
    this.mDimensionRatio = 0.0F;
    this.mDimensionRatioSide = -1;
    this.mX = 0;
    this.mY = 0;
    this.mRelX = 0;
    this.mRelY = 0;
    this.mOffsetX = 0;
    this.mOffsetY = 0;
    this.mBaselineDistance = 0;
    float f = DEFAULT_BIAS;
    this.mHorizontalBiasPercent = f;
    this.mVerticalBiasPercent = f;
    this.mContainerItemSkip = 0;
    this.mVisibility = 0;
    this.mDebugName = null;
    this.mType = null;
    this.mGroupsToSolver = false;
    this.mHorizontalChainStyle = 0;
    this.mVerticalChainStyle = 0;
    this.mWeight = new float[] { -1.0F, -1.0F };
    this.mListNextMatchConstraintsWidget = new ConstraintWidget[] { null, null };
    this.mNextChainWidget = new ConstraintWidget[] { null, null };
    this.mHorizontalNextWidget = null;
    this.mVerticalNextWidget = null;
    this.horizontalGroup = -1;
    this.verticalGroup = -1;
    addAnchors();
  }
  
  public ConstraintWidget(int paramInt1, int paramInt2) {
    this(0, 0, paramInt1, paramInt2);
  }
  
  public ConstraintWidget(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    ConstraintAnchor constraintAnchor = new ConstraintAnchor(this, ConstraintAnchor.Type.CENTER);
    this.mCenter = constraintAnchor;
    this.mListAnchors = new ConstraintAnchor[] { this.mLeft, this.mRight, this.mTop, this.mBottom, this.mBaseline, constraintAnchor };
    this.mAnchors = new ArrayList<ConstraintAnchor>();
    this.mIsInBarrier = new boolean[2];
    DimensionBehaviour dimensionBehaviour = DimensionBehaviour.FIXED;
    this.mListDimensionBehaviors = new DimensionBehaviour[] { dimensionBehaviour, dimensionBehaviour };
    this.mParent = null;
    this.mDimensionRatio = 0.0F;
    this.mDimensionRatioSide = -1;
    this.mRelX = 0;
    this.mRelY = 0;
    this.mOffsetX = 0;
    this.mOffsetY = 0;
    this.mBaselineDistance = 0;
    float f = DEFAULT_BIAS;
    this.mHorizontalBiasPercent = f;
    this.mVerticalBiasPercent = f;
    this.mContainerItemSkip = 0;
    this.mVisibility = 0;
    this.mDebugName = null;
    this.mType = null;
    this.mGroupsToSolver = false;
    this.mHorizontalChainStyle = 0;
    this.mVerticalChainStyle = 0;
    this.mWeight = new float[] { -1.0F, -1.0F };
    this.mListNextMatchConstraintsWidget = new ConstraintWidget[] { null, null };
    this.mNextChainWidget = new ConstraintWidget[] { null, null };
    this.mHorizontalNextWidget = null;
    this.mVerticalNextWidget = null;
    this.horizontalGroup = -1;
    this.verticalGroup = -1;
    this.mX = paramInt1;
    this.mY = paramInt2;
    this.mWidth = paramInt3;
    this.mHeight = paramInt4;
    addAnchors();
  }
  
  public ConstraintWidget(String paramString) {
    ConstraintAnchor constraintAnchor = new ConstraintAnchor(this, ConstraintAnchor.Type.CENTER);
    this.mCenter = constraintAnchor;
    this.mListAnchors = new ConstraintAnchor[] { this.mLeft, this.mRight, this.mTop, this.mBottom, this.mBaseline, constraintAnchor };
    this.mAnchors = new ArrayList<ConstraintAnchor>();
    this.mIsInBarrier = new boolean[2];
    DimensionBehaviour dimensionBehaviour = DimensionBehaviour.FIXED;
    this.mListDimensionBehaviors = new DimensionBehaviour[] { dimensionBehaviour, dimensionBehaviour };
    this.mParent = null;
    this.mWidth = 0;
    this.mHeight = 0;
    this.mDimensionRatio = 0.0F;
    this.mDimensionRatioSide = -1;
    this.mX = 0;
    this.mY = 0;
    this.mRelX = 0;
    this.mRelY = 0;
    this.mOffsetX = 0;
    this.mOffsetY = 0;
    this.mBaselineDistance = 0;
    float f = DEFAULT_BIAS;
    this.mHorizontalBiasPercent = f;
    this.mVerticalBiasPercent = f;
    this.mContainerItemSkip = 0;
    this.mVisibility = 0;
    this.mDebugName = null;
    this.mType = null;
    this.mGroupsToSolver = false;
    this.mHorizontalChainStyle = 0;
    this.mVerticalChainStyle = 0;
    this.mWeight = new float[] { -1.0F, -1.0F };
    this.mListNextMatchConstraintsWidget = new ConstraintWidget[] { null, null };
    this.mNextChainWidget = new ConstraintWidget[] { null, null };
    this.mHorizontalNextWidget = null;
    this.mVerticalNextWidget = null;
    this.horizontalGroup = -1;
    this.verticalGroup = -1;
    addAnchors();
    setDebugName(paramString);
  }
  
  public ConstraintWidget(String paramString, int paramInt1, int paramInt2) {
    this(paramInt1, paramInt2);
    setDebugName(paramString);
  }
  
  public ConstraintWidget(String paramString, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    this(paramInt1, paramInt2, paramInt3, paramInt4);
    setDebugName(paramString);
  }
  
  private void addAnchors() {
    this.mAnchors.add(this.mLeft);
    this.mAnchors.add(this.mTop);
    this.mAnchors.add(this.mRight);
    this.mAnchors.add(this.mBottom);
    this.mAnchors.add(this.mCenterX);
    this.mAnchors.add(this.mCenterY);
    this.mAnchors.add(this.mCenter);
    this.mAnchors.add(this.mBaseline);
  }
  
  private void applyConstraints(LinearSystem paramLinearSystem, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4, SolverVariable paramSolverVariable1, SolverVariable paramSolverVariable2, DimensionBehaviour paramDimensionBehaviour, boolean paramBoolean5, ConstraintAnchor paramConstraintAnchor1, ConstraintAnchor paramConstraintAnchor2, int paramInt1, int paramInt2, int paramInt3, int paramInt4, float paramFloat1, boolean paramBoolean6, boolean paramBoolean7, boolean paramBoolean8, boolean paramBoolean9, boolean paramBoolean10, int paramInt5, int paramInt6, int paramInt7, int paramInt8, float paramFloat2, boolean paramBoolean11) {
    throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: can not merge I and Z\r\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.copyTypes(TypeTransformer.java:311)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.fixTypes(TypeTransformer.java:226)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:207)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
  }
  
  private boolean isChainHead(int paramInt) {
    paramInt *= 2;
    ConstraintAnchor[] arrayOfConstraintAnchor = this.mListAnchors;
    if ((arrayOfConstraintAnchor[paramInt]).mTarget != null && (arrayOfConstraintAnchor[paramInt]).mTarget.mTarget != arrayOfConstraintAnchor[paramInt])
      if ((arrayOfConstraintAnchor[++paramInt]).mTarget != null && (arrayOfConstraintAnchor[paramInt]).mTarget.mTarget == arrayOfConstraintAnchor[paramInt])
        return true;  
    return false;
  }
  
  public void addChildrenToSolverByDependency(ConstraintWidgetContainer paramConstraintWidgetContainer, LinearSystem paramLinearSystem, HashSet<ConstraintWidget> paramHashSet, int paramInt, boolean paramBoolean) {
    if (paramBoolean) {
      if (!paramHashSet.contains(this))
        return; 
      Optimizer.checkMatchParent(paramConstraintWidgetContainer, paramLinearSystem, this);
      paramHashSet.remove(this);
      addToSolver(paramLinearSystem, paramConstraintWidgetContainer.optimizeFor(64));
    } 
    if (paramInt == 0) {
      HashSet<ConstraintAnchor> hashSet = this.mLeft.getDependents();
      if (hashSet != null) {
        Iterator<ConstraintAnchor> iterator = hashSet.iterator();
        while (iterator.hasNext())
          ((ConstraintAnchor)iterator.next()).mOwner.addChildrenToSolverByDependency(paramConstraintWidgetContainer, paramLinearSystem, paramHashSet, paramInt, true); 
      } 
      hashSet = this.mRight.getDependents();
      if (hashSet != null) {
        Iterator<ConstraintAnchor> iterator = hashSet.iterator();
        while (iterator.hasNext())
          ((ConstraintAnchor)iterator.next()).mOwner.addChildrenToSolverByDependency(paramConstraintWidgetContainer, paramLinearSystem, paramHashSet, paramInt, true); 
      } 
    } else {
      HashSet<ConstraintAnchor> hashSet = this.mTop.getDependents();
      if (hashSet != null) {
        Iterator<ConstraintAnchor> iterator = hashSet.iterator();
        while (iterator.hasNext())
          ((ConstraintAnchor)iterator.next()).mOwner.addChildrenToSolverByDependency(paramConstraintWidgetContainer, paramLinearSystem, paramHashSet, paramInt, true); 
      } 
      hashSet = this.mBottom.getDependents();
      if (hashSet != null) {
        Iterator<ConstraintAnchor> iterator = hashSet.iterator();
        while (iterator.hasNext())
          ((ConstraintAnchor)iterator.next()).mOwner.addChildrenToSolverByDependency(paramConstraintWidgetContainer, paramLinearSystem, paramHashSet, paramInt, true); 
      } 
      hashSet = this.mBaseline.getDependents();
      if (hashSet != null) {
        Iterator<ConstraintAnchor> iterator = hashSet.iterator();
        while (true) {
          if (iterator.hasNext()) {
            ConstraintWidget constraintWidget = ((ConstraintAnchor)iterator.next()).mOwner;
            try {
              constraintWidget.addChildrenToSolverByDependency(paramConstraintWidgetContainer, paramLinearSystem, paramHashSet, paramInt, true);
            } finally {}
            continue;
          } 
          return;
        } 
      } 
    } 
  }
  
  boolean addFirst() {
    return (this instanceof VirtualLayout || this instanceof Guideline);
  }
  
  public void addToSolver(LinearSystem paramLinearSystem, boolean paramBoolean) {
    // Byte code:
    //   0: aload_1
    //   1: aload_0
    //   2: getfield mLeft : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   5: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/solver/SolverVariable;
    //   8: astore #27
    //   10: aload_1
    //   11: aload_0
    //   12: getfield mRight : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   15: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/solver/SolverVariable;
    //   18: astore #26
    //   20: aload_1
    //   21: aload_0
    //   22: getfield mTop : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   25: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/solver/SolverVariable;
    //   28: astore #29
    //   30: aload_1
    //   31: aload_0
    //   32: getfield mBottom : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   35: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/solver/SolverVariable;
    //   38: astore #31
    //   40: aload_1
    //   41: aload_0
    //   42: getfield mBaseline : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   45: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/solver/SolverVariable;
    //   48: astore #30
    //   50: aload_0
    //   51: getfield mParent : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   54: astore #25
    //   56: aload #25
    //   58: ifnull -> 122
    //   61: aload #25
    //   63: ifnull -> 85
    //   66: aload #25
    //   68: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   71: iconst_0
    //   72: aaload
    //   73: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   76: if_acmpne -> 85
    //   79: iconst_1
    //   80: istore #12
    //   82: goto -> 88
    //   85: iconst_0
    //   86: istore #12
    //   88: aload #25
    //   90: ifnull -> 112
    //   93: aload #25
    //   95: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   98: iconst_1
    //   99: aaload
    //   100: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   103: if_acmpne -> 112
    //   106: iconst_1
    //   107: istore #13
    //   109: goto -> 115
    //   112: iconst_0
    //   113: istore #13
    //   115: iload #12
    //   117: istore #15
    //   119: goto -> 128
    //   122: iconst_0
    //   123: istore #15
    //   125: iconst_0
    //   126: istore #13
    //   128: aload_0
    //   129: getfield mVisibility : I
    //   132: bipush #8
    //   134: if_icmpne -> 165
    //   137: aload_0
    //   138: invokevirtual hasDependencies : ()Z
    //   141: ifne -> 165
    //   144: aload_0
    //   145: getfield mIsInBarrier : [Z
    //   148: astore #25
    //   150: aload #25
    //   152: iconst_0
    //   153: baload
    //   154: ifne -> 165
    //   157: aload #25
    //   159: iconst_1
    //   160: baload
    //   161: ifne -> 165
    //   164: return
    //   165: aload_0
    //   166: getfield resolvedHorizontal : Z
    //   169: istore #12
    //   171: iload #12
    //   173: ifne -> 183
    //   176: aload_0
    //   177: getfield resolvedVertical : Z
    //   180: ifeq -> 431
    //   183: iload #12
    //   185: ifeq -> 281
    //   188: aload_1
    //   189: aload #27
    //   191: aload_0
    //   192: getfield mX : I
    //   195: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;I)V
    //   198: aload_1
    //   199: aload #26
    //   201: aload_0
    //   202: getfield mX : I
    //   205: aload_0
    //   206: getfield mWidth : I
    //   209: iadd
    //   210: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;I)V
    //   213: iload #15
    //   215: ifeq -> 281
    //   218: aload_0
    //   219: getfield mParent : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   222: astore #25
    //   224: aload #25
    //   226: ifnull -> 281
    //   229: aload_0
    //   230: getfield OPTIMIZE_WRAP_ON_RESOLVED : Z
    //   233: ifeq -> 264
    //   236: aload #25
    //   238: checkcast androidx/constraintlayout/solver/widgets/ConstraintWidgetContainer
    //   241: astore #25
    //   243: aload #25
    //   245: aload_0
    //   246: getfield mLeft : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   249: invokevirtual addVerticalWrapMinVariable : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;)V
    //   252: aload #25
    //   254: aload_0
    //   255: getfield mRight : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   258: invokevirtual addHorizontalWrapMaxVariable : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;)V
    //   261: goto -> 281
    //   264: aload_1
    //   265: aload_1
    //   266: aload #25
    //   268: getfield mRight : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   271: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/solver/SolverVariable;
    //   274: aload #26
    //   276: iconst_0
    //   277: iconst_5
    //   278: invokevirtual addGreaterThan : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)V
    //   281: aload_0
    //   282: getfield resolvedVertical : Z
    //   285: ifeq -> 406
    //   288: aload_1
    //   289: aload #29
    //   291: aload_0
    //   292: getfield mY : I
    //   295: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;I)V
    //   298: aload_1
    //   299: aload #31
    //   301: aload_0
    //   302: getfield mY : I
    //   305: aload_0
    //   306: getfield mHeight : I
    //   309: iadd
    //   310: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;I)V
    //   313: aload_0
    //   314: getfield mBaseline : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   317: invokevirtual hasDependents : ()Z
    //   320: ifeq -> 338
    //   323: aload_1
    //   324: aload #30
    //   326: aload_0
    //   327: getfield mY : I
    //   330: aload_0
    //   331: getfield mBaselineDistance : I
    //   334: iadd
    //   335: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;I)V
    //   338: iload #13
    //   340: ifeq -> 406
    //   343: aload_0
    //   344: getfield mParent : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   347: astore #25
    //   349: aload #25
    //   351: ifnull -> 406
    //   354: aload_0
    //   355: getfield OPTIMIZE_WRAP_ON_RESOLVED : Z
    //   358: ifeq -> 389
    //   361: aload #25
    //   363: checkcast androidx/constraintlayout/solver/widgets/ConstraintWidgetContainer
    //   366: astore #25
    //   368: aload #25
    //   370: aload_0
    //   371: getfield mTop : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   374: invokevirtual addVerticalWrapMinVariable : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;)V
    //   377: aload #25
    //   379: aload_0
    //   380: getfield mBottom : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   383: invokevirtual addVerticalWrapMaxVariable : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;)V
    //   386: goto -> 406
    //   389: aload_1
    //   390: aload_1
    //   391: aload #25
    //   393: getfield mBottom : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   396: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/solver/SolverVariable;
    //   399: aload #31
    //   401: iconst_0
    //   402: iconst_5
    //   403: invokevirtual addGreaterThan : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)V
    //   406: aload_0
    //   407: getfield resolvedHorizontal : Z
    //   410: ifeq -> 431
    //   413: aload_0
    //   414: getfield resolvedVertical : Z
    //   417: ifeq -> 431
    //   420: aload_0
    //   421: iconst_0
    //   422: putfield resolvedHorizontal : Z
    //   425: aload_0
    //   426: iconst_0
    //   427: putfield resolvedVertical : Z
    //   430: return
    //   431: getstatic androidx/constraintlayout/solver/LinearSystem.sMetrics : Landroidx/constraintlayout/solver/Metrics;
    //   434: astore #25
    //   436: aload #25
    //   438: ifnull -> 453
    //   441: aload #25
    //   443: aload #25
    //   445: getfield widgets : J
    //   448: lconst_1
    //   449: ladd
    //   450: putfield widgets : J
    //   453: iload_2
    //   454: ifeq -> 722
    //   457: aload_0
    //   458: getfield horizontalRun : Landroidx/constraintlayout/solver/widgets/analyzer/HorizontalWidgetRun;
    //   461: astore #28
    //   463: aload #28
    //   465: ifnull -> 722
    //   468: aload_0
    //   469: getfield verticalRun : Landroidx/constraintlayout/solver/widgets/analyzer/VerticalWidgetRun;
    //   472: astore #32
    //   474: aload #32
    //   476: ifnull -> 722
    //   479: aload #28
    //   481: getfield start : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   484: astore #33
    //   486: aload #33
    //   488: getfield resolved : Z
    //   491: ifeq -> 722
    //   494: aload #28
    //   496: getfield end : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   499: getfield resolved : Z
    //   502: ifeq -> 722
    //   505: aload #32
    //   507: getfield start : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   510: getfield resolved : Z
    //   513: ifeq -> 722
    //   516: aload #32
    //   518: getfield end : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   521: getfield resolved : Z
    //   524: ifeq -> 722
    //   527: aload #25
    //   529: ifnull -> 544
    //   532: aload #25
    //   534: aload #25
    //   536: getfield graphSolved : J
    //   539: lconst_1
    //   540: ladd
    //   541: putfield graphSolved : J
    //   544: aload_1
    //   545: aload #27
    //   547: aload #33
    //   549: getfield value : I
    //   552: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;I)V
    //   555: aload_1
    //   556: aload #26
    //   558: aload_0
    //   559: getfield horizontalRun : Landroidx/constraintlayout/solver/widgets/analyzer/HorizontalWidgetRun;
    //   562: getfield end : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   565: getfield value : I
    //   568: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;I)V
    //   571: aload_1
    //   572: aload #29
    //   574: aload_0
    //   575: getfield verticalRun : Landroidx/constraintlayout/solver/widgets/analyzer/VerticalWidgetRun;
    //   578: getfield start : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   581: getfield value : I
    //   584: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;I)V
    //   587: aload_1
    //   588: aload #31
    //   590: aload_0
    //   591: getfield verticalRun : Landroidx/constraintlayout/solver/widgets/analyzer/VerticalWidgetRun;
    //   594: getfield end : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   597: getfield value : I
    //   600: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;I)V
    //   603: aload_1
    //   604: aload #30
    //   606: aload_0
    //   607: getfield verticalRun : Landroidx/constraintlayout/solver/widgets/analyzer/VerticalWidgetRun;
    //   610: getfield baseline : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   613: getfield value : I
    //   616: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;I)V
    //   619: aload_0
    //   620: getfield mParent : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   623: ifnull -> 711
    //   626: iload #15
    //   628: ifeq -> 667
    //   631: aload_0
    //   632: getfield isTerminalWidget : [Z
    //   635: iconst_0
    //   636: baload
    //   637: ifeq -> 667
    //   640: aload_0
    //   641: invokevirtual isInHorizontalChain : ()Z
    //   644: ifne -> 667
    //   647: aload_1
    //   648: aload_1
    //   649: aload_0
    //   650: getfield mParent : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   653: getfield mRight : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   656: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/solver/SolverVariable;
    //   659: aload #26
    //   661: iconst_0
    //   662: bipush #8
    //   664: invokevirtual addGreaterThan : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)V
    //   667: iload #13
    //   669: ifeq -> 711
    //   672: aload_0
    //   673: getfield isTerminalWidget : [Z
    //   676: iconst_1
    //   677: baload
    //   678: ifeq -> 711
    //   681: aload_0
    //   682: invokevirtual isInVerticalChain : ()Z
    //   685: ifne -> 711
    //   688: aload_1
    //   689: aload_1
    //   690: aload_0
    //   691: getfield mParent : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   694: getfield mBottom : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   697: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/solver/SolverVariable;
    //   700: aload #31
    //   702: iconst_0
    //   703: bipush #8
    //   705: invokevirtual addGreaterThan : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)V
    //   708: goto -> 711
    //   711: aload_0
    //   712: iconst_0
    //   713: putfield resolvedHorizontal : Z
    //   716: aload_0
    //   717: iconst_0
    //   718: putfield resolvedVertical : Z
    //   721: return
    //   722: aload #25
    //   724: ifnull -> 739
    //   727: aload #25
    //   729: aload #25
    //   731: getfield linearSolved : J
    //   734: lconst_1
    //   735: ladd
    //   736: putfield linearSolved : J
    //   739: aload_0
    //   740: getfield mParent : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   743: ifnull -> 940
    //   746: aload_0
    //   747: iconst_0
    //   748: invokespecial isChainHead : (I)Z
    //   751: ifeq -> 772
    //   754: aload_0
    //   755: getfield mParent : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   758: checkcast androidx/constraintlayout/solver/widgets/ConstraintWidgetContainer
    //   761: aload_0
    //   762: iconst_0
    //   763: invokevirtual addChain : (Landroidx/constraintlayout/solver/widgets/ConstraintWidget;I)V
    //   766: iconst_1
    //   767: istore #12
    //   769: goto -> 778
    //   772: aload_0
    //   773: invokevirtual isInHorizontalChain : ()Z
    //   776: istore #12
    //   778: aload_0
    //   779: iconst_1
    //   780: invokespecial isChainHead : (I)Z
    //   783: ifeq -> 804
    //   786: aload_0
    //   787: getfield mParent : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   790: checkcast androidx/constraintlayout/solver/widgets/ConstraintWidgetContainer
    //   793: aload_0
    //   794: iconst_1
    //   795: invokevirtual addChain : (Landroidx/constraintlayout/solver/widgets/ConstraintWidget;I)V
    //   798: iconst_1
    //   799: istore #14
    //   801: goto -> 810
    //   804: aload_0
    //   805: invokevirtual isInVerticalChain : ()Z
    //   808: istore #14
    //   810: iload #12
    //   812: ifne -> 868
    //   815: iload #15
    //   817: ifeq -> 868
    //   820: aload_0
    //   821: getfield mVisibility : I
    //   824: bipush #8
    //   826: if_icmpeq -> 868
    //   829: aload_0
    //   830: getfield mLeft : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   833: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   836: ifnonnull -> 868
    //   839: aload_0
    //   840: getfield mRight : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   843: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   846: ifnonnull -> 868
    //   849: aload_1
    //   850: aload_1
    //   851: aload_0
    //   852: getfield mParent : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   855: getfield mRight : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   858: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/solver/SolverVariable;
    //   861: aload #26
    //   863: iconst_0
    //   864: iconst_1
    //   865: invokevirtual addGreaterThan : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)V
    //   868: iload #14
    //   870: ifne -> 933
    //   873: iload #13
    //   875: ifeq -> 933
    //   878: aload_0
    //   879: getfield mVisibility : I
    //   882: bipush #8
    //   884: if_icmpeq -> 933
    //   887: aload_0
    //   888: getfield mTop : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   891: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   894: ifnonnull -> 933
    //   897: aload_0
    //   898: getfield mBottom : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   901: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   904: ifnonnull -> 933
    //   907: aload_0
    //   908: getfield mBaseline : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   911: ifnonnull -> 933
    //   914: aload_1
    //   915: aload_1
    //   916: aload_0
    //   917: getfield mParent : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   920: getfield mBottom : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   923: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/solver/SolverVariable;
    //   926: aload #31
    //   928: iconst_0
    //   929: iconst_1
    //   930: invokevirtual addGreaterThan : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)V
    //   933: iload #12
    //   935: istore #16
    //   937: goto -> 946
    //   940: iconst_0
    //   941: istore #14
    //   943: iconst_0
    //   944: istore #16
    //   946: aload_0
    //   947: getfield mWidth : I
    //   950: istore #9
    //   952: aload_0
    //   953: getfield mMinWidth : I
    //   956: istore #5
    //   958: iload #9
    //   960: iload #5
    //   962: if_icmpge -> 968
    //   965: goto -> 972
    //   968: iload #9
    //   970: istore #5
    //   972: aload_0
    //   973: getfield mHeight : I
    //   976: istore #10
    //   978: aload_0
    //   979: getfield mMinHeight : I
    //   982: istore #4
    //   984: iload #10
    //   986: iload #4
    //   988: if_icmpge -> 994
    //   991: goto -> 998
    //   994: iload #10
    //   996: istore #4
    //   998: aload_0
    //   999: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   1002: astore #28
    //   1004: aload #28
    //   1006: iconst_0
    //   1007: aaload
    //   1008: astore #25
    //   1010: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   1013: astore #34
    //   1015: aload #25
    //   1017: aload #34
    //   1019: if_acmpeq -> 1028
    //   1022: iconst_1
    //   1023: istore #12
    //   1025: goto -> 1031
    //   1028: iconst_0
    //   1029: istore #12
    //   1031: aload #28
    //   1033: iconst_1
    //   1034: aaload
    //   1035: aload #34
    //   1037: if_acmpeq -> 1046
    //   1040: iconst_1
    //   1041: istore #17
    //   1043: goto -> 1049
    //   1046: iconst_0
    //   1047: istore #17
    //   1049: aload_0
    //   1050: getfield mDimensionRatioSide : I
    //   1053: istore #11
    //   1055: aload_0
    //   1056: iload #11
    //   1058: putfield mResolvedDimensionRatioSide : I
    //   1061: aload_0
    //   1062: getfield mDimensionRatio : F
    //   1065: fstore_3
    //   1066: aload_0
    //   1067: fload_3
    //   1068: putfield mResolvedDimensionRatio : F
    //   1071: aload_0
    //   1072: getfield mMatchConstraintDefaultWidth : I
    //   1075: istore #7
    //   1077: aload_0
    //   1078: getfield mMatchConstraintDefaultHeight : I
    //   1081: istore #8
    //   1083: aload #26
    //   1085: astore #25
    //   1087: fload_3
    //   1088: fconst_0
    //   1089: fcmpl
    //   1090: ifle -> 1368
    //   1093: aload_0
    //   1094: getfield mVisibility : I
    //   1097: bipush #8
    //   1099: if_icmpeq -> 1368
    //   1102: iload #7
    //   1104: istore #6
    //   1106: aload #28
    //   1108: iconst_0
    //   1109: aaload
    //   1110: aload #34
    //   1112: if_acmpne -> 1127
    //   1115: iload #7
    //   1117: istore #6
    //   1119: iload #7
    //   1121: ifne -> 1127
    //   1124: iconst_3
    //   1125: istore #6
    //   1127: iload #8
    //   1129: istore #7
    //   1131: aload #28
    //   1133: iconst_1
    //   1134: aaload
    //   1135: aload #34
    //   1137: if_acmpne -> 1152
    //   1140: iload #8
    //   1142: istore #7
    //   1144: iload #8
    //   1146: ifne -> 1152
    //   1149: iconst_3
    //   1150: istore #7
    //   1152: aload #28
    //   1154: iconst_0
    //   1155: aaload
    //   1156: aload #34
    //   1158: if_acmpne -> 1197
    //   1161: aload #28
    //   1163: iconst_1
    //   1164: aaload
    //   1165: aload #34
    //   1167: if_acmpne -> 1197
    //   1170: iload #6
    //   1172: iconst_3
    //   1173: if_icmpne -> 1197
    //   1176: iload #7
    //   1178: iconst_3
    //   1179: if_icmpne -> 1197
    //   1182: aload_0
    //   1183: iload #15
    //   1185: iload #13
    //   1187: iload #12
    //   1189: iload #17
    //   1191: invokevirtual setupDimensionRatio : (ZZZZ)V
    //   1194: goto -> 1350
    //   1197: aload #28
    //   1199: iconst_0
    //   1200: aaload
    //   1201: aload #34
    //   1203: if_acmpne -> 1265
    //   1206: iload #6
    //   1208: iconst_3
    //   1209: if_icmpne -> 1265
    //   1212: aload_0
    //   1213: iconst_0
    //   1214: putfield mResolvedDimensionRatioSide : I
    //   1217: fload_3
    //   1218: iload #10
    //   1220: i2f
    //   1221: fmul
    //   1222: f2i
    //   1223: istore #8
    //   1225: aload #28
    //   1227: iconst_1
    //   1228: aaload
    //   1229: aload #34
    //   1231: if_acmpeq -> 1251
    //   1234: iload #7
    //   1236: istore #5
    //   1238: iconst_0
    //   1239: istore #12
    //   1241: iconst_4
    //   1242: istore #6
    //   1244: iload #8
    //   1246: istore #7
    //   1248: goto -> 1383
    //   1251: iload #7
    //   1253: istore #5
    //   1255: iconst_1
    //   1256: istore #12
    //   1258: iload #8
    //   1260: istore #7
    //   1262: goto -> 1383
    //   1265: aload #28
    //   1267: iconst_1
    //   1268: aaload
    //   1269: aload #34
    //   1271: if_acmpne -> 1350
    //   1274: iload #7
    //   1276: iconst_3
    //   1277: if_icmpne -> 1350
    //   1280: aload_0
    //   1281: iconst_1
    //   1282: putfield mResolvedDimensionRatioSide : I
    //   1285: iload #11
    //   1287: iconst_m1
    //   1288: if_icmpne -> 1298
    //   1291: aload_0
    //   1292: fconst_1
    //   1293: fload_3
    //   1294: fdiv
    //   1295: putfield mResolvedDimensionRatio : F
    //   1298: aload_0
    //   1299: getfield mResolvedDimensionRatio : F
    //   1302: iload #9
    //   1304: i2f
    //   1305: fmul
    //   1306: f2i
    //   1307: istore #4
    //   1309: aload #28
    //   1311: iconst_0
    //   1312: aaload
    //   1313: astore #28
    //   1315: iload #6
    //   1317: istore #8
    //   1319: aload #28
    //   1321: aload #34
    //   1323: if_acmpeq -> 1347
    //   1326: iconst_0
    //   1327: istore #12
    //   1329: iconst_4
    //   1330: istore #6
    //   1332: iload #5
    //   1334: istore #7
    //   1336: iload #6
    //   1338: istore #5
    //   1340: iload #8
    //   1342: istore #6
    //   1344: goto -> 1383
    //   1347: goto -> 1350
    //   1350: iload #7
    //   1352: istore #8
    //   1354: iconst_1
    //   1355: istore #12
    //   1357: iload #5
    //   1359: istore #7
    //   1361: iload #8
    //   1363: istore #5
    //   1365: goto -> 1383
    //   1368: iload #7
    //   1370: istore #6
    //   1372: iload #5
    //   1374: istore #7
    //   1376: iconst_0
    //   1377: istore #12
    //   1379: iload #8
    //   1381: istore #5
    //   1383: aload_0
    //   1384: getfield mResolvedMatchConstraintDefault : [I
    //   1387: astore #28
    //   1389: aload #28
    //   1391: iconst_0
    //   1392: iload #6
    //   1394: iastore
    //   1395: aload #28
    //   1397: iconst_1
    //   1398: iload #5
    //   1400: iastore
    //   1401: aload_0
    //   1402: iload #12
    //   1404: putfield mResolvedHasRatio : Z
    //   1407: iload #12
    //   1409: ifeq -> 1435
    //   1412: aload_0
    //   1413: getfield mResolvedDimensionRatioSide : I
    //   1416: istore #8
    //   1418: iload #8
    //   1420: ifeq -> 1429
    //   1423: iload #8
    //   1425: iconst_m1
    //   1426: if_icmpne -> 1435
    //   1429: iconst_1
    //   1430: istore #18
    //   1432: goto -> 1438
    //   1435: iconst_0
    //   1436: istore #18
    //   1438: iload #12
    //   1440: ifeq -> 1467
    //   1443: aload_0
    //   1444: getfield mResolvedDimensionRatioSide : I
    //   1447: istore #8
    //   1449: iload #8
    //   1451: iconst_1
    //   1452: if_icmpeq -> 1461
    //   1455: iload #8
    //   1457: iconst_m1
    //   1458: if_icmpne -> 1467
    //   1461: iconst_1
    //   1462: istore #17
    //   1464: goto -> 1470
    //   1467: iconst_0
    //   1468: istore #17
    //   1470: aload_0
    //   1471: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   1474: iconst_0
    //   1475: aaload
    //   1476: astore #28
    //   1478: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   1481: astore #35
    //   1483: aload #28
    //   1485: aload #35
    //   1487: if_acmpne -> 1503
    //   1490: aload_0
    //   1491: instanceof androidx/constraintlayout/solver/widgets/ConstraintWidgetContainer
    //   1494: ifeq -> 1503
    //   1497: iconst_1
    //   1498: istore #19
    //   1500: goto -> 1506
    //   1503: iconst_0
    //   1504: istore #19
    //   1506: iload #19
    //   1508: ifeq -> 1517
    //   1511: iconst_0
    //   1512: istore #7
    //   1514: goto -> 1517
    //   1517: aload_0
    //   1518: getfield mCenter : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1521: invokevirtual isConnected : ()Z
    //   1524: iconst_1
    //   1525: ixor
    //   1526: istore #21
    //   1528: aload_0
    //   1529: getfield mIsInBarrier : [Z
    //   1532: astore #28
    //   1534: aload #28
    //   1536: iconst_0
    //   1537: baload
    //   1538: istore #23
    //   1540: aload #28
    //   1542: iconst_1
    //   1543: baload
    //   1544: istore #22
    //   1546: aload_0
    //   1547: getfield mHorizontalResolution : I
    //   1550: iconst_2
    //   1551: if_icmpeq -> 1885
    //   1554: aload_0
    //   1555: getfield resolvedHorizontal : Z
    //   1558: ifne -> 1885
    //   1561: iload_2
    //   1562: ifeq -> 1690
    //   1565: aload_0
    //   1566: getfield horizontalRun : Landroidx/constraintlayout/solver/widgets/analyzer/HorizontalWidgetRun;
    //   1569: astore #28
    //   1571: aload #28
    //   1573: ifnull -> 1690
    //   1576: aload #28
    //   1578: getfield start : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   1581: astore #32
    //   1583: aload #32
    //   1585: getfield resolved : Z
    //   1588: ifeq -> 1690
    //   1591: aload #28
    //   1593: getfield end : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   1596: getfield resolved : Z
    //   1599: ifne -> 1605
    //   1602: goto -> 1690
    //   1605: iload_2
    //   1606: ifeq -> 1687
    //   1609: aload_1
    //   1610: aload #27
    //   1612: aload #32
    //   1614: getfield value : I
    //   1617: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;I)V
    //   1620: aload_1
    //   1621: aload #25
    //   1623: aload_0
    //   1624: getfield horizontalRun : Landroidx/constraintlayout/solver/widgets/analyzer/HorizontalWidgetRun;
    //   1627: getfield end : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   1630: getfield value : I
    //   1633: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;I)V
    //   1636: aload_0
    //   1637: getfield mParent : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   1640: ifnull -> 1684
    //   1643: iload #15
    //   1645: ifeq -> 1684
    //   1648: aload_0
    //   1649: getfield isTerminalWidget : [Z
    //   1652: iconst_0
    //   1653: baload
    //   1654: ifeq -> 1684
    //   1657: aload_0
    //   1658: invokevirtual isInHorizontalChain : ()Z
    //   1661: ifne -> 1684
    //   1664: aload_1
    //   1665: aload_1
    //   1666: aload_0
    //   1667: getfield mParent : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   1670: getfield mRight : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1673: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/solver/SolverVariable;
    //   1676: aload #25
    //   1678: iconst_0
    //   1679: bipush #8
    //   1681: invokevirtual addGreaterThan : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)V
    //   1684: goto -> 1885
    //   1687: goto -> 1885
    //   1690: aload_0
    //   1691: getfield mParent : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   1694: astore #25
    //   1696: aload #25
    //   1698: ifnull -> 1715
    //   1701: aload_1
    //   1702: aload #25
    //   1704: getfield mRight : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1707: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/solver/SolverVariable;
    //   1710: astore #25
    //   1712: goto -> 1718
    //   1715: aconst_null
    //   1716: astore #25
    //   1718: aload_0
    //   1719: getfield mParent : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   1722: astore #28
    //   1724: aload #28
    //   1726: ifnull -> 1743
    //   1729: aload_1
    //   1730: aload #28
    //   1732: getfield mLeft : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1735: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/solver/SolverVariable;
    //   1738: astore #28
    //   1740: goto -> 1746
    //   1743: aconst_null
    //   1744: astore #28
    //   1746: aload_0
    //   1747: getfield isTerminalWidget : [Z
    //   1750: iconst_0
    //   1751: baload
    //   1752: istore #24
    //   1754: aload_0
    //   1755: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   1758: astore #32
    //   1760: aload #32
    //   1762: iconst_0
    //   1763: aaload
    //   1764: astore #33
    //   1766: aload_0
    //   1767: getfield mLeft : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1770: astore #36
    //   1772: aload_0
    //   1773: getfield mRight : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1776: astore #37
    //   1778: aload_0
    //   1779: getfield mX : I
    //   1782: istore #8
    //   1784: aload_0
    //   1785: getfield mMinWidth : I
    //   1788: istore #9
    //   1790: aload_0
    //   1791: getfield mMaxDimension : [I
    //   1794: iconst_0
    //   1795: iaload
    //   1796: istore #10
    //   1798: aload_0
    //   1799: getfield mHorizontalBiasPercent : F
    //   1802: fstore_3
    //   1803: aload #32
    //   1805: iconst_1
    //   1806: aaload
    //   1807: aload #34
    //   1809: if_acmpne -> 1818
    //   1812: iconst_1
    //   1813: istore #20
    //   1815: goto -> 1821
    //   1818: iconst_0
    //   1819: istore #20
    //   1821: aload_0
    //   1822: aload_1
    //   1823: iconst_1
    //   1824: iload #15
    //   1826: iload #13
    //   1828: iload #24
    //   1830: aload #28
    //   1832: aload #25
    //   1834: aload #33
    //   1836: iload #19
    //   1838: aload #36
    //   1840: aload #37
    //   1842: iload #8
    //   1844: iload #7
    //   1846: iload #9
    //   1848: iload #10
    //   1850: fload_3
    //   1851: iload #18
    //   1853: iload #20
    //   1855: iload #16
    //   1857: iload #14
    //   1859: iload #23
    //   1861: iload #6
    //   1863: iload #5
    //   1865: aload_0
    //   1866: getfield mMatchConstraintMinWidth : I
    //   1869: aload_0
    //   1870: getfield mMatchConstraintMaxWidth : I
    //   1873: aload_0
    //   1874: getfield mMatchConstraintPercentWidth : F
    //   1877: iload #21
    //   1879: invokespecial applyConstraints : (Landroidx/constraintlayout/solver/LinearSystem;ZZZZLandroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;ZLandroidx/constraintlayout/solver/widgets/ConstraintAnchor;Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;IIIIFZZZZZIIIIFZ)V
    //   1882: goto -> 1885
    //   1885: aload #31
    //   1887: astore #25
    //   1889: aload #30
    //   1891: astore #28
    //   1893: aload #27
    //   1895: astore #30
    //   1897: iload #13
    //   1899: istore #19
    //   1901: aload #26
    //   1903: astore #31
    //   1905: iload_2
    //   1906: ifeq -> 2080
    //   1909: aload_0
    //   1910: astore #26
    //   1912: aload #26
    //   1914: getfield verticalRun : Landroidx/constraintlayout/solver/widgets/analyzer/VerticalWidgetRun;
    //   1917: astore #27
    //   1919: aload #27
    //   1921: ifnull -> 2077
    //   1924: aload #27
    //   1926: getfield start : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   1929: astore #32
    //   1931: aload #32
    //   1933: getfield resolved : Z
    //   1936: ifeq -> 2077
    //   1939: aload #27
    //   1941: getfield end : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   1944: getfield resolved : Z
    //   1947: ifeq -> 2077
    //   1950: aload #32
    //   1952: getfield value : I
    //   1955: istore #7
    //   1957: aload_1
    //   1958: astore #27
    //   1960: aload #27
    //   1962: aload #29
    //   1964: iload #7
    //   1966: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;I)V
    //   1969: aload #26
    //   1971: getfield verticalRun : Landroidx/constraintlayout/solver/widgets/analyzer/VerticalWidgetRun;
    //   1974: getfield end : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   1977: getfield value : I
    //   1980: istore #7
    //   1982: aload #25
    //   1984: astore #32
    //   1986: aload #27
    //   1988: aload #32
    //   1990: iload #7
    //   1992: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;I)V
    //   1995: aload #27
    //   1997: aload #28
    //   1999: aload #26
    //   2001: getfield verticalRun : Landroidx/constraintlayout/solver/widgets/analyzer/VerticalWidgetRun;
    //   2004: getfield baseline : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   2007: getfield value : I
    //   2010: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;I)V
    //   2013: aload #26
    //   2015: getfield mParent : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   2018: astore #33
    //   2020: aload #33
    //   2022: ifnull -> 2071
    //   2025: iload #14
    //   2027: ifne -> 2071
    //   2030: iload #19
    //   2032: ifeq -> 2071
    //   2035: aload #26
    //   2037: getfield isTerminalWidget : [Z
    //   2040: iconst_1
    //   2041: baload
    //   2042: ifeq -> 2068
    //   2045: aload #27
    //   2047: aload #27
    //   2049: aload #33
    //   2051: getfield mBottom : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2054: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/solver/SolverVariable;
    //   2057: aload #32
    //   2059: iconst_0
    //   2060: bipush #8
    //   2062: invokevirtual addGreaterThan : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)V
    //   2065: goto -> 2071
    //   2068: goto -> 2071
    //   2071: iconst_0
    //   2072: istore #7
    //   2074: goto -> 2083
    //   2077: goto -> 2080
    //   2080: iconst_1
    //   2081: istore #7
    //   2083: aload_0
    //   2084: astore #32
    //   2086: aload_1
    //   2087: astore #33
    //   2089: aload #29
    //   2091: astore #26
    //   2093: aload #28
    //   2095: astore #29
    //   2097: aload #32
    //   2099: getfield mVerticalResolution : I
    //   2102: iconst_2
    //   2103: if_icmpne -> 2112
    //   2106: iconst_0
    //   2107: istore #7
    //   2109: goto -> 2112
    //   2112: iload #7
    //   2114: ifeq -> 2513
    //   2117: aload #32
    //   2119: getfield resolvedVertical : Z
    //   2122: ifne -> 2513
    //   2125: aload #32
    //   2127: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   2130: iconst_1
    //   2131: aaload
    //   2132: aload #35
    //   2134: if_acmpne -> 2150
    //   2137: aload #32
    //   2139: instanceof androidx/constraintlayout/solver/widgets/ConstraintWidgetContainer
    //   2142: ifeq -> 2150
    //   2145: iconst_1
    //   2146: istore_2
    //   2147: goto -> 2152
    //   2150: iconst_0
    //   2151: istore_2
    //   2152: iload_2
    //   2153: ifeq -> 2159
    //   2156: iconst_0
    //   2157: istore #4
    //   2159: aload #32
    //   2161: getfield mParent : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   2164: astore #27
    //   2166: aload #27
    //   2168: ifnull -> 2186
    //   2171: aload #33
    //   2173: aload #27
    //   2175: getfield mBottom : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2178: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/solver/SolverVariable;
    //   2181: astore #27
    //   2183: goto -> 2189
    //   2186: aconst_null
    //   2187: astore #27
    //   2189: aload #32
    //   2191: getfield mParent : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   2194: astore #28
    //   2196: aload #28
    //   2198: ifnull -> 2216
    //   2201: aload #33
    //   2203: aload #28
    //   2205: getfield mTop : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2208: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/solver/SolverVariable;
    //   2211: astore #28
    //   2213: goto -> 2219
    //   2216: aconst_null
    //   2217: astore #28
    //   2219: aload #32
    //   2221: getfield mBaselineDistance : I
    //   2224: ifgt -> 2237
    //   2227: aload #32
    //   2229: getfield mVisibility : I
    //   2232: bipush #8
    //   2234: if_icmpne -> 2360
    //   2237: aload #32
    //   2239: getfield mBaseline : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2242: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2245: ifnull -> 2318
    //   2248: aload #33
    //   2250: aload #29
    //   2252: aload #26
    //   2254: aload_0
    //   2255: invokevirtual getBaselineDistance : ()I
    //   2258: bipush #8
    //   2260: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)Landroidx/constraintlayout/solver/ArrayRow;
    //   2263: pop
    //   2264: aload #33
    //   2266: aload #29
    //   2268: aload #33
    //   2270: aload #32
    //   2272: getfield mBaseline : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2275: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2278: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/solver/SolverVariable;
    //   2281: iconst_0
    //   2282: bipush #8
    //   2284: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)Landroidx/constraintlayout/solver/ArrayRow;
    //   2287: pop
    //   2288: iload #19
    //   2290: ifeq -> 2312
    //   2293: aload #33
    //   2295: aload #27
    //   2297: aload #33
    //   2299: aload #32
    //   2301: getfield mBottom : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2304: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/solver/SolverVariable;
    //   2307: iconst_0
    //   2308: iconst_5
    //   2309: invokevirtual addGreaterThan : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)V
    //   2312: iconst_0
    //   2313: istore #13
    //   2315: goto -> 2364
    //   2318: aload #32
    //   2320: getfield mVisibility : I
    //   2323: bipush #8
    //   2325: if_icmpne -> 2344
    //   2328: aload #33
    //   2330: aload #29
    //   2332: aload #26
    //   2334: iconst_0
    //   2335: bipush #8
    //   2337: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)Landroidx/constraintlayout/solver/ArrayRow;
    //   2340: pop
    //   2341: goto -> 2360
    //   2344: aload #33
    //   2346: aload #29
    //   2348: aload #26
    //   2350: aload_0
    //   2351: invokevirtual getBaselineDistance : ()I
    //   2354: bipush #8
    //   2356: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)Landroidx/constraintlayout/solver/ArrayRow;
    //   2359: pop
    //   2360: iload #21
    //   2362: istore #13
    //   2364: aload #32
    //   2366: getfield isTerminalWidget : [Z
    //   2369: iconst_1
    //   2370: baload
    //   2371: istore #20
    //   2373: aload #32
    //   2375: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   2378: astore #29
    //   2380: aload #29
    //   2382: iconst_1
    //   2383: aaload
    //   2384: astore #33
    //   2386: aload #32
    //   2388: getfield mTop : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2391: astore #35
    //   2393: aload #32
    //   2395: getfield mBottom : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2398: astore #36
    //   2400: aload #32
    //   2402: getfield mY : I
    //   2405: istore #7
    //   2407: aload #32
    //   2409: getfield mMinHeight : I
    //   2412: istore #8
    //   2414: aload #32
    //   2416: getfield mMaxDimension : [I
    //   2419: iconst_1
    //   2420: iaload
    //   2421: istore #9
    //   2423: aload #32
    //   2425: getfield mVerticalBiasPercent : F
    //   2428: fstore_3
    //   2429: aload #29
    //   2431: iconst_0
    //   2432: aaload
    //   2433: aload #34
    //   2435: if_acmpne -> 2444
    //   2438: iconst_1
    //   2439: istore #18
    //   2441: goto -> 2447
    //   2444: iconst_0
    //   2445: istore #18
    //   2447: aload_0
    //   2448: aload_1
    //   2449: iconst_0
    //   2450: iload #19
    //   2452: iload #15
    //   2454: iload #20
    //   2456: aload #28
    //   2458: aload #27
    //   2460: aload #33
    //   2462: iload_2
    //   2463: aload #35
    //   2465: aload #36
    //   2467: iload #7
    //   2469: iload #4
    //   2471: iload #8
    //   2473: iload #9
    //   2475: fload_3
    //   2476: iload #17
    //   2478: iload #18
    //   2480: iload #14
    //   2482: iload #16
    //   2484: iload #22
    //   2486: iload #5
    //   2488: iload #6
    //   2490: aload #32
    //   2492: getfield mMatchConstraintMinHeight : I
    //   2495: aload #32
    //   2497: getfield mMatchConstraintMaxHeight : I
    //   2500: aload #32
    //   2502: getfield mMatchConstraintPercentHeight : F
    //   2505: iload #13
    //   2507: invokespecial applyConstraints : (Landroidx/constraintlayout/solver/LinearSystem;ZZZZLandroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;ZLandroidx/constraintlayout/solver/widgets/ConstraintAnchor;Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;IIIIFZZZZZIIIIFZ)V
    //   2510: goto -> 2513
    //   2513: iload #12
    //   2515: ifeq -> 2574
    //   2518: aload_0
    //   2519: astore #27
    //   2521: aload #27
    //   2523: getfield mResolvedDimensionRatioSide : I
    //   2526: iconst_1
    //   2527: if_icmpne -> 2552
    //   2530: aload_1
    //   2531: aload #25
    //   2533: aload #26
    //   2535: aload #31
    //   2537: aload #30
    //   2539: aload #27
    //   2541: getfield mResolvedDimensionRatio : F
    //   2544: bipush #8
    //   2546: invokevirtual addRatio : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;FI)V
    //   2549: goto -> 2574
    //   2552: aload_1
    //   2553: aload #31
    //   2555: aload #30
    //   2557: aload #25
    //   2559: aload #26
    //   2561: aload #27
    //   2563: getfield mResolvedDimensionRatio : F
    //   2566: bipush #8
    //   2568: invokevirtual addRatio : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;FI)V
    //   2571: goto -> 2574
    //   2574: aload_0
    //   2575: astore #25
    //   2577: aload #25
    //   2579: getfield mCenter : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2582: invokevirtual isConnected : ()Z
    //   2585: ifeq -> 2627
    //   2588: aload_1
    //   2589: aload #25
    //   2591: aload #25
    //   2593: getfield mCenter : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2596: invokevirtual getTarget : ()Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2599: invokevirtual getOwner : ()Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   2602: aload #25
    //   2604: getfield mCircleConstraintAngle : F
    //   2607: ldc_w 90.0
    //   2610: fadd
    //   2611: f2d
    //   2612: invokestatic toRadians : (D)D
    //   2615: d2f
    //   2616: aload #25
    //   2618: getfield mCenter : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2621: invokevirtual getMargin : ()I
    //   2624: invokevirtual addCenterPoint : (Landroidx/constraintlayout/solver/widgets/ConstraintWidget;Landroidx/constraintlayout/solver/widgets/ConstraintWidget;FI)V
    //   2627: aload #25
    //   2629: iconst_0
    //   2630: putfield resolvedHorizontal : Z
    //   2633: aload #25
    //   2635: iconst_0
    //   2636: putfield resolvedVertical : Z
    //   2639: return
  }
  
  public boolean allowedInBarrier() {
    return (this.mVisibility != 8);
  }
  
  public void connect(ConstraintAnchor.Type paramType1, ConstraintWidget paramConstraintWidget, ConstraintAnchor.Type paramType2) {
    connect(paramType1, paramConstraintWidget, paramType2, 0);
  }
  
  public void connect(ConstraintAnchor.Type paramType1, ConstraintWidget paramConstraintWidget, ConstraintAnchor.Type paramType2, int paramInt) {
    // Byte code:
    //   0: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.CENTER : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   3: astore #6
    //   5: aload_1
    //   6: aload #6
    //   8: if_acmpne -> 357
    //   11: aload_3
    //   12: aload #6
    //   14: if_acmpne -> 250
    //   17: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.LEFT : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   20: astore_1
    //   21: aload_0
    //   22: aload_1
    //   23: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   26: astore_3
    //   27: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.RIGHT : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   30: astore #7
    //   32: aload_0
    //   33: aload #7
    //   35: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   38: astore #8
    //   40: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.TOP : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   43: astore #9
    //   45: aload_0
    //   46: aload #9
    //   48: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   51: astore #10
    //   53: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.BOTTOM : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   56: astore #11
    //   58: aload_0
    //   59: aload #11
    //   61: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   64: astore #12
    //   66: iconst_1
    //   67: istore #5
    //   69: aload_3
    //   70: ifnull -> 80
    //   73: aload_3
    //   74: invokevirtual isConnected : ()Z
    //   77: ifne -> 93
    //   80: aload #8
    //   82: ifnull -> 99
    //   85: aload #8
    //   87: invokevirtual isConnected : ()Z
    //   90: ifeq -> 99
    //   93: iconst_0
    //   94: istore #4
    //   96: goto -> 120
    //   99: aload_0
    //   100: aload_1
    //   101: aload_2
    //   102: aload_1
    //   103: iconst_0
    //   104: invokevirtual connect : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;Landroidx/constraintlayout/solver/widgets/ConstraintWidget;Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;I)V
    //   107: aload_0
    //   108: aload #7
    //   110: aload_2
    //   111: aload #7
    //   113: iconst_0
    //   114: invokevirtual connect : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;Landroidx/constraintlayout/solver/widgets/ConstraintWidget;Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;I)V
    //   117: iconst_1
    //   118: istore #4
    //   120: aload #10
    //   122: ifnull -> 133
    //   125: aload #10
    //   127: invokevirtual isConnected : ()Z
    //   130: ifne -> 146
    //   133: aload #12
    //   135: ifnull -> 152
    //   138: aload #12
    //   140: invokevirtual isConnected : ()Z
    //   143: ifeq -> 152
    //   146: iconst_0
    //   147: istore #5
    //   149: goto -> 172
    //   152: aload_0
    //   153: aload #9
    //   155: aload_2
    //   156: aload #9
    //   158: iconst_0
    //   159: invokevirtual connect : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;Landroidx/constraintlayout/solver/widgets/ConstraintWidget;Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;I)V
    //   162: aload_0
    //   163: aload #11
    //   165: aload_2
    //   166: aload #11
    //   168: iconst_0
    //   169: invokevirtual connect : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;Landroidx/constraintlayout/solver/widgets/ConstraintWidget;Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;I)V
    //   172: iload #4
    //   174: ifeq -> 200
    //   177: iload #5
    //   179: ifeq -> 200
    //   182: aload_0
    //   183: aload #6
    //   185: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   188: aload_2
    //   189: aload #6
    //   191: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   194: iconst_0
    //   195: invokevirtual connect : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;I)Z
    //   198: pop
    //   199: return
    //   200: iload #4
    //   202: ifeq -> 225
    //   205: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.CENTER_X : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   208: astore_1
    //   209: aload_0
    //   210: aload_1
    //   211: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   214: aload_2
    //   215: aload_1
    //   216: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   219: iconst_0
    //   220: invokevirtual connect : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;I)Z
    //   223: pop
    //   224: return
    //   225: iload #5
    //   227: ifeq -> 887
    //   230: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.CENTER_Y : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   233: astore_1
    //   234: aload_0
    //   235: aload_1
    //   236: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   239: aload_2
    //   240: aload_1
    //   241: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   244: iconst_0
    //   245: invokevirtual connect : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;I)Z
    //   248: pop
    //   249: return
    //   250: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.LEFT : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   253: astore_1
    //   254: aload_3
    //   255: aload_1
    //   256: if_acmpeq -> 320
    //   259: aload_3
    //   260: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.RIGHT : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   263: if_acmpne -> 269
    //   266: goto -> 320
    //   269: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.TOP : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   272: astore_1
    //   273: aload_3
    //   274: aload_1
    //   275: if_acmpeq -> 285
    //   278: aload_3
    //   279: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.BOTTOM : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   282: if_acmpne -> 887
    //   285: aload_0
    //   286: aload_1
    //   287: aload_2
    //   288: aload_3
    //   289: iconst_0
    //   290: invokevirtual connect : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;Landroidx/constraintlayout/solver/widgets/ConstraintWidget;Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;I)V
    //   293: aload_0
    //   294: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.BOTTOM : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   297: aload_2
    //   298: aload_3
    //   299: iconst_0
    //   300: invokevirtual connect : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;Landroidx/constraintlayout/solver/widgets/ConstraintWidget;Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;I)V
    //   303: aload_0
    //   304: aload #6
    //   306: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   309: aload_2
    //   310: aload_3
    //   311: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   314: iconst_0
    //   315: invokevirtual connect : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;I)Z
    //   318: pop
    //   319: return
    //   320: aload_0
    //   321: aload_1
    //   322: aload_2
    //   323: aload_3
    //   324: iconst_0
    //   325: invokevirtual connect : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;Landroidx/constraintlayout/solver/widgets/ConstraintWidget;Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;I)V
    //   328: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.RIGHT : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   331: astore_1
    //   332: aload_0
    //   333: aload_1
    //   334: aload_2
    //   335: aload_3
    //   336: iconst_0
    //   337: invokevirtual connect : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;Landroidx/constraintlayout/solver/widgets/ConstraintWidget;Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;I)V
    //   340: aload_0
    //   341: aload #6
    //   343: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   346: aload_2
    //   347: aload_3
    //   348: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   351: iconst_0
    //   352: invokevirtual connect : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;I)Z
    //   355: pop
    //   356: return
    //   357: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.CENTER_X : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   360: astore #7
    //   362: aload_1
    //   363: aload #7
    //   365: if_acmpne -> 434
    //   368: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.LEFT : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   371: astore #8
    //   373: aload_3
    //   374: aload #8
    //   376: if_acmpeq -> 386
    //   379: aload_3
    //   380: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.RIGHT : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   383: if_acmpne -> 434
    //   386: aload_0
    //   387: aload #8
    //   389: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   392: astore_1
    //   393: aload_2
    //   394: aload_3
    //   395: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   398: astore_2
    //   399: aload_0
    //   400: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.RIGHT : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   403: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   406: astore_3
    //   407: aload_1
    //   408: aload_2
    //   409: iconst_0
    //   410: invokevirtual connect : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;I)Z
    //   413: pop
    //   414: aload_3
    //   415: aload_2
    //   416: iconst_0
    //   417: invokevirtual connect : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;I)Z
    //   420: pop
    //   421: aload_0
    //   422: aload #7
    //   424: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   427: aload_2
    //   428: iconst_0
    //   429: invokevirtual connect : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;I)Z
    //   432: pop
    //   433: return
    //   434: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.CENTER_Y : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   437: astore #9
    //   439: aload_1
    //   440: aload #9
    //   442: if_acmpne -> 507
    //   445: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.TOP : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   448: astore #8
    //   450: aload_3
    //   451: aload #8
    //   453: if_acmpeq -> 463
    //   456: aload_3
    //   457: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.BOTTOM : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   460: if_acmpne -> 507
    //   463: aload_2
    //   464: aload_3
    //   465: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   468: astore_1
    //   469: aload_0
    //   470: aload #8
    //   472: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   475: aload_1
    //   476: iconst_0
    //   477: invokevirtual connect : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;I)Z
    //   480: pop
    //   481: aload_0
    //   482: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.BOTTOM : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   485: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   488: aload_1
    //   489: iconst_0
    //   490: invokevirtual connect : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;I)Z
    //   493: pop
    //   494: aload_0
    //   495: aload #9
    //   497: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   500: aload_1
    //   501: iconst_0
    //   502: invokevirtual connect : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;I)Z
    //   505: pop
    //   506: return
    //   507: aload_1
    //   508: aload #7
    //   510: if_acmpne -> 574
    //   513: aload_3
    //   514: aload #7
    //   516: if_acmpne -> 574
    //   519: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.LEFT : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   522: astore_1
    //   523: aload_0
    //   524: aload_1
    //   525: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   528: aload_2
    //   529: aload_1
    //   530: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   533: iconst_0
    //   534: invokevirtual connect : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;I)Z
    //   537: pop
    //   538: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.RIGHT : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   541: astore_1
    //   542: aload_0
    //   543: aload_1
    //   544: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   547: aload_2
    //   548: aload_1
    //   549: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   552: iconst_0
    //   553: invokevirtual connect : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;I)Z
    //   556: pop
    //   557: aload_0
    //   558: aload #7
    //   560: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   563: aload_2
    //   564: aload_3
    //   565: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   568: iconst_0
    //   569: invokevirtual connect : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;I)Z
    //   572: pop
    //   573: return
    //   574: aload_1
    //   575: aload #9
    //   577: if_acmpne -> 641
    //   580: aload_3
    //   581: aload #9
    //   583: if_acmpne -> 641
    //   586: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.TOP : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   589: astore_1
    //   590: aload_0
    //   591: aload_1
    //   592: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   595: aload_2
    //   596: aload_1
    //   597: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   600: iconst_0
    //   601: invokevirtual connect : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;I)Z
    //   604: pop
    //   605: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.BOTTOM : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   608: astore_1
    //   609: aload_0
    //   610: aload_1
    //   611: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   614: aload_2
    //   615: aload_1
    //   616: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   619: iconst_0
    //   620: invokevirtual connect : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;I)Z
    //   623: pop
    //   624: aload_0
    //   625: aload #9
    //   627: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   630: aload_2
    //   631: aload_3
    //   632: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   635: iconst_0
    //   636: invokevirtual connect : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;I)Z
    //   639: pop
    //   640: return
    //   641: aload_0
    //   642: aload_1
    //   643: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   646: astore #8
    //   648: aload_2
    //   649: aload_3
    //   650: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   653: astore_2
    //   654: aload #8
    //   656: aload_2
    //   657: invokevirtual isValidConnection : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;)Z
    //   660: ifeq -> 887
    //   663: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.BASELINE : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   666: astore_3
    //   667: aload_1
    //   668: aload_3
    //   669: if_acmpne -> 710
    //   672: aload_0
    //   673: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.TOP : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   676: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   679: astore_1
    //   680: aload_0
    //   681: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.BOTTOM : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   684: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   687: astore_3
    //   688: aload_1
    //   689: ifnull -> 696
    //   692: aload_1
    //   693: invokevirtual reset : ()V
    //   696: aload_3
    //   697: ifnull -> 704
    //   700: aload_3
    //   701: invokevirtual reset : ()V
    //   704: iconst_0
    //   705: istore #5
    //   707: goto -> 878
    //   710: aload_1
    //   711: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.TOP : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   714: if_acmpeq -> 806
    //   717: aload_1
    //   718: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.BOTTOM : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   721: if_acmpne -> 727
    //   724: goto -> 806
    //   727: aload_1
    //   728: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.LEFT : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   731: if_acmpeq -> 745
    //   734: iload #4
    //   736: istore #5
    //   738: aload_1
    //   739: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.RIGHT : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   742: if_acmpne -> 878
    //   745: aload_0
    //   746: aload #6
    //   748: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   751: astore_3
    //   752: aload_3
    //   753: invokevirtual getTarget : ()Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   756: aload_2
    //   757: if_acmpeq -> 764
    //   760: aload_3
    //   761: invokevirtual reset : ()V
    //   764: aload_0
    //   765: aload_1
    //   766: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   769: invokevirtual getOpposite : ()Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   772: astore_1
    //   773: aload_0
    //   774: aload #7
    //   776: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   779: astore_3
    //   780: iload #4
    //   782: istore #5
    //   784: aload_3
    //   785: invokevirtual isConnected : ()Z
    //   788: ifeq -> 878
    //   791: aload_1
    //   792: invokevirtual reset : ()V
    //   795: aload_3
    //   796: invokevirtual reset : ()V
    //   799: iload #4
    //   801: istore #5
    //   803: goto -> 878
    //   806: aload_0
    //   807: aload_3
    //   808: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   811: astore_3
    //   812: aload_3
    //   813: ifnull -> 820
    //   816: aload_3
    //   817: invokevirtual reset : ()V
    //   820: aload_0
    //   821: aload #6
    //   823: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   826: astore_3
    //   827: aload_3
    //   828: invokevirtual getTarget : ()Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   831: aload_2
    //   832: if_acmpeq -> 839
    //   835: aload_3
    //   836: invokevirtual reset : ()V
    //   839: aload_0
    //   840: aload_1
    //   841: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   844: invokevirtual getOpposite : ()Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   847: astore_1
    //   848: aload_0
    //   849: aload #9
    //   851: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   854: astore_3
    //   855: iload #4
    //   857: istore #5
    //   859: aload_3
    //   860: invokevirtual isConnected : ()Z
    //   863: ifeq -> 878
    //   866: aload_1
    //   867: invokevirtual reset : ()V
    //   870: aload_3
    //   871: invokevirtual reset : ()V
    //   874: iload #4
    //   876: istore #5
    //   878: aload #8
    //   880: aload_2
    //   881: iload #5
    //   883: invokevirtual connect : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;I)Z
    //   886: pop
    //   887: return
    //   888: astore_1
    //   889: aload_1
    //   890: athrow
    // Exception table:
    //   from	to	target	type
    //   332	340	888	finally
  }
  
  public void connect(ConstraintAnchor paramConstraintAnchor1, ConstraintAnchor paramConstraintAnchor2, int paramInt) {
    if (paramConstraintAnchor1.getOwner() == this)
      connect(paramConstraintAnchor1.getType(), paramConstraintAnchor2.getOwner(), paramConstraintAnchor2.getType(), paramInt); 
  }
  
  public void connectCircularConstraint(ConstraintWidget paramConstraintWidget, float paramFloat, int paramInt) {
    ConstraintAnchor.Type type = ConstraintAnchor.Type.CENTER;
    immediateConnect(type, paramConstraintWidget, type, paramInt, 0);
    this.mCircleConstraintAngle = paramFloat;
  }
  
  public void copy(ConstraintWidget paramConstraintWidget, HashMap<ConstraintWidget, ConstraintWidget> paramHashMap) {
    int[] arrayOfInt1;
    ConstraintWidget constraintWidget1;
    this.mHorizontalResolution = paramConstraintWidget.mHorizontalResolution;
    this.mVerticalResolution = paramConstraintWidget.mVerticalResolution;
    this.mMatchConstraintDefaultWidth = paramConstraintWidget.mMatchConstraintDefaultWidth;
    this.mMatchConstraintDefaultHeight = paramConstraintWidget.mMatchConstraintDefaultHeight;
    int[] arrayOfInt2 = this.mResolvedMatchConstraintDefault;
    int[] arrayOfInt3 = paramConstraintWidget.mResolvedMatchConstraintDefault;
    arrayOfInt2[0] = arrayOfInt3[0];
    arrayOfInt2[1] = arrayOfInt3[1];
    this.mMatchConstraintMinWidth = paramConstraintWidget.mMatchConstraintMinWidth;
    this.mMatchConstraintMaxWidth = paramConstraintWidget.mMatchConstraintMaxWidth;
    this.mMatchConstraintMinHeight = paramConstraintWidget.mMatchConstraintMinHeight;
    this.mMatchConstraintMaxHeight = paramConstraintWidget.mMatchConstraintMaxHeight;
    this.mMatchConstraintPercentHeight = paramConstraintWidget.mMatchConstraintPercentHeight;
    this.mIsWidthWrapContent = paramConstraintWidget.mIsWidthWrapContent;
    this.mIsHeightWrapContent = paramConstraintWidget.mIsHeightWrapContent;
    this.mResolvedDimensionRatioSide = paramConstraintWidget.mResolvedDimensionRatioSide;
    this.mResolvedDimensionRatio = paramConstraintWidget.mResolvedDimensionRatio;
    arrayOfInt2 = paramConstraintWidget.mMaxDimension;
    this.mMaxDimension = Arrays.copyOf(arrayOfInt2, arrayOfInt2.length);
    this.mCircleConstraintAngle = paramConstraintWidget.mCircleConstraintAngle;
    this.hasBaseline = paramConstraintWidget.hasBaseline;
    this.inPlaceholder = paramConstraintWidget.inPlaceholder;
    this.mLeft.reset();
    this.mTop.reset();
    this.mRight.reset();
    this.mBottom.reset();
    this.mBaseline.reset();
    this.mCenterX.reset();
    this.mCenterY.reset();
    this.mCenter.reset();
    this.mListDimensionBehaviors = Arrays.<DimensionBehaviour>copyOf(this.mListDimensionBehaviors, 2);
    ConstraintWidget constraintWidget3 = this.mParent;
    arrayOfInt3 = null;
    if (constraintWidget3 == null) {
      constraintWidget3 = null;
    } else {
      constraintWidget3 = paramHashMap.get(paramConstraintWidget.mParent);
    } 
    this.mParent = constraintWidget3;
    this.mWidth = paramConstraintWidget.mWidth;
    this.mHeight = paramConstraintWidget.mHeight;
    this.mDimensionRatio = paramConstraintWidget.mDimensionRatio;
    this.mDimensionRatioSide = paramConstraintWidget.mDimensionRatioSide;
    this.mX = paramConstraintWidget.mX;
    this.mY = paramConstraintWidget.mY;
    this.mRelX = paramConstraintWidget.mRelX;
    this.mRelY = paramConstraintWidget.mRelY;
    this.mOffsetX = paramConstraintWidget.mOffsetX;
    this.mOffsetY = paramConstraintWidget.mOffsetY;
    this.mBaselineDistance = paramConstraintWidget.mBaselineDistance;
    this.mMinWidth = paramConstraintWidget.mMinWidth;
    this.mMinHeight = paramConstraintWidget.mMinHeight;
    this.mHorizontalBiasPercent = paramConstraintWidget.mHorizontalBiasPercent;
    this.mVerticalBiasPercent = paramConstraintWidget.mVerticalBiasPercent;
    this.mCompanionWidget = paramConstraintWidget.mCompanionWidget;
    this.mContainerItemSkip = paramConstraintWidget.mContainerItemSkip;
    this.mVisibility = paramConstraintWidget.mVisibility;
    this.mDebugName = paramConstraintWidget.mDebugName;
    this.mType = paramConstraintWidget.mType;
    this.mDistToTop = paramConstraintWidget.mDistToTop;
    this.mDistToLeft = paramConstraintWidget.mDistToLeft;
    this.mDistToRight = paramConstraintWidget.mDistToRight;
    this.mDistToBottom = paramConstraintWidget.mDistToBottom;
    this.mLeftHasCentered = paramConstraintWidget.mLeftHasCentered;
    this.mRightHasCentered = paramConstraintWidget.mRightHasCentered;
    this.mTopHasCentered = paramConstraintWidget.mTopHasCentered;
    this.mBottomHasCentered = paramConstraintWidget.mBottomHasCentered;
    this.mHorizontalWrapVisited = paramConstraintWidget.mHorizontalWrapVisited;
    this.mVerticalWrapVisited = paramConstraintWidget.mVerticalWrapVisited;
    this.mHorizontalChainStyle = paramConstraintWidget.mHorizontalChainStyle;
    this.mVerticalChainStyle = paramConstraintWidget.mVerticalChainStyle;
    this.mHorizontalChainFixedPosition = paramConstraintWidget.mHorizontalChainFixedPosition;
    this.mVerticalChainFixedPosition = paramConstraintWidget.mVerticalChainFixedPosition;
    float[] arrayOfFloat1 = this.mWeight;
    float[] arrayOfFloat2 = paramConstraintWidget.mWeight;
    arrayOfFloat1[0] = arrayOfFloat2[0];
    arrayOfFloat1[1] = arrayOfFloat2[1];
    ConstraintWidget[] arrayOfConstraintWidget1 = this.mListNextMatchConstraintsWidget;
    ConstraintWidget[] arrayOfConstraintWidget2 = paramConstraintWidget.mListNextMatchConstraintsWidget;
    arrayOfConstraintWidget1[0] = arrayOfConstraintWidget2[0];
    arrayOfConstraintWidget1[1] = arrayOfConstraintWidget2[1];
    arrayOfConstraintWidget1 = this.mNextChainWidget;
    arrayOfConstraintWidget2 = paramConstraintWidget.mNextChainWidget;
    arrayOfConstraintWidget1[0] = arrayOfConstraintWidget2[0];
    arrayOfConstraintWidget1[1] = arrayOfConstraintWidget2[1];
    ConstraintWidget constraintWidget2 = paramConstraintWidget.mHorizontalNextWidget;
    if (constraintWidget2 == null) {
      constraintWidget2 = null;
    } else {
      constraintWidget2 = paramHashMap.get(constraintWidget2);
    } 
    this.mHorizontalNextWidget = constraintWidget2;
    paramConstraintWidget = paramConstraintWidget.mVerticalNextWidget;
    if (paramConstraintWidget == null) {
      arrayOfInt1 = arrayOfInt3;
    } else {
      constraintWidget1 = paramHashMap.get(arrayOfInt1);
    } 
    this.mVerticalNextWidget = constraintWidget1;
  }
  
  public void createObjectVariables(LinearSystem paramLinearSystem) {
    paramLinearSystem.createObjectVariable(this.mLeft);
    paramLinearSystem.createObjectVariable(this.mTop);
    paramLinearSystem.createObjectVariable(this.mRight);
    paramLinearSystem.createObjectVariable(this.mBottom);
    if (this.mBaselineDistance > 0)
      paramLinearSystem.createObjectVariable(this.mBaseline); 
  }
  
  public void ensureMeasureRequested() {
    this.mMeasureRequested = true;
  }
  
  public void ensureWidgetRuns() {
    if (this.horizontalRun == null)
      this.horizontalRun = new HorizontalWidgetRun(this); 
    if (this.verticalRun == null)
      this.verticalRun = new VerticalWidgetRun(this); 
  }
  
  public ConstraintAnchor getAnchor(ConstraintAnchor.Type paramType) {
    switch (paramType) {
      default:
        throw new AssertionError(paramType.name());
      case null:
        return null;
      case null:
        return this.mCenterY;
      case null:
        return this.mCenterX;
      case null:
        return this.mCenter;
      case null:
        return this.mBaseline;
      case null:
        return this.mBottom;
      case null:
        return this.mRight;
      case null:
        return this.mTop;
      case null:
        break;
    } 
    return this.mLeft;
  }
  
  public ArrayList<ConstraintAnchor> getAnchors() {
    return this.mAnchors;
  }
  
  public int getBaselineDistance() {
    return this.mBaselineDistance;
  }
  
  public float getBiasPercent(int paramInt) {
    return (paramInt == 0) ? this.mHorizontalBiasPercent : ((paramInt == 1) ? this.mVerticalBiasPercent : -1.0F);
  }
  
  public int getBottom() {
    return getY() + this.mHeight;
  }
  
  public Object getCompanionWidget() {
    return this.mCompanionWidget;
  }
  
  public int getContainerItemSkip() {
    return this.mContainerItemSkip;
  }
  
  public String getDebugName() {
    return this.mDebugName;
  }
  
  public DimensionBehaviour getDimensionBehaviour(int paramInt) {
    return (paramInt == 0) ? getHorizontalDimensionBehaviour() : ((paramInt == 1) ? getVerticalDimensionBehaviour() : null);
  }
  
  public float getDimensionRatio() {
    return this.mDimensionRatio;
  }
  
  public int getDimensionRatioSide() {
    return this.mDimensionRatioSide;
  }
  
  public boolean getHasBaseline() {
    return this.hasBaseline;
  }
  
  public int getHeight() {
    return (this.mVisibility == 8) ? 0 : this.mHeight;
  }
  
  public float getHorizontalBiasPercent() {
    return this.mHorizontalBiasPercent;
  }
  
  public ConstraintWidget getHorizontalChainControlWidget() {
    boolean bool = isInHorizontalChain();
    ConstraintWidget constraintWidget = null;
    if (bool) {
      ConstraintWidget constraintWidget1 = this;
      constraintWidget = null;
      while (constraintWidget == null && constraintWidget1 != null) {
        ConstraintWidget constraintWidget2;
        ConstraintAnchor constraintAnchor2;
        ConstraintAnchor constraintAnchor1 = constraintWidget1.getAnchor(ConstraintAnchor.Type.LEFT);
        if (constraintAnchor1 == null) {
          constraintAnchor1 = null;
        } else {
          constraintAnchor1 = constraintAnchor1.getTarget();
        } 
        if (constraintAnchor1 == null) {
          constraintAnchor1 = null;
        } else {
          constraintWidget2 = constraintAnchor1.getOwner();
        } 
        if (constraintWidget2 == getParent())
          return constraintWidget1; 
        if (constraintWidget2 == null) {
          constraintAnchor2 = null;
        } else {
          constraintAnchor2 = constraintWidget2.getAnchor(ConstraintAnchor.Type.RIGHT).getTarget();
        } 
        if (constraintAnchor2 != null && constraintAnchor2.getOwner() != constraintWidget1) {
          constraintWidget = constraintWidget1;
          continue;
        } 
        constraintWidget1 = constraintWidget2;
      } 
    } 
    return constraintWidget;
  }
  
  public int getHorizontalChainStyle() {
    return this.mHorizontalChainStyle;
  }
  
  public DimensionBehaviour getHorizontalDimensionBehaviour() {
    return this.mListDimensionBehaviors[0];
  }
  
  public int getHorizontalMargin() {
    ConstraintAnchor constraintAnchor = this.mLeft;
    int i = 0;
    if (constraintAnchor != null)
      i = 0 + constraintAnchor.mMargin; 
    constraintAnchor = this.mRight;
    int j = i;
    if (constraintAnchor != null)
      j = i + constraintAnchor.mMargin; 
    return j;
  }
  
  public int getLastHorizontalMeasureSpec() {
    return this.mLastHorizontalMeasureSpec;
  }
  
  public int getLastVerticalMeasureSpec() {
    return this.mLastVerticalMeasureSpec;
  }
  
  public int getLeft() {
    return getX();
  }
  
  public int getLength(int paramInt) {
    return (paramInt == 0) ? getWidth() : ((paramInt == 1) ? getHeight() : 0);
  }
  
  public int getMaxHeight() {
    return this.mMaxDimension[1];
  }
  
  public int getMaxWidth() {
    return this.mMaxDimension[0];
  }
  
  public int getMinHeight() {
    return this.mMinHeight;
  }
  
  public int getMinWidth() {
    return this.mMinWidth;
  }
  
  public ConstraintWidget getNextChainMember(int paramInt) {
    if (paramInt == 0) {
      ConstraintAnchor constraintAnchor1 = this.mRight;
      ConstraintAnchor constraintAnchor2 = constraintAnchor1.mTarget;
      if (constraintAnchor2 != null && constraintAnchor2.mTarget == constraintAnchor1)
        return constraintAnchor2.mOwner; 
    } else if (paramInt == 1) {
      ConstraintAnchor constraintAnchor1 = this.mBottom;
      ConstraintAnchor constraintAnchor2 = constraintAnchor1.mTarget;
      if (constraintAnchor2 != null && constraintAnchor2.mTarget == constraintAnchor1)
        return constraintAnchor2.mOwner; 
    } 
    return null;
  }
  
  public int getOptimizerWrapHeight() {
    int i = this.mHeight;
    int j = i;
    if (this.mListDimensionBehaviors[1] == DimensionBehaviour.MATCH_CONSTRAINT) {
      if (this.mMatchConstraintDefaultHeight == 1) {
        i = Math.max(this.mMatchConstraintMinHeight, i);
      } else {
        i = this.mMatchConstraintMinHeight;
        if (i > 0) {
          this.mHeight = i;
        } else {
          i = 0;
        } 
      } 
      int k = this.mMatchConstraintMaxHeight;
      j = i;
      if (k > 0) {
        j = i;
        if (k < i)
          j = k; 
      } 
    } 
    return j;
  }
  
  public int getOptimizerWrapWidth() {
    int i = this.mWidth;
    int j = i;
    if (this.mListDimensionBehaviors[0] == DimensionBehaviour.MATCH_CONSTRAINT) {
      if (this.mMatchConstraintDefaultWidth == 1) {
        i = Math.max(this.mMatchConstraintMinWidth, i);
      } else {
        i = this.mMatchConstraintMinWidth;
        if (i > 0) {
          this.mWidth = i;
        } else {
          i = 0;
        } 
      } 
      int k = this.mMatchConstraintMaxWidth;
      j = i;
      if (k > 0) {
        j = i;
        if (k < i)
          j = k; 
      } 
    } 
    return j;
  }
  
  public ConstraintWidget getParent() {
    return this.mParent;
  }
  
  public ConstraintWidget getPreviousChainMember(int paramInt) {
    if (paramInt == 0) {
      ConstraintAnchor constraintAnchor1 = this.mLeft;
      ConstraintAnchor constraintAnchor2 = constraintAnchor1.mTarget;
      if (constraintAnchor2 != null && constraintAnchor2.mTarget == constraintAnchor1)
        return constraintAnchor2.mOwner; 
    } else if (paramInt == 1) {
      ConstraintAnchor constraintAnchor1 = this.mTop;
      ConstraintAnchor constraintAnchor2 = constraintAnchor1.mTarget;
      if (constraintAnchor2 != null && constraintAnchor2.mTarget == constraintAnchor1)
        return constraintAnchor2.mOwner; 
    } 
    return null;
  }
  
  int getRelativePositioning(int paramInt) {
    return (paramInt == 0) ? this.mRelX : ((paramInt == 1) ? this.mRelY : 0);
  }
  
  public int getRight() {
    return getX() + this.mWidth;
  }
  
  protected int getRootX() {
    return this.mX + this.mOffsetX;
  }
  
  protected int getRootY() {
    return this.mY + this.mOffsetY;
  }
  
  public WidgetRun getRun(int paramInt) {
    return (WidgetRun)((paramInt == 0) ? this.horizontalRun : ((paramInt == 1) ? this.verticalRun : null));
  }
  
  public int getTop() {
    return getY();
  }
  
  public String getType() {
    return this.mType;
  }
  
  public float getVerticalBiasPercent() {
    return this.mVerticalBiasPercent;
  }
  
  public ConstraintWidget getVerticalChainControlWidget() {
    boolean bool = isInVerticalChain();
    ConstraintWidget constraintWidget = null;
    if (bool) {
      ConstraintWidget constraintWidget1 = this;
      constraintWidget = null;
      while (constraintWidget == null && constraintWidget1 != null) {
        ConstraintWidget constraintWidget2;
        ConstraintAnchor constraintAnchor2;
        ConstraintAnchor constraintAnchor1 = constraintWidget1.getAnchor(ConstraintAnchor.Type.TOP);
        if (constraintAnchor1 == null) {
          constraintAnchor1 = null;
        } else {
          constraintAnchor1 = constraintAnchor1.getTarget();
        } 
        if (constraintAnchor1 == null) {
          constraintAnchor1 = null;
        } else {
          constraintWidget2 = constraintAnchor1.getOwner();
        } 
        if (constraintWidget2 == getParent())
          return constraintWidget1; 
        if (constraintWidget2 == null) {
          constraintAnchor2 = null;
        } else {
          constraintAnchor2 = constraintWidget2.getAnchor(ConstraintAnchor.Type.BOTTOM).getTarget();
        } 
        if (constraintAnchor2 != null && constraintAnchor2.getOwner() != constraintWidget1) {
          constraintWidget = constraintWidget1;
          continue;
        } 
        constraintWidget1 = constraintWidget2;
      } 
    } 
    return constraintWidget;
  }
  
  public int getVerticalChainStyle() {
    return this.mVerticalChainStyle;
  }
  
  public DimensionBehaviour getVerticalDimensionBehaviour() {
    return this.mListDimensionBehaviors[1];
  }
  
  public int getVerticalMargin() {
    ConstraintAnchor constraintAnchor = this.mLeft;
    int i = 0;
    if (constraintAnchor != null)
      i = 0 + this.mTop.mMargin; 
    int j = i;
    if (this.mRight != null)
      j = i + this.mBottom.mMargin; 
    return j;
  }
  
  public int getVisibility() {
    return this.mVisibility;
  }
  
  public int getWidth() {
    return (this.mVisibility == 8) ? 0 : this.mWidth;
  }
  
  public int getX() {
    ConstraintWidget constraintWidget = this.mParent;
    return (constraintWidget != null && constraintWidget instanceof ConstraintWidgetContainer) ? (((ConstraintWidgetContainer)constraintWidget).mPaddingLeft + this.mX) : this.mX;
  }
  
  public int getY() {
    ConstraintWidget constraintWidget = this.mParent;
    return (constraintWidget != null && constraintWidget instanceof ConstraintWidgetContainer) ? (((ConstraintWidgetContainer)constraintWidget).mPaddingTop + this.mY) : this.mY;
  }
  
  public boolean hasBaseline() {
    return this.hasBaseline;
  }
  
  public boolean hasDanglingDimension(int paramInt) {
    byte b1;
    byte b2;
    if (paramInt == 0) {
      if (this.mLeft.mTarget != null) {
        paramInt = 1;
      } else {
        paramInt = 0;
      } 
      if (this.mRight.mTarget != null) {
        b1 = 1;
      } else {
        b1 = 0;
      } 
      return (paramInt + b1 < 2);
    } 
    if (this.mTop.mTarget != null) {
      paramInt = 1;
    } else {
      paramInt = 0;
    } 
    if (this.mBottom.mTarget != null) {
      b1 = 1;
    } else {
      b1 = 0;
    } 
    if (this.mBaseline.mTarget != null) {
      b2 = 1;
    } else {
      b2 = 0;
    } 
    return (paramInt + b1 + b2 < 2);
  }
  
  public boolean hasDependencies() {
    int j = this.mAnchors.size();
    for (int i = 0; i < j; i++) {
      if (((ConstraintAnchor)this.mAnchors.get(i)).hasDependents())
        return true; 
    } 
    return false;
  }
  
  public void immediateConnect(ConstraintAnchor.Type paramType1, ConstraintWidget paramConstraintWidget, ConstraintAnchor.Type paramType2, int paramInt1, int paramInt2) {
    getAnchor(paramType1).connect(paramConstraintWidget.getAnchor(paramType2), paramInt1, paramInt2, true);
  }
  
  public boolean isHeightWrapContent() {
    return this.mIsHeightWrapContent;
  }
  
  public boolean isInHorizontalChain() {
    ConstraintAnchor constraintAnchor1 = this.mLeft;
    ConstraintAnchor constraintAnchor2 = constraintAnchor1.mTarget;
    if (constraintAnchor2 == null || constraintAnchor2.mTarget != constraintAnchor1) {
      constraintAnchor1 = this.mRight;
      constraintAnchor2 = constraintAnchor1.mTarget;
      if (constraintAnchor2 == null || constraintAnchor2.mTarget != constraintAnchor1)
        return false; 
    } 
    return true;
  }
  
  public boolean isInPlaceholder() {
    return this.inPlaceholder;
  }
  
  public boolean isInVerticalChain() {
    ConstraintAnchor constraintAnchor1 = this.mTop;
    ConstraintAnchor constraintAnchor2 = constraintAnchor1.mTarget;
    if (constraintAnchor2 == null || constraintAnchor2.mTarget != constraintAnchor1) {
      constraintAnchor1 = this.mBottom;
      constraintAnchor2 = constraintAnchor1.mTarget;
      if (constraintAnchor2 == null || constraintAnchor2.mTarget != constraintAnchor1)
        return false; 
    } 
    return true;
  }
  
  public boolean isInVirtualLayout() {
    return this.mInVirtuaLayout;
  }
  
  public boolean isMeasureRequested() {
    return (this.mMeasureRequested && this.mVisibility != 8);
  }
  
  public boolean isResolvedHorizontally() {
    return (this.resolvedHorizontal || (this.mLeft.hasFinalValue() && this.mRight.hasFinalValue()));
  }
  
  public boolean isResolvedVertically() {
    return (this.resolvedVertical || (this.mTop.hasFinalValue() && this.mBottom.hasFinalValue()));
  }
  
  public boolean isRoot() {
    return (this.mParent == null);
  }
  
  public boolean isSpreadHeight() {
    return (this.mMatchConstraintDefaultHeight == 0 && this.mDimensionRatio == 0.0F && this.mMatchConstraintMinHeight == 0 && this.mMatchConstraintMaxHeight == 0 && this.mListDimensionBehaviors[1] == DimensionBehaviour.MATCH_CONSTRAINT);
  }
  
  public boolean isSpreadWidth() {
    int i = this.mMatchConstraintDefaultWidth;
    boolean bool2 = false;
    boolean bool1 = bool2;
    if (i == 0) {
      bool1 = bool2;
      if (this.mDimensionRatio == 0.0F) {
        bool1 = bool2;
        if (this.mMatchConstraintMinWidth == 0) {
          bool1 = bool2;
          if (this.mMatchConstraintMaxWidth == 0) {
            bool1 = bool2;
            if (this.mListDimensionBehaviors[0] == DimensionBehaviour.MATCH_CONSTRAINT)
              bool1 = true; 
          } 
        } 
      } 
    } 
    return bool1;
  }
  
  public boolean isWidthWrapContent() {
    return this.mIsWidthWrapContent;
  }
  
  public boolean oppositeDimensionDependsOn(int paramInt) {
    boolean bool;
    if (paramInt == 0) {
      bool = true;
    } else {
      bool = false;
    } 
    DimensionBehaviour[] arrayOfDimensionBehaviour = this.mListDimensionBehaviors;
    DimensionBehaviour dimensionBehaviour1 = arrayOfDimensionBehaviour[paramInt];
    DimensionBehaviour dimensionBehaviour2 = arrayOfDimensionBehaviour[bool];
    DimensionBehaviour dimensionBehaviour3 = DimensionBehaviour.MATCH_CONSTRAINT;
    return (dimensionBehaviour1 == dimensionBehaviour3 && dimensionBehaviour2 == dimensionBehaviour3);
  }
  
  public boolean oppositeDimensionsTied() {
    DimensionBehaviour[] arrayOfDimensionBehaviour = this.mListDimensionBehaviors;
    boolean bool2 = false;
    DimensionBehaviour dimensionBehaviour1 = arrayOfDimensionBehaviour[0];
    DimensionBehaviour dimensionBehaviour2 = DimensionBehaviour.MATCH_CONSTRAINT;
    boolean bool1 = bool2;
    if (dimensionBehaviour1 == dimensionBehaviour2) {
      bool1 = bool2;
      if (arrayOfDimensionBehaviour[1] == dimensionBehaviour2)
        bool1 = true; 
    } 
    return bool1;
  }
  
  public void reset() {
    this.mLeft.reset();
    this.mTop.reset();
    this.mRight.reset();
    this.mBottom.reset();
    this.mBaseline.reset();
    this.mCenterX.reset();
    this.mCenterY.reset();
    this.mCenter.reset();
    this.mParent = null;
    this.mCircleConstraintAngle = 0.0F;
    this.mWidth = 0;
    this.mHeight = 0;
    this.mDimensionRatio = 0.0F;
    this.mDimensionRatioSide = -1;
    this.mX = 0;
    this.mY = 0;
    this.mOffsetX = 0;
    this.mOffsetY = 0;
    this.mBaselineDistance = 0;
    this.mMinWidth = 0;
    this.mMinHeight = 0;
    float f = DEFAULT_BIAS;
    this.mHorizontalBiasPercent = f;
    this.mVerticalBiasPercent = f;
    DimensionBehaviour[] arrayOfDimensionBehaviour = this.mListDimensionBehaviors;
    DimensionBehaviour dimensionBehaviour = DimensionBehaviour.FIXED;
    arrayOfDimensionBehaviour[0] = dimensionBehaviour;
    arrayOfDimensionBehaviour[1] = dimensionBehaviour;
    this.mCompanionWidget = null;
    this.mContainerItemSkip = 0;
    this.mVisibility = 0;
    this.mType = null;
    this.mHorizontalWrapVisited = false;
    this.mVerticalWrapVisited = false;
    this.mHorizontalChainStyle = 0;
    this.mVerticalChainStyle = 0;
    this.mHorizontalChainFixedPosition = false;
    this.mVerticalChainFixedPosition = false;
    float[] arrayOfFloat = this.mWeight;
    arrayOfFloat[0] = -1.0F;
    arrayOfFloat[1] = -1.0F;
    this.mHorizontalResolution = -1;
    this.mVerticalResolution = -1;
    int[] arrayOfInt = this.mMaxDimension;
    arrayOfInt[0] = Integer.MAX_VALUE;
    arrayOfInt[1] = Integer.MAX_VALUE;
    this.mMatchConstraintDefaultWidth = 0;
    this.mMatchConstraintDefaultHeight = 0;
    this.mMatchConstraintPercentWidth = 1.0F;
    this.mMatchConstraintPercentHeight = 1.0F;
    this.mMatchConstraintMaxWidth = Integer.MAX_VALUE;
    this.mMatchConstraintMaxHeight = Integer.MAX_VALUE;
    this.mMatchConstraintMinWidth = 0;
    this.mMatchConstraintMinHeight = 0;
    this.mResolvedHasRatio = false;
    this.mResolvedDimensionRatioSide = -1;
    this.mResolvedDimensionRatio = 1.0F;
    this.mGroupsToSolver = false;
    boolean[] arrayOfBoolean = this.isTerminalWidget;
    arrayOfBoolean[0] = true;
    arrayOfBoolean[1] = true;
    this.mInVirtuaLayout = false;
    arrayOfBoolean = this.mIsInBarrier;
    arrayOfBoolean[0] = false;
    arrayOfBoolean[1] = false;
    this.mMeasureRequested = true;
  }
  
  public void resetAllConstraints() {
    resetAnchors();
    setVerticalBiasPercent(DEFAULT_BIAS);
    setHorizontalBiasPercent(DEFAULT_BIAS);
  }
  
  public void resetAnchor(ConstraintAnchor paramConstraintAnchor) {
    if (getParent() != null && getParent() instanceof ConstraintWidgetContainer && ((ConstraintWidgetContainer)getParent()).handlesInternalConstraints())
      return; 
    ConstraintAnchor constraintAnchor1 = getAnchor(ConstraintAnchor.Type.LEFT);
    ConstraintAnchor constraintAnchor2 = getAnchor(ConstraintAnchor.Type.RIGHT);
    ConstraintAnchor constraintAnchor3 = getAnchor(ConstraintAnchor.Type.TOP);
    ConstraintAnchor constraintAnchor4 = getAnchor(ConstraintAnchor.Type.BOTTOM);
    ConstraintAnchor constraintAnchor5 = getAnchor(ConstraintAnchor.Type.CENTER);
    ConstraintAnchor constraintAnchor6 = getAnchor(ConstraintAnchor.Type.CENTER_X);
    ConstraintAnchor constraintAnchor7 = getAnchor(ConstraintAnchor.Type.CENTER_Y);
    if (paramConstraintAnchor == constraintAnchor5) {
      if (constraintAnchor1.isConnected() && constraintAnchor2.isConnected() && constraintAnchor1.getTarget() == constraintAnchor2.getTarget()) {
        constraintAnchor1.reset();
        constraintAnchor2.reset();
      } 
      if (constraintAnchor3.isConnected() && constraintAnchor4.isConnected() && constraintAnchor3.getTarget() == constraintAnchor4.getTarget()) {
        constraintAnchor3.reset();
        constraintAnchor4.reset();
      } 
      this.mHorizontalBiasPercent = 0.5F;
      this.mVerticalBiasPercent = 0.5F;
    } else if (paramConstraintAnchor == constraintAnchor6) {
      if (constraintAnchor1.isConnected() && constraintAnchor2.isConnected() && constraintAnchor1.getTarget().getOwner() == constraintAnchor2.getTarget().getOwner()) {
        constraintAnchor1.reset();
        constraintAnchor2.reset();
      } 
      this.mHorizontalBiasPercent = 0.5F;
    } else if (paramConstraintAnchor == constraintAnchor7) {
      if (constraintAnchor3.isConnected() && constraintAnchor4.isConnected() && constraintAnchor3.getTarget().getOwner() == constraintAnchor4.getTarget().getOwner()) {
        constraintAnchor3.reset();
        constraintAnchor4.reset();
      } 
      this.mVerticalBiasPercent = 0.5F;
    } else if (paramConstraintAnchor == constraintAnchor1 || paramConstraintAnchor == constraintAnchor2) {
      if (constraintAnchor1.isConnected() && constraintAnchor1.getTarget() == constraintAnchor2.getTarget())
        constraintAnchor5.reset(); 
    } else if ((paramConstraintAnchor == constraintAnchor3 || paramConstraintAnchor == constraintAnchor4) && constraintAnchor3.isConnected() && constraintAnchor3.getTarget() == constraintAnchor4.getTarget()) {
      constraintAnchor5.reset();
    } 
    paramConstraintAnchor.reset();
  }
  
  public void resetAnchors() {
    ConstraintWidget constraintWidget = getParent();
    if (constraintWidget != null && constraintWidget instanceof ConstraintWidgetContainer && ((ConstraintWidgetContainer)getParent()).handlesInternalConstraints())
      return; 
    int i = 0;
    int j = this.mAnchors.size();
    while (i < j) {
      ((ConstraintAnchor)this.mAnchors.get(i)).reset();
      i++;
    } 
  }
  
  public void resetFinalResolution() {
    int i = 0;
    this.resolvedHorizontal = false;
    this.resolvedVertical = false;
    int j = this.mAnchors.size();
    while (i < j) {
      ((ConstraintAnchor)this.mAnchors.get(i)).resetFinalResolution();
      i++;
    } 
  }
  
  public void resetSolverVariables(Cache paramCache) {
    this.mLeft.resetSolverVariable(paramCache);
    this.mTop.resetSolverVariable(paramCache);
    this.mRight.resetSolverVariable(paramCache);
    this.mBottom.resetSolverVariable(paramCache);
    this.mBaseline.resetSolverVariable(paramCache);
    this.mCenter.resetSolverVariable(paramCache);
    this.mCenterX.resetSolverVariable(paramCache);
    this.mCenterY.resetSolverVariable(paramCache);
  }
  
  public void setBaselineDistance(int paramInt) {
    boolean bool;
    this.mBaselineDistance = paramInt;
    if (paramInt > 0) {
      bool = true;
    } else {
      bool = false;
    } 
    this.hasBaseline = bool;
  }
  
  public void setCompanionWidget(Object paramObject) {
    this.mCompanionWidget = paramObject;
  }
  
  public void setContainerItemSkip(int paramInt) {
    if (paramInt >= 0) {
      this.mContainerItemSkip = paramInt;
      return;
    } 
    this.mContainerItemSkip = 0;
  }
  
  public void setDebugName(String paramString) {
    this.mDebugName = paramString;
  }
  
  public void setDebugSolverName(LinearSystem paramLinearSystem, String paramString) {
    this.mDebugName = paramString;
    SolverVariable solverVariable5 = paramLinearSystem.createObjectVariable(this.mLeft);
    SolverVariable solverVariable4 = paramLinearSystem.createObjectVariable(this.mTop);
    SolverVariable solverVariable3 = paramLinearSystem.createObjectVariable(this.mRight);
    SolverVariable solverVariable2 = paramLinearSystem.createObjectVariable(this.mBottom);
    StringBuilder stringBuilder5 = new StringBuilder();
    stringBuilder5.append(paramString);
    stringBuilder5.append(".left");
    solverVariable5.setName(stringBuilder5.toString());
    StringBuilder stringBuilder4 = new StringBuilder();
    stringBuilder4.append(paramString);
    stringBuilder4.append(".top");
    solverVariable4.setName(stringBuilder4.toString());
    StringBuilder stringBuilder3 = new StringBuilder();
    stringBuilder3.append(paramString);
    stringBuilder3.append(".right");
    solverVariable3.setName(stringBuilder3.toString());
    StringBuilder stringBuilder2 = new StringBuilder();
    stringBuilder2.append(paramString);
    stringBuilder2.append(".bottom");
    solverVariable2.setName(stringBuilder2.toString());
    SolverVariable solverVariable1 = paramLinearSystem.createObjectVariable(this.mBaseline);
    StringBuilder stringBuilder1 = new StringBuilder();
    stringBuilder1.append(paramString);
    stringBuilder1.append(".baseline");
    solverVariable1.setName(stringBuilder1.toString());
  }
  
  public void setDimension(int paramInt1, int paramInt2) {
    this.mWidth = paramInt1;
    int i = this.mMinWidth;
    if (paramInt1 < i)
      this.mWidth = i; 
    this.mHeight = paramInt2;
    paramInt1 = this.mMinHeight;
    if (paramInt2 < paramInt1)
      this.mHeight = paramInt1; 
  }
  
  public void setDimensionRatio(float paramFloat, int paramInt) {
    this.mDimensionRatio = paramFloat;
    this.mDimensionRatioSide = paramInt;
  }
  
  public void setDimensionRatio(String paramString) {
    // Byte code:
    //   0: aload_1
    //   1: ifnull -> 261
    //   4: aload_1
    //   5: invokevirtual length : ()I
    //   8: ifne -> 14
    //   11: goto -> 261
    //   14: iconst_m1
    //   15: istore #6
    //   17: aload_1
    //   18: invokevirtual length : ()I
    //   21: istore #8
    //   23: aload_1
    //   24: bipush #44
    //   26: invokevirtual indexOf : (I)I
    //   29: istore #9
    //   31: iconst_0
    //   32: istore #7
    //   34: iload #6
    //   36: istore #4
    //   38: iload #7
    //   40: istore #5
    //   42: iload #9
    //   44: ifle -> 114
    //   47: iload #6
    //   49: istore #4
    //   51: iload #7
    //   53: istore #5
    //   55: iload #9
    //   57: iload #8
    //   59: iconst_1
    //   60: isub
    //   61: if_icmpge -> 114
    //   64: aload_1
    //   65: iconst_0
    //   66: iload #9
    //   68: invokevirtual substring : (II)Ljava/lang/String;
    //   71: astore #10
    //   73: aload #10
    //   75: ldc_w 'W'
    //   78: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   81: ifeq -> 90
    //   84: iconst_0
    //   85: istore #4
    //   87: goto -> 108
    //   90: iload #6
    //   92: istore #4
    //   94: aload #10
    //   96: ldc_w 'H'
    //   99: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   102: ifeq -> 108
    //   105: iconst_1
    //   106: istore #4
    //   108: iload #9
    //   110: iconst_1
    //   111: iadd
    //   112: istore #5
    //   114: aload_1
    //   115: bipush #58
    //   117: invokevirtual indexOf : (I)I
    //   120: istore #6
    //   122: iload #6
    //   124: iflt -> 219
    //   127: iload #6
    //   129: iload #8
    //   131: iconst_1
    //   132: isub
    //   133: if_icmpge -> 219
    //   136: aload_1
    //   137: iload #5
    //   139: iload #6
    //   141: invokevirtual substring : (II)Ljava/lang/String;
    //   144: astore #10
    //   146: aload_1
    //   147: iload #6
    //   149: iconst_1
    //   150: iadd
    //   151: invokevirtual substring : (I)Ljava/lang/String;
    //   154: astore_1
    //   155: aload #10
    //   157: invokevirtual length : ()I
    //   160: ifle -> 241
    //   163: aload_1
    //   164: invokevirtual length : ()I
    //   167: ifle -> 241
    //   170: aload #10
    //   172: invokestatic parseFloat : (Ljava/lang/String;)F
    //   175: fstore_2
    //   176: aload_1
    //   177: invokestatic parseFloat : (Ljava/lang/String;)F
    //   180: fstore_3
    //   181: fload_2
    //   182: fconst_0
    //   183: fcmpl
    //   184: ifle -> 241
    //   187: fload_3
    //   188: fconst_0
    //   189: fcmpl
    //   190: ifle -> 241
    //   193: iload #4
    //   195: iconst_1
    //   196: if_icmpne -> 209
    //   199: fload_3
    //   200: fload_2
    //   201: fdiv
    //   202: invokestatic abs : (F)F
    //   205: fstore_2
    //   206: goto -> 243
    //   209: fload_2
    //   210: fload_3
    //   211: fdiv
    //   212: invokestatic abs : (F)F
    //   215: fstore_2
    //   216: goto -> 243
    //   219: aload_1
    //   220: iload #5
    //   222: invokevirtual substring : (I)Ljava/lang/String;
    //   225: astore_1
    //   226: aload_1
    //   227: invokevirtual length : ()I
    //   230: ifle -> 241
    //   233: aload_1
    //   234: invokestatic parseFloat : (Ljava/lang/String;)F
    //   237: fstore_2
    //   238: goto -> 243
    //   241: fconst_0
    //   242: fstore_2
    //   243: fload_2
    //   244: fconst_0
    //   245: fcmpl
    //   246: ifle -> 260
    //   249: aload_0
    //   250: fload_2
    //   251: putfield mDimensionRatio : F
    //   254: aload_0
    //   255: iload #4
    //   257: putfield mDimensionRatioSide : I
    //   260: return
    //   261: aload_0
    //   262: fconst_0
    //   263: putfield mDimensionRatio : F
    //   266: return
    //   267: astore_1
    //   268: goto -> 241
    // Exception table:
    //   from	to	target	type
    //   170	181	267	java/lang/NumberFormatException
    //   199	206	267	java/lang/NumberFormatException
    //   209	216	267	java/lang/NumberFormatException
    //   233	238	267	java/lang/NumberFormatException
  }
  
  public void setFinalBaseline(int paramInt) {
    if (!this.hasBaseline)
      return; 
    int i = paramInt - this.mBaselineDistance;
    int j = this.mHeight;
    this.mY = i;
    this.mTop.setFinalValue(i);
    this.mBottom.setFinalValue(j + i);
    this.mBaseline.setFinalValue(paramInt);
    this.resolvedVertical = true;
  }
  
  public void setFinalFrame(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6) {
    setFrame(paramInt1, paramInt2, paramInt3, paramInt4);
    setBaselineDistance(paramInt5);
    if (paramInt6 == 0) {
      this.resolvedHorizontal = true;
      this.resolvedVertical = false;
      return;
    } 
    if (paramInt6 == 1) {
      this.resolvedHorizontal = false;
      this.resolvedVertical = true;
      return;
    } 
    if (paramInt6 == 2) {
      this.resolvedHorizontal = true;
      this.resolvedVertical = true;
      return;
    } 
    this.resolvedHorizontal = false;
    this.resolvedVertical = false;
  }
  
  public void setFinalHorizontal(int paramInt1, int paramInt2) {
    this.mLeft.setFinalValue(paramInt1);
    this.mRight.setFinalValue(paramInt2);
    this.mX = paramInt1;
    this.mWidth = paramInt2 - paramInt1;
    this.resolvedHorizontal = true;
  }
  
  public void setFinalLeft(int paramInt) {
    this.mLeft.setFinalValue(paramInt);
    this.mX = paramInt;
  }
  
  public void setFinalTop(int paramInt) {
    this.mTop.setFinalValue(paramInt);
    this.mY = paramInt;
  }
  
  public void setFinalVertical(int paramInt1, int paramInt2) {
    this.mTop.setFinalValue(paramInt1);
    this.mBottom.setFinalValue(paramInt2);
    this.mY = paramInt1;
    this.mHeight = paramInt2 - paramInt1;
    if (this.hasBaseline)
      this.mBaseline.setFinalValue(paramInt1 + this.mBaselineDistance); 
    this.resolvedVertical = true;
  }
  
  public void setFrame(int paramInt1, int paramInt2, int paramInt3) {
    if (paramInt3 == 0) {
      setHorizontalDimension(paramInt1, paramInt2);
      return;
    } 
    if (paramInt3 == 1)
      setVerticalDimension(paramInt1, paramInt2); 
  }
  
  public void setFrame(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    int i = paramInt3 - paramInt1;
    paramInt3 = paramInt4 - paramInt2;
    this.mX = paramInt1;
    this.mY = paramInt2;
    if (this.mVisibility == 8) {
      this.mWidth = 0;
      this.mHeight = 0;
      return;
    } 
    DimensionBehaviour[] arrayOfDimensionBehaviour = this.mListDimensionBehaviors;
    DimensionBehaviour dimensionBehaviour1 = arrayOfDimensionBehaviour[0];
    DimensionBehaviour dimensionBehaviour2 = DimensionBehaviour.FIXED;
    paramInt1 = i;
    if (dimensionBehaviour1 == dimensionBehaviour2) {
      paramInt2 = this.mWidth;
      paramInt1 = i;
      if (i < paramInt2)
        paramInt1 = paramInt2; 
    } 
    paramInt2 = paramInt3;
    if (arrayOfDimensionBehaviour[1] == dimensionBehaviour2) {
      paramInt4 = this.mHeight;
      paramInt2 = paramInt3;
      if (paramInt3 < paramInt4)
        paramInt2 = paramInt4; 
    } 
    this.mWidth = paramInt1;
    this.mHeight = paramInt2;
    paramInt3 = this.mMinHeight;
    if (paramInt2 < paramInt3)
      this.mHeight = paramInt3; 
    paramInt2 = this.mMinWidth;
    if (paramInt1 < paramInt2)
      this.mWidth = paramInt2; 
  }
  
  public void setGoneMargin(ConstraintAnchor.Type paramType, int paramInt) {
    int i = null.$SwitchMap$androidx$constraintlayout$solver$widgets$ConstraintAnchor$Type[paramType.ordinal()];
    if (i != 1) {
      if (i != 2) {
        if (i != 3) {
          if (i != 4)
            return; 
          this.mBottom.mGoneMargin = paramInt;
          return;
        } 
        this.mRight.mGoneMargin = paramInt;
        return;
      } 
      this.mTop.mGoneMargin = paramInt;
      return;
    } 
    this.mLeft.mGoneMargin = paramInt;
  }
  
  public void setHasBaseline(boolean paramBoolean) {
    this.hasBaseline = paramBoolean;
  }
  
  public void setHeight(int paramInt) {
    this.mHeight = paramInt;
    int i = this.mMinHeight;
    if (paramInt < i)
      this.mHeight = i; 
  }
  
  public void setHeightWrapContent(boolean paramBoolean) {
    this.mIsHeightWrapContent = paramBoolean;
  }
  
  public void setHorizontalBiasPercent(float paramFloat) {
    this.mHorizontalBiasPercent = paramFloat;
  }
  
  public void setHorizontalChainStyle(int paramInt) {
    this.mHorizontalChainStyle = paramInt;
  }
  
  public void setHorizontalDimension(int paramInt1, int paramInt2) {
    this.mX = paramInt1;
    paramInt1 = paramInt2 - paramInt1;
    this.mWidth = paramInt1;
    paramInt2 = this.mMinWidth;
    if (paramInt1 < paramInt2)
      this.mWidth = paramInt2; 
  }
  
  public void setHorizontalDimensionBehaviour(DimensionBehaviour paramDimensionBehaviour) {
    this.mListDimensionBehaviors[0] = paramDimensionBehaviour;
  }
  
  public void setHorizontalMatchStyle(int paramInt1, int paramInt2, int paramInt3, float paramFloat) {
    this.mMatchConstraintDefaultWidth = paramInt1;
    this.mMatchConstraintMinWidth = paramInt2;
    paramInt2 = paramInt3;
    if (paramInt3 == Integer.MAX_VALUE)
      paramInt2 = 0; 
    this.mMatchConstraintMaxWidth = paramInt2;
    this.mMatchConstraintPercentWidth = paramFloat;
    if (paramFloat > 0.0F && paramFloat < 1.0F && paramInt1 == 0)
      this.mMatchConstraintDefaultWidth = 2; 
  }
  
  public void setHorizontalWeight(float paramFloat) {
    this.mWeight[0] = paramFloat;
  }
  
  protected void setInBarrier(int paramInt, boolean paramBoolean) {
    this.mIsInBarrier[paramInt] = paramBoolean;
  }
  
  public void setInPlaceholder(boolean paramBoolean) {
    this.inPlaceholder = paramBoolean;
  }
  
  public void setInVirtualLayout(boolean paramBoolean) {
    this.mInVirtuaLayout = paramBoolean;
  }
  
  public void setLastMeasureSpec(int paramInt1, int paramInt2) {
    this.mLastHorizontalMeasureSpec = paramInt1;
    this.mLastVerticalMeasureSpec = paramInt2;
    setMeasureRequested(false);
  }
  
  public void setLength(int paramInt1, int paramInt2) {
    if (paramInt2 == 0) {
      setWidth(paramInt1);
      return;
    } 
    if (paramInt2 == 1)
      setHeight(paramInt1); 
  }
  
  public void setMaxHeight(int paramInt) {
    this.mMaxDimension[1] = paramInt;
  }
  
  public void setMaxWidth(int paramInt) {
    this.mMaxDimension[0] = paramInt;
  }
  
  public void setMeasureRequested(boolean paramBoolean) {
    this.mMeasureRequested = paramBoolean;
  }
  
  public void setMinHeight(int paramInt) {
    if (paramInt < 0) {
      this.mMinHeight = 0;
      return;
    } 
    this.mMinHeight = paramInt;
  }
  
  public void setMinWidth(int paramInt) {
    if (paramInt < 0) {
      this.mMinWidth = 0;
      return;
    } 
    this.mMinWidth = paramInt;
  }
  
  public void setOffset(int paramInt1, int paramInt2) {
    this.mOffsetX = paramInt1;
    this.mOffsetY = paramInt2;
  }
  
  public void setOrigin(int paramInt1, int paramInt2) {
    this.mX = paramInt1;
    this.mY = paramInt2;
  }
  
  public void setParent(ConstraintWidget paramConstraintWidget) {
    this.mParent = paramConstraintWidget;
  }
  
  void setRelativePositioning(int paramInt1, int paramInt2) {
    if (paramInt2 == 0) {
      this.mRelX = paramInt1;
      return;
    } 
    if (paramInt2 == 1)
      this.mRelY = paramInt1; 
  }
  
  public void setType(String paramString) {
    this.mType = paramString;
  }
  
  public void setVerticalBiasPercent(float paramFloat) {
    this.mVerticalBiasPercent = paramFloat;
  }
  
  public void setVerticalChainStyle(int paramInt) {
    this.mVerticalChainStyle = paramInt;
  }
  
  public void setVerticalDimension(int paramInt1, int paramInt2) {
    this.mY = paramInt1;
    paramInt1 = paramInt2 - paramInt1;
    this.mHeight = paramInt1;
    paramInt2 = this.mMinHeight;
    if (paramInt1 < paramInt2)
      this.mHeight = paramInt2; 
  }
  
  public void setVerticalDimensionBehaviour(DimensionBehaviour paramDimensionBehaviour) {
    this.mListDimensionBehaviors[1] = paramDimensionBehaviour;
  }
  
  public void setVerticalMatchStyle(int paramInt1, int paramInt2, int paramInt3, float paramFloat) {
    this.mMatchConstraintDefaultHeight = paramInt1;
    this.mMatchConstraintMinHeight = paramInt2;
    paramInt2 = paramInt3;
    if (paramInt3 == Integer.MAX_VALUE)
      paramInt2 = 0; 
    this.mMatchConstraintMaxHeight = paramInt2;
    this.mMatchConstraintPercentHeight = paramFloat;
    if (paramFloat > 0.0F && paramFloat < 1.0F && paramInt1 == 0)
      this.mMatchConstraintDefaultHeight = 2; 
  }
  
  public void setVerticalWeight(float paramFloat) {
    this.mWeight[1] = paramFloat;
  }
  
  public void setVisibility(int paramInt) {
    this.mVisibility = paramInt;
  }
  
  public void setWidth(int paramInt) {
    this.mWidth = paramInt;
    int i = this.mMinWidth;
    if (paramInt < i)
      this.mWidth = i; 
  }
  
  public void setWidthWrapContent(boolean paramBoolean) {
    this.mIsWidthWrapContent = paramBoolean;
  }
  
  public void setX(int paramInt) {
    this.mX = paramInt;
  }
  
  public void setY(int paramInt) {
    this.mY = paramInt;
  }
  
  public void setupDimensionRatio(boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4) {
    if (this.mResolvedDimensionRatioSide == -1)
      if (paramBoolean3 && !paramBoolean4) {
        this.mResolvedDimensionRatioSide = 0;
      } else if (!paramBoolean3 && paramBoolean4) {
        this.mResolvedDimensionRatioSide = 1;
        if (this.mDimensionRatioSide == -1)
          this.mResolvedDimensionRatio = 1.0F / this.mResolvedDimensionRatio; 
      }  
    if (this.mResolvedDimensionRatioSide == 0 && (!this.mTop.isConnected() || !this.mBottom.isConnected())) {
      this.mResolvedDimensionRatioSide = 1;
    } else if (this.mResolvedDimensionRatioSide == 1 && (!this.mLeft.isConnected() || !this.mRight.isConnected())) {
      this.mResolvedDimensionRatioSide = 0;
    } 
    if (this.mResolvedDimensionRatioSide == -1 && (!this.mTop.isConnected() || !this.mBottom.isConnected() || !this.mLeft.isConnected() || !this.mRight.isConnected()))
      if (this.mTop.isConnected() && this.mBottom.isConnected()) {
        this.mResolvedDimensionRatioSide = 0;
      } else if (this.mLeft.isConnected() && this.mRight.isConnected()) {
        this.mResolvedDimensionRatio = 1.0F / this.mResolvedDimensionRatio;
        this.mResolvedDimensionRatioSide = 1;
      }  
    if (this.mResolvedDimensionRatioSide == -1) {
      int i = this.mMatchConstraintMinWidth;
      if (i > 0 && this.mMatchConstraintMinHeight == 0) {
        this.mResolvedDimensionRatioSide = 0;
        return;
      } 
      if (i == 0 && this.mMatchConstraintMinHeight > 0) {
        this.mResolvedDimensionRatio = 1.0F / this.mResolvedDimensionRatio;
        this.mResolvedDimensionRatioSide = 1;
      } 
    } 
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    String str1 = this.mType;
    String str2 = "";
    if (str1 != null) {
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append("type: ");
      stringBuilder1.append(this.mType);
      stringBuilder1.append(" ");
      String str = stringBuilder1.toString();
    } else {
      str1 = "";
    } 
    stringBuilder.append(str1);
    str1 = str2;
    if (this.mDebugName != null) {
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append("id: ");
      stringBuilder1.append(this.mDebugName);
      stringBuilder1.append(" ");
      str1 = stringBuilder1.toString();
    } 
    stringBuilder.append(str1);
    stringBuilder.append("(");
    stringBuilder.append(this.mX);
    stringBuilder.append(", ");
    stringBuilder.append(this.mY);
    stringBuilder.append(") - (");
    stringBuilder.append(this.mWidth);
    stringBuilder.append(" x ");
    stringBuilder.append(this.mHeight);
    stringBuilder.append(")");
    return stringBuilder.toString();
  }
  
  public void updateFromRuns(boolean paramBoolean1, boolean paramBoolean2) {
    // Byte code:
    //   0: iload_1
    //   1: aload_0
    //   2: getfield horizontalRun : Landroidx/constraintlayout/solver/widgets/analyzer/HorizontalWidgetRun;
    //   5: invokevirtual isResolved : ()Z
    //   8: iand
    //   9: istore #9
    //   11: iload_2
    //   12: aload_0
    //   13: getfield verticalRun : Landroidx/constraintlayout/solver/widgets/analyzer/VerticalWidgetRun;
    //   16: invokevirtual isResolved : ()Z
    //   19: iand
    //   20: istore #8
    //   22: aload_0
    //   23: getfield horizontalRun : Landroidx/constraintlayout/solver/widgets/analyzer/HorizontalWidgetRun;
    //   26: astore #10
    //   28: aload #10
    //   30: getfield start : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   33: getfield value : I
    //   36: istore #4
    //   38: aload_0
    //   39: getfield verticalRun : Landroidx/constraintlayout/solver/widgets/analyzer/VerticalWidgetRun;
    //   42: astore #11
    //   44: aload #11
    //   46: getfield start : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   49: getfield value : I
    //   52: istore_3
    //   53: aload #10
    //   55: getfield end : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   58: getfield value : I
    //   61: istore #6
    //   63: aload #11
    //   65: getfield end : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   68: getfield value : I
    //   71: istore #7
    //   73: iload #6
    //   75: iload #4
    //   77: isub
    //   78: iflt -> 150
    //   81: iload #7
    //   83: iload_3
    //   84: isub
    //   85: iflt -> 150
    //   88: iload #4
    //   90: ldc_w -2147483648
    //   93: if_icmpeq -> 150
    //   96: iload #4
    //   98: ldc 2147483647
    //   100: if_icmpeq -> 150
    //   103: iload_3
    //   104: ldc_w -2147483648
    //   107: if_icmpeq -> 150
    //   110: iload_3
    //   111: ldc 2147483647
    //   113: if_icmpeq -> 150
    //   116: iload #6
    //   118: ldc_w -2147483648
    //   121: if_icmpeq -> 150
    //   124: iload #6
    //   126: ldc 2147483647
    //   128: if_icmpeq -> 150
    //   131: iload #7
    //   133: ldc_w -2147483648
    //   136: if_icmpeq -> 150
    //   139: iload #7
    //   141: istore #5
    //   143: iload #7
    //   145: ldc 2147483647
    //   147: if_icmpne -> 161
    //   150: iconst_0
    //   151: istore #6
    //   153: iconst_0
    //   154: istore #4
    //   156: iconst_0
    //   157: istore #5
    //   159: iconst_0
    //   160: istore_3
    //   161: iload #6
    //   163: iload #4
    //   165: isub
    //   166: istore #6
    //   168: iload #5
    //   170: iload_3
    //   171: isub
    //   172: istore #5
    //   174: iload #9
    //   176: ifeq -> 185
    //   179: aload_0
    //   180: iload #4
    //   182: putfield mX : I
    //   185: iload #8
    //   187: ifeq -> 195
    //   190: aload_0
    //   191: iload_3
    //   192: putfield mY : I
    //   195: aload_0
    //   196: getfield mVisibility : I
    //   199: bipush #8
    //   201: if_icmpne -> 215
    //   204: aload_0
    //   205: iconst_0
    //   206: putfield mWidth : I
    //   209: aload_0
    //   210: iconst_0
    //   211: putfield mHeight : I
    //   214: return
    //   215: iload #9
    //   217: ifeq -> 277
    //   220: iload #6
    //   222: istore_3
    //   223: aload_0
    //   224: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   227: iconst_0
    //   228: aaload
    //   229: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.FIXED : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   232: if_acmpne -> 254
    //   235: aload_0
    //   236: getfield mWidth : I
    //   239: istore #4
    //   241: iload #6
    //   243: istore_3
    //   244: iload #6
    //   246: iload #4
    //   248: if_icmpge -> 254
    //   251: iload #4
    //   253: istore_3
    //   254: aload_0
    //   255: iload_3
    //   256: putfield mWidth : I
    //   259: aload_0
    //   260: getfield mMinWidth : I
    //   263: istore #4
    //   265: iload_3
    //   266: iload #4
    //   268: if_icmpge -> 277
    //   271: aload_0
    //   272: iload #4
    //   274: putfield mWidth : I
    //   277: iload #8
    //   279: ifeq -> 339
    //   282: iload #5
    //   284: istore_3
    //   285: aload_0
    //   286: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   289: iconst_1
    //   290: aaload
    //   291: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.FIXED : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   294: if_acmpne -> 316
    //   297: aload_0
    //   298: getfield mHeight : I
    //   301: istore #4
    //   303: iload #5
    //   305: istore_3
    //   306: iload #5
    //   308: iload #4
    //   310: if_icmpge -> 316
    //   313: iload #4
    //   315: istore_3
    //   316: aload_0
    //   317: iload_3
    //   318: putfield mHeight : I
    //   321: aload_0
    //   322: getfield mMinHeight : I
    //   325: istore #4
    //   327: iload_3
    //   328: iload #4
    //   330: if_icmpge -> 339
    //   333: aload_0
    //   334: iload #4
    //   336: putfield mHeight : I
    //   339: return
  }
  
  public void updateFromSolver(LinearSystem paramLinearSystem, boolean paramBoolean) {
    // Byte code:
    //   0: aload_1
    //   1: aload_0
    //   2: getfield mLeft : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   5: invokevirtual getObjectVariableValue : (Ljava/lang/Object;)I
    //   8: istore #4
    //   10: aload_1
    //   11: aload_0
    //   12: getfield mTop : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   15: invokevirtual getObjectVariableValue : (Ljava/lang/Object;)I
    //   18: istore #7
    //   20: aload_1
    //   21: aload_0
    //   22: getfield mRight : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   25: invokevirtual getObjectVariableValue : (Ljava/lang/Object;)I
    //   28: istore #6
    //   30: aload_1
    //   31: aload_0
    //   32: getfield mBottom : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   35: invokevirtual getObjectVariableValue : (Ljava/lang/Object;)I
    //   38: istore #8
    //   40: iload #4
    //   42: istore #5
    //   44: iload #6
    //   46: istore_3
    //   47: iload_2
    //   48: ifeq -> 123
    //   51: aload_0
    //   52: getfield horizontalRun : Landroidx/constraintlayout/solver/widgets/analyzer/HorizontalWidgetRun;
    //   55: astore #9
    //   57: iload #4
    //   59: istore #5
    //   61: iload #6
    //   63: istore_3
    //   64: aload #9
    //   66: ifnull -> 123
    //   69: aload #9
    //   71: getfield start : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   74: astore_1
    //   75: iload #4
    //   77: istore #5
    //   79: iload #6
    //   81: istore_3
    //   82: aload_1
    //   83: getfield resolved : Z
    //   86: ifeq -> 123
    //   89: aload #9
    //   91: getfield end : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   94: astore #9
    //   96: iload #4
    //   98: istore #5
    //   100: iload #6
    //   102: istore_3
    //   103: aload #9
    //   105: getfield resolved : Z
    //   108: ifeq -> 123
    //   111: aload_1
    //   112: getfield value : I
    //   115: istore #5
    //   117: aload #9
    //   119: getfield value : I
    //   122: istore_3
    //   123: iload #7
    //   125: istore #6
    //   127: iload #8
    //   129: istore #4
    //   131: iload_2
    //   132: ifeq -> 211
    //   135: aload_0
    //   136: getfield verticalRun : Landroidx/constraintlayout/solver/widgets/analyzer/VerticalWidgetRun;
    //   139: astore #9
    //   141: iload #7
    //   143: istore #6
    //   145: iload #8
    //   147: istore #4
    //   149: aload #9
    //   151: ifnull -> 211
    //   154: aload #9
    //   156: getfield start : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   159: astore_1
    //   160: iload #7
    //   162: istore #6
    //   164: iload #8
    //   166: istore #4
    //   168: aload_1
    //   169: getfield resolved : Z
    //   172: ifeq -> 211
    //   175: aload #9
    //   177: getfield end : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   180: astore #9
    //   182: iload #7
    //   184: istore #6
    //   186: iload #8
    //   188: istore #4
    //   190: aload #9
    //   192: getfield resolved : Z
    //   195: ifeq -> 211
    //   198: aload_1
    //   199: getfield value : I
    //   202: istore #6
    //   204: aload #9
    //   206: getfield value : I
    //   209: istore #4
    //   211: iload_3
    //   212: iload #5
    //   214: isub
    //   215: iflt -> 290
    //   218: iload #4
    //   220: iload #6
    //   222: isub
    //   223: iflt -> 290
    //   226: iload #5
    //   228: ldc_w -2147483648
    //   231: if_icmpeq -> 290
    //   234: iload #5
    //   236: ldc 2147483647
    //   238: if_icmpeq -> 290
    //   241: iload #6
    //   243: ldc_w -2147483648
    //   246: if_icmpeq -> 290
    //   249: iload #6
    //   251: ldc 2147483647
    //   253: if_icmpeq -> 290
    //   256: iload_3
    //   257: ldc_w -2147483648
    //   260: if_icmpeq -> 290
    //   263: iload_3
    //   264: ldc 2147483647
    //   266: if_icmpeq -> 290
    //   269: iload #4
    //   271: ldc_w -2147483648
    //   274: if_icmpeq -> 290
    //   277: iload_3
    //   278: istore #7
    //   280: iload #4
    //   282: istore_3
    //   283: iload #4
    //   285: ldc 2147483647
    //   287: if_icmpne -> 301
    //   290: iconst_0
    //   291: istore_3
    //   292: iconst_0
    //   293: istore #5
    //   295: iconst_0
    //   296: istore #6
    //   298: iconst_0
    //   299: istore #7
    //   301: aload_0
    //   302: iload #5
    //   304: iload #6
    //   306: iload #7
    //   308: iload_3
    //   309: invokevirtual setFrame : (IIII)V
    //   312: return
  }
  
  public enum DimensionBehaviour {
    FIXED, MATCH_CONSTRAINT, MATCH_PARENT, WRAP_CONTENT;
    
    static {
      DimensionBehaviour dimensionBehaviour1 = new DimensionBehaviour("FIXED", 0);
      FIXED = dimensionBehaviour1;
      DimensionBehaviour dimensionBehaviour2 = new DimensionBehaviour("WRAP_CONTENT", 1);
      WRAP_CONTENT = dimensionBehaviour2;
      DimensionBehaviour dimensionBehaviour3 = new DimensionBehaviour("MATCH_CONSTRAINT", 2);
      MATCH_CONSTRAINT = dimensionBehaviour3;
      DimensionBehaviour dimensionBehaviour4 = new DimensionBehaviour("MATCH_PARENT", 3);
      MATCH_PARENT = dimensionBehaviour4;
      $VALUES = new DimensionBehaviour[] { dimensionBehaviour1, dimensionBehaviour2, dimensionBehaviour3, dimensionBehaviour4 };
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\BabyBus TV_Kids Videos & Games-dex2jar.jar!\androidx\constraintlayout\solver\widgets\ConstraintWidget.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */