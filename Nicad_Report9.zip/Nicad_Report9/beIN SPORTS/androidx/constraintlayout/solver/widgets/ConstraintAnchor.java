package androidx.constraintlayout.solver.widgets;

import androidx.constraintlayout.solver.Cache;
import androidx.constraintlayout.solver.SolverVariable;
import androidx.constraintlayout.solver.widgets.analyzer.Grouping;
import androidx.constraintlayout.solver.widgets.analyzer.WidgetGroup;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;

public class ConstraintAnchor {
  private static final boolean ALLOW_BINARY = false;
  
  private static final int UNSET_GONE_MARGIN = -1;
  
  private HashSet<ConstraintAnchor> mDependents = null;
  
  private int mFinalValue;
  
  int mGoneMargin = -1;
  
  private boolean mHasFinalValue;
  
  public int mMargin = 0;
  
  public final ConstraintWidget mOwner;
  
  SolverVariable mSolverVariable;
  
  public ConstraintAnchor mTarget;
  
  public final Type mType;
  
  public ConstraintAnchor(ConstraintWidget paramConstraintWidget, Type paramType) {
    this.mOwner = paramConstraintWidget;
    this.mType = paramType;
  }
  
  private boolean isConnectionToMe(ConstraintWidget paramConstraintWidget, HashSet<ConstraintWidget> paramHashSet) {
    if (paramHashSet.contains(paramConstraintWidget))
      return false; 
    paramHashSet.add(paramConstraintWidget);
    if (paramConstraintWidget == getOwner())
      return true; 
    ArrayList<ConstraintAnchor> arrayList = paramConstraintWidget.getAnchors();
    int j = arrayList.size();
    for (int i = 0; i < j; i++) {
      ConstraintAnchor constraintAnchor = arrayList.get(i);
      if (constraintAnchor.isSimilarDimensionConnection(this) && constraintAnchor.isConnected() && isConnectionToMe(constraintAnchor.getTarget().getOwner(), paramHashSet))
        return true; 
    } 
    return false;
  }
  
  public boolean connect(ConstraintAnchor paramConstraintAnchor, int paramInt) {
    return connect(paramConstraintAnchor, paramInt, -1, false);
  }
  
  public boolean connect(ConstraintAnchor paramConstraintAnchor, int paramInt1, int paramInt2, boolean paramBoolean) {
    if (paramConstraintAnchor == null) {
      reset();
      return true;
    } 
    if (!paramBoolean && !isValidConnection(paramConstraintAnchor))
      return false; 
    this.mTarget = paramConstraintAnchor;
    if (paramConstraintAnchor.mDependents == null)
      paramConstraintAnchor.mDependents = new HashSet<ConstraintAnchor>(); 
    HashSet<ConstraintAnchor> hashSet = this.mTarget.mDependents;
    if (hashSet != null)
      hashSet.add(this); 
    if (paramInt1 > 0) {
      this.mMargin = paramInt1;
    } else {
      this.mMargin = 0;
    } 
    this.mGoneMargin = paramInt2;
    return true;
  }
  
  public void copyFrom(ConstraintAnchor paramConstraintAnchor, HashMap<ConstraintWidget, ConstraintWidget> paramHashMap) {
    ConstraintAnchor constraintAnchor2 = this.mTarget;
    if (constraintAnchor2 != null) {
      HashSet<ConstraintAnchor> hashSet = constraintAnchor2.mDependents;
      if (hashSet != null)
        hashSet.remove(this); 
    } 
    constraintAnchor2 = paramConstraintAnchor.mTarget;
    if (constraintAnchor2 != null) {
      Type type = constraintAnchor2.getType();
      this.mTarget = ((ConstraintWidget)paramHashMap.get(paramConstraintAnchor.mTarget.mOwner)).getAnchor(type);
    } else {
      this.mTarget = null;
    } 
    ConstraintAnchor constraintAnchor1 = this.mTarget;
    if (constraintAnchor1 != null) {
      if (constraintAnchor1.mDependents == null)
        constraintAnchor1.mDependents = new HashSet<ConstraintAnchor>(); 
      this.mTarget.mDependents.add(this);
    } 
    this.mMargin = paramConstraintAnchor.mMargin;
    this.mGoneMargin = paramConstraintAnchor.mGoneMargin;
  }
  
  public void findDependents(int paramInt, ArrayList<WidgetGroup> paramArrayList, WidgetGroup paramWidgetGroup) {
    HashSet<ConstraintAnchor> hashSet = this.mDependents;
    if (hashSet != null) {
      Iterator<ConstraintAnchor> iterator = hashSet.iterator();
      while (iterator.hasNext())
        Grouping.findDependents(((ConstraintAnchor)iterator.next()).mOwner, paramInt, paramArrayList, paramWidgetGroup); 
    } 
  }
  
  public HashSet<ConstraintAnchor> getDependents() {
    return this.mDependents;
  }
  
  public int getFinalValue() {
    return !this.mHasFinalValue ? 0 : this.mFinalValue;
  }
  
  public int getMargin() {
    if (this.mOwner.getVisibility() == 8)
      return 0; 
    if (this.mGoneMargin > -1) {
      ConstraintAnchor constraintAnchor = this.mTarget;
      if (constraintAnchor != null && constraintAnchor.mOwner.getVisibility() == 8)
        return this.mGoneMargin; 
    } 
    return this.mMargin;
  }
  
  public final ConstraintAnchor getOpposite() {
    switch (this.mType) {
      default:
        throw new AssertionError(this.mType.name());
      case null:
        return this.mOwner.mTop;
      case null:
        return this.mOwner.mBottom;
      case null:
        return this.mOwner.mLeft;
      case null:
        return this.mOwner.mRight;
      case null:
      case null:
      case null:
      case null:
      case null:
        break;
    } 
    return null;
  }
  
  public ConstraintWidget getOwner() {
    return this.mOwner;
  }
  
  public SolverVariable getSolverVariable() {
    return this.mSolverVariable;
  }
  
  public ConstraintAnchor getTarget() {
    return this.mTarget;
  }
  
  public Type getType() {
    return this.mType;
  }
  
  public boolean hasCenteredDependents() {
    HashSet<ConstraintAnchor> hashSet = this.mDependents;
    if (hashSet == null)
      return false; 
    Iterator<ConstraintAnchor> iterator = hashSet.iterator();
    while (iterator.hasNext()) {
      if (((ConstraintAnchor)iterator.next()).getOpposite().isConnected())
        return true; 
    } 
    return false;
  }
  
  public boolean hasDependents() {
    HashSet<ConstraintAnchor> hashSet = this.mDependents;
    boolean bool = false;
    if (hashSet == null)
      return false; 
    if (hashSet.size() > 0)
      bool = true; 
    return bool;
  }
  
  public boolean hasFinalValue() {
    return this.mHasFinalValue;
  }
  
  public boolean isConnected() {
    return (this.mTarget != null);
  }
  
  public boolean isConnectionAllowed(ConstraintWidget paramConstraintWidget) {
    if (isConnectionToMe(paramConstraintWidget, new HashSet<ConstraintWidget>()))
      return false; 
    ConstraintWidget constraintWidget = getOwner().getParent();
    return (constraintWidget == paramConstraintWidget) ? true : ((paramConstraintWidget.getParent() == constraintWidget));
  }
  
  public boolean isConnectionAllowed(ConstraintWidget paramConstraintWidget, ConstraintAnchor paramConstraintAnchor) {
    return isConnectionAllowed(paramConstraintWidget);
  }
  
  public boolean isSideAnchor() {
    switch (this.mType) {
      default:
        throw new AssertionError(this.mType.name());
      case null:
      case null:
      case null:
      case null:
        return true;
      case null:
      case null:
      case null:
      case null:
      case null:
        break;
    } 
    return false;
  }
  
  public boolean isSimilarDimensionConnection(ConstraintAnchor paramConstraintAnchor) {
    boolean bool1;
    Type type1 = paramConstraintAnchor.getType();
    Type type2 = this.mType;
    boolean bool3 = true;
    boolean bool2 = true;
    if (type1 == type2)
      return true; 
    switch (type2) {
      default:
        throw new AssertionError(this.mType.name());
      case null:
        return false;
      case null:
      case null:
      case null:
      case null:
        bool1 = bool2;
        if (type1 != Type.TOP) {
          bool1 = bool2;
          if (type1 != Type.BOTTOM) {
            bool1 = bool2;
            if (type1 != Type.CENTER_Y) {
              if (type1 == Type.BASELINE)
                return true; 
              bool1 = false;
            } 
          } 
        } 
        return bool1;
      case null:
      case null:
      case null:
        bool1 = bool3;
        if (type1 != Type.LEFT) {
          bool1 = bool3;
          if (type1 != Type.RIGHT) {
            if (type1 == Type.CENTER_X)
              return true; 
            bool1 = false;
          } 
        } 
        return bool1;
      case null:
        break;
    } 
    return (type1 != Type.BASELINE);
  }
  
  public boolean isValidConnection(ConstraintAnchor paramConstraintAnchor) {
    // Byte code:
    //   0: iconst_0
    //   1: istore #5
    //   3: iconst_0
    //   4: istore_3
    //   5: iconst_0
    //   6: istore #4
    //   8: aload_1
    //   9: ifnonnull -> 14
    //   12: iconst_0
    //   13: ireturn
    //   14: aload_1
    //   15: invokevirtual getType : ()Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   18: astore #6
    //   20: aload_0
    //   21: getfield mType : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   24: astore #7
    //   26: aload #6
    //   28: aload #7
    //   30: if_acmpne -> 65
    //   33: aload #7
    //   35: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.BASELINE : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   38: if_acmpne -> 63
    //   41: aload_1
    //   42: invokevirtual getOwner : ()Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   45: invokevirtual hasBaseline : ()Z
    //   48: ifeq -> 61
    //   51: aload_0
    //   52: invokevirtual getOwner : ()Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   55: invokevirtual hasBaseline : ()Z
    //   58: ifne -> 63
    //   61: iconst_0
    //   62: ireturn
    //   63: iconst_1
    //   64: ireturn
    //   65: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$1.$SwitchMap$androidx$constraintlayout$solver$widgets$ConstraintAnchor$Type : [I
    //   68: aload #7
    //   70: invokevirtual ordinal : ()I
    //   73: iaload
    //   74: tableswitch default -> 124, 1 -> 259, 2 -> 200, 3 -> 200, 4 -> 141, 5 -> 141, 6 -> 139, 7 -> 139, 8 -> 139, 9 -> 139
    //   124: new java/lang/AssertionError
    //   127: dup
    //   128: aload_0
    //   129: getfield mType : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   132: invokevirtual name : ()Ljava/lang/String;
    //   135: invokespecial <init> : (Ljava/lang/Object;)V
    //   138: athrow
    //   139: iconst_0
    //   140: ireturn
    //   141: aload #6
    //   143: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.TOP : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   146: if_acmpeq -> 165
    //   149: aload #6
    //   151: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.BOTTOM : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   154: if_acmpne -> 160
    //   157: goto -> 165
    //   160: iconst_0
    //   161: istore_2
    //   162: goto -> 167
    //   165: iconst_1
    //   166: istore_2
    //   167: iload_2
    //   168: istore_3
    //   169: aload_1
    //   170: invokevirtual getOwner : ()Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   173: instanceof androidx/constraintlayout/solver/widgets/Guideline
    //   176: ifeq -> 198
    //   179: iload_2
    //   180: ifne -> 194
    //   183: iload #4
    //   185: istore_2
    //   186: aload #6
    //   188: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.CENTER_Y : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   191: if_acmpne -> 196
    //   194: iconst_1
    //   195: istore_2
    //   196: iload_2
    //   197: istore_3
    //   198: iload_3
    //   199: ireturn
    //   200: aload #6
    //   202: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.LEFT : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   205: if_acmpeq -> 224
    //   208: aload #6
    //   210: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.RIGHT : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   213: if_acmpne -> 219
    //   216: goto -> 224
    //   219: iconst_0
    //   220: istore_2
    //   221: goto -> 226
    //   224: iconst_1
    //   225: istore_2
    //   226: iload_2
    //   227: istore_3
    //   228: aload_1
    //   229: invokevirtual getOwner : ()Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   232: instanceof androidx/constraintlayout/solver/widgets/Guideline
    //   235: ifeq -> 257
    //   238: iload_2
    //   239: ifne -> 253
    //   242: iload #5
    //   244: istore_2
    //   245: aload #6
    //   247: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.CENTER_X : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   250: if_acmpne -> 255
    //   253: iconst_1
    //   254: istore_2
    //   255: iload_2
    //   256: istore_3
    //   257: iload_3
    //   258: ireturn
    //   259: iload_3
    //   260: istore_2
    //   261: aload #6
    //   263: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.BASELINE : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   266: if_acmpeq -> 291
    //   269: iload_3
    //   270: istore_2
    //   271: aload #6
    //   273: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.CENTER_X : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   276: if_acmpeq -> 291
    //   279: iload_3
    //   280: istore_2
    //   281: aload #6
    //   283: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.CENTER_Y : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   286: if_acmpeq -> 291
    //   289: iconst_1
    //   290: istore_2
    //   291: iload_2
    //   292: ireturn
  }
  
  public boolean isVerticalAnchor() {
    switch (this.mType) {
      default:
        throw new AssertionError(this.mType.name());
      case null:
      case null:
      case null:
      case null:
      case null:
        return true;
      case null:
      case null:
      case null:
      case null:
        break;
    } 
    return false;
  }
  
  public void reset() {
    ConstraintAnchor constraintAnchor = this.mTarget;
    if (constraintAnchor != null) {
      HashSet<ConstraintAnchor> hashSet = constraintAnchor.mDependents;
      if (hashSet != null) {
        hashSet.remove(this);
        if (this.mTarget.mDependents.size() == 0)
          this.mTarget.mDependents = null; 
      } 
    } 
    this.mDependents = null;
    this.mTarget = null;
    this.mMargin = 0;
    this.mGoneMargin = -1;
    this.mHasFinalValue = false;
    this.mFinalValue = 0;
  }
  
  public void resetFinalResolution() {
    this.mHasFinalValue = false;
    this.mFinalValue = 0;
  }
  
  public void resetSolverVariable(Cache paramCache) {
    SolverVariable solverVariable = this.mSolverVariable;
    if (solverVariable == null) {
      this.mSolverVariable = new SolverVariable(SolverVariable.Type.UNRESTRICTED, null);
      return;
    } 
    solverVariable.reset();
  }
  
  public void setFinalValue(int paramInt) {
    this.mFinalValue = paramInt;
    this.mHasFinalValue = true;
  }
  
  public void setGoneMargin(int paramInt) {
    if (isConnected())
      this.mGoneMargin = paramInt; 
  }
  
  public void setMargin(int paramInt) {
    if (isConnected())
      this.mMargin = paramInt; 
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(this.mOwner.getDebugName());
    stringBuilder.append(":");
    stringBuilder.append(this.mType.toString());
    return stringBuilder.toString();
  }
  
  public enum Type {
    BASELINE, BOTTOM, CENTER, CENTER_X, CENTER_Y, LEFT, NONE, RIGHT, TOP;
    
    static {
      Type type1 = new Type("NONE", 0);
      NONE = type1;
      Type type2 = new Type("LEFT", 1);
      LEFT = type2;
      Type type3 = new Type("TOP", 2);
      TOP = type3;
      Type type4 = new Type("RIGHT", 3);
      RIGHT = type4;
      Type type5 = new Type("BOTTOM", 4);
      BOTTOM = type5;
      Type type6 = new Type("BASELINE", 5);
      BASELINE = type6;
      Type type7 = new Type("CENTER", 6);
      CENTER = type7;
      Type type8 = new Type("CENTER_X", 7);
      CENTER_X = type8;
      Type type9 = new Type("CENTER_Y", 8);
      CENTER_Y = type9;
      $VALUES = new Type[] { type1, type2, type3, type4, type5, type6, type7, type8, type9 };
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\BabyBus TV_Kids Videos & Games-dex2jar.jar!\androidx\constraintlayout\solver\widgets\ConstraintAnchor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */