package androidx.constraintlayout.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.content.res.XmlResourceParser;
import android.graphics.Color;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseArray;
import android.util.SparseIntArray;
import android.util.Xml;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.constraintlayout.motion.utils.Easing;
import androidx.constraintlayout.motion.widget.Debug;
import androidx.constraintlayout.motion.widget.MotionScene;
import androidx.constraintlayout.solver.widgets.ConstraintWidget;
import androidx.constraintlayout.solver.widgets.HelperWidget;
import java.io.IOException;
import java.io.PrintStream;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

public class ConstraintSet {
  private static final int ALPHA = 43;
  
  private static final int ANIMATE_RELATIVE_TO = 64;
  
  private static final int BARRIER_ALLOWS_GONE_WIDGETS = 75;
  
  private static final int BARRIER_DIRECTION = 72;
  
  private static final int BARRIER_MARGIN = 73;
  
  private static final int BARRIER_TYPE = 1;
  
  public static final int BASELINE = 5;
  
  private static final int BASELINE_TO_BASELINE = 1;
  
  public static final int BOTTOM = 4;
  
  private static final int BOTTOM_MARGIN = 2;
  
  private static final int BOTTOM_TO_BOTTOM = 3;
  
  private static final int BOTTOM_TO_TOP = 4;
  
  public static final int CHAIN_PACKED = 2;
  
  public static final int CHAIN_SPREAD = 0;
  
  public static final int CHAIN_SPREAD_INSIDE = 1;
  
  private static final int CHAIN_USE_RTL = 71;
  
  private static final int CIRCLE = 61;
  
  private static final int CIRCLE_ANGLE = 63;
  
  private static final int CIRCLE_RADIUS = 62;
  
  private static final int CONSTRAINED_HEIGHT = 81;
  
  private static final int CONSTRAINED_WIDTH = 80;
  
  private static final int CONSTRAINT_REFERENCED_IDS = 74;
  
  private static final int CONSTRAINT_TAG = 77;
  
  private static final boolean DEBUG = false;
  
  private static final int DIMENSION_RATIO = 5;
  
  private static final int DRAW_PATH = 66;
  
  private static final int EDITOR_ABSOLUTE_X = 6;
  
  private static final int EDITOR_ABSOLUTE_Y = 7;
  
  private static final int ELEVATION = 44;
  
  public static final int END = 7;
  
  private static final int END_MARGIN = 8;
  
  private static final int END_TO_END = 9;
  
  private static final int END_TO_START = 10;
  
  private static final String ERROR_MESSAGE = "XML parser error must be within a Constraint ";
  
  public static final int GONE = 8;
  
  private static final int GONE_BOTTOM_MARGIN = 11;
  
  private static final int GONE_END_MARGIN = 12;
  
  private static final int GONE_LEFT_MARGIN = 13;
  
  private static final int GONE_RIGHT_MARGIN = 14;
  
  private static final int GONE_START_MARGIN = 15;
  
  private static final int GONE_TOP_MARGIN = 16;
  
  private static final int GUIDE_BEGIN = 17;
  
  private static final int GUIDE_END = 18;
  
  private static final int GUIDE_PERCENT = 19;
  
  private static final int HEIGHT_DEFAULT = 55;
  
  private static final int HEIGHT_MAX = 57;
  
  private static final int HEIGHT_MIN = 59;
  
  private static final int HEIGHT_PERCENT = 70;
  
  public static final int HORIZONTAL = 0;
  
  private static final int HORIZONTAL_BIAS = 20;
  
  public static final int HORIZONTAL_GUIDELINE = 0;
  
  private static final int HORIZONTAL_STYLE = 41;
  
  private static final int HORIZONTAL_WEIGHT = 39;
  
  public static final int INVISIBLE = 4;
  
  private static final int LAYOUT_HEIGHT = 21;
  
  private static final int LAYOUT_VISIBILITY = 22;
  
  private static final int LAYOUT_WIDTH = 23;
  
  public static final int LEFT = 1;
  
  private static final int LEFT_MARGIN = 24;
  
  private static final int LEFT_TO_LEFT = 25;
  
  private static final int LEFT_TO_RIGHT = 26;
  
  public static final int MATCH_CONSTRAINT = 0;
  
  public static final int MATCH_CONSTRAINT_SPREAD = 0;
  
  public static final int MATCH_CONSTRAINT_WRAP = 1;
  
  private static final int MOTION_STAGGER = 79;
  
  private static final int ORIENTATION = 27;
  
  public static final int PARENT_ID = 0;
  
  private static final int PATH_MOTION_ARC = 76;
  
  private static final int PROGRESS = 68;
  
  public static final int RIGHT = 2;
  
  private static final int RIGHT_MARGIN = 28;
  
  private static final int RIGHT_TO_LEFT = 29;
  
  private static final int RIGHT_TO_RIGHT = 30;
  
  private static final int ROTATION = 60;
  
  private static final int ROTATION_X = 45;
  
  private static final int ROTATION_Y = 46;
  
  private static final int SCALE_X = 47;
  
  private static final int SCALE_Y = 48;
  
  public static final int START = 6;
  
  private static final int START_MARGIN = 31;
  
  private static final int START_TO_END = 32;
  
  private static final int START_TO_START = 33;
  
  private static final String TAG = "ConstraintSet";
  
  public static final int TOP = 3;
  
  private static final int TOP_MARGIN = 34;
  
  private static final int TOP_TO_BOTTOM = 35;
  
  private static final int TOP_TO_TOP = 36;
  
  private static final int TRANSFORM_PIVOT_X = 49;
  
  private static final int TRANSFORM_PIVOT_Y = 50;
  
  private static final int TRANSITION_EASING = 65;
  
  private static final int TRANSITION_PATH_ROTATE = 67;
  
  private static final int TRANSLATION_X = 51;
  
  private static final int TRANSLATION_Y = 52;
  
  private static final int TRANSLATION_Z = 53;
  
  public static final int UNSET = -1;
  
  private static final int UNUSED = 82;
  
  public static final int VERTICAL = 1;
  
  private static final int VERTICAL_BIAS = 37;
  
  public static final int VERTICAL_GUIDELINE = 1;
  
  private static final int VERTICAL_STYLE = 42;
  
  private static final int VERTICAL_WEIGHT = 40;
  
  private static final int VIEW_ID = 38;
  
  private static final int[] VISIBILITY_FLAGS = new int[] { 0, 4, 8 };
  
  private static final int VISIBILITY_MODE = 78;
  
  public static final int VISIBILITY_MODE_IGNORE = 1;
  
  public static final int VISIBILITY_MODE_NORMAL = 0;
  
  public static final int VISIBLE = 0;
  
  private static final int WIDTH_DEFAULT = 54;
  
  private static final int WIDTH_MAX = 56;
  
  private static final int WIDTH_MIN = 58;
  
  private static final int WIDTH_PERCENT = 69;
  
  public static final int WRAP_CONTENT = -2;
  
  private static SparseIntArray mapToConstant;
  
  private HashMap<Integer, Constraint> mConstraints = new HashMap<Integer, Constraint>();
  
  private boolean mForceId = true;
  
  private HashMap<String, ConstraintAttribute> mSavedAttributes = new HashMap<String, ConstraintAttribute>();
  
  private boolean mValidate;
  
  static {
    SparseIntArray sparseIntArray = new SparseIntArray();
    mapToConstant = sparseIntArray;
    sparseIntArray.append(R.styleable.Constraint_layout_constraintLeft_toLeftOf, 25);
    mapToConstant.append(R.styleable.Constraint_layout_constraintLeft_toRightOf, 26);
    mapToConstant.append(R.styleable.Constraint_layout_constraintRight_toLeftOf, 29);
    mapToConstant.append(R.styleable.Constraint_layout_constraintRight_toRightOf, 30);
    mapToConstant.append(R.styleable.Constraint_layout_constraintTop_toTopOf, 36);
    mapToConstant.append(R.styleable.Constraint_layout_constraintTop_toBottomOf, 35);
    mapToConstant.append(R.styleable.Constraint_layout_constraintBottom_toTopOf, 4);
    mapToConstant.append(R.styleable.Constraint_layout_constraintBottom_toBottomOf, 3);
    mapToConstant.append(R.styleable.Constraint_layout_constraintBaseline_toBaselineOf, 1);
    mapToConstant.append(R.styleable.Constraint_layout_editor_absoluteX, 6);
    mapToConstant.append(R.styleable.Constraint_layout_editor_absoluteY, 7);
    mapToConstant.append(R.styleable.Constraint_layout_constraintGuide_begin, 17);
    mapToConstant.append(R.styleable.Constraint_layout_constraintGuide_end, 18);
    mapToConstant.append(R.styleable.Constraint_layout_constraintGuide_percent, 19);
    mapToConstant.append(R.styleable.Constraint_android_orientation, 27);
    mapToConstant.append(R.styleable.Constraint_layout_constraintStart_toEndOf, 32);
    mapToConstant.append(R.styleable.Constraint_layout_constraintStart_toStartOf, 33);
    mapToConstant.append(R.styleable.Constraint_layout_constraintEnd_toStartOf, 10);
    mapToConstant.append(R.styleable.Constraint_layout_constraintEnd_toEndOf, 9);
    mapToConstant.append(R.styleable.Constraint_layout_goneMarginLeft, 13);
    mapToConstant.append(R.styleable.Constraint_layout_goneMarginTop, 16);
    mapToConstant.append(R.styleable.Constraint_layout_goneMarginRight, 14);
    mapToConstant.append(R.styleable.Constraint_layout_goneMarginBottom, 11);
    mapToConstant.append(R.styleable.Constraint_layout_goneMarginStart, 15);
    mapToConstant.append(R.styleable.Constraint_layout_goneMarginEnd, 12);
    mapToConstant.append(R.styleable.Constraint_layout_constraintVertical_weight, 40);
    mapToConstant.append(R.styleable.Constraint_layout_constraintHorizontal_weight, 39);
    mapToConstant.append(R.styleable.Constraint_layout_constraintHorizontal_chainStyle, 41);
    mapToConstant.append(R.styleable.Constraint_layout_constraintVertical_chainStyle, 42);
    mapToConstant.append(R.styleable.Constraint_layout_constraintHorizontal_bias, 20);
    mapToConstant.append(R.styleable.Constraint_layout_constraintVertical_bias, 37);
    mapToConstant.append(R.styleable.Constraint_layout_constraintDimensionRatio, 5);
    mapToConstant.append(R.styleable.Constraint_layout_constraintLeft_creator, 82);
    mapToConstant.append(R.styleable.Constraint_layout_constraintTop_creator, 82);
    mapToConstant.append(R.styleable.Constraint_layout_constraintRight_creator, 82);
    mapToConstant.append(R.styleable.Constraint_layout_constraintBottom_creator, 82);
    mapToConstant.append(R.styleable.Constraint_layout_constraintBaseline_creator, 82);
    mapToConstant.append(R.styleable.Constraint_android_layout_marginLeft, 24);
    mapToConstant.append(R.styleable.Constraint_android_layout_marginRight, 28);
    mapToConstant.append(R.styleable.Constraint_android_layout_marginStart, 31);
    mapToConstant.append(R.styleable.Constraint_android_layout_marginEnd, 8);
    mapToConstant.append(R.styleable.Constraint_android_layout_marginTop, 34);
    mapToConstant.append(R.styleable.Constraint_android_layout_marginBottom, 2);
    mapToConstant.append(R.styleable.Constraint_android_layout_width, 23);
    mapToConstant.append(R.styleable.Constraint_android_layout_height, 21);
    mapToConstant.append(R.styleable.Constraint_android_visibility, 22);
    mapToConstant.append(R.styleable.Constraint_android_alpha, 43);
    mapToConstant.append(R.styleable.Constraint_android_elevation, 44);
    mapToConstant.append(R.styleable.Constraint_android_rotationX, 45);
    mapToConstant.append(R.styleable.Constraint_android_rotationY, 46);
    mapToConstant.append(R.styleable.Constraint_android_rotation, 60);
    mapToConstant.append(R.styleable.Constraint_android_scaleX, 47);
    mapToConstant.append(R.styleable.Constraint_android_scaleY, 48);
    mapToConstant.append(R.styleable.Constraint_android_transformPivotX, 49);
    mapToConstant.append(R.styleable.Constraint_android_transformPivotY, 50);
    mapToConstant.append(R.styleable.Constraint_android_translationX, 51);
    mapToConstant.append(R.styleable.Constraint_android_translationY, 52);
    mapToConstant.append(R.styleable.Constraint_android_translationZ, 53);
    mapToConstant.append(R.styleable.Constraint_layout_constraintWidth_default, 54);
    mapToConstant.append(R.styleable.Constraint_layout_constraintHeight_default, 55);
    mapToConstant.append(R.styleable.Constraint_layout_constraintWidth_max, 56);
    mapToConstant.append(R.styleable.Constraint_layout_constraintHeight_max, 57);
    mapToConstant.append(R.styleable.Constraint_layout_constraintWidth_min, 58);
    mapToConstant.append(R.styleable.Constraint_layout_constraintHeight_min, 59);
    mapToConstant.append(R.styleable.Constraint_layout_constraintCircle, 61);
    mapToConstant.append(R.styleable.Constraint_layout_constraintCircleRadius, 62);
    mapToConstant.append(R.styleable.Constraint_layout_constraintCircleAngle, 63);
    mapToConstant.append(R.styleable.Constraint_animate_relativeTo, 64);
    mapToConstant.append(R.styleable.Constraint_transitionEasing, 65);
    mapToConstant.append(R.styleable.Constraint_drawPath, 66);
    mapToConstant.append(R.styleable.Constraint_transitionPathRotate, 67);
    mapToConstant.append(R.styleable.Constraint_motionStagger, 79);
    mapToConstant.append(R.styleable.Constraint_android_id, 38);
    mapToConstant.append(R.styleable.Constraint_motionProgress, 68);
    mapToConstant.append(R.styleable.Constraint_layout_constraintWidth_percent, 69);
    mapToConstant.append(R.styleable.Constraint_layout_constraintHeight_percent, 70);
    mapToConstant.append(R.styleable.Constraint_chainUseRtl, 71);
    mapToConstant.append(R.styleable.Constraint_barrierDirection, 72);
    mapToConstant.append(R.styleable.Constraint_barrierMargin, 73);
    mapToConstant.append(R.styleable.Constraint_constraint_referenced_ids, 74);
    mapToConstant.append(R.styleable.Constraint_barrierAllowsGoneWidgets, 75);
    mapToConstant.append(R.styleable.Constraint_pathMotionArc, 76);
    mapToConstant.append(R.styleable.Constraint_layout_constraintTag, 77);
    mapToConstant.append(R.styleable.Constraint_visibilityMode, 78);
    mapToConstant.append(R.styleable.Constraint_layout_constrainedWidth, 80);
    mapToConstant.append(R.styleable.Constraint_layout_constrainedHeight, 81);
  }
  
  private void addAttributes(ConstraintAttribute.AttributeType paramAttributeType, String... paramVarArgs) {
    for (int i = 0; i < paramVarArgs.length; i++) {
      StringBuilder stringBuilder;
      if (this.mSavedAttributes.containsKey(paramVarArgs[i])) {
        ConstraintAttribute constraintAttribute = this.mSavedAttributes.get(paramVarArgs[i]);
        if (constraintAttribute.getType() != paramAttributeType) {
          stringBuilder = new StringBuilder();
          stringBuilder.append("ConstraintAttribute is already a ");
          stringBuilder.append(constraintAttribute.getType().name());
          throw new IllegalArgumentException(stringBuilder.toString());
        } 
      } else {
        ConstraintAttribute constraintAttribute = new ConstraintAttribute(paramVarArgs[i], (ConstraintAttribute.AttributeType)stringBuilder);
        this.mSavedAttributes.put(paramVarArgs[i], constraintAttribute);
      } 
    } 
  }
  
  private int[] convertReferenceString(View paramView, String paramString) {
    String[] arrayOfString = paramString.split(",");
    Context context = paramView.getContext();
    int[] arrayOfInt = new int[arrayOfString.length];
    int j = 0;
    int i = 0;
    while (true) {
      if (j < arrayOfString.length) {
        String str = arrayOfString[j].trim();
        try {
          m = R.id.class.getField(str).getInt(null);
        } catch (Exception exception) {
          m = 0;
        } 
        int k = m;
        if (!m)
          k = context.getResources().getIdentifier(str, "id", context.getPackageName()); 
        int m = k;
        if (k == 0) {
          m = k;
          if (paramView.isInEditMode()) {
            m = k;
            if (paramView.getParent() instanceof ConstraintLayout) {
              Object object = ((ConstraintLayout)paramView.getParent()).getDesignInformation(0, str);
              m = k;
              if (object != null) {
                m = k;
                if (object instanceof Integer)
                  m = ((Integer)object).intValue(); 
              } 
            } 
          } 
        } 
        arrayOfInt[i] = m;
        j++;
        i++;
        continue;
      } 
      int[] arrayOfInt1 = arrayOfInt;
      if (i != arrayOfString.length)
        arrayOfInt1 = Arrays.copyOf(arrayOfInt, i); 
      return arrayOfInt1;
    } 
  }
  
  private void createHorizontalChain(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int[] paramArrayOfint, float[] paramArrayOffloat, int paramInt5, int paramInt6, int paramInt7) {
    if (paramArrayOfint.length >= 2) {
      if (paramArrayOffloat == null || paramArrayOffloat.length == paramArrayOfint.length) {
        if (paramArrayOffloat != null)
          (get(paramArrayOfint[0])).layout.horizontalWeight = paramArrayOffloat[0]; 
        (get(paramArrayOfint[0])).layout.horizontalChainStyle = paramInt5;
        connect(paramArrayOfint[0], paramInt6, paramInt1, paramInt2, -1);
        for (paramInt1 = 1; paramInt1 < paramArrayOfint.length; paramInt1++) {
          paramInt2 = paramArrayOfint[paramInt1];
          paramInt2 = paramArrayOfint[paramInt1];
          paramInt5 = paramInt1 - 1;
          connect(paramInt2, paramInt6, paramArrayOfint[paramInt5], paramInt7, -1);
          connect(paramArrayOfint[paramInt5], paramInt7, paramArrayOfint[paramInt1], paramInt6, -1);
          if (paramArrayOffloat != null)
            (get(paramArrayOfint[paramInt1])).layout.horizontalWeight = paramArrayOffloat[paramInt1]; 
        } 
        connect(paramArrayOfint[paramArrayOfint.length - 1], paramInt7, paramInt3, paramInt4, -1);
        return;
      } 
      throw new IllegalArgumentException("must have 2 or more widgets in a chain");
    } 
    throw new IllegalArgumentException("must have 2 or more widgets in a chain");
  }
  
  private Constraint fillFromAttributeList(Context paramContext, AttributeSet paramAttributeSet) {
    Constraint constraint = new Constraint();
    TypedArray typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, R.styleable.Constraint);
    populateConstraint(paramContext, constraint, typedArray);
    typedArray.recycle();
    return constraint;
  }
  
  private Constraint get(int paramInt) {
    if (!this.mConstraints.containsKey(Integer.valueOf(paramInt)))
      this.mConstraints.put(Integer.valueOf(paramInt), new Constraint()); 
    return this.mConstraints.get(Integer.valueOf(paramInt));
  }
  
  private static int lookupID(TypedArray paramTypedArray, int paramInt1, int paramInt2) {
    int i = paramTypedArray.getResourceId(paramInt1, paramInt2);
    paramInt2 = i;
    if (i == -1)
      paramInt2 = paramTypedArray.getInt(paramInt1, -1); 
    return paramInt2;
  }
  
  private void populateConstraint(Context paramContext, Constraint paramConstraint, TypedArray paramTypedArray) {
    int j = paramTypedArray.getIndexCount();
    int i;
    for (i = 0; i < j; i++) {
      StringBuilder stringBuilder;
      Layout layout6;
      Motion motion3;
      PropertySet propertySet4;
      Motion motion2;
      Layout layout5;
      PropertySet propertySet3;
      Motion motion1;
      Layout layout4;
      Transform transform2;
      Layout layout3;
      Transform transform1;
      PropertySet propertySet2;
      Layout layout2;
      PropertySet propertySet1;
      Layout layout1;
      int k = paramTypedArray.getIndex(i);
      if (k != R.styleable.Constraint_android_id && R.styleable.Constraint_android_layout_marginStart != k && R.styleable.Constraint_android_layout_marginEnd != k) {
        paramConstraint.motion.mApply = true;
        paramConstraint.layout.mApply = true;
        paramConstraint.propertySet.mApply = true;
        paramConstraint.transform.mApply = true;
      } 
      switch (mapToConstant.get(k)) {
        default:
          stringBuilder = new StringBuilder();
          stringBuilder.append("Unknown attribute 0x");
          stringBuilder.append(Integer.toHexString(k));
          stringBuilder.append("   ");
          stringBuilder.append(mapToConstant.get(k));
          Log.w("ConstraintSet", stringBuilder.toString());
          break;
        case 82:
          stringBuilder = new StringBuilder();
          stringBuilder.append("unused attribute 0x");
          stringBuilder.append(Integer.toHexString(k));
          stringBuilder.append("   ");
          stringBuilder.append(mapToConstant.get(k));
          Log.w("ConstraintSet", stringBuilder.toString());
          break;
        case 81:
          layout6 = paramConstraint.layout;
          layout6.constrainedHeight = paramTypedArray.getBoolean(k, layout6.constrainedHeight);
          break;
        case 80:
          layout6 = paramConstraint.layout;
          layout6.constrainedWidth = paramTypedArray.getBoolean(k, layout6.constrainedWidth);
          break;
        case 79:
          motion3 = paramConstraint.motion;
          motion3.mMotionStagger = paramTypedArray.getFloat(k, motion3.mMotionStagger);
          break;
        case 78:
          propertySet4 = paramConstraint.propertySet;
          propertySet4.mVisibilityMode = paramTypedArray.getInt(k, propertySet4.mVisibilityMode);
          break;
        case 77:
          paramConstraint.layout.mConstraintTag = paramTypedArray.getString(k);
          break;
        case 76:
          motion2 = paramConstraint.motion;
          motion2.mPathMotionArc = paramTypedArray.getInt(k, motion2.mPathMotionArc);
          break;
        case 75:
          layout5 = paramConstraint.layout;
          layout5.mBarrierAllowsGoneWidgets = paramTypedArray.getBoolean(k, layout5.mBarrierAllowsGoneWidgets);
          break;
        case 74:
          paramConstraint.layout.mReferenceIdString = paramTypedArray.getString(k);
          break;
        case 73:
          layout5 = paramConstraint.layout;
          layout5.mBarrierMargin = paramTypedArray.getDimensionPixelSize(k, layout5.mBarrierMargin);
          break;
        case 72:
          layout5 = paramConstraint.layout;
          layout5.mBarrierDirection = paramTypedArray.getInt(k, layout5.mBarrierDirection);
          break;
        case 71:
          Log.e("ConstraintSet", "CURRENTLY UNSUPPORTED");
          break;
        case 70:
          paramConstraint.layout.heightPercent = paramTypedArray.getFloat(k, 1.0F);
          break;
        case 69:
          paramConstraint.layout.widthPercent = paramTypedArray.getFloat(k, 1.0F);
          break;
        case 68:
          propertySet3 = paramConstraint.propertySet;
          propertySet3.mProgress = paramTypedArray.getFloat(k, propertySet3.mProgress);
          break;
        case 67:
          motion1 = paramConstraint.motion;
          motion1.mPathRotate = paramTypedArray.getFloat(k, motion1.mPathRotate);
          break;
        case 66:
          paramConstraint.motion.mDrawPath = paramTypedArray.getInt(k, 0);
          break;
        case 65:
          if ((paramTypedArray.peekValue(k)).type == 3) {
            paramConstraint.motion.mTransitionEasing = paramTypedArray.getString(k);
            break;
          } 
          paramConstraint.motion.mTransitionEasing = Easing.NAMED_EASING[paramTypedArray.getInteger(k, 0)];
          break;
        case 64:
          motion1 = paramConstraint.motion;
          motion1.mAnimateRelativeTo = lookupID(paramTypedArray, k, motion1.mAnimateRelativeTo);
          break;
        case 63:
          layout4 = paramConstraint.layout;
          layout4.circleAngle = paramTypedArray.getFloat(k, layout4.circleAngle);
          break;
        case 62:
          layout4 = paramConstraint.layout;
          layout4.circleRadius = paramTypedArray.getDimensionPixelSize(k, layout4.circleRadius);
          break;
        case 61:
          layout4 = paramConstraint.layout;
          layout4.circleConstraint = lookupID(paramTypedArray, k, layout4.circleConstraint);
          break;
        case 60:
          transform2 = paramConstraint.transform;
          transform2.rotation = paramTypedArray.getFloat(k, transform2.rotation);
          break;
        case 59:
          layout3 = paramConstraint.layout;
          layout3.heightMin = paramTypedArray.getDimensionPixelSize(k, layout3.heightMin);
          break;
        case 58:
          layout3 = paramConstraint.layout;
          layout3.widthMin = paramTypedArray.getDimensionPixelSize(k, layout3.widthMin);
          break;
        case 57:
          layout3 = paramConstraint.layout;
          layout3.heightMax = paramTypedArray.getDimensionPixelSize(k, layout3.heightMax);
          break;
        case 56:
          layout3 = paramConstraint.layout;
          layout3.widthMax = paramTypedArray.getDimensionPixelSize(k, layout3.widthMax);
          break;
        case 55:
          layout3 = paramConstraint.layout;
          layout3.heightDefault = paramTypedArray.getInt(k, layout3.heightDefault);
          break;
        case 54:
          layout3 = paramConstraint.layout;
          layout3.widthDefault = paramTypedArray.getInt(k, layout3.widthDefault);
          break;
        case 53:
          transform1 = paramConstraint.transform;
          transform1.translationZ = paramTypedArray.getDimension(k, transform1.translationZ);
          break;
        case 52:
          transform1 = paramConstraint.transform;
          transform1.translationY = paramTypedArray.getDimension(k, transform1.translationY);
          break;
        case 51:
          transform1 = paramConstraint.transform;
          transform1.translationX = paramTypedArray.getDimension(k, transform1.translationX);
          break;
        case 50:
          transform1 = paramConstraint.transform;
          transform1.transformPivotY = paramTypedArray.getDimension(k, transform1.transformPivotY);
          break;
        case 49:
          transform1 = paramConstraint.transform;
          transform1.transformPivotX = paramTypedArray.getDimension(k, transform1.transformPivotX);
          break;
        case 48:
          transform1 = paramConstraint.transform;
          transform1.scaleY = paramTypedArray.getFloat(k, transform1.scaleY);
          break;
        case 47:
          transform1 = paramConstraint.transform;
          transform1.scaleX = paramTypedArray.getFloat(k, transform1.scaleX);
          break;
        case 46:
          transform1 = paramConstraint.transform;
          transform1.rotationY = paramTypedArray.getFloat(k, transform1.rotationY);
          break;
        case 45:
          transform1 = paramConstraint.transform;
          transform1.rotationX = paramTypedArray.getFloat(k, transform1.rotationX);
          break;
        case 44:
          transform1 = paramConstraint.transform;
          transform1.applyElevation = true;
          transform1.elevation = paramTypedArray.getDimension(k, transform1.elevation);
          break;
        case 43:
          propertySet2 = paramConstraint.propertySet;
          propertySet2.alpha = paramTypedArray.getFloat(k, propertySet2.alpha);
          break;
        case 42:
          layout2 = paramConstraint.layout;
          layout2.verticalChainStyle = paramTypedArray.getInt(k, layout2.verticalChainStyle);
          break;
        case 41:
          layout2 = paramConstraint.layout;
          layout2.horizontalChainStyle = paramTypedArray.getInt(k, layout2.horizontalChainStyle);
          break;
        case 40:
          layout2 = paramConstraint.layout;
          layout2.verticalWeight = paramTypedArray.getFloat(k, layout2.verticalWeight);
          break;
        case 39:
          layout2 = paramConstraint.layout;
          layout2.horizontalWeight = paramTypedArray.getFloat(k, layout2.horizontalWeight);
          break;
        case 38:
          paramConstraint.mViewId = paramTypedArray.getResourceId(k, paramConstraint.mViewId);
          break;
        case 37:
          layout2 = paramConstraint.layout;
          layout2.verticalBias = paramTypedArray.getFloat(k, layout2.verticalBias);
          break;
        case 36:
          layout2 = paramConstraint.layout;
          layout2.topToTop = lookupID(paramTypedArray, k, layout2.topToTop);
          break;
        case 35:
          layout2 = paramConstraint.layout;
          layout2.topToBottom = lookupID(paramTypedArray, k, layout2.topToBottom);
          break;
        case 34:
          layout2 = paramConstraint.layout;
          layout2.topMargin = paramTypedArray.getDimensionPixelSize(k, layout2.topMargin);
          break;
        case 33:
          layout2 = paramConstraint.layout;
          layout2.startToStart = lookupID(paramTypedArray, k, layout2.startToStart);
          break;
        case 32:
          layout2 = paramConstraint.layout;
          layout2.startToEnd = lookupID(paramTypedArray, k, layout2.startToEnd);
          break;
        case 31:
          layout2 = paramConstraint.layout;
          layout2.startMargin = paramTypedArray.getDimensionPixelSize(k, layout2.startMargin);
          break;
        case 30:
          layout2 = paramConstraint.layout;
          layout2.rightToRight = lookupID(paramTypedArray, k, layout2.rightToRight);
          break;
        case 29:
          layout2 = paramConstraint.layout;
          layout2.rightToLeft = lookupID(paramTypedArray, k, layout2.rightToLeft);
          break;
        case 28:
          layout2 = paramConstraint.layout;
          layout2.rightMargin = paramTypedArray.getDimensionPixelSize(k, layout2.rightMargin);
          break;
        case 27:
          layout2 = paramConstraint.layout;
          layout2.orientation = paramTypedArray.getInt(k, layout2.orientation);
          break;
        case 26:
          layout2 = paramConstraint.layout;
          layout2.leftToRight = lookupID(paramTypedArray, k, layout2.leftToRight);
          break;
        case 25:
          layout2 = paramConstraint.layout;
          layout2.leftToLeft = lookupID(paramTypedArray, k, layout2.leftToLeft);
          break;
        case 24:
          layout2 = paramConstraint.layout;
          layout2.leftMargin = paramTypedArray.getDimensionPixelSize(k, layout2.leftMargin);
          break;
        case 23:
          layout2 = paramConstraint.layout;
          layout2.mWidth = paramTypedArray.getLayoutDimension(k, layout2.mWidth);
          break;
        case 22:
          propertySet1 = paramConstraint.propertySet;
          propertySet1.visibility = paramTypedArray.getInt(k, propertySet1.visibility);
          propertySet1 = paramConstraint.propertySet;
          propertySet1.visibility = VISIBILITY_FLAGS[propertySet1.visibility];
          break;
        case 21:
          layout1 = paramConstraint.layout;
          layout1.mHeight = paramTypedArray.getLayoutDimension(k, layout1.mHeight);
          break;
        case 20:
          layout1 = paramConstraint.layout;
          layout1.horizontalBias = paramTypedArray.getFloat(k, layout1.horizontalBias);
          break;
        case 19:
          layout1 = paramConstraint.layout;
          layout1.guidePercent = paramTypedArray.getFloat(k, layout1.guidePercent);
          break;
        case 18:
          layout1 = paramConstraint.layout;
          layout1.guideEnd = paramTypedArray.getDimensionPixelOffset(k, layout1.guideEnd);
          break;
        case 17:
          layout1 = paramConstraint.layout;
          layout1.guideBegin = paramTypedArray.getDimensionPixelOffset(k, layout1.guideBegin);
          break;
        case 16:
          layout1 = paramConstraint.layout;
          layout1.goneTopMargin = paramTypedArray.getDimensionPixelSize(k, layout1.goneTopMargin);
          break;
        case 15:
          layout1 = paramConstraint.layout;
          layout1.goneStartMargin = paramTypedArray.getDimensionPixelSize(k, layout1.goneStartMargin);
          break;
        case 14:
          layout1 = paramConstraint.layout;
          layout1.goneRightMargin = paramTypedArray.getDimensionPixelSize(k, layout1.goneRightMargin);
          break;
        case 13:
          layout1 = paramConstraint.layout;
          layout1.goneLeftMargin = paramTypedArray.getDimensionPixelSize(k, layout1.goneLeftMargin);
          break;
        case 12:
          layout1 = paramConstraint.layout;
          layout1.goneEndMargin = paramTypedArray.getDimensionPixelSize(k, layout1.goneEndMargin);
          break;
        case 11:
          layout1 = paramConstraint.layout;
          layout1.goneBottomMargin = paramTypedArray.getDimensionPixelSize(k, layout1.goneBottomMargin);
          break;
        case 10:
          layout1 = paramConstraint.layout;
          layout1.endToStart = lookupID(paramTypedArray, k, layout1.endToStart);
          break;
        case 9:
          layout1 = paramConstraint.layout;
          layout1.endToEnd = lookupID(paramTypedArray, k, layout1.endToEnd);
          break;
        case 8:
          layout1 = paramConstraint.layout;
          layout1.endMargin = paramTypedArray.getDimensionPixelSize(k, layout1.endMargin);
          break;
        case 7:
          layout1 = paramConstraint.layout;
          layout1.editorAbsoluteY = paramTypedArray.getDimensionPixelOffset(k, layout1.editorAbsoluteY);
          break;
        case 6:
          layout1 = paramConstraint.layout;
          layout1.editorAbsoluteX = paramTypedArray.getDimensionPixelOffset(k, layout1.editorAbsoluteX);
          break;
        case 5:
          paramConstraint.layout.dimensionRatio = paramTypedArray.getString(k);
          break;
        case 4:
          layout1 = paramConstraint.layout;
          layout1.bottomToTop = lookupID(paramTypedArray, k, layout1.bottomToTop);
          break;
        case 3:
          layout1 = paramConstraint.layout;
          layout1.bottomToBottom = lookupID(paramTypedArray, k, layout1.bottomToBottom);
          break;
        case 2:
          layout1 = paramConstraint.layout;
          layout1.bottomMargin = paramTypedArray.getDimensionPixelSize(k, layout1.bottomMargin);
          break;
        case 1:
          layout1 = paramConstraint.layout;
          layout1.baselineToBaseline = lookupID(paramTypedArray, k, layout1.baselineToBaseline);
          break;
      } 
    } 
  }
  
  private String sideToString(int paramInt) {
    switch (paramInt) {
      default:
        return "undefined";
      case 7:
        return "end";
      case 6:
        return "start";
      case 5:
        return "baseline";
      case 4:
        return "bottom";
      case 3:
        return "top";
      case 2:
        return "right";
      case 1:
        break;
    } 
    return "left";
  }
  
  private static String[] splitString(String paramString) {
    char[] arrayOfChar = paramString.toCharArray();
    ArrayList<String> arrayList = new ArrayList();
    int j = 0;
    byte b = 0;
    for (int i = 0; j < arrayOfChar.length; i = k) {
      byte b1;
      int k;
      if (arrayOfChar[j] == ',' && !i) {
        arrayList.add(new String(arrayOfChar, b, j - b));
        b1 = j + 1;
        k = i;
      } else {
        b1 = b;
        k = i;
        if (arrayOfChar[j] == '"') {
          k = i ^ 0x1;
          b1 = b;
        } 
      } 
      j++;
      b = b1;
    } 
    arrayList.add(new String(arrayOfChar, b, arrayOfChar.length - b));
    return arrayList.<String>toArray(new String[arrayList.size()]);
  }
  
  public void addColorAttributes(String... paramVarArgs) {
    addAttributes(ConstraintAttribute.AttributeType.COLOR_TYPE, paramVarArgs);
  }
  
  public void addFloatAttributes(String... paramVarArgs) {
    addAttributes(ConstraintAttribute.AttributeType.FLOAT_TYPE, paramVarArgs);
  }
  
  public void addIntAttributes(String... paramVarArgs) {
    addAttributes(ConstraintAttribute.AttributeType.INT_TYPE, paramVarArgs);
  }
  
  public void addStringAttributes(String... paramVarArgs) {
    addAttributes(ConstraintAttribute.AttributeType.STRING_TYPE, paramVarArgs);
  }
  
  public void addToHorizontalChain(int paramInt1, int paramInt2, int paramInt3) {
    byte b;
    if (paramInt2 == 0) {
      b = 1;
    } else {
      b = 2;
    } 
    connect(paramInt1, 1, paramInt2, b, 0);
    if (paramInt3 == 0) {
      b = 2;
    } else {
      b = 1;
    } 
    connect(paramInt1, 2, paramInt3, b, 0);
    if (paramInt2 != 0)
      connect(paramInt2, 2, paramInt1, 1, 0); 
    if (paramInt3 != 0)
      connect(paramInt3, 1, paramInt1, 2, 0); 
  }
  
  public void addToHorizontalChainRTL(int paramInt1, int paramInt2, int paramInt3) {
    byte b;
    if (paramInt2 == 0) {
      b = 6;
    } else {
      b = 7;
    } 
    connect(paramInt1, 6, paramInt2, b, 0);
    if (paramInt3 == 0) {
      b = 7;
    } else {
      b = 6;
    } 
    connect(paramInt1, 7, paramInt3, b, 0);
    if (paramInt2 != 0)
      connect(paramInt2, 7, paramInt1, 6, 0); 
    if (paramInt3 != 0)
      connect(paramInt3, 6, paramInt1, 7, 0); 
  }
  
  public void addToVerticalChain(int paramInt1, int paramInt2, int paramInt3) {
    byte b;
    if (paramInt2 == 0) {
      b = 3;
    } else {
      b = 4;
    } 
    connect(paramInt1, 3, paramInt2, b, 0);
    if (paramInt3 == 0) {
      b = 4;
    } else {
      b = 3;
    } 
    connect(paramInt1, 4, paramInt3, b, 0);
    if (paramInt2 != 0)
      connect(paramInt2, 4, paramInt1, 3, 0); 
    if (paramInt3 != 0)
      connect(paramInt3, 3, paramInt1, 4, 0); 
  }
  
  public void applyCustomAttributes(ConstraintLayout paramConstraintLayout) {
    int j = paramConstraintLayout.getChildCount();
    for (int i = 0; i < j; i++) {
      View view = paramConstraintLayout.getChildAt(i);
      int k = view.getId();
      if (!this.mConstraints.containsKey(Integer.valueOf(k))) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("id unknown ");
        stringBuilder.append(Debug.getName(view));
        Log.v("ConstraintSet", stringBuilder.toString());
      } else if (!this.mForceId || k != -1) {
        if (this.mConstraints.containsKey(Integer.valueOf(k)))
          ConstraintAttribute.setAttributes(view, ((Constraint)this.mConstraints.get(Integer.valueOf(k))).mCustomConstraints); 
      } else {
        throw new RuntimeException("All children of ConstraintLayout must have ids to use ConstraintSet");
      } 
    } 
  }
  
  public void applyTo(ConstraintLayout paramConstraintLayout) {
    applyToInternal(paramConstraintLayout, true);
    paramConstraintLayout.setConstraintSet(null);
    paramConstraintLayout.requestLayout();
  }
  
  public void applyToHelper(ConstraintHelper paramConstraintHelper, ConstraintWidget paramConstraintWidget, ConstraintLayout.LayoutParams paramLayoutParams, SparseArray<ConstraintWidget> paramSparseArray) {
    int i = paramConstraintHelper.getId();
    if (this.mConstraints.containsKey(Integer.valueOf(i))) {
      Constraint constraint = this.mConstraints.get(Integer.valueOf(i));
      if (paramConstraintWidget instanceof HelperWidget)
        paramConstraintHelper.loadParameters(constraint, (HelperWidget)paramConstraintWidget, paramLayoutParams, paramSparseArray); 
    } 
  }
  
  void applyToInternal(ConstraintLayout paramConstraintLayout, boolean paramBoolean) {
    int j = paramConstraintLayout.getChildCount();
    HashSet hashSet = new HashSet(this.mConstraints.keySet());
    int i;
    for (i = 0; i < j; i++) {
      View view = paramConstraintLayout.getChildAt(i);
      int k = view.getId();
      if (!this.mConstraints.containsKey(Integer.valueOf(k))) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("id unknown ");
        stringBuilder.append(Debug.getName(view));
        Log.w("ConstraintSet", stringBuilder.toString());
      } else if (!this.mForceId || k != -1) {
        if (k != -1)
          if (this.mConstraints.containsKey(Integer.valueOf(k))) {
            hashSet.remove(Integer.valueOf(k));
            Constraint constraint = this.mConstraints.get(Integer.valueOf(k));
            if (view instanceof Barrier)
              constraint.layout.mHelperType = 1; 
            int m = constraint.layout.mHelperType;
            if (m != -1 && m == 1) {
              Barrier barrier = (Barrier)view;
              barrier.setId(k);
              barrier.setType(constraint.layout.mBarrierDirection);
              barrier.setMargin(constraint.layout.mBarrierMargin);
              barrier.setAllowsGoneWidget(constraint.layout.mBarrierAllowsGoneWidgets);
              Layout layout = constraint.layout;
              int[] arrayOfInt = layout.mReferenceIds;
              if (arrayOfInt != null) {
                barrier.setReferencedIds(arrayOfInt);
              } else {
                String str = layout.mReferenceIdString;
                if (str != null) {
                  layout.mReferenceIds = convertReferenceString(barrier, str);
                  barrier.setReferencedIds(constraint.layout.mReferenceIds);
                } 
              } 
            } 
            ConstraintLayout.LayoutParams layoutParams = (ConstraintLayout.LayoutParams)view.getLayoutParams();
            layoutParams.validate();
            constraint.applyTo(layoutParams);
            if (paramBoolean)
              ConstraintAttribute.setAttributes(view, constraint.mCustomConstraints); 
            view.setLayoutParams((ViewGroup.LayoutParams)layoutParams);
            PropertySet propertySet = constraint.propertySet;
            if (propertySet.mVisibilityMode == 0)
              view.setVisibility(propertySet.visibility); 
            view.setAlpha(constraint.propertySet.alpha);
            view.setRotation(constraint.transform.rotation);
            view.setRotationX(constraint.transform.rotationX);
            view.setRotationY(constraint.transform.rotationY);
            view.setScaleX(constraint.transform.scaleX);
            view.setScaleY(constraint.transform.scaleY);
            if (!Float.isNaN(constraint.transform.transformPivotX))
              view.setPivotX(constraint.transform.transformPivotX); 
            if (!Float.isNaN(constraint.transform.transformPivotY))
              view.setPivotY(constraint.transform.transformPivotY); 
            view.setTranslationX(constraint.transform.translationX);
            view.setTranslationY(constraint.transform.translationY);
            view.setTranslationZ(constraint.transform.translationZ);
            Transform transform = constraint.transform;
            if (transform.applyElevation)
              view.setElevation(transform.elevation); 
          } else {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("WARNING NO CONSTRAINTS for view ");
            stringBuilder.append(k);
            Log.v("ConstraintSet", stringBuilder.toString());
          }  
      } else {
        throw new RuntimeException("All children of ConstraintLayout must have ids to use ConstraintSet");
      } 
    } 
    for (Integer integer : hashSet) {
      Constraint constraint = this.mConstraints.get(integer);
      i = constraint.layout.mHelperType;
      if (i != -1 && i == 1) {
        Barrier barrier = new Barrier(paramConstraintLayout.getContext());
        barrier.setId(integer.intValue());
        Layout layout = constraint.layout;
        int[] arrayOfInt = layout.mReferenceIds;
        if (arrayOfInt != null) {
          barrier.setReferencedIds(arrayOfInt);
        } else {
          String str = layout.mReferenceIdString;
          if (str != null) {
            layout.mReferenceIds = convertReferenceString(barrier, str);
            barrier.setReferencedIds(constraint.layout.mReferenceIds);
          } 
        } 
        barrier.setType(constraint.layout.mBarrierDirection);
        barrier.setMargin(constraint.layout.mBarrierMargin);
        ConstraintLayout.LayoutParams layoutParams = paramConstraintLayout.generateDefaultLayoutParams();
        barrier.validateParams();
        constraint.applyTo(layoutParams);
        paramConstraintLayout.addView(barrier, (ViewGroup.LayoutParams)layoutParams);
      } 
      if (constraint.layout.mIsGuideline) {
        Guideline guideline = new Guideline(paramConstraintLayout.getContext());
        guideline.setId(integer.intValue());
        ConstraintLayout.LayoutParams layoutParams = paramConstraintLayout.generateDefaultLayoutParams();
        constraint.applyTo(layoutParams);
        paramConstraintLayout.addView(guideline, (ViewGroup.LayoutParams)layoutParams);
      } 
    } 
  }
  
  public void applyToLayoutParams(int paramInt, ConstraintLayout.LayoutParams paramLayoutParams) {
    if (this.mConstraints.containsKey(Integer.valueOf(paramInt)))
      ((Constraint)this.mConstraints.get(Integer.valueOf(paramInt))).applyTo(paramLayoutParams); 
  }
  
  public void applyToWithoutCustom(ConstraintLayout paramConstraintLayout) {
    applyToInternal(paramConstraintLayout, false);
    paramConstraintLayout.setConstraintSet(null);
  }
  
  public void center(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, float paramFloat) {
    if (paramInt4 >= 0) {
      if (paramInt7 >= 0) {
        if (paramFloat > 0.0F && paramFloat <= 1.0F) {
          if (paramInt3 == 1 || paramInt3 == 2) {
            connect(paramInt1, 1, paramInt2, paramInt3, paramInt4);
            connect(paramInt1, 2, paramInt5, paramInt6, paramInt7);
            ((Constraint)this.mConstraints.get(Integer.valueOf(paramInt1))).layout.horizontalBias = paramFloat;
            return;
          } 
          if (paramInt3 == 6 || paramInt3 == 7) {
            connect(paramInt1, 6, paramInt2, paramInt3, paramInt4);
            connect(paramInt1, 7, paramInt5, paramInt6, paramInt7);
            ((Constraint)this.mConstraints.get(Integer.valueOf(paramInt1))).layout.horizontalBias = paramFloat;
            return;
          } 
          connect(paramInt1, 3, paramInt2, paramInt3, paramInt4);
          connect(paramInt1, 4, paramInt5, paramInt6, paramInt7);
          ((Constraint)this.mConstraints.get(Integer.valueOf(paramInt1))).layout.verticalBias = paramFloat;
          return;
        } 
        throw new IllegalArgumentException("bias must be between 0 and 1 inclusive");
      } 
      throw new IllegalArgumentException("margin must be > 0");
    } 
    throw new IllegalArgumentException("margin must be > 0");
  }
  
  public void centerHorizontally(int paramInt1, int paramInt2) {
    if (paramInt2 == 0) {
      center(paramInt1, 0, 1, 0, 0, 2, 0, 0.5F);
      return;
    } 
    center(paramInt1, paramInt2, 2, 0, paramInt2, 1, 0, 0.5F);
  }
  
  public void centerHorizontally(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, float paramFloat) {
    connect(paramInt1, 1, paramInt2, paramInt3, paramInt4);
    connect(paramInt1, 2, paramInt5, paramInt6, paramInt7);
    ((Constraint)this.mConstraints.get(Integer.valueOf(paramInt1))).layout.horizontalBias = paramFloat;
  }
  
  public void centerHorizontallyRtl(int paramInt1, int paramInt2) {
    if (paramInt2 == 0) {
      center(paramInt1, 0, 6, 0, 0, 7, 0, 0.5F);
      return;
    } 
    center(paramInt1, paramInt2, 7, 0, paramInt2, 6, 0, 0.5F);
  }
  
  public void centerHorizontallyRtl(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, float paramFloat) {
    connect(paramInt1, 6, paramInt2, paramInt3, paramInt4);
    connect(paramInt1, 7, paramInt5, paramInt6, paramInt7);
    ((Constraint)this.mConstraints.get(Integer.valueOf(paramInt1))).layout.horizontalBias = paramFloat;
  }
  
  public void centerVertically(int paramInt1, int paramInt2) {
    if (paramInt2 == 0) {
      center(paramInt1, 0, 3, 0, 0, 4, 0, 0.5F);
      return;
    } 
    center(paramInt1, paramInt2, 4, 0, paramInt2, 3, 0, 0.5F);
  }
  
  public void centerVertically(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, float paramFloat) {
    connect(paramInt1, 3, paramInt2, paramInt3, paramInt4);
    connect(paramInt1, 4, paramInt5, paramInt6, paramInt7);
    ((Constraint)this.mConstraints.get(Integer.valueOf(paramInt1))).layout.verticalBias = paramFloat;
  }
  
  public void clear(int paramInt) {
    this.mConstraints.remove(Integer.valueOf(paramInt));
  }
  
  public void clear(int paramInt1, int paramInt2) {
    if (this.mConstraints.containsKey(Integer.valueOf(paramInt1))) {
      Constraint constraint = this.mConstraints.get(Integer.valueOf(paramInt1));
      switch (paramInt2) {
        default:
          throw new IllegalArgumentException("unknown constraint");
        case 7:
          layout = constraint.layout;
          layout.endToStart = -1;
          layout.endToEnd = -1;
          layout.endMargin = -1;
          layout.goneEndMargin = -1;
          return;
        case 6:
          layout = ((Constraint)layout).layout;
          layout.startToEnd = -1;
          layout.startToStart = -1;
          layout.startMargin = -1;
          layout.goneStartMargin = -1;
          return;
        case 5:
          ((Constraint)layout).layout.baselineToBaseline = -1;
          return;
        case 4:
          layout = ((Constraint)layout).layout;
          layout.bottomToTop = -1;
          layout.bottomToBottom = -1;
          layout.bottomMargin = -1;
          layout.goneBottomMargin = -1;
          return;
        case 3:
          layout = ((Constraint)layout).layout;
          layout.topToBottom = -1;
          layout.topToTop = -1;
          layout.topMargin = -1;
          layout.goneTopMargin = -1;
          return;
        case 2:
          layout = ((Constraint)layout).layout;
          layout.rightToRight = -1;
          layout.rightToLeft = -1;
          layout.rightMargin = -1;
          layout.goneRightMargin = -1;
          return;
        case 1:
          break;
      } 
      Layout layout = ((Constraint)layout).layout;
      layout.leftToRight = -1;
      layout.leftToLeft = -1;
      layout.leftMargin = -1;
      layout.goneLeftMargin = -1;
    } 
  }
  
  public void clone(Context paramContext, int paramInt) {
    clone((ConstraintLayout)LayoutInflater.from(paramContext).inflate(paramInt, null));
  }
  
  public void clone(ConstraintLayout paramConstraintLayout) {
    int j = paramConstraintLayout.getChildCount();
    this.mConstraints.clear();
    int i = 0;
    while (i < j) {
      View view = paramConstraintLayout.getChildAt(i);
      ConstraintLayout.LayoutParams layoutParams = (ConstraintLayout.LayoutParams)view.getLayoutParams();
      int k = view.getId();
      if (!this.mForceId || k != -1) {
        if (!this.mConstraints.containsKey(Integer.valueOf(k)))
          this.mConstraints.put(Integer.valueOf(k), new Constraint()); 
        Constraint constraint = this.mConstraints.get(Integer.valueOf(k));
        constraint.mCustomConstraints = ConstraintAttribute.extractAttributes(this.mSavedAttributes, view);
        constraint.fillFrom(k, layoutParams);
        constraint.propertySet.visibility = view.getVisibility();
        constraint.propertySet.alpha = view.getAlpha();
        constraint.transform.rotation = view.getRotation();
        constraint.transform.rotationX = view.getRotationX();
        constraint.transform.rotationY = view.getRotationY();
        constraint.transform.scaleX = view.getScaleX();
        constraint.transform.scaleY = view.getScaleY();
        float f1 = view.getPivotX();
        float f2 = view.getPivotY();
        if (f1 != 0.0D || f2 != 0.0D) {
          Transform transform1 = constraint.transform;
          transform1.transformPivotX = f1;
          transform1.transformPivotY = f2;
        } 
        constraint.transform.translationX = view.getTranslationX();
        constraint.transform.translationY = view.getTranslationY();
        constraint.transform.translationZ = view.getTranslationZ();
        Transform transform = constraint.transform;
        if (transform.applyElevation)
          transform.elevation = view.getElevation(); 
        if (view instanceof Barrier) {
          view = view;
          constraint.layout.mBarrierAllowsGoneWidgets = view.allowsGoneWidget();
          constraint.layout.mReferenceIds = view.getReferencedIds();
          constraint.layout.mBarrierDirection = view.getType();
          constraint.layout.mBarrierMargin = view.getMargin();
        } 
        i++;
        continue;
      } 
      throw new RuntimeException("All children of ConstraintLayout must have ids to use ConstraintSet");
    } 
  }
  
  public void clone(ConstraintSet paramConstraintSet) {
    this.mConstraints.clear();
    for (Integer integer : paramConstraintSet.mConstraints.keySet())
      this.mConstraints.put(integer, ((Constraint)paramConstraintSet.mConstraints.get(integer)).clone()); 
  }
  
  public void clone(Constraints paramConstraints) {
    int j = paramConstraints.getChildCount();
    this.mConstraints.clear();
    int i = 0;
    while (i < j) {
      View view = paramConstraints.getChildAt(i);
      Constraints.LayoutParams layoutParams = (Constraints.LayoutParams)view.getLayoutParams();
      int k = view.getId();
      if (!this.mForceId || k != -1) {
        if (!this.mConstraints.containsKey(Integer.valueOf(k)))
          this.mConstraints.put(Integer.valueOf(k), new Constraint()); 
        Constraint constraint = this.mConstraints.get(Integer.valueOf(k));
        if (view instanceof ConstraintHelper)
          constraint.fillFromConstraints((ConstraintHelper)view, k, layoutParams); 
        constraint.fillFromConstraints(k, layoutParams);
        i++;
        continue;
      } 
      throw new RuntimeException("All children of ConstraintLayout must have ids to use ConstraintSet");
    } 
  }
  
  public void connect(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    StringBuilder stringBuilder7;
    Layout layout6;
    StringBuilder stringBuilder6;
    Layout layout5;
    StringBuilder stringBuilder5;
    Layout layout4;
    StringBuilder stringBuilder4;
    Layout layout3;
    StringBuilder stringBuilder3;
    Layout layout2;
    StringBuilder stringBuilder2;
    Layout layout1;
    if (!this.mConstraints.containsKey(Integer.valueOf(paramInt1)))
      this.mConstraints.put(Integer.valueOf(paramInt1), new Constraint()); 
    Constraint constraint = this.mConstraints.get(Integer.valueOf(paramInt1));
    switch (paramInt2) {
      default:
        stringBuilder7 = new StringBuilder();
        stringBuilder7.append(sideToString(paramInt2));
        stringBuilder7.append(" to ");
        stringBuilder7.append(sideToString(paramInt4));
        stringBuilder7.append(" unknown");
        throw new IllegalArgumentException(stringBuilder7.toString());
      case 7:
        if (paramInt4 == 7) {
          layout6 = ((Constraint)stringBuilder7).layout;
          layout6.endToEnd = paramInt3;
          layout6.endToStart = -1;
          return;
        } 
        if (paramInt4 == 6) {
          layout6 = ((Constraint)layout6).layout;
          layout6.endToStart = paramInt3;
          layout6.endToEnd = -1;
          return;
        } 
        stringBuilder6 = new StringBuilder();
        stringBuilder6.append("right to ");
        stringBuilder6.append(sideToString(paramInt4));
        stringBuilder6.append(" undefined");
        throw new IllegalArgumentException(stringBuilder6.toString());
      case 6:
        if (paramInt4 == 6) {
          layout5 = ((Constraint)stringBuilder6).layout;
          layout5.startToStart = paramInt3;
          layout5.startToEnd = -1;
          return;
        } 
        if (paramInt4 == 7) {
          layout5 = ((Constraint)layout5).layout;
          layout5.startToEnd = paramInt3;
          layout5.startToStart = -1;
          return;
        } 
        stringBuilder5 = new StringBuilder();
        stringBuilder5.append("right to ");
        stringBuilder5.append(sideToString(paramInt4));
        stringBuilder5.append(" undefined");
        throw new IllegalArgumentException(stringBuilder5.toString());
      case 5:
        if (paramInt4 == 5) {
          layout4 = ((Constraint)stringBuilder5).layout;
          layout4.baselineToBaseline = paramInt3;
          layout4.bottomToBottom = -1;
          layout4.bottomToTop = -1;
          layout4.topToTop = -1;
          layout4.topToBottom = -1;
          return;
        } 
        stringBuilder5 = new StringBuilder();
        stringBuilder5.append("right to ");
        stringBuilder5.append(sideToString(paramInt4));
        stringBuilder5.append(" undefined");
        throw new IllegalArgumentException(stringBuilder5.toString());
      case 4:
        if (paramInt4 == 4) {
          layout4 = ((Constraint)stringBuilder5).layout;
          layout4.bottomToBottom = paramInt3;
          layout4.bottomToTop = -1;
          layout4.baselineToBaseline = -1;
          return;
        } 
        if (paramInt4 == 3) {
          layout4 = ((Constraint)layout4).layout;
          layout4.bottomToTop = paramInt3;
          layout4.bottomToBottom = -1;
          layout4.baselineToBaseline = -1;
          return;
        } 
        stringBuilder4 = new StringBuilder();
        stringBuilder4.append("right to ");
        stringBuilder4.append(sideToString(paramInt4));
        stringBuilder4.append(" undefined");
        throw new IllegalArgumentException(stringBuilder4.toString());
      case 3:
        if (paramInt4 == 3) {
          layout3 = ((Constraint)stringBuilder4).layout;
          layout3.topToTop = paramInt3;
          layout3.topToBottom = -1;
          layout3.baselineToBaseline = -1;
          return;
        } 
        if (paramInt4 == 4) {
          layout3 = ((Constraint)layout3).layout;
          layout3.topToBottom = paramInt3;
          layout3.topToTop = -1;
          layout3.baselineToBaseline = -1;
          return;
        } 
        stringBuilder3 = new StringBuilder();
        stringBuilder3.append("right to ");
        stringBuilder3.append(sideToString(paramInt4));
        stringBuilder3.append(" undefined");
        throw new IllegalArgumentException(stringBuilder3.toString());
      case 2:
        if (paramInt4 == 1) {
          layout2 = ((Constraint)stringBuilder3).layout;
          layout2.rightToLeft = paramInt3;
          layout2.rightToRight = -1;
          return;
        } 
        if (paramInt4 == 2) {
          layout2 = ((Constraint)layout2).layout;
          layout2.rightToRight = paramInt3;
          layout2.rightToLeft = -1;
          return;
        } 
        stringBuilder2 = new StringBuilder();
        stringBuilder2.append("right to ");
        stringBuilder2.append(sideToString(paramInt4));
        stringBuilder2.append(" undefined");
        throw new IllegalArgumentException(stringBuilder2.toString());
      case 1:
        break;
    } 
    if (paramInt4 == 1) {
      layout1 = ((Constraint)stringBuilder2).layout;
      layout1.leftToLeft = paramInt3;
      layout1.leftToRight = -1;
      return;
    } 
    if (paramInt4 == 2) {
      layout1 = ((Constraint)layout1).layout;
      layout1.leftToRight = paramInt3;
      layout1.leftToLeft = -1;
      return;
    } 
    StringBuilder stringBuilder1 = new StringBuilder();
    stringBuilder1.append("left to ");
    stringBuilder1.append(sideToString(paramInt4));
    stringBuilder1.append(" undefined");
    throw new IllegalArgumentException(stringBuilder1.toString());
  }
  
  public void connect(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
    StringBuilder stringBuilder;
    if (!this.mConstraints.containsKey(Integer.valueOf(paramInt1)))
      this.mConstraints.put(Integer.valueOf(paramInt1), new Constraint()); 
    Constraint constraint = this.mConstraints.get(Integer.valueOf(paramInt1));
    switch (paramInt2) {
      default:
        stringBuilder = new StringBuilder();
        stringBuilder.append(sideToString(paramInt2));
        stringBuilder.append(" to ");
        stringBuilder.append(sideToString(paramInt4));
        stringBuilder.append(" unknown");
        throw new IllegalArgumentException(stringBuilder.toString());
      case 7:
        if (paramInt4 == 7) {
          Layout layout = ((Constraint)stringBuilder).layout;
          layout.endToEnd = paramInt3;
          layout.endToStart = -1;
        } else if (paramInt4 == 6) {
          Layout layout = ((Constraint)stringBuilder).layout;
          layout.endToStart = paramInt3;
          layout.endToEnd = -1;
        } else {
          stringBuilder = new StringBuilder();
          stringBuilder.append("right to ");
          stringBuilder.append(sideToString(paramInt4));
          stringBuilder.append(" undefined");
          throw new IllegalArgumentException(stringBuilder.toString());
        } 
        ((Constraint)stringBuilder).layout.endMargin = paramInt5;
        return;
      case 6:
        if (paramInt4 == 6) {
          Layout layout = ((Constraint)stringBuilder).layout;
          layout.startToStart = paramInt3;
          layout.startToEnd = -1;
        } else if (paramInt4 == 7) {
          Layout layout = ((Constraint)stringBuilder).layout;
          layout.startToEnd = paramInt3;
          layout.startToStart = -1;
        } else {
          stringBuilder = new StringBuilder();
          stringBuilder.append("right to ");
          stringBuilder.append(sideToString(paramInt4));
          stringBuilder.append(" undefined");
          throw new IllegalArgumentException(stringBuilder.toString());
        } 
        ((Constraint)stringBuilder).layout.startMargin = paramInt5;
        return;
      case 5:
        if (paramInt4 == 5) {
          Layout layout = ((Constraint)stringBuilder).layout;
          layout.baselineToBaseline = paramInt3;
          layout.bottomToBottom = -1;
          layout.bottomToTop = -1;
          layout.topToTop = -1;
          layout.topToBottom = -1;
          return;
        } 
        stringBuilder = new StringBuilder();
        stringBuilder.append("right to ");
        stringBuilder.append(sideToString(paramInt4));
        stringBuilder.append(" undefined");
        throw new IllegalArgumentException(stringBuilder.toString());
      case 4:
        if (paramInt4 == 4) {
          Layout layout = ((Constraint)stringBuilder).layout;
          layout.bottomToBottom = paramInt3;
          layout.bottomToTop = -1;
          layout.baselineToBaseline = -1;
        } else if (paramInt4 == 3) {
          Layout layout = ((Constraint)stringBuilder).layout;
          layout.bottomToTop = paramInt3;
          layout.bottomToBottom = -1;
          layout.baselineToBaseline = -1;
        } else {
          stringBuilder = new StringBuilder();
          stringBuilder.append("right to ");
          stringBuilder.append(sideToString(paramInt4));
          stringBuilder.append(" undefined");
          throw new IllegalArgumentException(stringBuilder.toString());
        } 
        ((Constraint)stringBuilder).layout.bottomMargin = paramInt5;
        return;
      case 3:
        if (paramInt4 == 3) {
          Layout layout = ((Constraint)stringBuilder).layout;
          layout.topToTop = paramInt3;
          layout.topToBottom = -1;
          layout.baselineToBaseline = -1;
        } else if (paramInt4 == 4) {
          Layout layout = ((Constraint)stringBuilder).layout;
          layout.topToBottom = paramInt3;
          layout.topToTop = -1;
          layout.baselineToBaseline = -1;
        } else {
          stringBuilder = new StringBuilder();
          stringBuilder.append("right to ");
          stringBuilder.append(sideToString(paramInt4));
          stringBuilder.append(" undefined");
          throw new IllegalArgumentException(stringBuilder.toString());
        } 
        ((Constraint)stringBuilder).layout.topMargin = paramInt5;
        return;
      case 2:
        if (paramInt4 == 1) {
          Layout layout = ((Constraint)stringBuilder).layout;
          layout.rightToLeft = paramInt3;
          layout.rightToRight = -1;
        } else if (paramInt4 == 2) {
          Layout layout = ((Constraint)stringBuilder).layout;
          layout.rightToRight = paramInt3;
          layout.rightToLeft = -1;
        } else {
          stringBuilder = new StringBuilder();
          stringBuilder.append("right to ");
          stringBuilder.append(sideToString(paramInt4));
          stringBuilder.append(" undefined");
          throw new IllegalArgumentException(stringBuilder.toString());
        } 
        ((Constraint)stringBuilder).layout.rightMargin = paramInt5;
        return;
      case 1:
        break;
    } 
    if (paramInt4 == 1) {
      Layout layout = ((Constraint)stringBuilder).layout;
      layout.leftToLeft = paramInt3;
      layout.leftToRight = -1;
    } else if (paramInt4 == 2) {
      Layout layout = ((Constraint)stringBuilder).layout;
      layout.leftToRight = paramInt3;
      layout.leftToLeft = -1;
    } else {
      stringBuilder = new StringBuilder();
      stringBuilder.append("Left to ");
      stringBuilder.append(sideToString(paramInt4));
      stringBuilder.append(" undefined");
      throw new IllegalArgumentException(stringBuilder.toString());
    } 
    ((Constraint)stringBuilder).layout.leftMargin = paramInt5;
  }
  
  public void constrainCircle(int paramInt1, int paramInt2, int paramInt3, float paramFloat) {
    Layout layout = (get(paramInt1)).layout;
    layout.circleConstraint = paramInt2;
    layout.circleRadius = paramInt3;
    layout.circleAngle = paramFloat;
  }
  
  public void constrainDefaultHeight(int paramInt1, int paramInt2) {
    (get(paramInt1)).layout.heightDefault = paramInt2;
  }
  
  public void constrainDefaultWidth(int paramInt1, int paramInt2) {
    (get(paramInt1)).layout.widthDefault = paramInt2;
  }
  
  public void constrainHeight(int paramInt1, int paramInt2) {
    (get(paramInt1)).layout.mHeight = paramInt2;
  }
  
  public void constrainMaxHeight(int paramInt1, int paramInt2) {
    (get(paramInt1)).layout.heightMax = paramInt2;
  }
  
  public void constrainMaxWidth(int paramInt1, int paramInt2) {
    (get(paramInt1)).layout.widthMax = paramInt2;
  }
  
  public void constrainMinHeight(int paramInt1, int paramInt2) {
    (get(paramInt1)).layout.heightMin = paramInt2;
  }
  
  public void constrainMinWidth(int paramInt1, int paramInt2) {
    (get(paramInt1)).layout.widthMin = paramInt2;
  }
  
  public void constrainPercentHeight(int paramInt, float paramFloat) {
    (get(paramInt)).layout.heightPercent = paramFloat;
  }
  
  public void constrainPercentWidth(int paramInt, float paramFloat) {
    (get(paramInt)).layout.widthPercent = paramFloat;
  }
  
  public void constrainWidth(int paramInt1, int paramInt2) {
    (get(paramInt1)).layout.mWidth = paramInt2;
  }
  
  public void constrainedHeight(int paramInt, boolean paramBoolean) {
    (get(paramInt)).layout.constrainedHeight = paramBoolean;
  }
  
  public void constrainedWidth(int paramInt, boolean paramBoolean) {
    (get(paramInt)).layout.constrainedWidth = paramBoolean;
  }
  
  public void create(int paramInt1, int paramInt2) {
    Layout layout = (get(paramInt1)).layout;
    layout.mIsGuideline = true;
    layout.orientation = paramInt2;
  }
  
  public void createBarrier(int paramInt1, int paramInt2, int paramInt3, int... paramVarArgs) {
    Layout layout = (get(paramInt1)).layout;
    layout.mHelperType = 1;
    layout.mBarrierDirection = paramInt2;
    layout.mBarrierMargin = paramInt3;
    layout.mIsGuideline = false;
    layout.mReferenceIds = paramVarArgs;
  }
  
  public void createHorizontalChain(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int[] paramArrayOfint, float[] paramArrayOffloat, int paramInt5) {
    createHorizontalChain(paramInt1, paramInt2, paramInt3, paramInt4, paramArrayOfint, paramArrayOffloat, paramInt5, 1, 2);
  }
  
  public void createHorizontalChainRtl(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int[] paramArrayOfint, float[] paramArrayOffloat, int paramInt5) {
    createHorizontalChain(paramInt1, paramInt2, paramInt3, paramInt4, paramArrayOfint, paramArrayOffloat, paramInt5, 6, 7);
  }
  
  public void createVerticalChain(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int[] paramArrayOfint, float[] paramArrayOffloat, int paramInt5) {
    if (paramArrayOfint.length >= 2) {
      if (paramArrayOffloat == null || paramArrayOffloat.length == paramArrayOfint.length) {
        if (paramArrayOffloat != null)
          (get(paramArrayOfint[0])).layout.verticalWeight = paramArrayOffloat[0]; 
        (get(paramArrayOfint[0])).layout.verticalChainStyle = paramInt5;
        connect(paramArrayOfint[0], 3, paramInt1, paramInt2, 0);
        for (paramInt1 = 1; paramInt1 < paramArrayOfint.length; paramInt1++) {
          paramInt2 = paramArrayOfint[paramInt1];
          paramInt2 = paramArrayOfint[paramInt1];
          paramInt5 = paramInt1 - 1;
          connect(paramInt2, 3, paramArrayOfint[paramInt5], 4, 0);
          connect(paramArrayOfint[paramInt5], 4, paramArrayOfint[paramInt1], 3, 0);
          if (paramArrayOffloat != null)
            (get(paramArrayOfint[paramInt1])).layout.verticalWeight = paramArrayOffloat[paramInt1]; 
        } 
        connect(paramArrayOfint[paramArrayOfint.length - 1], 4, paramInt3, paramInt4, 0);
        return;
      } 
      throw new IllegalArgumentException("must have 2 or more widgets in a chain");
    } 
    throw new IllegalArgumentException("must have 2 or more widgets in a chain");
  }
  
  public void dump(MotionScene paramMotionScene, int... paramVarArgs) {
    Set<Integer> set = this.mConstraints.keySet();
    int i = paramVarArgs.length;
    boolean bool = false;
    if (i != 0) {
      HashSet<Integer> hashSet = new HashSet();
      int k = paramVarArgs.length;
      i = 0;
      while (true) {
        set = hashSet;
        if (i < k) {
          hashSet.add(Integer.valueOf(paramVarArgs[i]));
          i++;
          continue;
        } 
        break;
      } 
    } else {
      set = new HashSet<Integer>(set);
    } 
    PrintStream printStream = System.out;
    StringBuilder stringBuilder2 = new StringBuilder();
    stringBuilder2.append(set.size());
    stringBuilder2.append(" constraints");
    printStream.println(stringBuilder2.toString());
    StringBuilder stringBuilder1 = new StringBuilder();
    Integer[] arrayOfInteger = set.<Integer>toArray(new Integer[0]);
    int j = arrayOfInteger.length;
    for (i = bool; i < j; i++) {
      Integer integer = arrayOfInteger[i];
      Constraint constraint = this.mConstraints.get(integer);
      stringBuilder1.append("<Constraint id=");
      stringBuilder1.append(integer);
      stringBuilder1.append(" \n");
      constraint.layout.dump(paramMotionScene, stringBuilder1);
      stringBuilder1.append("/>\n");
    } 
    System.out.println(stringBuilder1.toString());
  }
  
  public boolean getApplyElevation(int paramInt) {
    return (get(paramInt)).transform.applyElevation;
  }
  
  public Constraint getConstraint(int paramInt) {
    return this.mConstraints.containsKey(Integer.valueOf(paramInt)) ? this.mConstraints.get(Integer.valueOf(paramInt)) : null;
  }
  
  public HashMap<String, ConstraintAttribute> getCustomAttributeSet() {
    return this.mSavedAttributes;
  }
  
  public int getHeight(int paramInt) {
    return (get(paramInt)).layout.mHeight;
  }
  
  public int[] getKnownIds() {
    Set<Integer> set = this.mConstraints.keySet();
    int i = 0;
    Integer[] arrayOfInteger = set.<Integer>toArray(new Integer[0]);
    int j = arrayOfInteger.length;
    int[] arrayOfInt = new int[j];
    while (i < j) {
      arrayOfInt[i] = arrayOfInteger[i].intValue();
      i++;
    } 
    return arrayOfInt;
  }
  
  public Constraint getParameters(int paramInt) {
    return get(paramInt);
  }
  
  public int[] getReferencedIds(int paramInt) {
    int[] arrayOfInt = (get(paramInt)).layout.mReferenceIds;
    return (arrayOfInt == null) ? new int[0] : Arrays.copyOf(arrayOfInt, arrayOfInt.length);
  }
  
  public int getVisibility(int paramInt) {
    return (get(paramInt)).propertySet.visibility;
  }
  
  public int getVisibilityMode(int paramInt) {
    return (get(paramInt)).propertySet.mVisibilityMode;
  }
  
  public int getWidth(int paramInt) {
    return (get(paramInt)).layout.mWidth;
  }
  
  public boolean isForceId() {
    return this.mForceId;
  }
  
  public void load(Context paramContext, int paramInt) {
    XmlResourceParser xmlResourceParser = paramContext.getResources().getXml(paramInt);
    try {
      paramInt = xmlResourceParser.getEventType();
    } catch (XmlPullParserException xmlPullParserException) {
      xmlPullParserException.printStackTrace();
      return;
    } catch (IOException iOException) {
      iOException.printStackTrace();
      return;
    } 
    while (true) {
      if (paramInt != 1) {
        if (paramInt != 0) {
          if (paramInt == 2) {
            String str = xmlResourceParser.getName();
            Constraint constraint = fillFromAttributeList((Context)iOException, Xml.asAttributeSet((XmlPullParser)xmlResourceParser));
            if (str.equalsIgnoreCase("Guideline"))
              constraint.layout.mIsGuideline = true; 
            this.mConstraints.put(Integer.valueOf(constraint.mViewId), constraint);
          } 
        } else {
          xmlResourceParser.getName();
        } 
        paramInt = xmlResourceParser.next();
        continue;
      } 
      return;
    } 
  }
  
  public void load(Context paramContext, XmlPullParser paramXmlPullParser) {
    try {
      int i = paramXmlPullParser.getEventType();
      Constraint constraint = null;
      while (i != 1) {
        Layout layout1;
        if (i != 0) {
          byte b = 3;
          if (i != 2) {
            if (i != 3) {
              Constraint constraint1 = constraint;
            } else {
              String str = paramXmlPullParser.getName();
              if ("ConstraintSet".equals(str))
                return; 
              Constraint constraint1 = constraint;
              if (str.equalsIgnoreCase("Constraint")) {
                this.mConstraints.put(Integer.valueOf(constraint.mViewId), constraint);
                constraint1 = null;
              } 
            } 
          } else {
            StringBuilder stringBuilder;
            boolean bool;
            Constraint constraint9;
            Layout layout10;
            Constraint constraint8;
            Layout layout9;
            Constraint constraint7;
            Layout layout8;
            Constraint constraint6;
            Layout layout7;
            Constraint constraint5;
            Layout layout6;
            Constraint constraint4;
            Layout layout5;
            Constraint constraint3;
            Layout layout4;
            Constraint constraint2;
            Layout layout3;
            Constraint constraint1;
            String str = paramXmlPullParser.getName();
            switch (str.hashCode()) {
              case 1803088381:
                if (str.equals("Constraint")) {
                  i = 0;
                } else {
                  break;
                } 
                switch (i) {
                  default:
                    constraint9 = constraint;
                    break;
                  case 7:
                    if (constraint != null) {
                      ConstraintAttribute.parse(paramContext, paramXmlPullParser, constraint.mCustomConstraints);
                      constraint9 = constraint;
                      break;
                    } 
                    stringBuilder = new StringBuilder();
                    stringBuilder.append("XML parser error must be within a Constraint ");
                    stringBuilder.append(paramXmlPullParser.getLineNumber());
                    throw new RuntimeException(stringBuilder.toString());
                  case 6:
                    if (constraint != null) {
                      constraint.motion.fillFromAttributeList((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser));
                      constraint9 = constraint;
                      break;
                    } 
                    stringBuilder = new StringBuilder();
                    stringBuilder.append("XML parser error must be within a Constraint ");
                    stringBuilder.append(paramXmlPullParser.getLineNumber());
                    throw new RuntimeException(stringBuilder.toString());
                  case 5:
                    if (constraint != null) {
                      constraint.layout.fillFromAttributeList((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser));
                      constraint9 = constraint;
                      break;
                    } 
                    stringBuilder = new StringBuilder();
                    stringBuilder.append("XML parser error must be within a Constraint ");
                    stringBuilder.append(paramXmlPullParser.getLineNumber());
                    throw new RuntimeException(stringBuilder.toString());
                  case 4:
                    if (constraint != null) {
                      constraint.transform.fillFromAttributeList((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser));
                      constraint9 = constraint;
                      break;
                    } 
                    stringBuilder = new StringBuilder();
                    stringBuilder.append("XML parser error must be within a Constraint ");
                    stringBuilder.append(paramXmlPullParser.getLineNumber());
                    throw new RuntimeException(stringBuilder.toString());
                  case 3:
                    if (constraint != null) {
                      constraint.propertySet.fillFromAttributeList((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser));
                      constraint9 = constraint;
                      break;
                    } 
                    stringBuilder = new StringBuilder();
                    stringBuilder.append("XML parser error must be within a Constraint ");
                    stringBuilder.append(paramXmlPullParser.getLineNumber());
                    throw new RuntimeException(stringBuilder.toString());
                  case 2:
                    constraint9 = fillFromAttributeList((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser));
                    constraint9.layout.mHelperType = 1;
                    break;
                  case 1:
                    constraint9 = fillFromAttributeList((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser));
                    layout2 = constraint9.layout;
                    layout2.mIsGuideline = true;
                    layout2.mApply = true;
                    break;
                  case 0:
                    constraint9 = fillFromAttributeList((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser));
                    break;
                } 
              case 1791837707:
                if (constraint9.equals("CustomAttribute")) {
                  i = 7;
                } else {
                  break;
                } 
                switch (i) {
                  default:
                    layout10 = layout2;
                    break;
                  case 7:
                    if (layout2 != null) {
                      ConstraintAttribute.parse((Context)stringBuilder, paramXmlPullParser, ((Constraint)layout2).mCustomConstraints);
                      layout10 = layout2;
                      break;
                    } 
                    stringBuilder = new StringBuilder();
                    stringBuilder.append("XML parser error must be within a Constraint ");
                    stringBuilder.append(paramXmlPullParser.getLineNumber());
                    throw new RuntimeException(stringBuilder.toString());
                  case 6:
                    if (layout2 != null) {
                      ((Constraint)layout2).motion.fillFromAttributeList((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser));
                      layout10 = layout2;
                      break;
                    } 
                    stringBuilder = new StringBuilder();
                    stringBuilder.append("XML parser error must be within a Constraint ");
                    stringBuilder.append(paramXmlPullParser.getLineNumber());
                    throw new RuntimeException(stringBuilder.toString());
                  case 5:
                    if (layout2 != null) {
                      ((Constraint)layout2).layout.fillFromAttributeList((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser));
                      layout10 = layout2;
                      break;
                    } 
                    stringBuilder = new StringBuilder();
                    stringBuilder.append("XML parser error must be within a Constraint ");
                    stringBuilder.append(paramXmlPullParser.getLineNumber());
                    throw new RuntimeException(stringBuilder.toString());
                  case 4:
                    if (layout2 != null) {
                      ((Constraint)layout2).transform.fillFromAttributeList((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser));
                      layout10 = layout2;
                      break;
                    } 
                    stringBuilder = new StringBuilder();
                    stringBuilder.append("XML parser error must be within a Constraint ");
                    stringBuilder.append(paramXmlPullParser.getLineNumber());
                    throw new RuntimeException(stringBuilder.toString());
                  case 3:
                    if (layout2 != null) {
                      ((Constraint)layout2).propertySet.fillFromAttributeList((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser));
                      layout10 = layout2;
                      break;
                    } 
                    stringBuilder = new StringBuilder();
                    stringBuilder.append("XML parser error must be within a Constraint ");
                    stringBuilder.append(paramXmlPullParser.getLineNumber());
                    throw new RuntimeException(stringBuilder.toString());
                  case 2:
                    constraint8 = fillFromAttributeList((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser));
                    constraint8.layout.mHelperType = 1;
                    break;
                  case 1:
                    constraint8 = fillFromAttributeList((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser));
                    layout2 = constraint8.layout;
                    layout2.mIsGuideline = true;
                    layout2.mApply = true;
                    break;
                  case 0:
                    constraint8 = fillFromAttributeList((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser));
                    break;
                } 
              case 1331510167:
                if (constraint8.equals("Barrier")) {
                  i = 2;
                } else {
                  break;
                } 
                switch (i) {
                  default:
                    layout9 = layout2;
                    break;
                  case 7:
                    if (layout2 != null) {
                      ConstraintAttribute.parse((Context)stringBuilder, paramXmlPullParser, ((Constraint)layout2).mCustomConstraints);
                      layout9 = layout2;
                      break;
                    } 
                    stringBuilder = new StringBuilder();
                    stringBuilder.append("XML parser error must be within a Constraint ");
                    stringBuilder.append(paramXmlPullParser.getLineNumber());
                    throw new RuntimeException(stringBuilder.toString());
                  case 6:
                    if (layout2 != null) {
                      ((Constraint)layout2).motion.fillFromAttributeList((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser));
                      layout9 = layout2;
                      break;
                    } 
                    stringBuilder = new StringBuilder();
                    stringBuilder.append("XML parser error must be within a Constraint ");
                    stringBuilder.append(paramXmlPullParser.getLineNumber());
                    throw new RuntimeException(stringBuilder.toString());
                  case 5:
                    if (layout2 != null) {
                      ((Constraint)layout2).layout.fillFromAttributeList((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser));
                      layout9 = layout2;
                      break;
                    } 
                    stringBuilder = new StringBuilder();
                    stringBuilder.append("XML parser error must be within a Constraint ");
                    stringBuilder.append(paramXmlPullParser.getLineNumber());
                    throw new RuntimeException(stringBuilder.toString());
                  case 4:
                    if (layout2 != null) {
                      ((Constraint)layout2).transform.fillFromAttributeList((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser));
                      layout9 = layout2;
                      break;
                    } 
                    stringBuilder = new StringBuilder();
                    stringBuilder.append("XML parser error must be within a Constraint ");
                    stringBuilder.append(paramXmlPullParser.getLineNumber());
                    throw new RuntimeException(stringBuilder.toString());
                  case 3:
                    if (layout2 != null) {
                      ((Constraint)layout2).propertySet.fillFromAttributeList((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser));
                      layout9 = layout2;
                      break;
                    } 
                    stringBuilder = new StringBuilder();
                    stringBuilder.append("XML parser error must be within a Constraint ");
                    stringBuilder.append(paramXmlPullParser.getLineNumber());
                    throw new RuntimeException(stringBuilder.toString());
                  case 2:
                    constraint7 = fillFromAttributeList((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser));
                    constraint7.layout.mHelperType = 1;
                    break;
                  case 1:
                    constraint7 = fillFromAttributeList((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser));
                    layout2 = constraint7.layout;
                    layout2.mIsGuideline = true;
                    layout2.mApply = true;
                    break;
                  case 0:
                    constraint7 = fillFromAttributeList((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser));
                    break;
                } 
              case -71750448:
                if (constraint7.equals("Guideline")) {
                  i = 1;
                } else {
                  break;
                } 
                switch (i) {
                  default:
                    layout8 = layout2;
                    break;
                  case 7:
                    if (layout2 != null) {
                      ConstraintAttribute.parse((Context)stringBuilder, paramXmlPullParser, ((Constraint)layout2).mCustomConstraints);
                      layout8 = layout2;
                      break;
                    } 
                    stringBuilder = new StringBuilder();
                    stringBuilder.append("XML parser error must be within a Constraint ");
                    stringBuilder.append(paramXmlPullParser.getLineNumber());
                    throw new RuntimeException(stringBuilder.toString());
                  case 6:
                    if (layout2 != null) {
                      ((Constraint)layout2).motion.fillFromAttributeList((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser));
                      layout8 = layout2;
                      break;
                    } 
                    stringBuilder = new StringBuilder();
                    stringBuilder.append("XML parser error must be within a Constraint ");
                    stringBuilder.append(paramXmlPullParser.getLineNumber());
                    throw new RuntimeException(stringBuilder.toString());
                  case 5:
                    if (layout2 != null) {
                      ((Constraint)layout2).layout.fillFromAttributeList((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser));
                      layout8 = layout2;
                      break;
                    } 
                    stringBuilder = new StringBuilder();
                    stringBuilder.append("XML parser error must be within a Constraint ");
                    stringBuilder.append(paramXmlPullParser.getLineNumber());
                    throw new RuntimeException(stringBuilder.toString());
                  case 4:
                    if (layout2 != null) {
                      ((Constraint)layout2).transform.fillFromAttributeList((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser));
                      layout8 = layout2;
                      break;
                    } 
                    stringBuilder = new StringBuilder();
                    stringBuilder.append("XML parser error must be within a Constraint ");
                    stringBuilder.append(paramXmlPullParser.getLineNumber());
                    throw new RuntimeException(stringBuilder.toString());
                  case 3:
                    if (layout2 != null) {
                      ((Constraint)layout2).propertySet.fillFromAttributeList((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser));
                      layout8 = layout2;
                      break;
                    } 
                    stringBuilder = new StringBuilder();
                    stringBuilder.append("XML parser error must be within a Constraint ");
                    stringBuilder.append(paramXmlPullParser.getLineNumber());
                    throw new RuntimeException(stringBuilder.toString());
                  case 2:
                    constraint6 = fillFromAttributeList((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser));
                    constraint6.layout.mHelperType = 1;
                    break;
                  case 1:
                    constraint6 = fillFromAttributeList((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser));
                    layout2 = constraint6.layout;
                    layout2.mIsGuideline = true;
                    layout2.mApply = true;
                    break;
                  case 0:
                    constraint6 = fillFromAttributeList((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser));
                    break;
                } 
              case -1238332596:
                if (constraint6.equals("Transform")) {
                  i = 4;
                } else {
                  break;
                } 
                switch (i) {
                  default:
                    layout7 = layout2;
                    break;
                  case 7:
                    if (layout2 != null) {
                      ConstraintAttribute.parse((Context)stringBuilder, paramXmlPullParser, ((Constraint)layout2).mCustomConstraints);
                      layout7 = layout2;
                      break;
                    } 
                    stringBuilder = new StringBuilder();
                    stringBuilder.append("XML parser error must be within a Constraint ");
                    stringBuilder.append(paramXmlPullParser.getLineNumber());
                    throw new RuntimeException(stringBuilder.toString());
                  case 6:
                    if (layout2 != null) {
                      ((Constraint)layout2).motion.fillFromAttributeList((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser));
                      layout7 = layout2;
                      break;
                    } 
                    stringBuilder = new StringBuilder();
                    stringBuilder.append("XML parser error must be within a Constraint ");
                    stringBuilder.append(paramXmlPullParser.getLineNumber());
                    throw new RuntimeException(stringBuilder.toString());
                  case 5:
                    if (layout2 != null) {
                      ((Constraint)layout2).layout.fillFromAttributeList((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser));
                      layout7 = layout2;
                      break;
                    } 
                    stringBuilder = new StringBuilder();
                    stringBuilder.append("XML parser error must be within a Constraint ");
                    stringBuilder.append(paramXmlPullParser.getLineNumber());
                    throw new RuntimeException(stringBuilder.toString());
                  case 4:
                    if (layout2 != null) {
                      ((Constraint)layout2).transform.fillFromAttributeList((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser));
                      layout7 = layout2;
                      break;
                    } 
                    stringBuilder = new StringBuilder();
                    stringBuilder.append("XML parser error must be within a Constraint ");
                    stringBuilder.append(paramXmlPullParser.getLineNumber());
                    throw new RuntimeException(stringBuilder.toString());
                  case 3:
                    if (layout2 != null) {
                      ((Constraint)layout2).propertySet.fillFromAttributeList((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser));
                      layout7 = layout2;
                      break;
                    } 
                    stringBuilder = new StringBuilder();
                    stringBuilder.append("XML parser error must be within a Constraint ");
                    stringBuilder.append(paramXmlPullParser.getLineNumber());
                    throw new RuntimeException(stringBuilder.toString());
                  case 2:
                    constraint5 = fillFromAttributeList((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser));
                    constraint5.layout.mHelperType = 1;
                    break;
                  case 1:
                    constraint5 = fillFromAttributeList((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser));
                    layout2 = constraint5.layout;
                    layout2.mIsGuideline = true;
                    layout2.mApply = true;
                    break;
                  case 0:
                    constraint5 = fillFromAttributeList((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser));
                    break;
                } 
              case -1269513683:
                if (constraint5.equals("PropertySet")) {
                  i = b;
                } else {
                  break;
                } 
                switch (i) {
                  default:
                    layout6 = layout2;
                    break;
                  case 7:
                    if (layout2 != null) {
                      ConstraintAttribute.parse((Context)stringBuilder, paramXmlPullParser, ((Constraint)layout2).mCustomConstraints);
                      layout6 = layout2;
                      break;
                    } 
                    stringBuilder = new StringBuilder();
                    stringBuilder.append("XML parser error must be within a Constraint ");
                    stringBuilder.append(paramXmlPullParser.getLineNumber());
                    throw new RuntimeException(stringBuilder.toString());
                  case 6:
                    if (layout2 != null) {
                      ((Constraint)layout2).motion.fillFromAttributeList((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser));
                      layout6 = layout2;
                      break;
                    } 
                    stringBuilder = new StringBuilder();
                    stringBuilder.append("XML parser error must be within a Constraint ");
                    stringBuilder.append(paramXmlPullParser.getLineNumber());
                    throw new RuntimeException(stringBuilder.toString());
                  case 5:
                    if (layout2 != null) {
                      ((Constraint)layout2).layout.fillFromAttributeList((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser));
                      layout6 = layout2;
                      break;
                    } 
                    stringBuilder = new StringBuilder();
                    stringBuilder.append("XML parser error must be within a Constraint ");
                    stringBuilder.append(paramXmlPullParser.getLineNumber());
                    throw new RuntimeException(stringBuilder.toString());
                  case 4:
                    if (layout2 != null) {
                      ((Constraint)layout2).transform.fillFromAttributeList((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser));
                      layout6 = layout2;
                      break;
                    } 
                    stringBuilder = new StringBuilder();
                    stringBuilder.append("XML parser error must be within a Constraint ");
                    stringBuilder.append(paramXmlPullParser.getLineNumber());
                    throw new RuntimeException(stringBuilder.toString());
                  case 3:
                    if (layout2 != null) {
                      ((Constraint)layout2).propertySet.fillFromAttributeList((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser));
                      layout6 = layout2;
                      break;
                    } 
                    stringBuilder = new StringBuilder();
                    stringBuilder.append("XML parser error must be within a Constraint ");
                    stringBuilder.append(paramXmlPullParser.getLineNumber());
                    throw new RuntimeException(stringBuilder.toString());
                  case 2:
                    constraint4 = fillFromAttributeList((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser));
                    constraint4.layout.mHelperType = 1;
                    break;
                  case 1:
                    constraint4 = fillFromAttributeList((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser));
                    layout2 = constraint4.layout;
                    layout2.mIsGuideline = true;
                    layout2.mApply = true;
                    break;
                  case 0:
                    constraint4 = fillFromAttributeList((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser));
                    break;
                } 
              case -1984451626:
                if (constraint4.equals("Motion")) {
                  i = 6;
                } else {
                  break;
                } 
                switch (i) {
                  default:
                    layout5 = layout2;
                    break;
                  case 7:
                    if (layout2 != null) {
                      ConstraintAttribute.parse((Context)stringBuilder, paramXmlPullParser, ((Constraint)layout2).mCustomConstraints);
                      layout5 = layout2;
                      break;
                    } 
                    stringBuilder = new StringBuilder();
                    stringBuilder.append("XML parser error must be within a Constraint ");
                    stringBuilder.append(paramXmlPullParser.getLineNumber());
                    throw new RuntimeException(stringBuilder.toString());
                  case 6:
                    if (layout2 != null) {
                      ((Constraint)layout2).motion.fillFromAttributeList((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser));
                      layout5 = layout2;
                      break;
                    } 
                    stringBuilder = new StringBuilder();
                    stringBuilder.append("XML parser error must be within a Constraint ");
                    stringBuilder.append(paramXmlPullParser.getLineNumber());
                    throw new RuntimeException(stringBuilder.toString());
                  case 5:
                    if (layout2 != null) {
                      ((Constraint)layout2).layout.fillFromAttributeList((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser));
                      layout5 = layout2;
                      break;
                    } 
                    stringBuilder = new StringBuilder();
                    stringBuilder.append("XML parser error must be within a Constraint ");
                    stringBuilder.append(paramXmlPullParser.getLineNumber());
                    throw new RuntimeException(stringBuilder.toString());
                  case 4:
                    if (layout2 != null) {
                      ((Constraint)layout2).transform.fillFromAttributeList((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser));
                      layout5 = layout2;
                      break;
                    } 
                    stringBuilder = new StringBuilder();
                    stringBuilder.append("XML parser error must be within a Constraint ");
                    stringBuilder.append(paramXmlPullParser.getLineNumber());
                    throw new RuntimeException(stringBuilder.toString());
                  case 3:
                    if (layout2 != null) {
                      ((Constraint)layout2).propertySet.fillFromAttributeList((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser));
                      layout5 = layout2;
                      break;
                    } 
                    stringBuilder = new StringBuilder();
                    stringBuilder.append("XML parser error must be within a Constraint ");
                    stringBuilder.append(paramXmlPullParser.getLineNumber());
                    throw new RuntimeException(stringBuilder.toString());
                  case 2:
                    constraint3 = fillFromAttributeList((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser));
                    constraint3.layout.mHelperType = 1;
                    break;
                  case 1:
                    constraint3 = fillFromAttributeList((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser));
                    layout2 = constraint3.layout;
                    layout2.mIsGuideline = true;
                    layout2.mApply = true;
                    break;
                  case 0:
                    constraint3 = fillFromAttributeList((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser));
                    break;
                } 
              case -2025855158:
                bool = constraint3.equals("Layout");
                if (bool) {
                  i = 5;
                } else {
                  break;
                } 
                switch (i) {
                  default:
                    layout4 = layout2;
                    break;
                  case 7:
                    if (layout2 != null) {
                      ConstraintAttribute.parse((Context)stringBuilder, paramXmlPullParser, ((Constraint)layout2).mCustomConstraints);
                      layout4 = layout2;
                      break;
                    } 
                    stringBuilder = new StringBuilder();
                    stringBuilder.append("XML parser error must be within a Constraint ");
                    stringBuilder.append(paramXmlPullParser.getLineNumber());
                    throw new RuntimeException(stringBuilder.toString());
                  case 6:
                    if (layout2 != null) {
                      ((Constraint)layout2).motion.fillFromAttributeList((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser));
                      layout4 = layout2;
                      break;
                    } 
                    stringBuilder = new StringBuilder();
                    stringBuilder.append("XML parser error must be within a Constraint ");
                    stringBuilder.append(paramXmlPullParser.getLineNumber());
                    throw new RuntimeException(stringBuilder.toString());
                  case 5:
                    if (layout2 != null) {
                      ((Constraint)layout2).layout.fillFromAttributeList((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser));
                      layout4 = layout2;
                      break;
                    } 
                    stringBuilder = new StringBuilder();
                    stringBuilder.append("XML parser error must be within a Constraint ");
                    stringBuilder.append(paramXmlPullParser.getLineNumber());
                    throw new RuntimeException(stringBuilder.toString());
                  case 4:
                    if (layout2 != null) {
                      ((Constraint)layout2).transform.fillFromAttributeList((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser));
                      layout4 = layout2;
                      break;
                    } 
                    stringBuilder = new StringBuilder();
                    stringBuilder.append("XML parser error must be within a Constraint ");
                    stringBuilder.append(paramXmlPullParser.getLineNumber());
                    throw new RuntimeException(stringBuilder.toString());
                  case 3:
                    if (layout2 != null) {
                      ((Constraint)layout2).propertySet.fillFromAttributeList((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser));
                      layout4 = layout2;
                      break;
                    } 
                    stringBuilder = new StringBuilder();
                    stringBuilder.append("XML parser error must be within a Constraint ");
                    stringBuilder.append(paramXmlPullParser.getLineNumber());
                    throw new RuntimeException(stringBuilder.toString());
                  case 2:
                    constraint2 = fillFromAttributeList((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser));
                    constraint2.layout.mHelperType = 1;
                    break;
                  case 1:
                    constraint2 = fillFromAttributeList((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser));
                    layout2 = constraint2.layout;
                    layout2.mIsGuideline = true;
                    layout2.mApply = true;
                    break;
                  case 0:
                    constraint2 = fillFromAttributeList((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser));
                    break;
                } 
            } 
            i = -1;
            switch (i) {
              default:
                layout3 = layout2;
                break;
              case 7:
                if (layout2 != null) {
                  ConstraintAttribute.parse((Context)stringBuilder, paramXmlPullParser, ((Constraint)layout2).mCustomConstraints);
                  layout3 = layout2;
                  break;
                } 
                stringBuilder = new StringBuilder();
                stringBuilder.append("XML parser error must be within a Constraint ");
                stringBuilder.append(paramXmlPullParser.getLineNumber());
                throw new RuntimeException(stringBuilder.toString());
              case 6:
                if (layout2 != null) {
                  ((Constraint)layout2).motion.fillFromAttributeList((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser));
                  layout3 = layout2;
                  break;
                } 
                stringBuilder = new StringBuilder();
                stringBuilder.append("XML parser error must be within a Constraint ");
                stringBuilder.append(paramXmlPullParser.getLineNumber());
                throw new RuntimeException(stringBuilder.toString());
              case 5:
                if (layout2 != null) {
                  ((Constraint)layout2).layout.fillFromAttributeList((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser));
                  layout3 = layout2;
                  break;
                } 
                stringBuilder = new StringBuilder();
                stringBuilder.append("XML parser error must be within a Constraint ");
                stringBuilder.append(paramXmlPullParser.getLineNumber());
                throw new RuntimeException(stringBuilder.toString());
              case 4:
                if (layout2 != null) {
                  ((Constraint)layout2).transform.fillFromAttributeList((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser));
                  layout3 = layout2;
                  break;
                } 
                stringBuilder = new StringBuilder();
                stringBuilder.append("XML parser error must be within a Constraint ");
                stringBuilder.append(paramXmlPullParser.getLineNumber());
                throw new RuntimeException(stringBuilder.toString());
              case 3:
                if (layout2 != null) {
                  ((Constraint)layout2).propertySet.fillFromAttributeList((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser));
                  layout3 = layout2;
                  break;
                } 
                stringBuilder = new StringBuilder();
                stringBuilder.append("XML parser error must be within a Constraint ");
                stringBuilder.append(paramXmlPullParser.getLineNumber());
                throw new RuntimeException(stringBuilder.toString());
              case 2:
                constraint1 = fillFromAttributeList((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser));
                constraint1.layout.mHelperType = 1;
                break;
              case 1:
                constraint1 = fillFromAttributeList((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser));
                layout2 = constraint1.layout;
                layout2.mIsGuideline = true;
                layout2.mApply = true;
                break;
              case 0:
                constraint1 = fillFromAttributeList((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser));
                break;
            } 
          } 
        } else {
          paramXmlPullParser.getName();
          layout1 = layout2;
        } 
        i = paramXmlPullParser.next();
        Layout layout2 = layout1;
      } 
    } catch (XmlPullParserException xmlPullParserException) {
      xmlPullParserException.printStackTrace();
    } catch (IOException iOException) {
      iOException.printStackTrace();
      return;
    } 
  }
  
  public void parseColorAttributes(Constraint paramConstraint, String paramString) {
    String[] arrayOfString = paramString.split(",");
    for (int i = 0; i < arrayOfString.length; i++) {
      StringBuilder stringBuilder;
      String[] arrayOfString1 = arrayOfString[i].split("=");
      if (arrayOfString1.length != 2) {
        stringBuilder = new StringBuilder();
        stringBuilder.append(" Unable to parse ");
        stringBuilder.append(arrayOfString[i]);
        Log.w("ConstraintSet", stringBuilder.toString());
      } else {
        paramConstraint.setColorValue((String)stringBuilder[0], Color.parseColor((String)stringBuilder[1]));
      } 
    } 
  }
  
  public void parseFloatAttributes(Constraint paramConstraint, String paramString) {
    String[] arrayOfString = paramString.split(",");
    for (int i = 0; i < arrayOfString.length; i++) {
      StringBuilder stringBuilder;
      String[] arrayOfString1 = arrayOfString[i].split("=");
      if (arrayOfString1.length != 2) {
        stringBuilder = new StringBuilder();
        stringBuilder.append(" Unable to parse ");
        stringBuilder.append(arrayOfString[i]);
        Log.w("ConstraintSet", stringBuilder.toString());
      } else {
        paramConstraint.setFloatValue((String)stringBuilder[0], Float.parseFloat((String)stringBuilder[1]));
      } 
    } 
  }
  
  public void parseIntAttributes(Constraint paramConstraint, String paramString) {
    String[] arrayOfString = paramString.split(",");
    for (int i = 0; i < arrayOfString.length; i++) {
      StringBuilder stringBuilder;
      String[] arrayOfString1 = arrayOfString[i].split("=");
      if (arrayOfString1.length != 2) {
        stringBuilder = new StringBuilder();
        stringBuilder.append(" Unable to parse ");
        stringBuilder.append(arrayOfString[i]);
        Log.w("ConstraintSet", stringBuilder.toString());
      } else {
        paramConstraint.setFloatValue((String)stringBuilder[0], Integer.decode((String)stringBuilder[1]).intValue());
      } 
    } 
  }
  
  public void parseStringAttributes(Constraint paramConstraint, String paramString) {
    String[] arrayOfString = splitString(paramString);
    for (int i = 0; i < arrayOfString.length; i++) {
      String[] arrayOfString1 = arrayOfString[i].split("=");
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(" Unable to parse ");
      stringBuilder.append(arrayOfString[i]);
      Log.w("ConstraintSet", stringBuilder.toString());
      paramConstraint.setStringValue(arrayOfString1[0], arrayOfString1[1]);
    } 
  }
  
  public void readFallback(ConstraintLayout paramConstraintLayout) {
    int j = paramConstraintLayout.getChildCount();
    int i = 0;
    while (i < j) {
      View view = paramConstraintLayout.getChildAt(i);
      ConstraintLayout.LayoutParams layoutParams = (ConstraintLayout.LayoutParams)view.getLayoutParams();
      int k = view.getId();
      if (!this.mForceId || k != -1) {
        if (!this.mConstraints.containsKey(Integer.valueOf(k)))
          this.mConstraints.put(Integer.valueOf(k), new Constraint()); 
        Constraint constraint = this.mConstraints.get(Integer.valueOf(k));
        if (!constraint.layout.mApply) {
          constraint.fillFrom(k, layoutParams);
          if (view instanceof ConstraintHelper) {
            constraint.layout.mReferenceIds = ((ConstraintHelper)view).getReferencedIds();
            if (view instanceof Barrier) {
              Barrier barrier = (Barrier)view;
              constraint.layout.mBarrierAllowsGoneWidgets = barrier.allowsGoneWidget();
              constraint.layout.mBarrierDirection = barrier.getType();
              constraint.layout.mBarrierMargin = barrier.getMargin();
            } 
          } 
          constraint.layout.mApply = true;
        } 
        PropertySet propertySet = constraint.propertySet;
        if (!propertySet.mApply) {
          propertySet.visibility = view.getVisibility();
          constraint.propertySet.alpha = view.getAlpha();
          constraint.propertySet.mApply = true;
        } 
        Transform transform = constraint.transform;
        if (!transform.mApply) {
          transform.mApply = true;
          transform.rotation = view.getRotation();
          constraint.transform.rotationX = view.getRotationX();
          constraint.transform.rotationY = view.getRotationY();
          constraint.transform.scaleX = view.getScaleX();
          constraint.transform.scaleY = view.getScaleY();
          float f1 = view.getPivotX();
          float f2 = view.getPivotY();
          if (f1 != 0.0D || f2 != 0.0D) {
            transform = constraint.transform;
            transform.transformPivotX = f1;
            transform.transformPivotY = f2;
          } 
          constraint.transform.translationX = view.getTranslationX();
          constraint.transform.translationY = view.getTranslationY();
          constraint.transform.translationZ = view.getTranslationZ();
          Transform transform1 = constraint.transform;
          if (transform1.applyElevation)
            transform1.elevation = view.getElevation(); 
        } 
        i++;
        continue;
      } 
      throw new RuntimeException("All children of ConstraintLayout must have ids to use ConstraintSet");
    } 
  }
  
  public void readFallback(ConstraintSet paramConstraintSet) {
    for (Integer integer : paramConstraintSet.mConstraints.keySet()) {
      int i = integer.intValue();
      Constraint constraint1 = paramConstraintSet.mConstraints.get(integer);
      if (!this.mConstraints.containsKey(Integer.valueOf(i)))
        this.mConstraints.put(Integer.valueOf(i), new Constraint()); 
      Constraint constraint2 = this.mConstraints.get(Integer.valueOf(i));
      Layout layout = constraint2.layout;
      if (!layout.mApply)
        layout.copyFrom(constraint1.layout); 
      PropertySet propertySet = constraint2.propertySet;
      if (!propertySet.mApply)
        propertySet.copyFrom(constraint1.propertySet); 
      Transform transform = constraint2.transform;
      if (!transform.mApply)
        transform.copyFrom(constraint1.transform); 
      Motion motion = constraint2.motion;
      if (!motion.mApply)
        motion.copyFrom(constraint1.motion); 
      for (String str : constraint1.mCustomConstraints.keySet()) {
        if (!constraint2.mCustomConstraints.containsKey(str))
          constraint2.mCustomConstraints.put(str, constraint1.mCustomConstraints.get(str)); 
      } 
    } 
  }
  
  public void removeAttribute(String paramString) {
    this.mSavedAttributes.remove(paramString);
  }
  
  public void removeFromHorizontalChain(int paramInt) {
    if (this.mConstraints.containsKey(Integer.valueOf(paramInt))) {
      Layout layout = ((Constraint)this.mConstraints.get(Integer.valueOf(paramInt))).layout;
      int i = layout.leftToRight;
      int j = layout.rightToLeft;
      if (i != -1 || j != -1) {
        if (i != -1 && j != -1) {
          connect(i, 2, j, 1, 0);
          connect(j, 1, i, 2, 0);
        } else if (i != -1 || j != -1) {
          int m = layout.rightToRight;
          if (m != -1) {
            connect(i, 2, m, 2, 0);
          } else {
            i = layout.leftToLeft;
            if (i != -1)
              connect(j, 1, i, 1, 0); 
          } 
        } 
        clear(paramInt, 1);
        clear(paramInt, 2);
        return;
      } 
      int k = layout.startToEnd;
      j = layout.endToStart;
      if (k != -1 || j != -1)
        if (k != -1 && j != -1) {
          connect(k, 7, j, 6, 0);
          connect(j, 6, i, 7, 0);
        } else if (i != -1 || j != -1) {
          k = layout.rightToRight;
          if (k != -1) {
            connect(i, 7, k, 7, 0);
          } else {
            i = layout.leftToLeft;
            if (i != -1)
              connect(j, 6, i, 6, 0); 
          } 
        }  
      clear(paramInt, 6);
      clear(paramInt, 7);
      return;
    } 
  }
  
  public void removeFromVerticalChain(int paramInt) {
    if (this.mConstraints.containsKey(Integer.valueOf(paramInt))) {
      Layout layout = ((Constraint)this.mConstraints.get(Integer.valueOf(paramInt))).layout;
      int j = layout.topToBottom;
      int i = layout.bottomToTop;
      if (j != -1 || i != -1)
        if (j != -1 && i != -1) {
          connect(j, 4, i, 3, 0);
          connect(i, 3, j, 4, 0);
        } else if (j != -1 || i != -1) {
          int k = layout.bottomToBottom;
          if (k != -1) {
            connect(j, 4, k, 4, 0);
          } else {
            j = layout.topToTop;
            if (j != -1)
              connect(i, 3, j, 3, 0); 
          } 
        }  
    } 
    clear(paramInt, 3);
    clear(paramInt, 4);
  }
  
  public void setAlpha(int paramInt, float paramFloat) {
    (get(paramInt)).propertySet.alpha = paramFloat;
  }
  
  public void setApplyElevation(int paramInt, boolean paramBoolean) {
    (get(paramInt)).transform.applyElevation = paramBoolean;
  }
  
  public void setBarrierType(int paramInt1, int paramInt2) {
    (get(paramInt1)).layout.mHelperType = paramInt2;
  }
  
  public void setColorValue(int paramInt1, String paramString, int paramInt2) {
    get(paramInt1).setColorValue(paramString, paramInt2);
  }
  
  public void setDimensionRatio(int paramInt, String paramString) {
    (get(paramInt)).layout.dimensionRatio = paramString;
  }
  
  public void setEditorAbsoluteX(int paramInt1, int paramInt2) {
    (get(paramInt1)).layout.editorAbsoluteX = paramInt2;
  }
  
  public void setEditorAbsoluteY(int paramInt1, int paramInt2) {
    (get(paramInt1)).layout.editorAbsoluteY = paramInt2;
  }
  
  public void setElevation(int paramInt, float paramFloat) {
    (get(paramInt)).transform.elevation = paramFloat;
    (get(paramInt)).transform.applyElevation = true;
  }
  
  public void setFloatValue(int paramInt, String paramString, float paramFloat) {
    get(paramInt).setFloatValue(paramString, paramFloat);
  }
  
  public void setForceId(boolean paramBoolean) {
    this.mForceId = paramBoolean;
  }
  
  public void setGoneMargin(int paramInt1, int paramInt2, int paramInt3) {
    Constraint constraint = get(paramInt1);
    switch (paramInt2) {
      default:
        throw new IllegalArgumentException("unknown constraint");
      case 7:
        constraint.layout.goneEndMargin = paramInt3;
        return;
      case 6:
        constraint.layout.goneStartMargin = paramInt3;
        return;
      case 5:
        throw new IllegalArgumentException("baseline does not support margins");
      case 4:
        constraint.layout.goneBottomMargin = paramInt3;
        return;
      case 3:
        constraint.layout.goneTopMargin = paramInt3;
        return;
      case 2:
        constraint.layout.goneRightMargin = paramInt3;
        return;
      case 1:
        break;
    } 
    constraint.layout.goneLeftMargin = paramInt3;
  }
  
  public void setGuidelineBegin(int paramInt1, int paramInt2) {
    (get(paramInt1)).layout.guideBegin = paramInt2;
    (get(paramInt1)).layout.guideEnd = -1;
    (get(paramInt1)).layout.guidePercent = -1.0F;
  }
  
  public void setGuidelineEnd(int paramInt1, int paramInt2) {
    (get(paramInt1)).layout.guideEnd = paramInt2;
    (get(paramInt1)).layout.guideBegin = -1;
    (get(paramInt1)).layout.guidePercent = -1.0F;
  }
  
  public void setGuidelinePercent(int paramInt, float paramFloat) {
    (get(paramInt)).layout.guidePercent = paramFloat;
    (get(paramInt)).layout.guideEnd = -1;
    (get(paramInt)).layout.guideBegin = -1;
  }
  
  public void setHorizontalBias(int paramInt, float paramFloat) {
    (get(paramInt)).layout.horizontalBias = paramFloat;
  }
  
  public void setHorizontalChainStyle(int paramInt1, int paramInt2) {
    (get(paramInt1)).layout.horizontalChainStyle = paramInt2;
  }
  
  public void setHorizontalWeight(int paramInt, float paramFloat) {
    (get(paramInt)).layout.horizontalWeight = paramFloat;
  }
  
  public void setIntValue(int paramInt1, String paramString, int paramInt2) {
    get(paramInt1).setIntValue(paramString, paramInt2);
  }
  
  public void setMargin(int paramInt1, int paramInt2, int paramInt3) {
    Constraint constraint = get(paramInt1);
    switch (paramInt2) {
      default:
        throw new IllegalArgumentException("unknown constraint");
      case 7:
        constraint.layout.endMargin = paramInt3;
        return;
      case 6:
        constraint.layout.startMargin = paramInt3;
        return;
      case 5:
        throw new IllegalArgumentException("baseline does not support margins");
      case 4:
        constraint.layout.bottomMargin = paramInt3;
        return;
      case 3:
        constraint.layout.topMargin = paramInt3;
        return;
      case 2:
        constraint.layout.rightMargin = paramInt3;
        return;
      case 1:
        break;
    } 
    constraint.layout.leftMargin = paramInt3;
  }
  
  public void setReferencedIds(int paramInt, int... paramVarArgs) {
    (get(paramInt)).layout.mReferenceIds = paramVarArgs;
  }
  
  public void setRotation(int paramInt, float paramFloat) {
    (get(paramInt)).transform.rotation = paramFloat;
  }
  
  public void setRotationX(int paramInt, float paramFloat) {
    (get(paramInt)).transform.rotationX = paramFloat;
  }
  
  public void setRotationY(int paramInt, float paramFloat) {
    (get(paramInt)).transform.rotationY = paramFloat;
  }
  
  public void setScaleX(int paramInt, float paramFloat) {
    (get(paramInt)).transform.scaleX = paramFloat;
  }
  
  public void setScaleY(int paramInt, float paramFloat) {
    (get(paramInt)).transform.scaleY = paramFloat;
  }
  
  public void setStringValue(int paramInt, String paramString1, String paramString2) {
    get(paramInt).setStringValue(paramString1, paramString2);
  }
  
  public void setTransformPivot(int paramInt, float paramFloat1, float paramFloat2) {
    Transform transform = (get(paramInt)).transform;
    transform.transformPivotY = paramFloat2;
    transform.transformPivotX = paramFloat1;
  }
  
  public void setTransformPivotX(int paramInt, float paramFloat) {
    (get(paramInt)).transform.transformPivotX = paramFloat;
  }
  
  public void setTransformPivotY(int paramInt, float paramFloat) {
    (get(paramInt)).transform.transformPivotY = paramFloat;
  }
  
  public void setTranslation(int paramInt, float paramFloat1, float paramFloat2) {
    Transform transform = (get(paramInt)).transform;
    transform.translationX = paramFloat1;
    transform.translationY = paramFloat2;
  }
  
  public void setTranslationX(int paramInt, float paramFloat) {
    (get(paramInt)).transform.translationX = paramFloat;
  }
  
  public void setTranslationY(int paramInt, float paramFloat) {
    (get(paramInt)).transform.translationY = paramFloat;
  }
  
  public void setTranslationZ(int paramInt, float paramFloat) {
    (get(paramInt)).transform.translationZ = paramFloat;
  }
  
  public void setValidateOnParse(boolean paramBoolean) {
    this.mValidate = paramBoolean;
  }
  
  public void setVerticalBias(int paramInt, float paramFloat) {
    (get(paramInt)).layout.verticalBias = paramFloat;
  }
  
  public void setVerticalChainStyle(int paramInt1, int paramInt2) {
    (get(paramInt1)).layout.verticalChainStyle = paramInt2;
  }
  
  public void setVerticalWeight(int paramInt, float paramFloat) {
    (get(paramInt)).layout.verticalWeight = paramFloat;
  }
  
  public void setVisibility(int paramInt1, int paramInt2) {
    (get(paramInt1)).propertySet.visibility = paramInt2;
  }
  
  public void setVisibilityMode(int paramInt1, int paramInt2) {
    (get(paramInt1)).propertySet.mVisibilityMode = paramInt2;
  }
  
  public static class Constraint {
    public final ConstraintSet.Layout layout = new ConstraintSet.Layout();
    
    public HashMap<String, ConstraintAttribute> mCustomConstraints = new HashMap<String, ConstraintAttribute>();
    
    int mViewId;
    
    public final ConstraintSet.Motion motion = new ConstraintSet.Motion();
    
    public final ConstraintSet.PropertySet propertySet = new ConstraintSet.PropertySet();
    
    public final ConstraintSet.Transform transform = new ConstraintSet.Transform();
    
    private void fillFrom(int param1Int, ConstraintLayout.LayoutParams param1LayoutParams) {
      this.mViewId = param1Int;
      ConstraintSet.Layout layout = this.layout;
      layout.leftToLeft = param1LayoutParams.leftToLeft;
      layout.leftToRight = param1LayoutParams.leftToRight;
      layout.rightToLeft = param1LayoutParams.rightToLeft;
      layout.rightToRight = param1LayoutParams.rightToRight;
      layout.topToTop = param1LayoutParams.topToTop;
      layout.topToBottom = param1LayoutParams.topToBottom;
      layout.bottomToTop = param1LayoutParams.bottomToTop;
      layout.bottomToBottom = param1LayoutParams.bottomToBottom;
      layout.baselineToBaseline = param1LayoutParams.baselineToBaseline;
      layout.startToEnd = param1LayoutParams.startToEnd;
      layout.startToStart = param1LayoutParams.startToStart;
      layout.endToStart = param1LayoutParams.endToStart;
      layout.endToEnd = param1LayoutParams.endToEnd;
      layout.horizontalBias = param1LayoutParams.horizontalBias;
      layout.verticalBias = param1LayoutParams.verticalBias;
      layout.dimensionRatio = param1LayoutParams.dimensionRatio;
      layout.circleConstraint = param1LayoutParams.circleConstraint;
      layout.circleRadius = param1LayoutParams.circleRadius;
      layout.circleAngle = param1LayoutParams.circleAngle;
      layout.editorAbsoluteX = param1LayoutParams.editorAbsoluteX;
      layout.editorAbsoluteY = param1LayoutParams.editorAbsoluteY;
      layout.orientation = param1LayoutParams.orientation;
      layout.guidePercent = param1LayoutParams.guidePercent;
      layout.guideBegin = param1LayoutParams.guideBegin;
      layout.guideEnd = param1LayoutParams.guideEnd;
      layout.mWidth = param1LayoutParams.width;
      layout.mHeight = param1LayoutParams.height;
      layout.leftMargin = param1LayoutParams.leftMargin;
      layout.rightMargin = param1LayoutParams.rightMargin;
      layout.topMargin = param1LayoutParams.topMargin;
      layout.bottomMargin = param1LayoutParams.bottomMargin;
      layout.verticalWeight = param1LayoutParams.verticalWeight;
      layout.horizontalWeight = param1LayoutParams.horizontalWeight;
      layout.verticalChainStyle = param1LayoutParams.verticalChainStyle;
      layout.horizontalChainStyle = param1LayoutParams.horizontalChainStyle;
      layout.constrainedWidth = param1LayoutParams.constrainedWidth;
      layout.constrainedHeight = param1LayoutParams.constrainedHeight;
      layout.widthDefault = param1LayoutParams.matchConstraintDefaultWidth;
      layout.heightDefault = param1LayoutParams.matchConstraintDefaultHeight;
      layout.widthMax = param1LayoutParams.matchConstraintMaxWidth;
      layout.heightMax = param1LayoutParams.matchConstraintMaxHeight;
      layout.widthMin = param1LayoutParams.matchConstraintMinWidth;
      layout.heightMin = param1LayoutParams.matchConstraintMinHeight;
      layout.widthPercent = param1LayoutParams.matchConstraintPercentWidth;
      layout.heightPercent = param1LayoutParams.matchConstraintPercentHeight;
      layout.mConstraintTag = param1LayoutParams.constraintTag;
      layout.goneTopMargin = param1LayoutParams.goneTopMargin;
      layout.goneBottomMargin = param1LayoutParams.goneBottomMargin;
      layout.goneLeftMargin = param1LayoutParams.goneLeftMargin;
      layout.goneRightMargin = param1LayoutParams.goneRightMargin;
      layout.goneStartMargin = param1LayoutParams.goneStartMargin;
      layout.goneEndMargin = param1LayoutParams.goneEndMargin;
      layout.endMargin = param1LayoutParams.getMarginEnd();
      this.layout.startMargin = param1LayoutParams.getMarginStart();
    }
    
    private void fillFromConstraints(int param1Int, Constraints.LayoutParams param1LayoutParams) {
      fillFrom(param1Int, param1LayoutParams);
      this.propertySet.alpha = param1LayoutParams.alpha;
      ConstraintSet.Transform transform = this.transform;
      transform.rotation = param1LayoutParams.rotation;
      transform.rotationX = param1LayoutParams.rotationX;
      transform.rotationY = param1LayoutParams.rotationY;
      transform.scaleX = param1LayoutParams.scaleX;
      transform.scaleY = param1LayoutParams.scaleY;
      transform.transformPivotX = param1LayoutParams.transformPivotX;
      transform.transformPivotY = param1LayoutParams.transformPivotY;
      transform.translationX = param1LayoutParams.translationX;
      transform.translationY = param1LayoutParams.translationY;
      transform.translationZ = param1LayoutParams.translationZ;
      transform.elevation = param1LayoutParams.elevation;
      transform.applyElevation = param1LayoutParams.applyElevation;
    }
    
    private void fillFromConstraints(ConstraintHelper param1ConstraintHelper, int param1Int, Constraints.LayoutParams param1LayoutParams) {
      fillFromConstraints(param1Int, param1LayoutParams);
      if (param1ConstraintHelper instanceof Barrier) {
        ConstraintSet.Layout layout = this.layout;
        layout.mHelperType = 1;
        param1ConstraintHelper = param1ConstraintHelper;
        layout.mBarrierDirection = param1ConstraintHelper.getType();
        this.layout.mReferenceIds = param1ConstraintHelper.getReferencedIds();
        this.layout.mBarrierMargin = param1ConstraintHelper.getMargin();
      } 
    }
    
    private ConstraintAttribute get(String param1String, ConstraintAttribute.AttributeType param1AttributeType) {
      ConstraintAttribute constraintAttribute1;
      StringBuilder stringBuilder;
      if (this.mCustomConstraints.containsKey(param1String)) {
        constraintAttribute1 = this.mCustomConstraints.get(param1String);
        if (constraintAttribute1.getType() == param1AttributeType)
          return constraintAttribute1; 
        stringBuilder = new StringBuilder();
        stringBuilder.append("ConstraintAttribute is already a ");
        stringBuilder.append(constraintAttribute1.getType().name());
        throw new IllegalArgumentException(stringBuilder.toString());
      } 
      ConstraintAttribute constraintAttribute2 = new ConstraintAttribute((String)constraintAttribute1, (ConstraintAttribute.AttributeType)stringBuilder);
      this.mCustomConstraints.put(constraintAttribute1, constraintAttribute2);
      return constraintAttribute2;
    }
    
    private void setColorValue(String param1String, int param1Int) {
      get(param1String, ConstraintAttribute.AttributeType.COLOR_TYPE).setColorValue(param1Int);
    }
    
    private void setFloatValue(String param1String, float param1Float) {
      get(param1String, ConstraintAttribute.AttributeType.FLOAT_TYPE).setFloatValue(param1Float);
    }
    
    private void setIntValue(String param1String, int param1Int) {
      get(param1String, ConstraintAttribute.AttributeType.INT_TYPE).setIntValue(param1Int);
    }
    
    private void setStringValue(String param1String1, String param1String2) {
      get(param1String1, ConstraintAttribute.AttributeType.STRING_TYPE).setStringValue(param1String2);
    }
    
    public void applyTo(ConstraintLayout.LayoutParams param1LayoutParams) {
      ConstraintSet.Layout layout = this.layout;
      param1LayoutParams.leftToLeft = layout.leftToLeft;
      param1LayoutParams.leftToRight = layout.leftToRight;
      param1LayoutParams.rightToLeft = layout.rightToLeft;
      param1LayoutParams.rightToRight = layout.rightToRight;
      param1LayoutParams.topToTop = layout.topToTop;
      param1LayoutParams.topToBottom = layout.topToBottom;
      param1LayoutParams.bottomToTop = layout.bottomToTop;
      param1LayoutParams.bottomToBottom = layout.bottomToBottom;
      param1LayoutParams.baselineToBaseline = layout.baselineToBaseline;
      param1LayoutParams.startToEnd = layout.startToEnd;
      param1LayoutParams.startToStart = layout.startToStart;
      param1LayoutParams.endToStart = layout.endToStart;
      param1LayoutParams.endToEnd = layout.endToEnd;
      param1LayoutParams.leftMargin = layout.leftMargin;
      param1LayoutParams.rightMargin = layout.rightMargin;
      param1LayoutParams.topMargin = layout.topMargin;
      param1LayoutParams.bottomMargin = layout.bottomMargin;
      param1LayoutParams.goneStartMargin = layout.goneStartMargin;
      param1LayoutParams.goneEndMargin = layout.goneEndMargin;
      param1LayoutParams.goneTopMargin = layout.goneTopMargin;
      param1LayoutParams.goneBottomMargin = layout.goneBottomMargin;
      param1LayoutParams.horizontalBias = layout.horizontalBias;
      param1LayoutParams.verticalBias = layout.verticalBias;
      param1LayoutParams.circleConstraint = layout.circleConstraint;
      param1LayoutParams.circleRadius = layout.circleRadius;
      param1LayoutParams.circleAngle = layout.circleAngle;
      param1LayoutParams.dimensionRatio = layout.dimensionRatio;
      param1LayoutParams.editorAbsoluteX = layout.editorAbsoluteX;
      param1LayoutParams.editorAbsoluteY = layout.editorAbsoluteY;
      param1LayoutParams.verticalWeight = layout.verticalWeight;
      param1LayoutParams.horizontalWeight = layout.horizontalWeight;
      param1LayoutParams.verticalChainStyle = layout.verticalChainStyle;
      param1LayoutParams.horizontalChainStyle = layout.horizontalChainStyle;
      param1LayoutParams.constrainedWidth = layout.constrainedWidth;
      param1LayoutParams.constrainedHeight = layout.constrainedHeight;
      param1LayoutParams.matchConstraintDefaultWidth = layout.widthDefault;
      param1LayoutParams.matchConstraintDefaultHeight = layout.heightDefault;
      param1LayoutParams.matchConstraintMaxWidth = layout.widthMax;
      param1LayoutParams.matchConstraintMaxHeight = layout.heightMax;
      param1LayoutParams.matchConstraintMinWidth = layout.widthMin;
      param1LayoutParams.matchConstraintMinHeight = layout.heightMin;
      param1LayoutParams.matchConstraintPercentWidth = layout.widthPercent;
      param1LayoutParams.matchConstraintPercentHeight = layout.heightPercent;
      param1LayoutParams.orientation = layout.orientation;
      param1LayoutParams.guidePercent = layout.guidePercent;
      param1LayoutParams.guideBegin = layout.guideBegin;
      param1LayoutParams.guideEnd = layout.guideEnd;
      param1LayoutParams.width = layout.mWidth;
      param1LayoutParams.height = layout.mHeight;
      String str = layout.mConstraintTag;
      if (str != null)
        param1LayoutParams.constraintTag = str; 
      param1LayoutParams.setMarginStart(layout.startMargin);
      param1LayoutParams.setMarginEnd(this.layout.endMargin);
      param1LayoutParams.validate();
    }
    
    public Constraint clone() {
      Constraint constraint = new Constraint();
      constraint.layout.copyFrom(this.layout);
      constraint.motion.copyFrom(this.motion);
      constraint.propertySet.copyFrom(this.propertySet);
      constraint.transform.copyFrom(this.transform);
      constraint.mViewId = this.mViewId;
      return constraint;
    }
  }
  
  public static class Layout {
    private static final int BARRIER_ALLOWS_GONE_WIDGETS = 75;
    
    private static final int BARRIER_DIRECTION = 72;
    
    private static final int BARRIER_MARGIN = 73;
    
    private static final int BASELINE_TO_BASELINE = 1;
    
    private static final int BOTTOM_MARGIN = 2;
    
    private static final int BOTTOM_TO_BOTTOM = 3;
    
    private static final int BOTTOM_TO_TOP = 4;
    
    private static final int CHAIN_USE_RTL = 71;
    
    private static final int CIRCLE = 61;
    
    private static final int CIRCLE_ANGLE = 63;
    
    private static final int CIRCLE_RADIUS = 62;
    
    private static final int CONSTRAINT_REFERENCED_IDS = 74;
    
    private static final int DIMENSION_RATIO = 5;
    
    private static final int EDITOR_ABSOLUTE_X = 6;
    
    private static final int EDITOR_ABSOLUTE_Y = 7;
    
    private static final int END_MARGIN = 8;
    
    private static final int END_TO_END = 9;
    
    private static final int END_TO_START = 10;
    
    private static final int GONE_BOTTOM_MARGIN = 11;
    
    private static final int GONE_END_MARGIN = 12;
    
    private static final int GONE_LEFT_MARGIN = 13;
    
    private static final int GONE_RIGHT_MARGIN = 14;
    
    private static final int GONE_START_MARGIN = 15;
    
    private static final int GONE_TOP_MARGIN = 16;
    
    private static final int GUIDE_BEGIN = 17;
    
    private static final int GUIDE_END = 18;
    
    private static final int GUIDE_PERCENT = 19;
    
    private static final int HEIGHT_PERCENT = 70;
    
    private static final int HORIZONTAL_BIAS = 20;
    
    private static final int HORIZONTAL_STYLE = 39;
    
    private static final int HORIZONTAL_WEIGHT = 37;
    
    private static final int LAYOUT_HEIGHT = 21;
    
    private static final int LAYOUT_WIDTH = 22;
    
    private static final int LEFT_MARGIN = 23;
    
    private static final int LEFT_TO_LEFT = 24;
    
    private static final int LEFT_TO_RIGHT = 25;
    
    private static final int ORIENTATION = 26;
    
    private static final int RIGHT_MARGIN = 27;
    
    private static final int RIGHT_TO_LEFT = 28;
    
    private static final int RIGHT_TO_RIGHT = 29;
    
    private static final int START_MARGIN = 30;
    
    private static final int START_TO_END = 31;
    
    private static final int START_TO_START = 32;
    
    private static final int TOP_MARGIN = 33;
    
    private static final int TOP_TO_BOTTOM = 34;
    
    private static final int TOP_TO_TOP = 35;
    
    public static final int UNSET = -1;
    
    private static final int UNUSED = 76;
    
    private static final int VERTICAL_BIAS = 36;
    
    private static final int VERTICAL_STYLE = 40;
    
    private static final int VERTICAL_WEIGHT = 38;
    
    private static final int WIDTH_PERCENT = 69;
    
    private static SparseIntArray mapToConstant;
    
    public int baselineToBaseline = -1;
    
    public int bottomMargin = -1;
    
    public int bottomToBottom = -1;
    
    public int bottomToTop = -1;
    
    public float circleAngle = 0.0F;
    
    public int circleConstraint = -1;
    
    public int circleRadius = 0;
    
    public boolean constrainedHeight = false;
    
    public boolean constrainedWidth = false;
    
    public String dimensionRatio = null;
    
    public int editorAbsoluteX = -1;
    
    public int editorAbsoluteY = -1;
    
    public int endMargin = -1;
    
    public int endToEnd = -1;
    
    public int endToStart = -1;
    
    public int goneBottomMargin = -1;
    
    public int goneEndMargin = -1;
    
    public int goneLeftMargin = -1;
    
    public int goneRightMargin = -1;
    
    public int goneStartMargin = -1;
    
    public int goneTopMargin = -1;
    
    public int guideBegin = -1;
    
    public int guideEnd = -1;
    
    public float guidePercent = -1.0F;
    
    public int heightDefault = 0;
    
    public int heightMax = -1;
    
    public int heightMin = -1;
    
    public float heightPercent = 1.0F;
    
    public float horizontalBias = 0.5F;
    
    public int horizontalChainStyle = 0;
    
    public float horizontalWeight = -1.0F;
    
    public int leftMargin = -1;
    
    public int leftToLeft = -1;
    
    public int leftToRight = -1;
    
    public boolean mApply = false;
    
    public boolean mBarrierAllowsGoneWidgets = true;
    
    public int mBarrierDirection = -1;
    
    public int mBarrierMargin = 0;
    
    public String mConstraintTag;
    
    public int mHeight;
    
    public int mHelperType = -1;
    
    public boolean mIsGuideline = false;
    
    public String mReferenceIdString;
    
    public int[] mReferenceIds;
    
    public int mWidth;
    
    public int orientation = -1;
    
    public int rightMargin = -1;
    
    public int rightToLeft = -1;
    
    public int rightToRight = -1;
    
    public int startMargin = -1;
    
    public int startToEnd = -1;
    
    public int startToStart = -1;
    
    public int topMargin = -1;
    
    public int topToBottom = -1;
    
    public int topToTop = -1;
    
    public float verticalBias = 0.5F;
    
    public int verticalChainStyle = 0;
    
    public float verticalWeight = -1.0F;
    
    public int widthDefault = 0;
    
    public int widthMax = -1;
    
    public int widthMin = -1;
    
    public float widthPercent = 1.0F;
    
    static {
      SparseIntArray sparseIntArray = new SparseIntArray();
      mapToConstant = sparseIntArray;
      sparseIntArray.append(R.styleable.Layout_layout_constraintLeft_toLeftOf, 24);
      mapToConstant.append(R.styleable.Layout_layout_constraintLeft_toRightOf, 25);
      mapToConstant.append(R.styleable.Layout_layout_constraintRight_toLeftOf, 28);
      mapToConstant.append(R.styleable.Layout_layout_constraintRight_toRightOf, 29);
      mapToConstant.append(R.styleable.Layout_layout_constraintTop_toTopOf, 35);
      mapToConstant.append(R.styleable.Layout_layout_constraintTop_toBottomOf, 34);
      mapToConstant.append(R.styleable.Layout_layout_constraintBottom_toTopOf, 4);
      mapToConstant.append(R.styleable.Layout_layout_constraintBottom_toBottomOf, 3);
      mapToConstant.append(R.styleable.Layout_layout_constraintBaseline_toBaselineOf, 1);
      mapToConstant.append(R.styleable.Layout_layout_editor_absoluteX, 6);
      mapToConstant.append(R.styleable.Layout_layout_editor_absoluteY, 7);
      mapToConstant.append(R.styleable.Layout_layout_constraintGuide_begin, 17);
      mapToConstant.append(R.styleable.Layout_layout_constraintGuide_end, 18);
      mapToConstant.append(R.styleable.Layout_layout_constraintGuide_percent, 19);
      mapToConstant.append(R.styleable.Layout_android_orientation, 26);
      mapToConstant.append(R.styleable.Layout_layout_constraintStart_toEndOf, 31);
      mapToConstant.append(R.styleable.Layout_layout_constraintStart_toStartOf, 32);
      mapToConstant.append(R.styleable.Layout_layout_constraintEnd_toStartOf, 10);
      mapToConstant.append(R.styleable.Layout_layout_constraintEnd_toEndOf, 9);
      mapToConstant.append(R.styleable.Layout_layout_goneMarginLeft, 13);
      mapToConstant.append(R.styleable.Layout_layout_goneMarginTop, 16);
      mapToConstant.append(R.styleable.Layout_layout_goneMarginRight, 14);
      mapToConstant.append(R.styleable.Layout_layout_goneMarginBottom, 11);
      mapToConstant.append(R.styleable.Layout_layout_goneMarginStart, 15);
      mapToConstant.append(R.styleable.Layout_layout_goneMarginEnd, 12);
      mapToConstant.append(R.styleable.Layout_layout_constraintVertical_weight, 38);
      mapToConstant.append(R.styleable.Layout_layout_constraintHorizontal_weight, 37);
      mapToConstant.append(R.styleable.Layout_layout_constraintHorizontal_chainStyle, 39);
      mapToConstant.append(R.styleable.Layout_layout_constraintVertical_chainStyle, 40);
      mapToConstant.append(R.styleable.Layout_layout_constraintHorizontal_bias, 20);
      mapToConstant.append(R.styleable.Layout_layout_constraintVertical_bias, 36);
      mapToConstant.append(R.styleable.Layout_layout_constraintDimensionRatio, 5);
      mapToConstant.append(R.styleable.Layout_layout_constraintLeft_creator, 76);
      mapToConstant.append(R.styleable.Layout_layout_constraintTop_creator, 76);
      mapToConstant.append(R.styleable.Layout_layout_constraintRight_creator, 76);
      mapToConstant.append(R.styleable.Layout_layout_constraintBottom_creator, 76);
      mapToConstant.append(R.styleable.Layout_layout_constraintBaseline_creator, 76);
      mapToConstant.append(R.styleable.Layout_android_layout_marginLeft, 23);
      mapToConstant.append(R.styleable.Layout_android_layout_marginRight, 27);
      mapToConstant.append(R.styleable.Layout_android_layout_marginStart, 30);
      mapToConstant.append(R.styleable.Layout_android_layout_marginEnd, 8);
      mapToConstant.append(R.styleable.Layout_android_layout_marginTop, 33);
      mapToConstant.append(R.styleable.Layout_android_layout_marginBottom, 2);
      mapToConstant.append(R.styleable.Layout_android_layout_width, 22);
      mapToConstant.append(R.styleable.Layout_android_layout_height, 21);
      mapToConstant.append(R.styleable.Layout_layout_constraintCircle, 61);
      mapToConstant.append(R.styleable.Layout_layout_constraintCircleRadius, 62);
      mapToConstant.append(R.styleable.Layout_layout_constraintCircleAngle, 63);
      mapToConstant.append(R.styleable.Layout_layout_constraintWidth_percent, 69);
      mapToConstant.append(R.styleable.Layout_layout_constraintHeight_percent, 70);
      mapToConstant.append(R.styleable.Layout_chainUseRtl, 71);
      mapToConstant.append(R.styleable.Layout_barrierDirection, 72);
      mapToConstant.append(R.styleable.Layout_barrierMargin, 73);
      mapToConstant.append(R.styleable.Layout_constraint_referenced_ids, 74);
      mapToConstant.append(R.styleable.Layout_barrierAllowsGoneWidgets, 75);
    }
    
    public void copyFrom(Layout param1Layout) {
      this.mIsGuideline = param1Layout.mIsGuideline;
      this.mWidth = param1Layout.mWidth;
      this.mApply = param1Layout.mApply;
      this.mHeight = param1Layout.mHeight;
      this.guideBegin = param1Layout.guideBegin;
      this.guideEnd = param1Layout.guideEnd;
      this.guidePercent = param1Layout.guidePercent;
      this.leftToLeft = param1Layout.leftToLeft;
      this.leftToRight = param1Layout.leftToRight;
      this.rightToLeft = param1Layout.rightToLeft;
      this.rightToRight = param1Layout.rightToRight;
      this.topToTop = param1Layout.topToTop;
      this.topToBottom = param1Layout.topToBottom;
      this.bottomToTop = param1Layout.bottomToTop;
      this.bottomToBottom = param1Layout.bottomToBottom;
      this.baselineToBaseline = param1Layout.baselineToBaseline;
      this.startToEnd = param1Layout.startToEnd;
      this.startToStart = param1Layout.startToStart;
      this.endToStart = param1Layout.endToStart;
      this.endToEnd = param1Layout.endToEnd;
      this.horizontalBias = param1Layout.horizontalBias;
      this.verticalBias = param1Layout.verticalBias;
      this.dimensionRatio = param1Layout.dimensionRatio;
      this.circleConstraint = param1Layout.circleConstraint;
      this.circleRadius = param1Layout.circleRadius;
      this.circleAngle = param1Layout.circleAngle;
      this.editorAbsoluteX = param1Layout.editorAbsoluteX;
      this.editorAbsoluteY = param1Layout.editorAbsoluteY;
      this.orientation = param1Layout.orientation;
      this.leftMargin = param1Layout.leftMargin;
      this.rightMargin = param1Layout.rightMargin;
      this.topMargin = param1Layout.topMargin;
      this.bottomMargin = param1Layout.bottomMargin;
      this.endMargin = param1Layout.endMargin;
      this.startMargin = param1Layout.startMargin;
      this.goneLeftMargin = param1Layout.goneLeftMargin;
      this.goneTopMargin = param1Layout.goneTopMargin;
      this.goneRightMargin = param1Layout.goneRightMargin;
      this.goneBottomMargin = param1Layout.goneBottomMargin;
      this.goneEndMargin = param1Layout.goneEndMargin;
      this.goneStartMargin = param1Layout.goneStartMargin;
      this.verticalWeight = param1Layout.verticalWeight;
      this.horizontalWeight = param1Layout.horizontalWeight;
      this.horizontalChainStyle = param1Layout.horizontalChainStyle;
      this.verticalChainStyle = param1Layout.verticalChainStyle;
      this.widthDefault = param1Layout.widthDefault;
      this.heightDefault = param1Layout.heightDefault;
      this.widthMax = param1Layout.widthMax;
      this.heightMax = param1Layout.heightMax;
      this.widthMin = param1Layout.widthMin;
      this.heightMin = param1Layout.heightMin;
      this.widthPercent = param1Layout.widthPercent;
      this.heightPercent = param1Layout.heightPercent;
      this.mBarrierDirection = param1Layout.mBarrierDirection;
      this.mBarrierMargin = param1Layout.mBarrierMargin;
      this.mHelperType = param1Layout.mHelperType;
      this.mConstraintTag = param1Layout.mConstraintTag;
      int[] arrayOfInt = param1Layout.mReferenceIds;
      if (arrayOfInt != null) {
        this.mReferenceIds = Arrays.copyOf(arrayOfInt, arrayOfInt.length);
      } else {
        this.mReferenceIds = null;
      } 
      this.mReferenceIdString = param1Layout.mReferenceIdString;
      this.constrainedWidth = param1Layout.constrainedWidth;
      this.constrainedHeight = param1Layout.constrainedHeight;
      this.mBarrierAllowsGoneWidgets = param1Layout.mBarrierAllowsGoneWidgets;
    }
    
    public void dump(MotionScene param1MotionScene, StringBuilder param1StringBuilder) {
      Field[] arrayOfField = getClass().getDeclaredFields();
      param1StringBuilder.append("\n");
      int i = 0;
      while (true) {
        if (i < arrayOfField.length) {
          Field field = arrayOfField[i];
          String str = field.getName();
          if (!Modifier.isStatic(field.getModifiers()))
            try {
              String str1;
              Object object = field.get(this);
              Class<?> clazz = field.getType();
              Class<int> clazz1 = int.class;
              if (clazz == clazz1) {
                object = object;
                if (object.intValue() != -1) {
                  str1 = param1MotionScene.lookUpConstraintName(object.intValue());
                  param1StringBuilder.append("    ");
                  param1StringBuilder.append(str);
                  param1StringBuilder.append(" = \"");
                  if (str1 != null)
                    object = str1; 
                  param1StringBuilder.append(object);
                  param1StringBuilder.append("\"\n");
                } 
              } else if (str1 == float.class) {
                object = object;
                if (object.floatValue() != -1.0F) {
                  param1StringBuilder.append("    ");
                  param1StringBuilder.append(str);
                  param1StringBuilder.append(" = \"");
                  param1StringBuilder.append(object);
                  param1StringBuilder.append("\"\n");
                } 
              } 
            } catch (IllegalAccessException illegalAccessException) {
              illegalAccessException.printStackTrace();
            }  
          i++;
          continue;
        } 
        return;
      } 
    }
    
    void fillFromAttributeList(Context param1Context, AttributeSet param1AttributeSet) {
      TypedArray typedArray = param1Context.obtainStyledAttributes(param1AttributeSet, R.styleable.Layout);
      this.mApply = true;
      int j = typedArray.getIndexCount();
      for (int i = 0; i < j; i++) {
        int k = typedArray.getIndex(i);
        int m = mapToConstant.get(k);
        if (m != 80) {
          if (m != 81) {
            StringBuilder stringBuilder;
            switch (m) {
              default:
                switch (m) {
                  default:
                    switch (m) {
                      default:
                        switch (m) {
                          default:
                            stringBuilder = new StringBuilder();
                            stringBuilder.append("Unknown attribute 0x");
                            stringBuilder.append(Integer.toHexString(k));
                            stringBuilder.append("   ");
                            stringBuilder.append(mapToConstant.get(k));
                            Log.w("ConstraintSet", stringBuilder.toString());
                            break;
                          case 77:
                            this.mConstraintTag = typedArray.getString(k);
                            break;
                          case 76:
                            stringBuilder = new StringBuilder();
                            stringBuilder.append("unused attribute 0x");
                            stringBuilder.append(Integer.toHexString(k));
                            stringBuilder.append("   ");
                            stringBuilder.append(mapToConstant.get(k));
                            Log.w("ConstraintSet", stringBuilder.toString());
                            break;
                          case 75:
                            this.mBarrierAllowsGoneWidgets = typedArray.getBoolean(k, this.mBarrierAllowsGoneWidgets);
                            break;
                          case 74:
                            this.mReferenceIdString = typedArray.getString(k);
                            break;
                          case 73:
                            this.mBarrierMargin = typedArray.getDimensionPixelSize(k, this.mBarrierMargin);
                            break;
                          case 72:
                            this.mBarrierDirection = typedArray.getInt(k, this.mBarrierDirection);
                            break;
                          case 71:
                            Log.e("ConstraintSet", "CURRENTLY UNSUPPORTED");
                            break;
                          case 70:
                            this.heightPercent = typedArray.getFloat(k, 1.0F);
                            break;
                          case 69:
                            break;
                        } 
                        this.widthPercent = typedArray.getFloat(k, 1.0F);
                        break;
                      case 63:
                        this.circleAngle = typedArray.getFloat(k, this.circleAngle);
                        break;
                      case 62:
                        this.circleRadius = typedArray.getDimensionPixelSize(k, this.circleRadius);
                        break;
                      case 61:
                        break;
                    } 
                    this.circleConstraint = ConstraintSet.lookupID(typedArray, k, this.circleConstraint);
                    break;
                  case 59:
                    this.heightMin = typedArray.getDimensionPixelSize(k, this.heightMin);
                    break;
                  case 58:
                    this.widthMin = typedArray.getDimensionPixelSize(k, this.widthMin);
                    break;
                  case 57:
                    this.heightMax = typedArray.getDimensionPixelSize(k, this.heightMax);
                    break;
                  case 56:
                    this.widthMax = typedArray.getDimensionPixelSize(k, this.widthMax);
                    break;
                  case 55:
                    this.heightDefault = typedArray.getInt(k, this.heightDefault);
                    break;
                  case 54:
                    break;
                } 
                this.widthDefault = typedArray.getInt(k, this.widthDefault);
                break;
              case 40:
                this.verticalChainStyle = typedArray.getInt(k, this.verticalChainStyle);
                break;
              case 39:
                this.horizontalChainStyle = typedArray.getInt(k, this.horizontalChainStyle);
                break;
              case 38:
                this.verticalWeight = typedArray.getFloat(k, this.verticalWeight);
                break;
              case 37:
                this.horizontalWeight = typedArray.getFloat(k, this.horizontalWeight);
                break;
              case 36:
                this.verticalBias = typedArray.getFloat(k, this.verticalBias);
                break;
              case 35:
                this.topToTop = ConstraintSet.lookupID(typedArray, k, this.topToTop);
                break;
              case 34:
                this.topToBottom = ConstraintSet.lookupID(typedArray, k, this.topToBottom);
                break;
              case 33:
                this.topMargin = typedArray.getDimensionPixelSize(k, this.topMargin);
                break;
              case 32:
                this.startToStart = ConstraintSet.lookupID(typedArray, k, this.startToStart);
                break;
              case 31:
                this.startToEnd = ConstraintSet.lookupID(typedArray, k, this.startToEnd);
                break;
              case 30:
                this.startMargin = typedArray.getDimensionPixelSize(k, this.startMargin);
                break;
              case 29:
                this.rightToRight = ConstraintSet.lookupID(typedArray, k, this.rightToRight);
                break;
              case 28:
                this.rightToLeft = ConstraintSet.lookupID(typedArray, k, this.rightToLeft);
                break;
              case 27:
                this.rightMargin = typedArray.getDimensionPixelSize(k, this.rightMargin);
                break;
              case 26:
                this.orientation = typedArray.getInt(k, this.orientation);
                break;
              case 25:
                this.leftToRight = ConstraintSet.lookupID(typedArray, k, this.leftToRight);
                break;
              case 24:
                this.leftToLeft = ConstraintSet.lookupID(typedArray, k, this.leftToLeft);
                break;
              case 23:
                this.leftMargin = typedArray.getDimensionPixelSize(k, this.leftMargin);
                break;
              case 22:
                this.mWidth = typedArray.getLayoutDimension(k, this.mWidth);
                break;
              case 21:
                this.mHeight = typedArray.getLayoutDimension(k, this.mHeight);
                break;
              case 20:
                this.horizontalBias = typedArray.getFloat(k, this.horizontalBias);
                break;
              case 19:
                this.guidePercent = typedArray.getFloat(k, this.guidePercent);
                break;
              case 18:
                this.guideEnd = typedArray.getDimensionPixelOffset(k, this.guideEnd);
                break;
              case 17:
                this.guideBegin = typedArray.getDimensionPixelOffset(k, this.guideBegin);
                break;
              case 16:
                this.goneTopMargin = typedArray.getDimensionPixelSize(k, this.goneTopMargin);
                break;
              case 15:
                this.goneStartMargin = typedArray.getDimensionPixelSize(k, this.goneStartMargin);
                break;
              case 14:
                this.goneRightMargin = typedArray.getDimensionPixelSize(k, this.goneRightMargin);
                break;
              case 13:
                this.goneLeftMargin = typedArray.getDimensionPixelSize(k, this.goneLeftMargin);
                break;
              case 12:
                this.goneEndMargin = typedArray.getDimensionPixelSize(k, this.goneEndMargin);
                break;
              case 11:
                this.goneBottomMargin = typedArray.getDimensionPixelSize(k, this.goneBottomMargin);
                break;
              case 10:
                this.endToStart = ConstraintSet.lookupID(typedArray, k, this.endToStart);
                break;
              case 9:
                this.endToEnd = ConstraintSet.lookupID(typedArray, k, this.endToEnd);
                break;
              case 8:
                this.endMargin = typedArray.getDimensionPixelSize(k, this.endMargin);
                break;
              case 7:
                this.editorAbsoluteY = typedArray.getDimensionPixelOffset(k, this.editorAbsoluteY);
                break;
              case 6:
                this.editorAbsoluteX = typedArray.getDimensionPixelOffset(k, this.editorAbsoluteX);
                break;
              case 5:
                this.dimensionRatio = typedArray.getString(k);
                break;
              case 4:
                this.bottomToTop = ConstraintSet.lookupID(typedArray, k, this.bottomToTop);
                break;
              case 3:
                this.bottomToBottom = ConstraintSet.lookupID(typedArray, k, this.bottomToBottom);
                break;
              case 2:
                this.bottomMargin = typedArray.getDimensionPixelSize(k, this.bottomMargin);
                break;
              case 1:
                this.baselineToBaseline = ConstraintSet.lookupID(typedArray, k, this.baselineToBaseline);
                break;
            } 
          } else {
            this.constrainedHeight = typedArray.getBoolean(k, this.constrainedHeight);
          } 
        } else {
          this.constrainedWidth = typedArray.getBoolean(k, this.constrainedWidth);
        } 
      } 
      typedArray.recycle();
    }
  }
  
  public static class Motion {
    private static final int ANIMATE_RELATIVE_TO = 5;
    
    private static final int MOTION_DRAW_PATH = 4;
    
    private static final int MOTION_STAGGER = 6;
    
    private static final int PATH_MOTION_ARC = 2;
    
    private static final int TRANSITION_EASING = 3;
    
    private static final int TRANSITION_PATH_ROTATE = 1;
    
    private static SparseIntArray mapToConstant;
    
    public int mAnimateRelativeTo = -1;
    
    public boolean mApply = false;
    
    public int mDrawPath = 0;
    
    public float mMotionStagger = Float.NaN;
    
    public int mPathMotionArc = -1;
    
    public float mPathRotate = Float.NaN;
    
    public String mTransitionEasing = null;
    
    static {
      SparseIntArray sparseIntArray = new SparseIntArray();
      mapToConstant = sparseIntArray;
      sparseIntArray.append(R.styleable.Motion_motionPathRotate, 1);
      mapToConstant.append(R.styleable.Motion_pathMotionArc, 2);
      mapToConstant.append(R.styleable.Motion_transitionEasing, 3);
      mapToConstant.append(R.styleable.Motion_drawPath, 4);
      mapToConstant.append(R.styleable.Motion_animate_relativeTo, 5);
      mapToConstant.append(R.styleable.Motion_motionStagger, 6);
    }
    
    public void copyFrom(Motion param1Motion) {
      this.mApply = param1Motion.mApply;
      this.mAnimateRelativeTo = param1Motion.mAnimateRelativeTo;
      this.mTransitionEasing = param1Motion.mTransitionEasing;
      this.mPathMotionArc = param1Motion.mPathMotionArc;
      this.mDrawPath = param1Motion.mDrawPath;
      this.mPathRotate = param1Motion.mPathRotate;
      this.mMotionStagger = param1Motion.mMotionStagger;
    }
    
    void fillFromAttributeList(Context param1Context, AttributeSet param1AttributeSet) {
      TypedArray typedArray = param1Context.obtainStyledAttributes(param1AttributeSet, R.styleable.Motion);
      this.mApply = true;
      int j = typedArray.getIndexCount();
      for (int i = 0; i < j; i++) {
        int k = typedArray.getIndex(i);
        switch (mapToConstant.get(k)) {
          case 6:
            this.mMotionStagger = typedArray.getFloat(k, this.mMotionStagger);
            break;
          case 5:
            this.mAnimateRelativeTo = ConstraintSet.lookupID(typedArray, k, this.mAnimateRelativeTo);
            break;
          case 4:
            this.mDrawPath = typedArray.getInt(k, 0);
            break;
          case 3:
            if ((typedArray.peekValue(k)).type == 3) {
              this.mTransitionEasing = typedArray.getString(k);
              break;
            } 
            this.mTransitionEasing = Easing.NAMED_EASING[typedArray.getInteger(k, 0)];
            break;
          case 2:
            this.mPathMotionArc = typedArray.getInt(k, this.mPathMotionArc);
            break;
          case 1:
            this.mPathRotate = typedArray.getFloat(k, this.mPathRotate);
            break;
        } 
      } 
      typedArray.recycle();
    }
  }
  
  public static class PropertySet {
    public float alpha = 1.0F;
    
    public boolean mApply = false;
    
    public float mProgress = Float.NaN;
    
    public int mVisibilityMode = 0;
    
    public int visibility = 0;
    
    public void copyFrom(PropertySet param1PropertySet) {
      this.mApply = param1PropertySet.mApply;
      this.visibility = param1PropertySet.visibility;
      this.alpha = param1PropertySet.alpha;
      this.mProgress = param1PropertySet.mProgress;
      this.mVisibilityMode = param1PropertySet.mVisibilityMode;
    }
    
    void fillFromAttributeList(Context param1Context, AttributeSet param1AttributeSet) {
      TypedArray typedArray = param1Context.obtainStyledAttributes(param1AttributeSet, R.styleable.PropertySet);
      this.mApply = true;
      int j = typedArray.getIndexCount();
      for (int i = 0; i < j; i++) {
        int k = typedArray.getIndex(i);
        if (k == R.styleable.PropertySet_android_alpha) {
          this.alpha = typedArray.getFloat(k, this.alpha);
        } else if (k == R.styleable.PropertySet_android_visibility) {
          this.visibility = typedArray.getInt(k, this.visibility);
          this.visibility = ConstraintSet.VISIBILITY_FLAGS[this.visibility];
        } else if (k == R.styleable.PropertySet_visibilityMode) {
          this.mVisibilityMode = typedArray.getInt(k, this.mVisibilityMode);
        } else if (k == R.styleable.PropertySet_motionProgress) {
          this.mProgress = typedArray.getFloat(k, this.mProgress);
        } 
      } 
      typedArray.recycle();
    }
  }
  
  public static class Transform {
    private static final int ELEVATION = 11;
    
    private static final int ROTATION = 1;
    
    private static final int ROTATION_X = 2;
    
    private static final int ROTATION_Y = 3;
    
    private static final int SCALE_X = 4;
    
    private static final int SCALE_Y = 5;
    
    private static final int TRANSFORM_PIVOT_X = 6;
    
    private static final int TRANSFORM_PIVOT_Y = 7;
    
    private static final int TRANSLATION_X = 8;
    
    private static final int TRANSLATION_Y = 9;
    
    private static final int TRANSLATION_Z = 10;
    
    private static SparseIntArray mapToConstant;
    
    public boolean applyElevation = false;
    
    public float elevation = 0.0F;
    
    public boolean mApply = false;
    
    public float rotation = 0.0F;
    
    public float rotationX = 0.0F;
    
    public float rotationY = 0.0F;
    
    public float scaleX = 1.0F;
    
    public float scaleY = 1.0F;
    
    public float transformPivotX = Float.NaN;
    
    public float transformPivotY = Float.NaN;
    
    public float translationX = 0.0F;
    
    public float translationY = 0.0F;
    
    public float translationZ = 0.0F;
    
    static {
      SparseIntArray sparseIntArray = new SparseIntArray();
      mapToConstant = sparseIntArray;
      sparseIntArray.append(R.styleable.Transform_android_rotation, 1);
      mapToConstant.append(R.styleable.Transform_android_rotationX, 2);
      mapToConstant.append(R.styleable.Transform_android_rotationY, 3);
      mapToConstant.append(R.styleable.Transform_android_scaleX, 4);
      mapToConstant.append(R.styleable.Transform_android_scaleY, 5);
      mapToConstant.append(R.styleable.Transform_android_transformPivotX, 6);
      mapToConstant.append(R.styleable.Transform_android_transformPivotY, 7);
      mapToConstant.append(R.styleable.Transform_android_translationX, 8);
      mapToConstant.append(R.styleable.Transform_android_translationY, 9);
      mapToConstant.append(R.styleable.Transform_android_translationZ, 10);
      mapToConstant.append(R.styleable.Transform_android_elevation, 11);
    }
    
    public void copyFrom(Transform param1Transform) {
      this.mApply = param1Transform.mApply;
      this.rotation = param1Transform.rotation;
      this.rotationX = param1Transform.rotationX;
      this.rotationY = param1Transform.rotationY;
      this.scaleX = param1Transform.scaleX;
      this.scaleY = param1Transform.scaleY;
      this.transformPivotX = param1Transform.transformPivotX;
      this.transformPivotY = param1Transform.transformPivotY;
      this.translationX = param1Transform.translationX;
      this.translationY = param1Transform.translationY;
      this.translationZ = param1Transform.translationZ;
      this.applyElevation = param1Transform.applyElevation;
      this.elevation = param1Transform.elevation;
    }
    
    void fillFromAttributeList(Context param1Context, AttributeSet param1AttributeSet) {
      TypedArray typedArray = param1Context.obtainStyledAttributes(param1AttributeSet, R.styleable.Transform);
      this.mApply = true;
      int j = typedArray.getIndexCount();
      for (int i = 0; i < j; i++) {
        int k = typedArray.getIndex(i);
        switch (mapToConstant.get(k)) {
          case 11:
            this.applyElevation = true;
            this.elevation = typedArray.getDimension(k, this.elevation);
            break;
          case 10:
            this.translationZ = typedArray.getDimension(k, this.translationZ);
            break;
          case 9:
            this.translationY = typedArray.getDimension(k, this.translationY);
            break;
          case 8:
            this.translationX = typedArray.getDimension(k, this.translationX);
            break;
          case 7:
            this.transformPivotY = typedArray.getDimension(k, this.transformPivotY);
            break;
          case 6:
            this.transformPivotX = typedArray.getDimension(k, this.transformPivotX);
            break;
          case 5:
            this.scaleY = typedArray.getFloat(k, this.scaleY);
            break;
          case 4:
            this.scaleX = typedArray.getFloat(k, this.scaleX);
            break;
          case 3:
            this.rotationY = typedArray.getFloat(k, this.rotationY);
            break;
          case 2:
            this.rotationX = typedArray.getFloat(k, this.rotationX);
            break;
          case 1:
            this.rotation = typedArray.getFloat(k, this.rotation);
            break;
        } 
      } 
      typedArray.recycle();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\BabyBus TV_Kids Videos & Games-dex2jar.jar!\androidx\constraintlayout\widget\ConstraintSet.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */