package androidx.constraintlayout.motion.widget;

import android.util.Log;
import android.view.View;
import androidx.constraintlayout.motion.utils.Easing;
import androidx.constraintlayout.solver.widgets.ConstraintWidget;
import androidx.constraintlayout.widget.ConstraintAttribute;
import androidx.constraintlayout.widget.ConstraintSet;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;

class MotionConstrainedPoint implements Comparable<MotionConstrainedPoint> {
  static final int CARTESIAN = 2;
  
  public static final boolean DEBUG = false;
  
  static final int PERPENDICULAR = 1;
  
  public static final String TAG = "MotionPaths";
  
  static String[] names = new String[] { "position", "x", "y", "width", "height", "pathRotate" };
  
  private float alpha = 1.0F;
  
  private boolean applyElevation = false;
  
  LinkedHashMap<String, ConstraintAttribute> attributes = new LinkedHashMap<String, ConstraintAttribute>();
  
  private float elevation = 0.0F;
  
  private float height;
  
  private int mDrawPath = 0;
  
  private Easing mKeyFrameEasing;
  
  int mMode = 0;
  
  private float mPathRotate = Float.NaN;
  
  private float mPivotX = Float.NaN;
  
  private float mPivotY = Float.NaN;
  
  private float mProgress = Float.NaN;
  
  double[] mTempDelta = new double[18];
  
  double[] mTempValue = new double[18];
  
  int mVisibilityMode = 0;
  
  private float position;
  
  private float rotation = 0.0F;
  
  private float rotationX = 0.0F;
  
  public float rotationY = 0.0F;
  
  private float scaleX = 1.0F;
  
  private float scaleY = 1.0F;
  
  private float translationX = 0.0F;
  
  private float translationY = 0.0F;
  
  private float translationZ = 0.0F;
  
  int visibility;
  
  private float width;
  
  private float x;
  
  private float y;
  
  private boolean diff(float paramFloat1, float paramFloat2) {
    return (Float.isNaN(paramFloat1) || Float.isNaN(paramFloat2)) ? ((Float.isNaN(paramFloat1) != Float.isNaN(paramFloat2))) : ((Math.abs(paramFloat1 - paramFloat2) > 1.0E-6F));
  }
  
  public void addValues(HashMap<String, SplineSet> paramHashMap, int paramInt) {
    for (String str : paramHashMap.keySet()) {
      StringBuilder stringBuilder1;
      StringBuilder stringBuilder2;
      SplineSet splineSet = paramHashMap.get(str);
      str.hashCode();
      byte b = -1;
      switch (str.hashCode()) {
        case 92909918:
          if (!str.equals("alpha"))
            break; 
          b = 13;
          break;
        case 37232917:
          if (!str.equals("transitionPathRotate"))
            break; 
          b = 12;
          break;
        case -4379043:
          if (!str.equals("elevation"))
            break; 
          b = 11;
          break;
        case -40300674:
          if (!str.equals("rotation"))
            break; 
          b = 10;
          break;
        case -760884509:
          if (!str.equals("transformPivotY"))
            break; 
          b = 9;
          break;
        case -760884510:
          if (!str.equals("transformPivotX"))
            break; 
          b = 8;
          break;
        case -908189617:
          if (!str.equals("scaleY"))
            break; 
          b = 7;
          break;
        case -908189618:
          if (!str.equals("scaleX"))
            break; 
          b = 6;
          break;
        case -1001078227:
          if (!str.equals("progress"))
            break; 
          b = 5;
          break;
        case -1225497655:
          if (!str.equals("translationZ"))
            break; 
          b = 4;
          break;
        case -1225497656:
          if (!str.equals("translationY"))
            break; 
          b = 3;
          break;
        case -1225497657:
          if (!str.equals("translationX"))
            break; 
          b = 2;
          break;
        case -1249320805:
          if (!str.equals("rotationY"))
            break; 
          b = 1;
          break;
        case -1249320806:
          if (!str.equals("rotationX"))
            break; 
          b = 0;
          break;
      } 
      float f1 = 1.0F;
      float f3 = 0.0F;
      float f4 = 0.0F;
      float f5 = 0.0F;
      float f6 = 0.0F;
      float f7 = 0.0F;
      float f8 = 0.0F;
      float f9 = 0.0F;
      float f10 = 0.0F;
      float f11 = 0.0F;
      float f12 = 0.0F;
      float f2 = 0.0F;
      switch (b) {
        default:
          if (str.startsWith("CUSTOM")) {
            ConstraintAttribute constraintAttribute;
            String str1 = str.split(",")[1];
            if (this.attributes.containsKey(str1)) {
              constraintAttribute = this.attributes.get(str1);
              if (splineSet instanceof SplineSet.CustomSet) {
                ((SplineSet.CustomSet)splineSet).setPoint(paramInt, constraintAttribute);
                continue;
              } 
              StringBuilder stringBuilder = new StringBuilder();
              stringBuilder.append(str);
              stringBuilder.append(" splineSet not a CustomSet frame = ");
              stringBuilder.append(paramInt);
              stringBuilder.append(", value");
              stringBuilder.append(constraintAttribute.getValueToInterpolate());
              stringBuilder.append(splineSet);
              Log.e("MotionPaths", stringBuilder.toString());
              continue;
            } 
            stringBuilder1 = new StringBuilder();
            stringBuilder1.append("UNKNOWN customName ");
            stringBuilder1.append((String)constraintAttribute);
            Log.e("MotionPaths", stringBuilder1.toString());
            continue;
          } 
          stringBuilder2 = new StringBuilder();
          stringBuilder2.append("UNKNOWN spline ");
          stringBuilder2.append((String)stringBuilder1);
          Log.e("MotionPaths", stringBuilder2.toString());
          continue;
        case 13:
          if (!Float.isNaN(this.alpha))
            f1 = this.alpha; 
          stringBuilder2.setPoint(paramInt, f1);
          continue;
        case 12:
          if (Float.isNaN(this.mPathRotate)) {
            f1 = f2;
          } else {
            f1 = this.mPathRotate;
          } 
          stringBuilder2.setPoint(paramInt, f1);
          continue;
        case 11:
          if (Float.isNaN(this.elevation)) {
            f1 = f3;
          } else {
            f1 = this.elevation;
          } 
          stringBuilder2.setPoint(paramInt, f1);
          continue;
        case 10:
          if (Float.isNaN(this.rotation)) {
            f1 = f4;
          } else {
            f1 = this.rotation;
          } 
          stringBuilder2.setPoint(paramInt, f1);
          continue;
        case 9:
          if (Float.isNaN(this.mPivotY)) {
            f1 = f5;
          } else {
            f1 = this.mPivotY;
          } 
          stringBuilder2.setPoint(paramInt, f1);
          continue;
        case 8:
          if (Float.isNaN(this.mPivotX)) {
            f1 = f6;
          } else {
            f1 = this.mPivotX;
          } 
          stringBuilder2.setPoint(paramInt, f1);
          continue;
        case 7:
          if (!Float.isNaN(this.scaleY))
            f1 = this.scaleY; 
          stringBuilder2.setPoint(paramInt, f1);
          continue;
        case 6:
          if (!Float.isNaN(this.scaleX))
            f1 = this.scaleX; 
          stringBuilder2.setPoint(paramInt, f1);
          continue;
        case 5:
          if (Float.isNaN(this.mProgress)) {
            f1 = f7;
          } else {
            f1 = this.mProgress;
          } 
          stringBuilder2.setPoint(paramInt, f1);
          continue;
        case 4:
          if (Float.isNaN(this.translationZ)) {
            f1 = f8;
          } else {
            f1 = this.translationZ;
          } 
          stringBuilder2.setPoint(paramInt, f1);
          continue;
        case 3:
          if (Float.isNaN(this.translationY)) {
            f1 = f9;
          } else {
            f1 = this.translationY;
          } 
          stringBuilder2.setPoint(paramInt, f1);
          continue;
        case 2:
          if (Float.isNaN(this.translationX)) {
            f1 = f10;
          } else {
            f1 = this.translationX;
          } 
          stringBuilder2.setPoint(paramInt, f1);
          continue;
        case 1:
          if (Float.isNaN(this.rotationY)) {
            f1 = f11;
          } else {
            f1 = this.rotationY;
          } 
          stringBuilder2.setPoint(paramInt, f1);
          continue;
        case 0:
          break;
      } 
      if (Float.isNaN(this.rotationX)) {
        f1 = f12;
      } else {
        f1 = this.rotationX;
      } 
      stringBuilder2.setPoint(paramInt, f1);
    } 
  }
  
  public void applyParameters(View paramView) {
    float f;
    this.visibility = paramView.getVisibility();
    if (paramView.getVisibility() != 0) {
      f = 0.0F;
    } else {
      f = paramView.getAlpha();
    } 
    this.alpha = f;
    this.applyElevation = false;
    this.elevation = paramView.getElevation();
    this.rotation = paramView.getRotation();
    this.rotationX = paramView.getRotationX();
    this.rotationY = paramView.getRotationY();
    this.scaleX = paramView.getScaleX();
    this.scaleY = paramView.getScaleY();
    this.mPivotX = paramView.getPivotX();
    this.mPivotY = paramView.getPivotY();
    this.translationX = paramView.getTranslationX();
    this.translationY = paramView.getTranslationY();
    this.translationZ = paramView.getTranslationZ();
  }
  
  public void applyParameters(ConstraintSet.Constraint paramConstraint) {
    float f;
    ConstraintSet.PropertySet propertySet = paramConstraint.propertySet;
    int i = propertySet.mVisibilityMode;
    this.mVisibilityMode = i;
    int j = propertySet.visibility;
    this.visibility = j;
    if (j != 0 && i == 0) {
      f = 0.0F;
    } else {
      f = propertySet.alpha;
    } 
    this.alpha = f;
    ConstraintSet.Transform transform = paramConstraint.transform;
    this.applyElevation = transform.applyElevation;
    this.elevation = transform.elevation;
    this.rotation = transform.rotation;
    this.rotationX = transform.rotationX;
    this.rotationY = transform.rotationY;
    this.scaleX = transform.scaleX;
    this.scaleY = transform.scaleY;
    this.mPivotX = transform.transformPivotX;
    this.mPivotY = transform.transformPivotY;
    this.translationX = transform.translationX;
    this.translationY = transform.translationY;
    this.translationZ = transform.translationZ;
    this.mKeyFrameEasing = Easing.getInterpolator(paramConstraint.motion.mTransitionEasing);
    ConstraintSet.Motion motion = paramConstraint.motion;
    this.mPathRotate = motion.mPathRotate;
    this.mDrawPath = motion.mDrawPath;
    this.mProgress = paramConstraint.propertySet.mProgress;
    for (String str : paramConstraint.mCustomConstraints.keySet()) {
      ConstraintAttribute constraintAttribute = (ConstraintAttribute)paramConstraint.mCustomConstraints.get(str);
      if (constraintAttribute.getType() != ConstraintAttribute.AttributeType.STRING_TYPE)
        this.attributes.put(str, constraintAttribute); 
    } 
  }
  
  public int compareTo(MotionConstrainedPoint paramMotionConstrainedPoint) {
    return Float.compare(this.position, paramMotionConstrainedPoint.position);
  }
  
  void different(MotionConstrainedPoint paramMotionConstrainedPoint, HashSet<String> paramHashSet) {
    if (diff(this.alpha, paramMotionConstrainedPoint.alpha))
      paramHashSet.add("alpha"); 
    if (diff(this.elevation, paramMotionConstrainedPoint.elevation))
      paramHashSet.add("elevation"); 
    int i = this.visibility;
    int j = paramMotionConstrainedPoint.visibility;
    if (i != j && this.mVisibilityMode == 0 && (i == 0 || j == 0))
      paramHashSet.add("alpha"); 
    if (diff(this.rotation, paramMotionConstrainedPoint.rotation))
      paramHashSet.add("rotation"); 
    if (!Float.isNaN(this.mPathRotate) || !Float.isNaN(paramMotionConstrainedPoint.mPathRotate))
      paramHashSet.add("transitionPathRotate"); 
    if (!Float.isNaN(this.mProgress) || !Float.isNaN(paramMotionConstrainedPoint.mProgress))
      paramHashSet.add("progress"); 
    if (diff(this.rotationX, paramMotionConstrainedPoint.rotationX))
      paramHashSet.add("rotationX"); 
    if (diff(this.rotationY, paramMotionConstrainedPoint.rotationY))
      paramHashSet.add("rotationY"); 
    if (diff(this.mPivotX, paramMotionConstrainedPoint.mPivotX))
      paramHashSet.add("transformPivotX"); 
    if (diff(this.mPivotY, paramMotionConstrainedPoint.mPivotY))
      paramHashSet.add("transformPivotY"); 
    if (diff(this.scaleX, paramMotionConstrainedPoint.scaleX))
      paramHashSet.add("scaleX"); 
    if (diff(this.scaleY, paramMotionConstrainedPoint.scaleY))
      paramHashSet.add("scaleY"); 
    if (diff(this.translationX, paramMotionConstrainedPoint.translationX))
      paramHashSet.add("translationX"); 
    if (diff(this.translationY, paramMotionConstrainedPoint.translationY))
      paramHashSet.add("translationY"); 
    if (diff(this.translationZ, paramMotionConstrainedPoint.translationZ))
      paramHashSet.add("translationZ"); 
  }
  
  void different(MotionConstrainedPoint paramMotionConstrainedPoint, boolean[] paramArrayOfboolean, String[] paramArrayOfString) {
    paramArrayOfboolean[0] = paramArrayOfboolean[0] | diff(this.position, paramMotionConstrainedPoint.position);
    paramArrayOfboolean[1] = paramArrayOfboolean[1] | diff(this.x, paramMotionConstrainedPoint.x);
    paramArrayOfboolean[2] = paramArrayOfboolean[2] | diff(this.y, paramMotionConstrainedPoint.y);
    paramArrayOfboolean[3] = paramArrayOfboolean[3] | diff(this.width, paramMotionConstrainedPoint.width);
    boolean bool = paramArrayOfboolean[4];
    paramArrayOfboolean[4] = diff(this.height, paramMotionConstrainedPoint.height) | bool;
  }
  
  void fillStandard(double[] paramArrayOfdouble, int[] paramArrayOfint) {
    float f1 = this.position;
    int i = 0;
    float f2 = this.x;
    float f3 = this.y;
    float f4 = this.width;
    float f5 = this.height;
    float f6 = this.alpha;
    float f7 = this.elevation;
    float f8 = this.rotation;
    float f9 = this.rotationX;
    float f10 = this.rotationY;
    float f11 = this.scaleX;
    float f12 = this.scaleY;
    float f13 = this.mPivotX;
    float f14 = this.mPivotY;
    float f15 = this.translationX;
    float f16 = this.translationY;
    float f17 = this.translationZ;
    float f18 = this.mPathRotate;
    int j;
    for (j = 0; i < paramArrayOfint.length; j = k) {
      int k = j;
      if (paramArrayOfint[i] < 18) {
        k = paramArrayOfint[i];
        (new float[18])[0] = f1;
        (new float[18])[1] = f2;
        (new float[18])[2] = f3;
        (new float[18])[3] = f4;
        (new float[18])[4] = f5;
        (new float[18])[5] = f6;
        (new float[18])[6] = f7;
        (new float[18])[7] = f8;
        (new float[18])[8] = f9;
        (new float[18])[9] = f10;
        (new float[18])[10] = f11;
        (new float[18])[11] = f12;
        (new float[18])[12] = f13;
        (new float[18])[13] = f14;
        (new float[18])[14] = f15;
        (new float[18])[15] = f16;
        (new float[18])[16] = f17;
        (new float[18])[17] = f18;
        paramArrayOfdouble[j] = (new float[18])[k];
        k = j + 1;
      } 
      i++;
    } 
  }
  
  int getCustomData(String paramString, double[] paramArrayOfdouble, int paramInt) {
    ConstraintAttribute constraintAttribute = this.attributes.get(paramString);
    if (constraintAttribute.noOfInterpValues() == 1) {
      paramArrayOfdouble[paramInt] = constraintAttribute.getValueToInterpolate();
      return 1;
    } 
    int j = constraintAttribute.noOfInterpValues();
    float[] arrayOfFloat = new float[j];
    constraintAttribute.getValuesToInterpolate(arrayOfFloat);
    int i = 0;
    while (i < j) {
      paramArrayOfdouble[paramInt] = arrayOfFloat[i];
      i++;
      paramInt++;
    } 
    return j;
  }
  
  int getCustomDataCount(String paramString) {
    return ((ConstraintAttribute)this.attributes.get(paramString)).noOfInterpValues();
  }
  
  boolean hasCustomData(String paramString) {
    return this.attributes.containsKey(paramString);
  }
  
  void setBounds(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
    this.x = paramFloat1;
    this.y = paramFloat2;
    this.width = paramFloat3;
    this.height = paramFloat4;
  }
  
  public void setState(View paramView) {
    setBounds(paramView.getX(), paramView.getY(), paramView.getWidth(), paramView.getHeight());
    applyParameters(paramView);
  }
  
  public void setState(ConstraintWidget paramConstraintWidget, ConstraintSet paramConstraintSet, int paramInt) {
    setBounds(paramConstraintWidget.getX(), paramConstraintWidget.getY(), paramConstraintWidget.getWidth(), paramConstraintWidget.getHeight());
    applyParameters(paramConstraintSet.getParameters(paramInt));
  }
}


/* Location:              C:\soft\dex2jar-2.0\BabyBus TV_Kids Videos & Games-dex2jar.jar!\androidx\constraintlayout\motion\widget\MotionConstrainedPoint.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */