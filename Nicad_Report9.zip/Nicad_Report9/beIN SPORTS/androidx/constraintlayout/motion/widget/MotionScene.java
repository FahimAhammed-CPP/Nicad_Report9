package androidx.constraintlayout.motion.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.content.res.XmlResourceParser;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseArray;
import android.util.SparseIntArray;
import android.util.Xml;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.AnimationUtils;
import android.view.animation.AnticipateInterpolator;
import android.view.animation.BounceInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.Interpolator;
import androidx.constraintlayout.motion.utils.Easing;
import androidx.constraintlayout.widget.ConstraintSet;
import androidx.constraintlayout.widget.R;
import androidx.constraintlayout.widget.StateSet;
import java.io.IOException;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

public class MotionScene {
  static final int ANTICIPATE = 4;
  
  static final int BOUNCE = 5;
  
  private static final boolean DEBUG = false;
  
  static final int EASE_IN = 1;
  
  static final int EASE_IN_OUT = 0;
  
  static final int EASE_OUT = 2;
  
  private static final int INTERPOLATOR_REFRENCE_ID = -2;
  
  public static final int LAYOUT_HONOR_REQUEST = 1;
  
  public static final int LAYOUT_IGNORE_REQUEST = 0;
  
  static final int LINEAR = 3;
  
  private static final int SPLINE_STRING = -1;
  
  public static final String TAG = "MotionScene";
  
  static final int TRANSITION_BACKWARD = 0;
  
  static final int TRANSITION_FORWARD = 1;
  
  public static final int UNSET = -1;
  
  private boolean DEBUG_DESKTOP = false;
  
  private ArrayList<Transition> mAbstractTransitionList = new ArrayList<Transition>();
  
  private HashMap<String, Integer> mConstraintSetIdMap = new HashMap<String, Integer>();
  
  private SparseArray<ConstraintSet> mConstraintSetMap = new SparseArray();
  
  Transition mCurrentTransition = null;
  
  private int mDefaultDuration = 400;
  
  private Transition mDefaultTransition = null;
  
  private SparseIntArray mDeriveMap = new SparseIntArray();
  
  private boolean mDisableAutoTransition = false;
  
  private boolean mIgnoreTouch = false;
  
  private MotionEvent mLastTouchDown;
  
  float mLastTouchX;
  
  float mLastTouchY;
  
  private int mLayoutDuringTransition = 0;
  
  private final MotionLayout mMotionLayout;
  
  private boolean mMotionOutsideRegion = false;
  
  private boolean mRtl;
  
  StateSet mStateSet = null;
  
  private ArrayList<Transition> mTransitionList = new ArrayList<Transition>();
  
  private MotionLayout.MotionTracker mVelocityTracker;
  
  MotionScene(Context paramContext, MotionLayout paramMotionLayout, int paramInt) {
    this.mMotionLayout = paramMotionLayout;
    load(paramContext, paramInt);
    SparseArray<ConstraintSet> sparseArray = this.mConstraintSetMap;
    paramInt = R.id.motion_base;
    sparseArray.put(paramInt, new ConstraintSet());
    this.mConstraintSetIdMap.put("motion_base", Integer.valueOf(paramInt));
  }
  
  public MotionScene(MotionLayout paramMotionLayout) {
    this.mMotionLayout = paramMotionLayout;
  }
  
  private int getId(Context paramContext, String paramString) {
    byte b;
    if (paramString.contains("/")) {
      String str = paramString.substring(paramString.indexOf('/') + 1);
      int i = paramContext.getResources().getIdentifier(str, "id", paramContext.getPackageName());
      b = i;
      if (this.DEBUG_DESKTOP) {
        PrintStream printStream = System.out;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("id getMap res = ");
        stringBuilder.append(i);
        printStream.println(stringBuilder.toString());
        b = i;
      } 
    } else {
      b = -1;
    } 
    if (b == -1) {
      if (paramString.length() > 1)
        return Integer.parseInt(paramString.substring(1)); 
      Log.e("MotionScene", "error in parsing id");
    } 
    return b;
  }
  
  private int getIndex(Transition paramTransition) {
    int i = paramTransition.mId;
    if (i != -1) {
      for (int j = 0; j < this.mTransitionList.size(); j++) {
        if ((this.mTransitionList.get(j)).mId == i)
          return j; 
      } 
      return -1;
    } 
    throw new IllegalArgumentException("The transition must have an id");
  }
  
  private int getRealID(int paramInt) {
    StateSet stateSet = this.mStateSet;
    if (stateSet != null) {
      int i = stateSet.stateGetConstraintID(paramInt, -1, -1);
      if (i != -1)
        return i; 
    } 
    return paramInt;
  }
  
  private boolean hasCycleDependency(int paramInt) {
    int j = this.mDeriveMap.get(paramInt);
    for (int i = this.mDeriveMap.size(); j > 0; i--) {
      if (j == paramInt)
        return true; 
      if (i < 0)
        return true; 
      j = this.mDeriveMap.get(j);
    } 
    return false;
  }
  
  private boolean isProcessingTouch() {
    return (this.mVelocityTracker != null);
  }
  
  private void load(Context paramContext, int paramInt) {
    int i;
    XmlResourceParser xmlResourceParser = paramContext.getResources().getXml(paramInt);
    Transition transition = null;
    try {
      i = xmlResourceParser.getEventType();
    } catch (XmlPullParserException xmlPullParserException) {
      xmlPullParserException.printStackTrace();
      return;
    } catch (IOException iOException) {
      iOException.printStackTrace();
      return;
    } 
    while (true) {
      boolean bool = true;
      if (i != 1) {
        if (i != 0) {
          if (i == 2) {
            KeyFrames keyFrames;
            ArrayList<Transition> arrayList;
            String str = xmlResourceParser.getName();
            if (this.DEBUG_DESKTOP) {
              PrintStream printStream = System.out;
              StringBuilder stringBuilder1 = new StringBuilder();
              stringBuilder1.append("parsing = ");
              stringBuilder1.append(str);
              printStream.println(stringBuilder1.toString());
            } 
            i = str.hashCode();
            switch (i) {
              default:
                i = -1;
                break;
              case 1382829617:
                if (str.equals("StateSet")) {
                  i = 4;
                  break;
                } 
              case 793277014:
                if (str.equals("MotionScene")) {
                  i = 0;
                  break;
                } 
              case 327855227:
                if (str.equals("OnSwipe")) {
                  i = 2;
                  break;
                } 
              case 312750793:
                if (str.equals("OnClick")) {
                  i = 3;
                  break;
                } 
              case 269306229:
                if (str.equals("Transition")) {
                  i = bool;
                  break;
                } 
              case -1239391468:
                if (str.equals("KeyFrameSet")) {
                  i = 6;
                  break;
                } 
              case -1349929691:
                if (str.equals("ConstraintSet")) {
                  i = 5;
                  break;
                } 
            } 
            switch (i) {
              case 6:
                keyFrames = new KeyFrames((Context)iOException, (XmlPullParser)xmlResourceParser);
                transition.mKeyFramesList.add(keyFrames);
                i = xmlResourceParser.next();
                continue;
              case 5:
                parseConstraintSet((Context)iOException, (XmlPullParser)xmlResourceParser);
                i = xmlResourceParser.next();
                continue;
              case 4:
                this.mStateSet = new StateSet((Context)iOException, (XmlPullParser)xmlResourceParser);
                i = xmlResourceParser.next();
                continue;
              case 3:
                transition.addOnClick((Context)iOException, (XmlPullParser)xmlResourceParser);
                i = xmlResourceParser.next();
                continue;
              case 2:
                if (transition == null) {
                  String str1 = iOException.getResources().getResourceEntryName(paramInt);
                  i = xmlResourceParser.getLineNumber();
                  StringBuilder stringBuilder1 = new StringBuilder();
                  stringBuilder1.append(" OnSwipe (");
                  stringBuilder1.append(str1);
                  stringBuilder1.append(".xml:");
                  stringBuilder1.append(i);
                  stringBuilder1.append(")");
                  Log.v("MotionScene", stringBuilder1.toString());
                } 
                Transition.access$202(transition, new TouchResponse((Context)iOException, this.mMotionLayout, (XmlPullParser)xmlResourceParser));
                i = xmlResourceParser.next();
                continue;
              case 1:
                arrayList = this.mTransitionList;
                transition = new Transition(this, (Context)iOException, (XmlPullParser)xmlResourceParser);
                arrayList.add(transition);
                if (this.mCurrentTransition == null && !transition.mIsAbstract) {
                  this.mCurrentTransition = transition;
                  if (transition.mTouchResponse != null)
                    this.mCurrentTransition.mTouchResponse.setRTL(this.mRtl); 
                } 
                if (transition.mIsAbstract) {
                  if (transition.mConstraintSetEnd == -1) {
                    this.mDefaultTransition = transition;
                  } else {
                    this.mAbstractTransitionList.add(transition);
                  } 
                  this.mTransitionList.remove(transition);
                } 
                i = xmlResourceParser.next();
                continue;
              case 0:
                parseMotionSceneTags((Context)iOException, (XmlPullParser)xmlResourceParser);
                i = xmlResourceParser.next();
                continue;
            } 
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("WARNING UNKNOWN ATTRIBUTE ");
            stringBuilder.append((String)arrayList);
            Log.v("MotionScene", stringBuilder.toString());
          } 
        } else {
          xmlResourceParser.getName();
        } 
      } else {
        return;
      } 
      i = xmlResourceParser.next();
    } 
  }
  
  private void parseConstraintSet(Context paramContext, XmlPullParser paramXmlPullParser) {
    ConstraintSet constraintSet = new ConstraintSet();
    int i = 0;
    constraintSet.setForceId(false);
    int m = paramXmlPullParser.getAttributeCount();
    int k = -1;
    int j = -1;
    while (i < m) {
      String str1 = paramXmlPullParser.getAttributeName(i);
      String str2 = paramXmlPullParser.getAttributeValue(i);
      if (this.DEBUG_DESKTOP) {
        PrintStream printStream = System.out;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("id string = ");
        stringBuilder.append(str2);
        printStream.println(stringBuilder.toString());
      } 
      str1.hashCode();
      if (!str1.equals("deriveConstraintsFrom")) {
        if (str1.equals("id")) {
          k = getId(paramContext, str2);
          this.mConstraintSetIdMap.put(stripID(str2), Integer.valueOf(k));
        } 
      } else {
        j = getId(paramContext, str2);
      } 
      i++;
    } 
    if (k != -1) {
      if (this.mMotionLayout.mDebugPath != 0)
        constraintSet.setValidateOnParse(true); 
      constraintSet.load(paramContext, paramXmlPullParser);
      if (j != -1)
        this.mDeriveMap.put(k, j); 
      this.mConstraintSetMap.put(k, constraintSet);
    } 
  }
  
  private void parseMotionSceneTags(Context paramContext, XmlPullParser paramXmlPullParser) {
    TypedArray typedArray = paramContext.obtainStyledAttributes(Xml.asAttributeSet(paramXmlPullParser), R.styleable.MotionScene);
    int j = typedArray.getIndexCount();
    for (int i = 0; i < j; i++) {
      int k = typedArray.getIndex(i);
      if (k == R.styleable.MotionScene_defaultDuration) {
        this.mDefaultDuration = typedArray.getInt(k, this.mDefaultDuration);
      } else if (k == R.styleable.MotionScene_layoutDuringTransition) {
        this.mLayoutDuringTransition = typedArray.getInteger(k, 0);
      } 
    } 
    typedArray.recycle();
  }
  
  private void readConstraintChain(int paramInt) {
    int i = this.mDeriveMap.get(paramInt);
    if (i > 0) {
      StringBuilder stringBuilder;
      readConstraintChain(this.mDeriveMap.get(paramInt));
      ConstraintSet constraintSet1 = (ConstraintSet)this.mConstraintSetMap.get(paramInt);
      ConstraintSet constraintSet2 = (ConstraintSet)this.mConstraintSetMap.get(i);
      if (constraintSet2 == null) {
        stringBuilder = new StringBuilder();
        stringBuilder.append("ERROR! invalid deriveConstraintsFrom: @id/");
        stringBuilder.append(Debug.getName(this.mMotionLayout.getContext(), i));
        Log.e("MotionScene", stringBuilder.toString());
        return;
      } 
      stringBuilder.readFallback(constraintSet2);
      this.mDeriveMap.put(paramInt, -1);
    } 
  }
  
  public static String stripID(String paramString) {
    if (paramString == null)
      return ""; 
    int i = paramString.indexOf('/');
    return (i < 0) ? paramString : paramString.substring(i + 1);
  }
  
  public void addOnClickListeners(MotionLayout paramMotionLayout, int paramInt) {
    for (Transition transition : this.mTransitionList) {
      if (transition.mOnClicks.size() > 0) {
        Iterator<Transition.TransitionOnClick> iterator = transition.mOnClicks.iterator();
        while (iterator.hasNext())
          ((Transition.TransitionOnClick)iterator.next()).removeOnClickListeners(paramMotionLayout); 
      } 
    } 
    for (Transition transition : this.mAbstractTransitionList) {
      if (transition.mOnClicks.size() > 0) {
        Iterator<Transition.TransitionOnClick> iterator = transition.mOnClicks.iterator();
        while (iterator.hasNext())
          ((Transition.TransitionOnClick)iterator.next()).removeOnClickListeners(paramMotionLayout); 
      } 
    } 
    for (Transition transition : this.mTransitionList) {
      if (transition.mOnClicks.size() > 0) {
        Iterator<Transition.TransitionOnClick> iterator = transition.mOnClicks.iterator();
        while (iterator.hasNext())
          ((Transition.TransitionOnClick)iterator.next()).addOnClickListeners(paramMotionLayout, paramInt, transition); 
      } 
    } 
    for (Transition transition : this.mAbstractTransitionList) {
      if (transition.mOnClicks.size() > 0) {
        Iterator<Transition.TransitionOnClick> iterator = transition.mOnClicks.iterator();
        while (iterator.hasNext())
          ((Transition.TransitionOnClick)iterator.next()).addOnClickListeners(paramMotionLayout, paramInt, transition); 
      } 
    } 
  }
  
  public void addTransition(Transition paramTransition) {
    int i = getIndex(paramTransition);
    if (i == -1) {
      this.mTransitionList.add(paramTransition);
      return;
    } 
    this.mTransitionList.set(i, paramTransition);
  }
  
  boolean autoTransition(MotionLayout paramMotionLayout, int paramInt) {
    if (isProcessingTouch())
      return false; 
    if (this.mDisableAutoTransition)
      return false; 
    Iterator<Transition> iterator = this.mTransitionList.iterator();
    while (iterator.hasNext()) {
      Transition transition = iterator.next();
      if (transition.mAutoTransition == 0 || this.mCurrentTransition == transition)
        continue; 
      if (paramInt == transition.mConstraintSetStart && (transition.mAutoTransition == 4 || transition.mAutoTransition == 2)) {
        MotionLayout.TransitionState transitionState = MotionLayout.TransitionState.FINISHED;
        paramMotionLayout.setState(transitionState);
        paramMotionLayout.setTransition(transition);
        if (transition.mAutoTransition == 4) {
          paramMotionLayout.transitionToEnd();
          paramMotionLayout.setState(MotionLayout.TransitionState.SETUP);
          paramMotionLayout.setState(MotionLayout.TransitionState.MOVING);
          return true;
        } 
        paramMotionLayout.setProgress(1.0F);
        paramMotionLayout.evaluate(true);
        paramMotionLayout.setState(MotionLayout.TransitionState.SETUP);
        paramMotionLayout.setState(MotionLayout.TransitionState.MOVING);
        paramMotionLayout.setState(transitionState);
        paramMotionLayout.onNewStateAttachHandlers();
        return true;
      } 
      if (paramInt == transition.mConstraintSetEnd && (transition.mAutoTransition == 3 || transition.mAutoTransition == 1)) {
        MotionLayout.TransitionState transitionState = MotionLayout.TransitionState.FINISHED;
        paramMotionLayout.setState(transitionState);
        paramMotionLayout.setTransition(transition);
        if (transition.mAutoTransition == 3) {
          paramMotionLayout.transitionToStart();
          paramMotionLayout.setState(MotionLayout.TransitionState.SETUP);
          paramMotionLayout.setState(MotionLayout.TransitionState.MOVING);
          return true;
        } 
        paramMotionLayout.setProgress(0.0F);
        paramMotionLayout.evaluate(true);
        paramMotionLayout.setState(MotionLayout.TransitionState.SETUP);
        paramMotionLayout.setState(MotionLayout.TransitionState.MOVING);
        paramMotionLayout.setState(transitionState);
        paramMotionLayout.onNewStateAttachHandlers();
        return true;
      } 
    } 
    return false;
  }
  
  public Transition bestTransitionFor(int paramInt, float paramFloat1, float paramFloat2, MotionEvent paramMotionEvent) {
    if (paramInt != -1) {
      List<Transition> list = getTransitionsWithState(paramInt);
      float f = 0.0F;
      Transition transition = null;
      RectF rectF = new RectF();
      for (Transition transition1 : list) {
        if (!transition1.mDisable && transition1.mTouchResponse != null) {
          transition1.mTouchResponse.setRTL(this.mRtl);
          RectF rectF1 = transition1.mTouchResponse.getTouchRegion((ViewGroup)this.mMotionLayout, rectF);
          if (rectF1 != null && paramMotionEvent != null && !rectF1.contains(paramMotionEvent.getX(), paramMotionEvent.getY()))
            continue; 
          rectF1 = transition1.mTouchResponse.getTouchRegion((ViewGroup)this.mMotionLayout, rectF);
          if (rectF1 != null && paramMotionEvent != null && !rectF1.contains(paramMotionEvent.getX(), paramMotionEvent.getY()))
            continue; 
          float f2 = transition1.mTouchResponse.dot(paramFloat1, paramFloat2);
          if (transition1.mConstraintSetEnd == paramInt) {
            f1 = -1.0F;
          } else {
            f1 = 1.1F;
          } 
          float f1 = f2 * f1;
          if (f1 > f) {
            transition = transition1;
            f = f1;
          } 
        } 
      } 
      return transition;
    } 
    return this.mCurrentTransition;
  }
  
  public void disableAutoTransition(boolean paramBoolean) {
    this.mDisableAutoTransition = paramBoolean;
  }
  
  public int gatPathMotionArc() {
    Transition transition = this.mCurrentTransition;
    return (transition != null) ? transition.mPathMotionArc : -1;
  }
  
  ConstraintSet getConstraintSet(int paramInt) {
    return getConstraintSet(paramInt, -1, -1);
  }
  
  ConstraintSet getConstraintSet(int paramInt1, int paramInt2, int paramInt3) {
    if (this.DEBUG_DESKTOP) {
      PrintStream printStream = System.out;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("id ");
      stringBuilder.append(paramInt1);
      printStream.println(stringBuilder.toString());
      printStream = System.out;
      stringBuilder = new StringBuilder();
      stringBuilder.append("size ");
      stringBuilder.append(this.mConstraintSetMap.size());
      printStream.println(stringBuilder.toString());
    } 
    StateSet stateSet = this.mStateSet;
    int i = paramInt1;
    if (stateSet != null) {
      paramInt2 = stateSet.stateGetConstraintID(paramInt1, paramInt2, paramInt3);
      i = paramInt1;
      if (paramInt2 != -1)
        i = paramInt2; 
    } 
    if (this.mConstraintSetMap.get(i) == null) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Warning could not find ConstraintSet id/");
      stringBuilder.append(Debug.getName(this.mMotionLayout.getContext(), i));
      stringBuilder.append(" In MotionScene");
      Log.e("MotionScene", stringBuilder.toString());
      SparseArray<ConstraintSet> sparseArray = this.mConstraintSetMap;
      return (ConstraintSet)sparseArray.get(sparseArray.keyAt(0));
    } 
    return (ConstraintSet)this.mConstraintSetMap.get(i);
  }
  
  public ConstraintSet getConstraintSet(Context paramContext, String paramString) {
    if (this.DEBUG_DESKTOP) {
      PrintStream printStream = System.out;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("id ");
      stringBuilder.append(paramString);
      printStream.println(stringBuilder.toString());
      printStream = System.out;
      stringBuilder = new StringBuilder();
      stringBuilder.append("size ");
      stringBuilder.append(this.mConstraintSetMap.size());
      printStream.println(stringBuilder.toString());
    } 
    for (int i = 0; i < this.mConstraintSetMap.size(); i++) {
      int j = this.mConstraintSetMap.keyAt(i);
      String str = paramContext.getResources().getResourceName(j);
      if (this.DEBUG_DESKTOP) {
        PrintStream printStream = System.out;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Id for <");
        stringBuilder.append(i);
        stringBuilder.append("> is <");
        stringBuilder.append(str);
        stringBuilder.append("> looking for <");
        stringBuilder.append(paramString);
        stringBuilder.append(">");
        printStream.println(stringBuilder.toString());
      } 
      if (paramString.equals(str))
        return (ConstraintSet)this.mConstraintSetMap.get(j); 
    } 
    return null;
  }
  
  public int[] getConstraintSetIds() {
    int j = this.mConstraintSetMap.size();
    int[] arrayOfInt = new int[j];
    for (int i = 0; i < j; i++)
      arrayOfInt[i] = this.mConstraintSetMap.keyAt(i); 
    return arrayOfInt;
  }
  
  public ArrayList<Transition> getDefinedTransitions() {
    return this.mTransitionList;
  }
  
  public int getDuration() {
    Transition transition = this.mCurrentTransition;
    return (transition != null) ? transition.mDuration : this.mDefaultDuration;
  }
  
  int getEndId() {
    Transition transition = this.mCurrentTransition;
    return (transition == null) ? -1 : transition.mConstraintSetEnd;
  }
  
  public Interpolator getInterpolator() {
    int i = this.mCurrentTransition.mDefaultInterpolator;
    return (Interpolator)((i != -2) ? ((i != -1) ? ((i != 0) ? ((i != 1) ? ((i != 2) ? ((i != 4) ? ((i != 5) ? null : new BounceInterpolator()) : new AnticipateInterpolator()) : new DecelerateInterpolator()) : new AccelerateInterpolator()) : new AccelerateDecelerateInterpolator()) : new Interpolator() {
        public float getInterpolation(float param1Float) {
          return (float)easing.get(param1Float);
        }
      }) : AnimationUtils.loadInterpolator(this.mMotionLayout.getContext(), this.mCurrentTransition.mDefaultInterpolatorID));
  }
  
  Key getKeyFrame(Context paramContext, int paramInt1, int paramInt2, int paramInt3) {
    Transition transition = this.mCurrentTransition;
    if (transition == null)
      return null; 
    for (KeyFrames keyFrames : transition.mKeyFramesList) {
      for (Integer integer : keyFrames.getKeys()) {
        if (paramInt2 == integer.intValue())
          for (Key key : keyFrames.getKeyFramesForView(integer.intValue())) {
            if (key.mFramePosition == paramInt3 && key.mType == paramInt1)
              return key; 
          }  
      } 
    } 
    return null;
  }
  
  public void getKeyFrames(MotionController paramMotionController) {
    Transition transition = this.mCurrentTransition;
    if (transition == null) {
      transition = this.mDefaultTransition;
      if (transition != null) {
        iterator = transition.mKeyFramesList.iterator();
        while (iterator.hasNext())
          ((KeyFrames)iterator.next()).addFrames(paramMotionController); 
      } 
      return;
    } 
    Iterator<KeyFrames> iterator = ((Transition)iterator).mKeyFramesList.iterator();
    while (iterator.hasNext())
      ((KeyFrames)iterator.next()).addFrames(paramMotionController); 
  }
  
  float getMaxAcceleration() {
    Transition transition = this.mCurrentTransition;
    return (transition != null && transition.mTouchResponse != null) ? this.mCurrentTransition.mTouchResponse.getMaxAcceleration() : 0.0F;
  }
  
  float getMaxVelocity() {
    Transition transition = this.mCurrentTransition;
    return (transition != null && transition.mTouchResponse != null) ? this.mCurrentTransition.mTouchResponse.getMaxVelocity() : 0.0F;
  }
  
  boolean getMoveWhenScrollAtTop() {
    Transition transition = this.mCurrentTransition;
    return (transition != null && transition.mTouchResponse != null) ? this.mCurrentTransition.mTouchResponse.getMoveWhenScrollAtTop() : false;
  }
  
  public float getPathPercent(View paramView, int paramInt) {
    return 0.0F;
  }
  
  float getProgressDirection(float paramFloat1, float paramFloat2) {
    Transition transition = this.mCurrentTransition;
    return (transition != null && transition.mTouchResponse != null) ? this.mCurrentTransition.mTouchResponse.getProgressDirection(paramFloat1, paramFloat2) : 0.0F;
  }
  
  public float getStaggered() {
    Transition transition = this.mCurrentTransition;
    return (transition != null) ? transition.mStagger : 0.0F;
  }
  
  int getStartId() {
    Transition transition = this.mCurrentTransition;
    return (transition == null) ? -1 : transition.mConstraintSetStart;
  }
  
  public Transition getTransitionById(int paramInt) {
    for (Transition transition : this.mTransitionList) {
      if (transition.mId == paramInt)
        return transition; 
    } 
    return null;
  }
  
  int getTransitionDirection(int paramInt) {
    Iterator<Transition> iterator = this.mTransitionList.iterator();
    while (iterator.hasNext()) {
      if ((iterator.next()).mConstraintSetStart == paramInt)
        return 0; 
    } 
    return 1;
  }
  
  public List<Transition> getTransitionsWithState(int paramInt) {
    paramInt = getRealID(paramInt);
    ArrayList<Transition> arrayList = new ArrayList();
    for (Transition transition : this.mTransitionList) {
      if (transition.mConstraintSetStart == paramInt || transition.mConstraintSetEnd == paramInt)
        arrayList.add(transition); 
    } 
    return arrayList;
  }
  
  boolean hasKeyFramePosition(View paramView, int paramInt) {
    Transition transition = this.mCurrentTransition;
    if (transition == null)
      return false; 
    Iterator<KeyFrames> iterator = transition.mKeyFramesList.iterator();
    while (iterator.hasNext()) {
      Iterator<Key> iterator1 = ((KeyFrames)iterator.next()).getKeyFramesForView(paramView.getId()).iterator();
      while (iterator1.hasNext()) {
        if (((Key)iterator1.next()).mFramePosition == paramInt)
          return true; 
      } 
    } 
    return false;
  }
  
  public int lookUpConstraintId(String paramString) {
    return ((Integer)this.mConstraintSetIdMap.get(paramString)).intValue();
  }
  
  public String lookUpConstraintName(int paramInt) {
    for (Map.Entry<String, Integer> entry : this.mConstraintSetIdMap.entrySet()) {
      if (((Integer)entry.getValue()).intValue() == paramInt)
        return (String)entry.getKey(); 
    } 
    return null;
  }
  
  protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {}
  
  void processScrollMove(float paramFloat1, float paramFloat2) {
    Transition transition = this.mCurrentTransition;
    if (transition != null && transition.mTouchResponse != null)
      this.mCurrentTransition.mTouchResponse.scrollMove(paramFloat1, paramFloat2); 
  }
  
  void processScrollUp(float paramFloat1, float paramFloat2) {
    Transition transition = this.mCurrentTransition;
    if (transition != null && transition.mTouchResponse != null)
      this.mCurrentTransition.mTouchResponse.scrollUp(paramFloat1, paramFloat2); 
  }
  
  void processTouchEvent(MotionEvent paramMotionEvent, int paramInt, MotionLayout paramMotionLayout) {
    RectF rectF1;
    RectF rectF2 = new RectF();
    if (this.mVelocityTracker == null)
      this.mVelocityTracker = this.mMotionLayout.obtainVelocityTracker(); 
    this.mVelocityTracker.addMovement(paramMotionEvent);
    if (paramInt != -1) {
      int i = paramMotionEvent.getAction();
      boolean bool = false;
      if (i != 0) {
        if (i == 2 && !this.mIgnoreTouch) {
          MotionEvent motionEvent;
          float f1 = paramMotionEvent.getRawY() - this.mLastTouchY;
          float f2 = paramMotionEvent.getRawX() - this.mLastTouchX;
          if (f2 != 0.0D || f1 != 0.0D) {
            motionEvent = this.mLastTouchDown;
            if (motionEvent == null)
              return; 
          } else {
            return;
          } 
          Transition transition1 = bestTransitionFor(paramInt, f2, f1, motionEvent);
          if (transition1 != null) {
            paramMotionLayout.setTransition(transition1);
            rectF2 = this.mCurrentTransition.mTouchResponse.getTouchRegion((ViewGroup)this.mMotionLayout, rectF2);
            boolean bool1 = bool;
            if (rectF2 != null) {
              bool1 = bool;
              if (!rectF2.contains(this.mLastTouchDown.getX(), this.mLastTouchDown.getY()))
                bool1 = true; 
            } 
            this.mMotionOutsideRegion = bool1;
            this.mCurrentTransition.mTouchResponse.setUpTouchEvent(this.mLastTouchX, this.mLastTouchY);
          } 
        } 
      } else {
        this.mLastTouchX = paramMotionEvent.getRawX();
        this.mLastTouchY = paramMotionEvent.getRawY();
        this.mLastTouchDown = paramMotionEvent;
        this.mIgnoreTouch = false;
        if (this.mCurrentTransition.mTouchResponse != null) {
          rectF1 = this.mCurrentTransition.mTouchResponse.getLimitBoundsTo((ViewGroup)this.mMotionLayout, rectF2);
          if (rectF1 != null && !rectF1.contains(this.mLastTouchDown.getX(), this.mLastTouchDown.getY())) {
            this.mLastTouchDown = null;
            this.mIgnoreTouch = true;
            return;
          } 
          rectF1 = this.mCurrentTransition.mTouchResponse.getTouchRegion((ViewGroup)this.mMotionLayout, rectF2);
          if (rectF1 != null && !rectF1.contains(this.mLastTouchDown.getX(), this.mLastTouchDown.getY())) {
            this.mMotionOutsideRegion = true;
          } else {
            this.mMotionOutsideRegion = false;
          } 
          this.mCurrentTransition.mTouchResponse.setDown(this.mLastTouchX, this.mLastTouchY);
        } 
        return;
      } 
    } 
    if (this.mIgnoreTouch)
      return; 
    Transition transition = this.mCurrentTransition;
    if (transition != null && transition.mTouchResponse != null && !this.mMotionOutsideRegion)
      this.mCurrentTransition.mTouchResponse.processTouchEvent((MotionEvent)rectF1, this.mVelocityTracker, paramInt, this); 
    this.mLastTouchX = rectF1.getRawX();
    this.mLastTouchY = rectF1.getRawY();
    if (rectF1.getAction() == 1) {
      MotionLayout.MotionTracker motionTracker = this.mVelocityTracker;
      if (motionTracker != null) {
        motionTracker.recycle();
        this.mVelocityTracker = null;
        paramInt = paramMotionLayout.mCurrentState;
        if (paramInt != -1)
          autoTransition(paramMotionLayout, paramInt); 
      } 
    } 
  }
  
  void readFallback(MotionLayout paramMotionLayout) {
    int j;
    byte b = 0;
    int i = 0;
    while (true) {
      j = b;
      if (i < this.mConstraintSetMap.size()) {
        j = this.mConstraintSetMap.keyAt(i);
        if (hasCycleDependency(j)) {
          Log.e("MotionScene", "Cannot be derived from yourself");
          return;
        } 
        readConstraintChain(j);
        i++;
        continue;
      } 
      break;
    } 
    while (j < this.mConstraintSetMap.size()) {
      ((ConstraintSet)this.mConstraintSetMap.valueAt(j)).readFallback(paramMotionLayout);
      j++;
    } 
  }
  
  public void removeTransition(Transition paramTransition) {
    int i = getIndex(paramTransition);
    if (i != -1)
      this.mTransitionList.remove(i); 
  }
  
  public void setConstraintSet(int paramInt, ConstraintSet paramConstraintSet) {
    this.mConstraintSetMap.put(paramInt, paramConstraintSet);
  }
  
  public void setDuration(int paramInt) {
    Transition transition = this.mCurrentTransition;
    if (transition != null) {
      transition.setDuration(paramInt);
      return;
    } 
    this.mDefaultDuration = paramInt;
  }
  
  public void setKeyframe(View paramView, int paramInt, String paramString, Object paramObject) {
    Transition transition = this.mCurrentTransition;
    if (transition == null)
      return; 
    Iterator<KeyFrames> iterator = transition.mKeyFramesList.iterator();
    while (iterator.hasNext()) {
      Iterator<Key> iterator1 = ((KeyFrames)iterator.next()).getKeyFramesForView(paramView.getId()).iterator();
      while (iterator1.hasNext()) {
        if (((Key)iterator1.next()).mFramePosition == paramInt) {
          if (paramObject != null)
            ((Float)paramObject).floatValue(); 
          paramString.equalsIgnoreCase("app:PerpendicularPath_percent");
        } 
      } 
    } 
  }
  
  public void setRtl(boolean paramBoolean) {
    this.mRtl = paramBoolean;
    Transition transition = this.mCurrentTransition;
    if (transition != null && transition.mTouchResponse != null)
      this.mCurrentTransition.mTouchResponse.setRTL(this.mRtl); 
  }
  
  void setTransition(int paramInt1, int paramInt2) {
    // Byte code:
    //   0: aload_0
    //   1: getfield mStateSet : Landroidx/constraintlayout/widget/StateSet;
    //   4: astore #6
    //   6: aload #6
    //   8: ifnull -> 54
    //   11: aload #6
    //   13: iload_1
    //   14: iconst_m1
    //   15: iconst_m1
    //   16: invokevirtual stateGetConstraintID : (III)I
    //   19: istore_3
    //   20: iload_3
    //   21: iconst_m1
    //   22: if_icmpeq -> 28
    //   25: goto -> 30
    //   28: iload_1
    //   29: istore_3
    //   30: aload_0
    //   31: getfield mStateSet : Landroidx/constraintlayout/widget/StateSet;
    //   34: iload_2
    //   35: iconst_m1
    //   36: iconst_m1
    //   37: invokevirtual stateGetConstraintID : (III)I
    //   40: istore #5
    //   42: iload_3
    //   43: istore #4
    //   45: iload #5
    //   47: iconst_m1
    //   48: if_icmpeq -> 57
    //   51: goto -> 63
    //   54: iload_1
    //   55: istore #4
    //   57: iload_2
    //   58: istore #5
    //   60: iload #4
    //   62: istore_3
    //   63: aload_0
    //   64: getfield mTransitionList : Ljava/util/ArrayList;
    //   67: invokevirtual iterator : ()Ljava/util/Iterator;
    //   70: astore #6
    //   72: aload #6
    //   74: invokeinterface hasNext : ()Z
    //   79: ifeq -> 165
    //   82: aload #6
    //   84: invokeinterface next : ()Ljava/lang/Object;
    //   89: checkcast androidx/constraintlayout/motion/widget/MotionScene$Transition
    //   92: astore #7
    //   94: aload #7
    //   96: invokestatic access$000 : (Landroidx/constraintlayout/motion/widget/MotionScene$Transition;)I
    //   99: iload #5
    //   101: if_icmpne -> 113
    //   104: aload #7
    //   106: invokestatic access$100 : (Landroidx/constraintlayout/motion/widget/MotionScene$Transition;)I
    //   109: iload_3
    //   110: if_icmpeq -> 131
    //   113: aload #7
    //   115: invokestatic access$000 : (Landroidx/constraintlayout/motion/widget/MotionScene$Transition;)I
    //   118: iload_2
    //   119: if_icmpne -> 72
    //   122: aload #7
    //   124: invokestatic access$100 : (Landroidx/constraintlayout/motion/widget/MotionScene$Transition;)I
    //   127: iload_1
    //   128: if_icmpne -> 72
    //   131: aload_0
    //   132: aload #7
    //   134: putfield mCurrentTransition : Landroidx/constraintlayout/motion/widget/MotionScene$Transition;
    //   137: aload #7
    //   139: ifnull -> 164
    //   142: aload #7
    //   144: invokestatic access$200 : (Landroidx/constraintlayout/motion/widget/MotionScene$Transition;)Landroidx/constraintlayout/motion/widget/TouchResponse;
    //   147: ifnull -> 164
    //   150: aload_0
    //   151: getfield mCurrentTransition : Landroidx/constraintlayout/motion/widget/MotionScene$Transition;
    //   154: invokestatic access$200 : (Landroidx/constraintlayout/motion/widget/MotionScene$Transition;)Landroidx/constraintlayout/motion/widget/TouchResponse;
    //   157: aload_0
    //   158: getfield mRtl : Z
    //   161: invokevirtual setRTL : (Z)V
    //   164: return
    //   165: aload_0
    //   166: getfield mDefaultTransition : Landroidx/constraintlayout/motion/widget/MotionScene$Transition;
    //   169: astore #6
    //   171: aload_0
    //   172: getfield mAbstractTransitionList : Ljava/util/ArrayList;
    //   175: invokevirtual iterator : ()Ljava/util/Iterator;
    //   178: astore #8
    //   180: aload #8
    //   182: invokeinterface hasNext : ()Z
    //   187: ifeq -> 218
    //   190: aload #8
    //   192: invokeinterface next : ()Ljava/lang/Object;
    //   197: checkcast androidx/constraintlayout/motion/widget/MotionScene$Transition
    //   200: astore #7
    //   202: aload #7
    //   204: invokestatic access$000 : (Landroidx/constraintlayout/motion/widget/MotionScene$Transition;)I
    //   207: iload_2
    //   208: if_icmpne -> 180
    //   211: aload #7
    //   213: astore #6
    //   215: goto -> 180
    //   218: new androidx/constraintlayout/motion/widget/MotionScene$Transition
    //   221: dup
    //   222: aload_0
    //   223: aload #6
    //   225: invokespecial <init> : (Landroidx/constraintlayout/motion/widget/MotionScene;Landroidx/constraintlayout/motion/widget/MotionScene$Transition;)V
    //   228: astore #6
    //   230: aload #6
    //   232: iload_3
    //   233: invokestatic access$102 : (Landroidx/constraintlayout/motion/widget/MotionScene$Transition;I)I
    //   236: pop
    //   237: aload #6
    //   239: iload #5
    //   241: invokestatic access$002 : (Landroidx/constraintlayout/motion/widget/MotionScene$Transition;I)I
    //   244: pop
    //   245: iload_3
    //   246: iconst_m1
    //   247: if_icmpeq -> 260
    //   250: aload_0
    //   251: getfield mTransitionList : Ljava/util/ArrayList;
    //   254: aload #6
    //   256: invokevirtual add : (Ljava/lang/Object;)Z
    //   259: pop
    //   260: aload_0
    //   261: aload #6
    //   263: putfield mCurrentTransition : Landroidx/constraintlayout/motion/widget/MotionScene$Transition;
    //   266: return
  }
  
  public void setTransition(Transition paramTransition) {
    this.mCurrentTransition = paramTransition;
    if (paramTransition != null && paramTransition.mTouchResponse != null)
      this.mCurrentTransition.mTouchResponse.setRTL(this.mRtl); 
  }
  
  void setupTouch() {
    Transition transition = this.mCurrentTransition;
    if (transition != null && transition.mTouchResponse != null)
      this.mCurrentTransition.mTouchResponse.setupTouch(); 
  }
  
  boolean supportTouch() {
    Iterator<Transition> iterator = this.mTransitionList.iterator();
    while (iterator.hasNext()) {
      if ((iterator.next()).mTouchResponse != null)
        return true; 
    } 
    Transition transition = this.mCurrentTransition;
    return (transition != null && transition.mTouchResponse != null);
  }
  
  public boolean validateLayout(MotionLayout paramMotionLayout) {
    return (paramMotionLayout == this.mMotionLayout && paramMotionLayout.mScene == this);
  }
  
  public static class Transition {
    public static final int AUTO_ANIMATE_TO_END = 4;
    
    public static final int AUTO_ANIMATE_TO_START = 3;
    
    public static final int AUTO_JUMP_TO_END = 2;
    
    public static final int AUTO_JUMP_TO_START = 1;
    
    public static final int AUTO_NONE = 0;
    
    static final int TRANSITION_FLAG_FIRST_DRAW = 1;
    
    private int mAutoTransition = 0;
    
    private int mConstraintSetEnd = -1;
    
    private int mConstraintSetStart = -1;
    
    private int mDefaultInterpolator = 0;
    
    private int mDefaultInterpolatorID = -1;
    
    private String mDefaultInterpolatorString = null;
    
    private boolean mDisable = false;
    
    private int mDuration = 400;
    
    private int mId = -1;
    
    private boolean mIsAbstract = false;
    
    private ArrayList<KeyFrames> mKeyFramesList = new ArrayList<KeyFrames>();
    
    private int mLayoutDuringTransition = 0;
    
    private final MotionScene mMotionScene;
    
    private ArrayList<TransitionOnClick> mOnClicks = new ArrayList<TransitionOnClick>();
    
    private int mPathMotionArc = -1;
    
    private float mStagger = 0.0F;
    
    private TouchResponse mTouchResponse = null;
    
    private int mTransitionFlags = 0;
    
    public Transition(int param1Int1, MotionScene param1MotionScene, int param1Int2, int param1Int3) {
      this.mId = param1Int1;
      this.mMotionScene = param1MotionScene;
      this.mConstraintSetStart = param1Int2;
      this.mConstraintSetEnd = param1Int3;
      this.mDuration = param1MotionScene.mDefaultDuration;
      this.mLayoutDuringTransition = param1MotionScene.mLayoutDuringTransition;
    }
    
    Transition(MotionScene param1MotionScene, Context param1Context, XmlPullParser param1XmlPullParser) {
      this.mDuration = param1MotionScene.mDefaultDuration;
      this.mLayoutDuringTransition = param1MotionScene.mLayoutDuringTransition;
      this.mMotionScene = param1MotionScene;
      fillFromAttributeList(param1MotionScene, param1Context, Xml.asAttributeSet(param1XmlPullParser));
    }
    
    Transition(MotionScene param1MotionScene, Transition param1Transition) {
      this.mMotionScene = param1MotionScene;
      if (param1Transition != null) {
        this.mPathMotionArc = param1Transition.mPathMotionArc;
        this.mDefaultInterpolator = param1Transition.mDefaultInterpolator;
        this.mDefaultInterpolatorString = param1Transition.mDefaultInterpolatorString;
        this.mDefaultInterpolatorID = param1Transition.mDefaultInterpolatorID;
        this.mDuration = param1Transition.mDuration;
        this.mKeyFramesList = param1Transition.mKeyFramesList;
        this.mStagger = param1Transition.mStagger;
        this.mLayoutDuringTransition = param1Transition.mLayoutDuringTransition;
      } 
    }
    
    private void fill(MotionScene param1MotionScene, Context param1Context, TypedArray param1TypedArray) {
      int j = param1TypedArray.getIndexCount();
      int i;
      for (i = 0; i < j; i++) {
        int k = param1TypedArray.getIndex(i);
        if (k == R.styleable.Transition_constraintSetEnd) {
          this.mConstraintSetEnd = param1TypedArray.getResourceId(k, this.mConstraintSetEnd);
          if ("layout".equals(param1Context.getResources().getResourceTypeName(this.mConstraintSetEnd))) {
            ConstraintSet constraintSet = new ConstraintSet();
            constraintSet.load(param1Context, this.mConstraintSetEnd);
            param1MotionScene.mConstraintSetMap.append(this.mConstraintSetEnd, constraintSet);
          } 
        } else if (k == R.styleable.Transition_constraintSetStart) {
          this.mConstraintSetStart = param1TypedArray.getResourceId(k, this.mConstraintSetStart);
          if ("layout".equals(param1Context.getResources().getResourceTypeName(this.mConstraintSetStart))) {
            ConstraintSet constraintSet = new ConstraintSet();
            constraintSet.load(param1Context, this.mConstraintSetStart);
            param1MotionScene.mConstraintSetMap.append(this.mConstraintSetStart, constraintSet);
          } 
        } else if (k == R.styleable.Transition_motionInterpolator) {
          int m = (param1TypedArray.peekValue(k)).type;
          if (m == 1) {
            k = param1TypedArray.getResourceId(k, -1);
            this.mDefaultInterpolatorID = k;
            if (k != -1)
              this.mDefaultInterpolator = -2; 
          } else if (m == 3) {
            String str = param1TypedArray.getString(k);
            this.mDefaultInterpolatorString = str;
            if (str.indexOf("/") > 0) {
              this.mDefaultInterpolatorID = param1TypedArray.getResourceId(k, -1);
              this.mDefaultInterpolator = -2;
            } else {
              this.mDefaultInterpolator = -1;
            } 
          } else {
            this.mDefaultInterpolator = param1TypedArray.getInteger(k, this.mDefaultInterpolator);
          } 
        } else if (k == R.styleable.Transition_duration) {
          this.mDuration = param1TypedArray.getInt(k, this.mDuration);
        } else if (k == R.styleable.Transition_staggered) {
          this.mStagger = param1TypedArray.getFloat(k, this.mStagger);
        } else if (k == R.styleable.Transition_autoTransition) {
          this.mAutoTransition = param1TypedArray.getInteger(k, this.mAutoTransition);
        } else if (k == R.styleable.Transition_android_id) {
          this.mId = param1TypedArray.getResourceId(k, this.mId);
        } else if (k == R.styleable.Transition_transitionDisable) {
          this.mDisable = param1TypedArray.getBoolean(k, this.mDisable);
        } else if (k == R.styleable.Transition_pathMotionArc) {
          this.mPathMotionArc = param1TypedArray.getInteger(k, -1);
        } else if (k == R.styleable.Transition_layoutDuringTransition) {
          this.mLayoutDuringTransition = param1TypedArray.getInteger(k, 0);
        } else if (k == R.styleable.Transition_transitionFlags) {
          this.mTransitionFlags = param1TypedArray.getInteger(k, 0);
        } 
      } 
      if (this.mConstraintSetStart == -1)
        this.mIsAbstract = true; 
    }
    
    private void fillFromAttributeList(MotionScene param1MotionScene, Context param1Context, AttributeSet param1AttributeSet) {
      TypedArray typedArray = param1Context.obtainStyledAttributes(param1AttributeSet, R.styleable.Transition);
      fill(param1MotionScene, param1Context, typedArray);
      typedArray.recycle();
    }
    
    public void addOnClick(Context param1Context, XmlPullParser param1XmlPullParser) {
      this.mOnClicks.add(new TransitionOnClick(param1Context, this, param1XmlPullParser));
    }
    
    public String debugString(Context param1Context) {
      StringBuilder stringBuilder1;
      String str;
      if (this.mConstraintSetStart == -1) {
        str = "null";
      } else {
        str = param1Context.getResources().getResourceEntryName(this.mConstraintSetStart);
      } 
      if (this.mConstraintSetEnd == -1) {
        stringBuilder1 = new StringBuilder();
        stringBuilder1.append(str);
        stringBuilder1.append(" -> null");
        return stringBuilder1.toString();
      } 
      StringBuilder stringBuilder2 = new StringBuilder();
      stringBuilder2.append(str);
      stringBuilder2.append(" -> ");
      stringBuilder2.append(stringBuilder1.getResources().getResourceEntryName(this.mConstraintSetEnd));
      return stringBuilder2.toString();
    }
    
    public int getAutoTransition() {
      return this.mAutoTransition;
    }
    
    public int getDuration() {
      return this.mDuration;
    }
    
    public int getEndConstraintSetId() {
      return this.mConstraintSetEnd;
    }
    
    public int getId() {
      return this.mId;
    }
    
    public List<KeyFrames> getKeyFrameList() {
      return this.mKeyFramesList;
    }
    
    public int getLayoutDuringTransition() {
      return this.mLayoutDuringTransition;
    }
    
    public List<TransitionOnClick> getOnClickList() {
      return this.mOnClicks;
    }
    
    public int getPathMotionArc() {
      return this.mPathMotionArc;
    }
    
    public float getStagger() {
      return this.mStagger;
    }
    
    public int getStartConstraintSetId() {
      return this.mConstraintSetStart;
    }
    
    public TouchResponse getTouchResponse() {
      return this.mTouchResponse;
    }
    
    public boolean isEnabled() {
      return this.mDisable ^ true;
    }
    
    public boolean isTransitionFlag(int param1Int) {
      return ((param1Int & this.mTransitionFlags) != 0);
    }
    
    public void setAutoTransition(int param1Int) {
      this.mAutoTransition = param1Int;
    }
    
    public void setDuration(int param1Int) {
      this.mDuration = param1Int;
    }
    
    public void setEnable(boolean param1Boolean) {
      this.mDisable = param1Boolean ^ true;
    }
    
    public void setPathMotionArc(int param1Int) {
      this.mPathMotionArc = param1Int;
    }
    
    public void setStagger(float param1Float) {
      this.mStagger = param1Float;
    }
    
    static class TransitionOnClick implements View.OnClickListener {
      public static final int ANIM_TOGGLE = 17;
      
      public static final int ANIM_TO_END = 1;
      
      public static final int ANIM_TO_START = 16;
      
      public static final int JUMP_TO_END = 256;
      
      public static final int JUMP_TO_START = 4096;
      
      int mMode = 17;
      
      int mTargetId = -1;
      
      private final MotionScene.Transition mTransition;
      
      public TransitionOnClick(Context param2Context, MotionScene.Transition param2Transition, XmlPullParser param2XmlPullParser) {
        this.mTransition = param2Transition;
        TypedArray typedArray = param2Context.obtainStyledAttributes(Xml.asAttributeSet(param2XmlPullParser), R.styleable.OnClick);
        int j = typedArray.getIndexCount();
        int i;
        for (i = 0; i < j; i++) {
          int k = typedArray.getIndex(i);
          if (k == R.styleable.OnClick_targetId) {
            this.mTargetId = typedArray.getResourceId(k, this.mTargetId);
          } else if (k == R.styleable.OnClick_clickAction) {
            this.mMode = typedArray.getInt(k, this.mMode);
          } 
        } 
        typedArray.recycle();
      }
      
      public void addOnClickListeners(MotionLayout param2MotionLayout, int param2Int, MotionScene.Transition param2Transition) {
        View view;
        StringBuilder stringBuilder;
        byte b;
        boolean bool1;
        int i = this.mTargetId;
        if (i != -1)
          view = param2MotionLayout.findViewById(i); 
        if (view == null) {
          stringBuilder = new StringBuilder();
          stringBuilder.append("OnClick could not find id ");
          stringBuilder.append(this.mTargetId);
          Log.e("MotionScene", stringBuilder.toString());
          return;
        } 
        int j = param2Transition.mConstraintSetStart;
        int k = param2Transition.mConstraintSetEnd;
        if (j == -1) {
          stringBuilder.setOnClickListener(this);
          return;
        } 
        int m = this.mMode;
        boolean bool3 = false;
        if ((m & 0x1) != 0 && param2Int == j) {
          i = 1;
        } else {
          i = 0;
        } 
        if ((m & 0x100) != 0 && param2Int == j) {
          b = 1;
        } else {
          b = 0;
        } 
        if ((m & 0x1) != 0 && param2Int == j) {
          j = 1;
        } else {
          j = 0;
        } 
        if ((m & 0x10) != 0 && param2Int == k) {
          bool1 = true;
        } else {
          bool1 = false;
        } 
        boolean bool2 = bool3;
        if ((m & 0x1000) != 0) {
          bool2 = bool3;
          if (param2Int == k)
            bool2 = true; 
        } 
        if ((j | i | b | bool1 | bool2) != 0)
          stringBuilder.setOnClickListener(this); 
      }
      
      boolean isTransitionViable(MotionScene.Transition param2Transition, MotionLayout param2MotionLayout) {
        MotionScene.Transition transition = this.mTransition;
        boolean bool = true;
        if (transition == param2Transition)
          return true; 
        int i = transition.mConstraintSetEnd;
        int j = this.mTransition.mConstraintSetStart;
        if (j == -1)
          return (param2MotionLayout.mCurrentState != i); 
        int k = param2MotionLayout.mCurrentState;
        if (k != j) {
          if (k == i)
            return true; 
          bool = false;
        } 
        return bool;
      }
      
      public void onClick(View param2View) {
        boolean bool1;
        boolean bool2;
        int j;
        MotionLayout motionLayout = this.mTransition.mMotionScene.mMotionLayout;
        if (!motionLayout.isInteractionEnabled())
          return; 
        if (this.mTransition.mConstraintSetStart == -1) {
          bool1 = motionLayout.getCurrentState();
          if (bool1 == -1) {
            motionLayout.transitionToState(this.mTransition.mConstraintSetEnd);
            return;
          } 
          MotionScene.Transition transition1 = new MotionScene.Transition(this.mTransition.mMotionScene, this.mTransition);
          MotionScene.Transition.access$102(transition1, bool1);
          MotionScene.Transition.access$002(transition1, this.mTransition.mConstraintSetEnd);
          motionLayout.setTransition(transition1);
          motionLayout.transitionToEnd();
          return;
        } 
        MotionScene.Transition transition = this.mTransition.mMotionScene.mCurrentTransition;
        int i = this.mMode;
        boolean bool3 = false;
        if ((i & 0x1) != 0 || (i & 0x100) != 0) {
          bool1 = true;
        } else {
          bool1 = false;
        } 
        if ((i & 0x10) != 0 || (i & 0x1000) != 0) {
          i = 1;
        } else {
          i = 0;
        } 
        if (bool1 && i != 0) {
          bool2 = true;
        } else {
          bool2 = false;
        } 
        if (bool2) {
          MotionScene.Transition transition1 = this.mTransition.mMotionScene.mCurrentTransition;
          MotionScene.Transition transition2 = this.mTransition;
          if (transition1 != transition2)
            motionLayout.setTransition(transition2); 
          j = i;
          bool2 = bool3;
          if (motionLayout.getCurrentState() != motionLayout.getEndState())
            if (motionLayout.getProgress() > 0.5F) {
              j = i;
              bool2 = bool3;
            } else {
              j = 0;
              bool2 = bool1;
            }  
        } else {
          bool2 = bool1;
          j = i;
        } 
        if (isTransitionViable(transition, motionLayout)) {
          if (bool2 && (this.mMode & 0x1) != 0) {
            motionLayout.setTransition(this.mTransition);
            motionLayout.transitionToEnd();
            return;
          } 
          if (j != 0 && (this.mMode & 0x10) != 0) {
            motionLayout.setTransition(this.mTransition);
            motionLayout.transitionToStart();
            return;
          } 
          if (bool2 && (this.mMode & 0x100) != 0) {
            motionLayout.setTransition(this.mTransition);
            motionLayout.setProgress(1.0F);
            return;
          } 
          if (j != 0 && (this.mMode & 0x1000) != 0) {
            motionLayout.setTransition(this.mTransition);
            motionLayout.setProgress(0.0F);
          } 
        } 
      }
      
      public void removeOnClickListeners(MotionLayout param2MotionLayout) {
        StringBuilder stringBuilder;
        int i = this.mTargetId;
        if (i == -1)
          return; 
        View view = param2MotionLayout.findViewById(i);
        if (view == null) {
          stringBuilder = new StringBuilder();
          stringBuilder.append(" (*)  could not find id ");
          stringBuilder.append(this.mTargetId);
          Log.e("MotionScene", stringBuilder.toString());
          return;
        } 
        stringBuilder.setOnClickListener(null);
      }
    }
  }
  
  static class TransitionOnClick implements View.OnClickListener {
    public static final int ANIM_TOGGLE = 17;
    
    public static final int ANIM_TO_END = 1;
    
    public static final int ANIM_TO_START = 16;
    
    public static final int JUMP_TO_END = 256;
    
    public static final int JUMP_TO_START = 4096;
    
    int mMode = 17;
    
    int mTargetId = -1;
    
    private final MotionScene.Transition mTransition;
    
    public TransitionOnClick(Context param1Context, MotionScene.Transition param1Transition, XmlPullParser param1XmlPullParser) {
      this.mTransition = param1Transition;
      TypedArray typedArray = param1Context.obtainStyledAttributes(Xml.asAttributeSet(param1XmlPullParser), R.styleable.OnClick);
      int j = typedArray.getIndexCount();
      int i;
      for (i = 0; i < j; i++) {
        int k = typedArray.getIndex(i);
        if (k == R.styleable.OnClick_targetId) {
          this.mTargetId = typedArray.getResourceId(k, this.mTargetId);
        } else if (k == R.styleable.OnClick_clickAction) {
          this.mMode = typedArray.getInt(k, this.mMode);
        } 
      } 
      typedArray.recycle();
    }
    
    public void addOnClickListeners(MotionLayout param1MotionLayout, int param1Int, MotionScene.Transition param1Transition) {
      View view;
      StringBuilder stringBuilder;
      byte b;
      boolean bool1;
      int i = this.mTargetId;
      if (i != -1)
        view = param1MotionLayout.findViewById(i); 
      if (view == null) {
        stringBuilder = new StringBuilder();
        stringBuilder.append("OnClick could not find id ");
        stringBuilder.append(this.mTargetId);
        Log.e("MotionScene", stringBuilder.toString());
        return;
      } 
      int j = param1Transition.mConstraintSetStart;
      int k = param1Transition.mConstraintSetEnd;
      if (j == -1) {
        stringBuilder.setOnClickListener(this);
        return;
      } 
      int m = this.mMode;
      boolean bool3 = false;
      if ((m & 0x1) != 0 && param1Int == j) {
        i = 1;
      } else {
        i = 0;
      } 
      if ((m & 0x100) != 0 && param1Int == j) {
        b = 1;
      } else {
        b = 0;
      } 
      if ((m & 0x1) != 0 && param1Int == j) {
        j = 1;
      } else {
        j = 0;
      } 
      if ((m & 0x10) != 0 && param1Int == k) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
      boolean bool2 = bool3;
      if ((m & 0x1000) != 0) {
        bool2 = bool3;
        if (param1Int == k)
          bool2 = true; 
      } 
      if ((j | i | b | bool1 | bool2) != 0)
        stringBuilder.setOnClickListener(this); 
    }
    
    boolean isTransitionViable(MotionScene.Transition param1Transition, MotionLayout param1MotionLayout) {
      MotionScene.Transition transition = this.mTransition;
      boolean bool = true;
      if (transition == param1Transition)
        return true; 
      int i = transition.mConstraintSetEnd;
      int j = this.mTransition.mConstraintSetStart;
      if (j == -1)
        return (param1MotionLayout.mCurrentState != i); 
      int k = param1MotionLayout.mCurrentState;
      if (k != j) {
        if (k == i)
          return true; 
        bool = false;
      } 
      return bool;
    }
    
    public void onClick(View param1View) {
      boolean bool1;
      boolean bool2;
      int j;
      MotionLayout motionLayout = this.mTransition.mMotionScene.mMotionLayout;
      if (!motionLayout.isInteractionEnabled())
        return; 
      if (this.mTransition.mConstraintSetStart == -1) {
        bool1 = motionLayout.getCurrentState();
        if (bool1 == -1) {
          motionLayout.transitionToState(this.mTransition.mConstraintSetEnd);
          return;
        } 
        MotionScene.Transition transition1 = new MotionScene.Transition(this.mTransition.mMotionScene, this.mTransition);
        MotionScene.Transition.access$102(transition1, bool1);
        MotionScene.Transition.access$002(transition1, this.mTransition.mConstraintSetEnd);
        motionLayout.setTransition(transition1);
        motionLayout.transitionToEnd();
        return;
      } 
      MotionScene.Transition transition = this.mTransition.mMotionScene.mCurrentTransition;
      int i = this.mMode;
      boolean bool3 = false;
      if ((i & 0x1) != 0 || (i & 0x100) != 0) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
      if ((i & 0x10) != 0 || (i & 0x1000) != 0) {
        i = 1;
      } else {
        i = 0;
      } 
      if (bool1 && i != 0) {
        bool2 = true;
      } else {
        bool2 = false;
      } 
      if (bool2) {
        MotionScene.Transition transition1 = this.mTransition.mMotionScene.mCurrentTransition;
        MotionScene.Transition transition2 = this.mTransition;
        if (transition1 != transition2)
          motionLayout.setTransition(transition2); 
        j = i;
        bool2 = bool3;
        if (motionLayout.getCurrentState() != motionLayout.getEndState())
          if (motionLayout.getProgress() > 0.5F) {
            j = i;
            bool2 = bool3;
          } else {
            j = 0;
            bool2 = bool1;
          }  
      } else {
        bool2 = bool1;
        j = i;
      } 
      if (isTransitionViable(transition, motionLayout)) {
        if (bool2 && (this.mMode & 0x1) != 0) {
          motionLayout.setTransition(this.mTransition);
          motionLayout.transitionToEnd();
          return;
        } 
        if (j != 0 && (this.mMode & 0x10) != 0) {
          motionLayout.setTransition(this.mTransition);
          motionLayout.transitionToStart();
          return;
        } 
        if (bool2 && (this.mMode & 0x100) != 0) {
          motionLayout.setTransition(this.mTransition);
          motionLayout.setProgress(1.0F);
          return;
        } 
        if (j != 0 && (this.mMode & 0x1000) != 0) {
          motionLayout.setTransition(this.mTransition);
          motionLayout.setProgress(0.0F);
        } 
      } 
    }
    
    public void removeOnClickListeners(MotionLayout param1MotionLayout) {
      StringBuilder stringBuilder;
      int i = this.mTargetId;
      if (i == -1)
        return; 
      View view = param1MotionLayout.findViewById(i);
      if (view == null) {
        stringBuilder = new StringBuilder();
        stringBuilder.append(" (*)  could not find id ");
        stringBuilder.append(this.mTargetId);
        Log.e("MotionScene", stringBuilder.toString());
        return;
      } 
      stringBuilder.setOnClickListener(null);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\BabyBus TV_Kids Videos & Games-dex2jar.jar!\androidx\constraintlayout\motion\widget\MotionScene.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */