package androidx.constraintlayout.motion.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseIntArray;
import android.view.View;
import androidx.constraintlayout.widget.ConstraintAttribute;
import androidx.constraintlayout.widget.R;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.HashSet;

public class KeyTrigger extends Key {
  public static final int KEY_TYPE = 5;
  
  static final String NAME = "KeyTrigger";
  
  private static final String TAG = "KeyTrigger";
  
  RectF mCollisionRect;
  
  private String mCross = null;
  
  private int mCurveFit = -1;
  
  private Method mFireCross;
  
  private boolean mFireCrossReset;
  
  private float mFireLastPos;
  
  private Method mFireNegativeCross;
  
  private boolean mFireNegativeReset;
  
  private Method mFirePositiveCross;
  
  private boolean mFirePositiveReset;
  
  private float mFireThreshold;
  
  private String mNegativeCross;
  
  private String mPositiveCross;
  
  private boolean mPostLayout;
  
  RectF mTargetRect;
  
  private int mTriggerCollisionId;
  
  private View mTriggerCollisionView;
  
  private int mTriggerID;
  
  private int mTriggerReceiver;
  
  float mTriggerSlack;
  
  public KeyTrigger() {
    int i = Key.UNSET;
    this.mTriggerReceiver = i;
    this.mNegativeCross = null;
    this.mPositiveCross = null;
    this.mTriggerID = i;
    this.mTriggerCollisionId = i;
    this.mTriggerCollisionView = null;
    this.mTriggerSlack = 0.1F;
    this.mFireCrossReset = true;
    this.mFireNegativeReset = true;
    this.mFirePositiveReset = true;
    this.mFireThreshold = Float.NaN;
    this.mPostLayout = false;
    this.mCollisionRect = new RectF();
    this.mTargetRect = new RectF();
    this.mType = 5;
    this.mCustomConstraints = new HashMap<String, ConstraintAttribute>();
  }
  
  private void setUpRect(RectF paramRectF, View paramView, boolean paramBoolean) {
    paramRectF.top = paramView.getTop();
    paramRectF.bottom = paramView.getBottom();
    paramRectF.left = paramView.getLeft();
    paramRectF.right = paramView.getRight();
    if (paramBoolean)
      paramView.getMatrix().mapRect(paramRectF); 
  }
  
  public void addValues(HashMap<String, SplineSet> paramHashMap) {}
  
  public void conditionallyFire(float paramFloat, View paramView) {
    // Byte code:
    //   0: aload_0
    //   1: getfield mTriggerCollisionId : I
    //   4: istore #5
    //   6: getstatic androidx/constraintlayout/motion/widget/Key.UNSET : I
    //   9: istore #6
    //   11: iconst_1
    //   12: istore #7
    //   14: iload #5
    //   16: iload #6
    //   18: if_icmpeq -> 192
    //   21: aload_0
    //   22: getfield mTriggerCollisionView : Landroid/view/View;
    //   25: ifnonnull -> 46
    //   28: aload_0
    //   29: aload_2
    //   30: invokevirtual getParent : ()Landroid/view/ViewParent;
    //   33: checkcast android/view/ViewGroup
    //   36: aload_0
    //   37: getfield mTriggerCollisionId : I
    //   40: invokevirtual findViewById : (I)Landroid/view/View;
    //   43: putfield mTriggerCollisionView : Landroid/view/View;
    //   46: aload_0
    //   47: aload_0
    //   48: getfield mCollisionRect : Landroid/graphics/RectF;
    //   51: aload_0
    //   52: getfield mTriggerCollisionView : Landroid/view/View;
    //   55: aload_0
    //   56: getfield mPostLayout : Z
    //   59: invokespecial setUpRect : (Landroid/graphics/RectF;Landroid/view/View;Z)V
    //   62: aload_0
    //   63: aload_0
    //   64: getfield mTargetRect : Landroid/graphics/RectF;
    //   67: aload_2
    //   68: aload_0
    //   69: getfield mPostLayout : Z
    //   72: invokespecial setUpRect : (Landroid/graphics/RectF;Landroid/view/View;Z)V
    //   75: aload_0
    //   76: getfield mCollisionRect : Landroid/graphics/RectF;
    //   79: aload_0
    //   80: getfield mTargetRect : Landroid/graphics/RectF;
    //   83: invokevirtual intersect : (Landroid/graphics/RectF;)Z
    //   86: ifeq -> 142
    //   89: aload_0
    //   90: getfield mFireCrossReset : Z
    //   93: ifeq -> 107
    //   96: aload_0
    //   97: iconst_0
    //   98: putfield mFireCrossReset : Z
    //   101: iconst_1
    //   102: istore #5
    //   104: goto -> 110
    //   107: iconst_0
    //   108: istore #5
    //   110: aload_0
    //   111: getfield mFirePositiveReset : Z
    //   114: ifeq -> 128
    //   117: aload_0
    //   118: iconst_0
    //   119: putfield mFirePositiveReset : Z
    //   122: iconst_1
    //   123: istore #7
    //   125: goto -> 131
    //   128: iconst_0
    //   129: istore #7
    //   131: aload_0
    //   132: iconst_1
    //   133: putfield mFireNegativeReset : Z
    //   136: iconst_0
    //   137: istore #6
    //   139: goto -> 406
    //   142: aload_0
    //   143: getfield mFireCrossReset : Z
    //   146: ifne -> 160
    //   149: aload_0
    //   150: iconst_1
    //   151: putfield mFireCrossReset : Z
    //   154: iconst_1
    //   155: istore #5
    //   157: goto -> 163
    //   160: iconst_0
    //   161: istore #5
    //   163: aload_0
    //   164: getfield mFireNegativeReset : Z
    //   167: ifeq -> 181
    //   170: aload_0
    //   171: iconst_0
    //   172: putfield mFireNegativeReset : Z
    //   175: iconst_1
    //   176: istore #6
    //   178: goto -> 184
    //   181: iconst_0
    //   182: istore #6
    //   184: aload_0
    //   185: iconst_1
    //   186: putfield mFirePositiveReset : Z
    //   189: goto -> 403
    //   192: aload_0
    //   193: getfield mFireCrossReset : Z
    //   196: ifeq -> 230
    //   199: aload_0
    //   200: getfield mFireThreshold : F
    //   203: fstore_3
    //   204: fload_1
    //   205: fload_3
    //   206: fsub
    //   207: aload_0
    //   208: getfield mFireLastPos : F
    //   211: fload_3
    //   212: fsub
    //   213: fmul
    //   214: fconst_0
    //   215: fcmpg
    //   216: ifge -> 252
    //   219: aload_0
    //   220: iconst_0
    //   221: putfield mFireCrossReset : Z
    //   224: iconst_1
    //   225: istore #5
    //   227: goto -> 255
    //   230: fload_1
    //   231: aload_0
    //   232: getfield mFireThreshold : F
    //   235: fsub
    //   236: invokestatic abs : (F)F
    //   239: aload_0
    //   240: getfield mTriggerSlack : F
    //   243: fcmpl
    //   244: ifle -> 252
    //   247: aload_0
    //   248: iconst_1
    //   249: putfield mFireCrossReset : Z
    //   252: iconst_0
    //   253: istore #5
    //   255: aload_0
    //   256: getfield mFireNegativeReset : Z
    //   259: ifeq -> 304
    //   262: aload_0
    //   263: getfield mFireThreshold : F
    //   266: fstore_3
    //   267: fload_1
    //   268: fload_3
    //   269: fsub
    //   270: fstore #4
    //   272: aload_0
    //   273: getfield mFireLastPos : F
    //   276: fload_3
    //   277: fsub
    //   278: fload #4
    //   280: fmul
    //   281: fconst_0
    //   282: fcmpg
    //   283: ifge -> 326
    //   286: fload #4
    //   288: fconst_0
    //   289: fcmpg
    //   290: ifge -> 326
    //   293: aload_0
    //   294: iconst_0
    //   295: putfield mFireNegativeReset : Z
    //   298: iconst_1
    //   299: istore #6
    //   301: goto -> 329
    //   304: fload_1
    //   305: aload_0
    //   306: getfield mFireThreshold : F
    //   309: fsub
    //   310: invokestatic abs : (F)F
    //   313: aload_0
    //   314: getfield mTriggerSlack : F
    //   317: fcmpl
    //   318: ifle -> 326
    //   321: aload_0
    //   322: iconst_1
    //   323: putfield mFireNegativeReset : Z
    //   326: iconst_0
    //   327: istore #6
    //   329: aload_0
    //   330: getfield mFirePositiveReset : Z
    //   333: ifeq -> 381
    //   336: aload_0
    //   337: getfield mFireThreshold : F
    //   340: fstore_3
    //   341: fload_1
    //   342: fload_3
    //   343: fsub
    //   344: fstore #4
    //   346: aload_0
    //   347: getfield mFireLastPos : F
    //   350: fload_3
    //   351: fsub
    //   352: fload #4
    //   354: fmul
    //   355: fconst_0
    //   356: fcmpg
    //   357: ifge -> 375
    //   360: fload #4
    //   362: fconst_0
    //   363: fcmpl
    //   364: ifle -> 375
    //   367: aload_0
    //   368: iconst_0
    //   369: putfield mFirePositiveReset : Z
    //   372: goto -> 378
    //   375: iconst_0
    //   376: istore #7
    //   378: goto -> 406
    //   381: fload_1
    //   382: aload_0
    //   383: getfield mFireThreshold : F
    //   386: fsub
    //   387: invokestatic abs : (F)F
    //   390: aload_0
    //   391: getfield mTriggerSlack : F
    //   394: fcmpl
    //   395: ifle -> 403
    //   398: aload_0
    //   399: iconst_1
    //   400: putfield mFirePositiveReset : Z
    //   403: iconst_0
    //   404: istore #7
    //   406: aload_0
    //   407: fload_1
    //   408: putfield mFireLastPos : F
    //   411: iload #6
    //   413: ifne -> 426
    //   416: iload #5
    //   418: ifne -> 426
    //   421: iload #7
    //   423: ifeq -> 443
    //   426: aload_2
    //   427: invokevirtual getParent : ()Landroid/view/ViewParent;
    //   430: checkcast androidx/constraintlayout/motion/widget/MotionLayout
    //   433: aload_0
    //   434: getfield mTriggerID : I
    //   437: iload #7
    //   439: fload_1
    //   440: invokevirtual fireTrigger : (IZF)V
    //   443: aload_0
    //   444: getfield mTriggerReceiver : I
    //   447: getstatic androidx/constraintlayout/motion/widget/Key.UNSET : I
    //   450: if_icmpne -> 456
    //   453: goto -> 471
    //   456: aload_2
    //   457: invokevirtual getParent : ()Landroid/view/ViewParent;
    //   460: checkcast androidx/constraintlayout/motion/widget/MotionLayout
    //   463: aload_0
    //   464: getfield mTriggerReceiver : I
    //   467: invokevirtual findViewById : (I)Landroid/view/View;
    //   470: astore_2
    //   471: iload #6
    //   473: ifeq -> 682
    //   476: aload_0
    //   477: getfield mNegativeCross : Ljava/lang/String;
    //   480: ifnull -> 682
    //   483: aload_0
    //   484: getfield mFireNegativeCross : Ljava/lang/reflect/Method;
    //   487: ifnonnull -> 589
    //   490: aload_0
    //   491: aload_2
    //   492: invokevirtual getClass : ()Ljava/lang/Class;
    //   495: aload_0
    //   496: getfield mNegativeCross : Ljava/lang/String;
    //   499: iconst_0
    //   500: anewarray java/lang/Class
    //   503: invokevirtual getMethod : (Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
    //   506: putfield mFireNegativeCross : Ljava/lang/reflect/Method;
    //   509: goto -> 589
    //   512: new java/lang/StringBuilder
    //   515: dup
    //   516: invokespecial <init> : ()V
    //   519: astore #8
    //   521: aload #8
    //   523: ldc 'Could not find method "'
    //   525: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   528: pop
    //   529: aload #8
    //   531: aload_0
    //   532: getfield mNegativeCross : Ljava/lang/String;
    //   535: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   538: pop
    //   539: aload #8
    //   541: ldc '"on class '
    //   543: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   546: pop
    //   547: aload #8
    //   549: aload_2
    //   550: invokevirtual getClass : ()Ljava/lang/Class;
    //   553: invokevirtual getSimpleName : ()Ljava/lang/String;
    //   556: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   559: pop
    //   560: aload #8
    //   562: ldc ' '
    //   564: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   567: pop
    //   568: aload #8
    //   570: aload_2
    //   571: invokestatic getName : (Landroid/view/View;)Ljava/lang/String;
    //   574: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   577: pop
    //   578: ldc 'KeyTrigger'
    //   580: aload #8
    //   582: invokevirtual toString : ()Ljava/lang/String;
    //   585: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
    //   588: pop
    //   589: aload_0
    //   590: getfield mFireNegativeCross : Ljava/lang/reflect/Method;
    //   593: aload_2
    //   594: iconst_0
    //   595: anewarray java/lang/Object
    //   598: invokevirtual invoke : (Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    //   601: pop
    //   602: goto -> 682
    //   605: new java/lang/StringBuilder
    //   608: dup
    //   609: invokespecial <init> : ()V
    //   612: astore #8
    //   614: aload #8
    //   616: ldc 'Exception in call "'
    //   618: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   621: pop
    //   622: aload #8
    //   624: aload_0
    //   625: getfield mNegativeCross : Ljava/lang/String;
    //   628: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   631: pop
    //   632: aload #8
    //   634: ldc '"on class '
    //   636: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   639: pop
    //   640: aload #8
    //   642: aload_2
    //   643: invokevirtual getClass : ()Ljava/lang/Class;
    //   646: invokevirtual getSimpleName : ()Ljava/lang/String;
    //   649: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   652: pop
    //   653: aload #8
    //   655: ldc ' '
    //   657: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   660: pop
    //   661: aload #8
    //   663: aload_2
    //   664: invokestatic getName : (Landroid/view/View;)Ljava/lang/String;
    //   667: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   670: pop
    //   671: ldc 'KeyTrigger'
    //   673: aload #8
    //   675: invokevirtual toString : ()Ljava/lang/String;
    //   678: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
    //   681: pop
    //   682: iload #7
    //   684: ifeq -> 893
    //   687: aload_0
    //   688: getfield mPositiveCross : Ljava/lang/String;
    //   691: ifnull -> 893
    //   694: aload_0
    //   695: getfield mFirePositiveCross : Ljava/lang/reflect/Method;
    //   698: ifnonnull -> 800
    //   701: aload_0
    //   702: aload_2
    //   703: invokevirtual getClass : ()Ljava/lang/Class;
    //   706: aload_0
    //   707: getfield mPositiveCross : Ljava/lang/String;
    //   710: iconst_0
    //   711: anewarray java/lang/Class
    //   714: invokevirtual getMethod : (Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
    //   717: putfield mFirePositiveCross : Ljava/lang/reflect/Method;
    //   720: goto -> 800
    //   723: new java/lang/StringBuilder
    //   726: dup
    //   727: invokespecial <init> : ()V
    //   730: astore #8
    //   732: aload #8
    //   734: ldc 'Could not find method "'
    //   736: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   739: pop
    //   740: aload #8
    //   742: aload_0
    //   743: getfield mPositiveCross : Ljava/lang/String;
    //   746: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   749: pop
    //   750: aload #8
    //   752: ldc '"on class '
    //   754: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   757: pop
    //   758: aload #8
    //   760: aload_2
    //   761: invokevirtual getClass : ()Ljava/lang/Class;
    //   764: invokevirtual getSimpleName : ()Ljava/lang/String;
    //   767: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   770: pop
    //   771: aload #8
    //   773: ldc ' '
    //   775: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   778: pop
    //   779: aload #8
    //   781: aload_2
    //   782: invokestatic getName : (Landroid/view/View;)Ljava/lang/String;
    //   785: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   788: pop
    //   789: ldc 'KeyTrigger'
    //   791: aload #8
    //   793: invokevirtual toString : ()Ljava/lang/String;
    //   796: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
    //   799: pop
    //   800: aload_0
    //   801: getfield mFirePositiveCross : Ljava/lang/reflect/Method;
    //   804: aload_2
    //   805: iconst_0
    //   806: anewarray java/lang/Object
    //   809: invokevirtual invoke : (Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    //   812: pop
    //   813: goto -> 893
    //   816: new java/lang/StringBuilder
    //   819: dup
    //   820: invokespecial <init> : ()V
    //   823: astore #8
    //   825: aload #8
    //   827: ldc 'Exception in call "'
    //   829: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   832: pop
    //   833: aload #8
    //   835: aload_0
    //   836: getfield mPositiveCross : Ljava/lang/String;
    //   839: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   842: pop
    //   843: aload #8
    //   845: ldc '"on class '
    //   847: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   850: pop
    //   851: aload #8
    //   853: aload_2
    //   854: invokevirtual getClass : ()Ljava/lang/Class;
    //   857: invokevirtual getSimpleName : ()Ljava/lang/String;
    //   860: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   863: pop
    //   864: aload #8
    //   866: ldc ' '
    //   868: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   871: pop
    //   872: aload #8
    //   874: aload_2
    //   875: invokestatic getName : (Landroid/view/View;)Ljava/lang/String;
    //   878: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   881: pop
    //   882: ldc 'KeyTrigger'
    //   884: aload #8
    //   886: invokevirtual toString : ()Ljava/lang/String;
    //   889: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
    //   892: pop
    //   893: iload #5
    //   895: ifeq -> 1102
    //   898: aload_0
    //   899: getfield mCross : Ljava/lang/String;
    //   902: ifnull -> 1102
    //   905: aload_0
    //   906: getfield mFireCross : Ljava/lang/reflect/Method;
    //   909: ifnonnull -> 1011
    //   912: aload_0
    //   913: aload_2
    //   914: invokevirtual getClass : ()Ljava/lang/Class;
    //   917: aload_0
    //   918: getfield mCross : Ljava/lang/String;
    //   921: iconst_0
    //   922: anewarray java/lang/Class
    //   925: invokevirtual getMethod : (Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
    //   928: putfield mFireCross : Ljava/lang/reflect/Method;
    //   931: goto -> 1011
    //   934: new java/lang/StringBuilder
    //   937: dup
    //   938: invokespecial <init> : ()V
    //   941: astore #8
    //   943: aload #8
    //   945: ldc 'Could not find method "'
    //   947: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   950: pop
    //   951: aload #8
    //   953: aload_0
    //   954: getfield mCross : Ljava/lang/String;
    //   957: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   960: pop
    //   961: aload #8
    //   963: ldc '"on class '
    //   965: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   968: pop
    //   969: aload #8
    //   971: aload_2
    //   972: invokevirtual getClass : ()Ljava/lang/Class;
    //   975: invokevirtual getSimpleName : ()Ljava/lang/String;
    //   978: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   981: pop
    //   982: aload #8
    //   984: ldc ' '
    //   986: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   989: pop
    //   990: aload #8
    //   992: aload_2
    //   993: invokestatic getName : (Landroid/view/View;)Ljava/lang/String;
    //   996: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   999: pop
    //   1000: ldc 'KeyTrigger'
    //   1002: aload #8
    //   1004: invokevirtual toString : ()Ljava/lang/String;
    //   1007: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
    //   1010: pop
    //   1011: aload_0
    //   1012: getfield mFireCross : Ljava/lang/reflect/Method;
    //   1015: aload_2
    //   1016: iconst_0
    //   1017: anewarray java/lang/Object
    //   1020: invokevirtual invoke : (Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    //   1023: pop
    //   1024: return
    //   1025: new java/lang/StringBuilder
    //   1028: dup
    //   1029: invokespecial <init> : ()V
    //   1032: astore #8
    //   1034: aload #8
    //   1036: ldc 'Exception in call "'
    //   1038: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1041: pop
    //   1042: aload #8
    //   1044: aload_0
    //   1045: getfield mCross : Ljava/lang/String;
    //   1048: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1051: pop
    //   1052: aload #8
    //   1054: ldc '"on class '
    //   1056: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1059: pop
    //   1060: aload #8
    //   1062: aload_2
    //   1063: invokevirtual getClass : ()Ljava/lang/Class;
    //   1066: invokevirtual getSimpleName : ()Ljava/lang/String;
    //   1069: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1072: pop
    //   1073: aload #8
    //   1075: ldc ' '
    //   1077: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1080: pop
    //   1081: aload #8
    //   1083: aload_2
    //   1084: invokestatic getName : (Landroid/view/View;)Ljava/lang/String;
    //   1087: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1090: pop
    //   1091: ldc 'KeyTrigger'
    //   1093: aload #8
    //   1095: invokevirtual toString : ()Ljava/lang/String;
    //   1098: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
    //   1101: pop
    //   1102: return
    //   1103: astore #8
    //   1105: goto -> 512
    //   1108: astore #8
    //   1110: goto -> 605
    //   1113: astore #8
    //   1115: goto -> 723
    //   1118: astore #8
    //   1120: goto -> 816
    //   1123: astore #8
    //   1125: goto -> 934
    //   1128: astore #8
    //   1130: goto -> 1025
    // Exception table:
    //   from	to	target	type
    //   490	509	1103	java/lang/NoSuchMethodException
    //   589	602	1108	java/lang/Exception
    //   701	720	1113	java/lang/NoSuchMethodException
    //   800	813	1118	java/lang/Exception
    //   912	931	1123	java/lang/NoSuchMethodException
    //   1011	1024	1128	java/lang/Exception
  }
  
  public void getAttributeNames(HashSet<String> paramHashSet) {}
  
  int getCurveFit() {
    return this.mCurveFit;
  }
  
  public void load(Context paramContext, AttributeSet paramAttributeSet) {
    Loader.read(this, paramContext.obtainStyledAttributes(paramAttributeSet, R.styleable.KeyTrigger), paramContext);
  }
  
  public void setValue(String paramString, Object paramObject) {}
  
  private static class Loader {
    private static final int COLLISION = 9;
    
    private static final int CROSS = 4;
    
    private static final int FRAME_POS = 8;
    
    private static final int NEGATIVE_CROSS = 1;
    
    private static final int POSITIVE_CROSS = 2;
    
    private static final int POST_LAYOUT = 10;
    
    private static final int TARGET_ID = 7;
    
    private static final int TRIGGER_ID = 6;
    
    private static final int TRIGGER_RECEIVER = 11;
    
    private static final int TRIGGER_SLACK = 5;
    
    private static SparseIntArray mAttrMap;
    
    static {
      SparseIntArray sparseIntArray = new SparseIntArray();
      mAttrMap = sparseIntArray;
      sparseIntArray.append(R.styleable.KeyTrigger_framePosition, 8);
      mAttrMap.append(R.styleable.KeyTrigger_onCross, 4);
      mAttrMap.append(R.styleable.KeyTrigger_onNegativeCross, 1);
      mAttrMap.append(R.styleable.KeyTrigger_onPositiveCross, 2);
      mAttrMap.append(R.styleable.KeyTrigger_motionTarget, 7);
      mAttrMap.append(R.styleable.KeyTrigger_triggerId, 6);
      mAttrMap.append(R.styleable.KeyTrigger_triggerSlack, 5);
      mAttrMap.append(R.styleable.KeyTrigger_motion_triggerOnCollision, 9);
      mAttrMap.append(R.styleable.KeyTrigger_motion_postLayoutCollision, 10);
      mAttrMap.append(R.styleable.KeyTrigger_triggerReceiver, 11);
    }
    
    public static void read(KeyTrigger param1KeyTrigger, TypedArray param1TypedArray, Context param1Context) {
      int j = param1TypedArray.getIndexCount();
      for (int i = 0;; i++) {
        if (i < j) {
          StringBuilder stringBuilder;
          int k = param1TypedArray.getIndex(i);
          switch (mAttrMap.get(k)) {
            default:
              stringBuilder = new StringBuilder();
              stringBuilder.append("unused attribute 0x");
              stringBuilder.append(Integer.toHexString(k));
              stringBuilder.append("   ");
              stringBuilder.append(mAttrMap.get(k));
              Log.e("KeyTrigger", stringBuilder.toString());
              i++;
              continue;
            case 11:
              KeyTrigger.access$702(param1KeyTrigger, param1TypedArray.getResourceId(k, param1KeyTrigger.mTriggerReceiver));
            case 10:
              KeyTrigger.access$602(param1KeyTrigger, param1TypedArray.getBoolean(k, param1KeyTrigger.mPostLayout));
              break;
            case 9:
              KeyTrigger.access$502(param1KeyTrigger, param1TypedArray.getResourceId(k, param1KeyTrigger.mTriggerCollisionId));
              break;
            case 8:
              k = param1TypedArray.getInteger(k, param1KeyTrigger.mFramePosition);
              param1KeyTrigger.mFramePosition = k;
              KeyTrigger.access$002(param1KeyTrigger, (k + 0.5F) / 100.0F);
              break;
            case 7:
              if (MotionLayout.IS_IN_EDIT_MODE) {
                int m = param1TypedArray.getResourceId(k, param1KeyTrigger.mTargetId);
                param1KeyTrigger.mTargetId = m;
                if (m == -1)
                  param1KeyTrigger.mTargetString = param1TypedArray.getString(k); 
                break;
              } 
              if ((param1TypedArray.peekValue(k)).type == 3) {
                param1KeyTrigger.mTargetString = param1TypedArray.getString(k);
                break;
              } 
              param1KeyTrigger.mTargetId = param1TypedArray.getResourceId(k, param1KeyTrigger.mTargetId);
              break;
            case 6:
              KeyTrigger.access$402(param1KeyTrigger, param1TypedArray.getResourceId(k, param1KeyTrigger.mTriggerID));
              break;
            case 5:
              param1KeyTrigger.mTriggerSlack = param1TypedArray.getFloat(k, param1KeyTrigger.mTriggerSlack);
              break;
            case 4:
              KeyTrigger.access$302(param1KeyTrigger, param1TypedArray.getString(k));
              break;
            case 2:
              KeyTrigger.access$202(param1KeyTrigger, param1TypedArray.getString(k));
              break;
            case 1:
              KeyTrigger.access$102(param1KeyTrigger, param1TypedArray.getString(k));
              break;
          } 
        } else {
          break;
        } 
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\BabyBus TV_Kids Videos & Games-dex2jar.jar!\androidx\constraintlayout\motion\widget\KeyTrigger.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */