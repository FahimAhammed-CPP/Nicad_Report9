package androidx.constraintlayout.motion.widget;

import android.graphics.RectF;
import android.util.Log;
import android.util.SparseArray;
import android.view.View;
import android.view.ViewGroup;
import androidx.constraintlayout.motion.utils.CurveFit;
import androidx.constraintlayout.motion.utils.Easing;
import androidx.constraintlayout.motion.utils.VelocityMatrix;
import androidx.constraintlayout.solver.widgets.ConstraintWidget;
import androidx.constraintlayout.widget.ConstraintAttribute;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.constraintlayout.widget.ConstraintSet;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;

public class MotionController {
  private static final boolean DEBUG = false;
  
  public static final int DRAW_PATH_AS_CONFIGURED = 4;
  
  public static final int DRAW_PATH_BASIC = 1;
  
  public static final int DRAW_PATH_CARTESIAN = 3;
  
  public static final int DRAW_PATH_NONE = 0;
  
  public static final int DRAW_PATH_RECTANGLE = 5;
  
  public static final int DRAW_PATH_RELATIVE = 2;
  
  public static final int DRAW_PATH_SCREEN = 6;
  
  private static final boolean FAVOR_FIXED_SIZE_VIEWS = false;
  
  public static final int HORIZONTAL_PATH_X = 2;
  
  public static final int HORIZONTAL_PATH_Y = 3;
  
  public static final int PATH_PERCENT = 0;
  
  public static final int PATH_PERPENDICULAR = 1;
  
  private static final String TAG = "MotionController";
  
  public static final int VERTICAL_PATH_X = 4;
  
  public static final int VERTICAL_PATH_Y = 5;
  
  private int MAX_DIMENSION = 4;
  
  String[] attributeTable;
  
  private CurveFit mArcSpline;
  
  private int[] mAttributeInterpCount;
  
  private String[] mAttributeNames;
  
  private HashMap<String, SplineSet> mAttributesMap;
  
  String mConstraintTag;
  
  private int mCurveFitType = -1;
  
  private HashMap<String, KeyCycleOscillator> mCycleMap;
  
  private MotionPaths mEndMotionPath = new MotionPaths();
  
  private MotionConstrainedPoint mEndPoint = new MotionConstrainedPoint();
  
  int mId;
  
  private double[] mInterpolateData;
  
  private int[] mInterpolateVariables;
  
  private double[] mInterpolateVelocity;
  
  private ArrayList<Key> mKeyList = new ArrayList<Key>();
  
  private KeyTrigger[] mKeyTriggers;
  
  private ArrayList<MotionPaths> mMotionPaths = new ArrayList<MotionPaths>();
  
  float mMotionStagger = Float.NaN;
  
  private int mPathMotionArc = Key.UNSET;
  
  private CurveFit[] mSpline;
  
  float mStaggerOffset = 0.0F;
  
  float mStaggerScale = 1.0F;
  
  private MotionPaths mStartMotionPath = new MotionPaths();
  
  private MotionConstrainedPoint mStartPoint = new MotionConstrainedPoint();
  
  private HashMap<String, TimeCycleSplineSet> mTimeCycleAttributesMap;
  
  private float[] mValuesBuff = new float[4];
  
  private float[] mVelocity = new float[1];
  
  View mView;
  
  MotionController(View paramView) {
    setView(paramView);
  }
  
  private float getAdjustedPosition(float paramFloat, float[] paramArrayOffloat) {
    float f1;
    float f3 = 0.0F;
    float f4 = 1.0F;
    if (paramArrayOffloat != null) {
      paramArrayOffloat[0] = 1.0F;
      f1 = paramFloat;
    } else {
      float f = this.mStaggerScale;
      f1 = paramFloat;
      if (f != 1.0D) {
        float f6 = this.mStaggerOffset;
        float f5 = paramFloat;
        if (paramFloat < f6)
          f5 = 0.0F; 
        f1 = f5;
        if (f5 > f6) {
          f1 = f5;
          if (f5 < 1.0D)
            f1 = (f5 - f6) * f; 
        } 
      } 
    } 
    Easing easing = this.mStartMotionPath.mKeyFrameEasing;
    paramFloat = Float.NaN;
    Iterator<MotionPaths> iterator = this.mMotionPaths.iterator();
    float f2 = f3;
    while (iterator.hasNext()) {
      MotionPaths motionPaths = iterator.next();
      Easing easing1 = motionPaths.mKeyFrameEasing;
      if (easing1 != null) {
        f3 = motionPaths.time;
        if (f3 < f1) {
          easing = easing1;
          f2 = f3;
          continue;
        } 
        if (Float.isNaN(paramFloat))
          paramFloat = motionPaths.time; 
      } 
    } 
    f3 = f1;
    if (easing != null) {
      if (Float.isNaN(paramFloat))
        paramFloat = f4; 
      paramFloat -= f2;
      double d = ((f1 - f2) / paramFloat);
      paramFloat = (float)easing.get(d) * paramFloat + f2;
      f3 = paramFloat;
      if (paramArrayOffloat != null) {
        paramArrayOffloat[0] = (float)easing.getDiff(d);
        f3 = paramFloat;
      } 
    } 
    return f3;
  }
  
  private float getPreCycleDistance() {
    float[] arrayOfFloat = new float[2];
    float f1 = 1.0F / 99;
    double d1 = 0.0D;
    double d2 = 0.0D;
    int i = 0;
    float f2;
    for (f2 = 0.0F; i < 100; f2 = f3) {
      float f5 = i * f1;
      double d = f5;
      Easing easing = this.mStartMotionPath.mKeyFrameEasing;
      float f3 = Float.NaN;
      Iterator<MotionPaths> iterator = this.mMotionPaths.iterator();
      float f4;
      for (f4 = 0.0F; iterator.hasNext(); f4 = f7) {
        MotionPaths motionPaths = iterator.next();
        Easing easing2 = motionPaths.mKeyFrameEasing;
        Easing easing1 = easing;
        float f6 = f3;
        float f7 = f4;
        if (easing2 != null) {
          f7 = motionPaths.time;
          if (f7 < f5) {
            easing1 = easing2;
            f6 = f3;
          } else {
            easing1 = easing;
            f6 = f3;
            f7 = f4;
            if (Float.isNaN(f3)) {
              f6 = motionPaths.time;
              f7 = f4;
              easing1 = easing;
            } 
          } 
        } 
        easing = easing1;
        f3 = f6;
      } 
      if (easing != null) {
        float f = f3;
        if (Float.isNaN(f3))
          f = 1.0F; 
        f3 = f - f4;
        d = ((float)easing.get(((f5 - f4) / f3)) * f3 + f4);
      } 
      this.mSpline[0].getPos(d, this.mInterpolateData);
      this.mStartMotionPath.getCenter(this.mInterpolateVariables, this.mInterpolateData, arrayOfFloat, 0);
      f3 = f2;
      if (i > 0)
        f3 = (float)(f2 + Math.hypot(d2 - arrayOfFloat[1], d1 - arrayOfFloat[0])); 
      d1 = arrayOfFloat[0];
      d2 = arrayOfFloat[1];
      i++;
    } 
    return f2;
  }
  
  private void insertKey(MotionPaths paramMotionPaths) {
    int i = Collections.binarySearch((List)this.mMotionPaths, paramMotionPaths);
    if (i == 0) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(" KeyPath positon \"");
      stringBuilder.append(paramMotionPaths.position);
      stringBuilder.append("\" outside of range");
      Log.e("MotionController", stringBuilder.toString());
    } 
    this.mMotionPaths.add(-i - 1, paramMotionPaths);
  }
  
  private void readView(MotionPaths paramMotionPaths) {
    paramMotionPaths.setBounds((int)this.mView.getX(), (int)this.mView.getY(), this.mView.getWidth(), this.mView.getHeight());
  }
  
  void addKey(Key paramKey) {
    this.mKeyList.add(paramKey);
  }
  
  void addKeys(ArrayList<Key> paramArrayList) {
    this.mKeyList.addAll(paramArrayList);
  }
  
  void buildBounds(float[] paramArrayOffloat, int paramInt) {
    float f = 1.0F / (paramInt - 1);
    HashMap<String, SplineSet> hashMap1 = this.mAttributesMap;
    if (hashMap1 != null)
      SplineSet splineSet = hashMap1.get("translationX"); 
    hashMap1 = this.mAttributesMap;
    if (hashMap1 != null)
      SplineSet splineSet = hashMap1.get("translationY"); 
    HashMap<String, KeyCycleOscillator> hashMap = this.mCycleMap;
    if (hashMap != null)
      KeyCycleOscillator keyCycleOscillator = hashMap.get("translationX"); 
    hashMap = this.mCycleMap;
    if (hashMap != null)
      KeyCycleOscillator keyCycleOscillator = hashMap.get("translationY"); 
    int i;
    for (i = 0; i < paramInt; i++) {
      float f3 = i * f;
      float f5 = this.mStaggerScale;
      float f4 = 0.0F;
      float f1 = f3;
      if (f5 != 1.0F) {
        float f7 = this.mStaggerOffset;
        float f6 = f3;
        if (f3 < f7)
          f6 = 0.0F; 
        f1 = f6;
        if (f6 > f7) {
          f1 = f6;
          if (f6 < 1.0D)
            f1 = (f6 - f7) * f5; 
        } 
      } 
      double d = f1;
      Easing easing = this.mStartMotionPath.mKeyFrameEasing;
      float f2 = Float.NaN;
      Iterator<MotionPaths> iterator = this.mMotionPaths.iterator();
      f3 = f4;
      while (iterator.hasNext()) {
        MotionPaths motionPaths = iterator.next();
        Easing easing1 = motionPaths.mKeyFrameEasing;
        if (easing1 != null) {
          f4 = motionPaths.time;
          if (f4 < f1) {
            easing = easing1;
            f3 = f4;
            continue;
          } 
          if (Float.isNaN(f2))
            f2 = motionPaths.time; 
        } 
      } 
      if (easing != null) {
        f4 = f2;
        if (Float.isNaN(f2))
          f4 = 1.0F; 
        f2 = f4 - f3;
        d = ((float)easing.get(((f1 - f3) / f2)) * f2 + f3);
      } 
      this.mSpline[0].getPos(d, this.mInterpolateData);
      CurveFit curveFit = this.mArcSpline;
      if (curveFit != null) {
        double[] arrayOfDouble = this.mInterpolateData;
        if (arrayOfDouble.length > 0)
          curveFit.getPos(d, arrayOfDouble); 
      } 
      this.mStartMotionPath.getBounds(this.mInterpolateVariables, this.mInterpolateData, paramArrayOffloat, i * 2);
    } 
  }
  
  int buildKeyBounds(float[] paramArrayOffloat, int[] paramArrayOfint) {
    if (paramArrayOffloat != null) {
      double[] arrayOfDouble = this.mSpline[0].getTimePoints();
      if (paramArrayOfint != null) {
        Iterator<MotionPaths> iterator = this.mMotionPaths.iterator();
        for (int k = 0; iterator.hasNext(); k++)
          paramArrayOfint[k] = ((MotionPaths)iterator.next()).mMode; 
      } 
      int i = 0;
      int j = 0;
      while (i < arrayOfDouble.length) {
        this.mSpline[0].getPos(arrayOfDouble[i], this.mInterpolateData);
        this.mStartMotionPath.getBounds(this.mInterpolateVariables, this.mInterpolateData, paramArrayOffloat, j);
        j += 2;
        i++;
      } 
      return j / 2;
    } 
    return 0;
  }
  
  int buildKeyFrames(float[] paramArrayOffloat, int[] paramArrayOfint) {
    if (paramArrayOffloat != null) {
      double[] arrayOfDouble = this.mSpline[0].getTimePoints();
      if (paramArrayOfint != null) {
        Iterator<MotionPaths> iterator = this.mMotionPaths.iterator();
        for (int k = 0; iterator.hasNext(); k++)
          paramArrayOfint[k] = ((MotionPaths)iterator.next()).mMode; 
      } 
      int i = 0;
      int j = 0;
      while (i < arrayOfDouble.length) {
        this.mSpline[0].getPos(arrayOfDouble[i], this.mInterpolateData);
        this.mStartMotionPath.getCenter(this.mInterpolateVariables, this.mInterpolateData, paramArrayOffloat, j);
        j += 2;
        i++;
      } 
      return j / 2;
    } 
    return 0;
  }
  
  void buildPath(float[] paramArrayOffloat, int paramInt) {
    SplineSet splineSet1;
    SplineSet splineSet2;
    KeyCycleOscillator keyCycleOscillator1;
    float f = 1.0F / (paramInt - 1);
    HashMap<String, SplineSet> hashMap1 = this.mAttributesMap;
    KeyCycleOscillator keyCycleOscillator2 = null;
    if (hashMap1 == null) {
      hashMap1 = null;
    } else {
      splineSet1 = hashMap1.get("translationX");
    } 
    HashMap<String, SplineSet> hashMap2 = this.mAttributesMap;
    if (hashMap2 == null) {
      hashMap2 = null;
    } else {
      splineSet2 = hashMap2.get("translationY");
    } 
    HashMap<String, KeyCycleOscillator> hashMap3 = this.mCycleMap;
    if (hashMap3 == null) {
      hashMap3 = null;
    } else {
      keyCycleOscillator1 = hashMap3.get("translationX");
    } 
    HashMap<String, KeyCycleOscillator> hashMap4 = this.mCycleMap;
    if (hashMap4 != null)
      keyCycleOscillator2 = hashMap4.get("translationY"); 
    int i;
    for (i = 0; i < paramInt; i++) {
      float f3 = i * f;
      float f4 = this.mStaggerScale;
      float f2 = f3;
      if (f4 != 1.0F) {
        float f6 = this.mStaggerOffset;
        float f5 = f3;
        if (f3 < f6)
          f5 = 0.0F; 
        f2 = f5;
        if (f5 > f6) {
          f2 = f5;
          if (f5 < 1.0D)
            f2 = (f5 - f6) * f4; 
        } 
      } 
      double d = f2;
      Easing easing = this.mStartMotionPath.mKeyFrameEasing;
      float f1 = Float.NaN;
      Iterator<MotionPaths> iterator = this.mMotionPaths.iterator();
      for (f3 = 0.0F; iterator.hasNext(); f3 = f5) {
        MotionPaths motionPaths1 = iterator.next();
        Easing easing2 = motionPaths1.mKeyFrameEasing;
        Easing easing1 = easing;
        f4 = f1;
        float f5 = f3;
        if (easing2 != null) {
          f5 = motionPaths1.time;
          if (f5 < f2) {
            easing1 = easing2;
            f4 = f1;
          } else {
            easing1 = easing;
            f4 = f1;
            f5 = f3;
            if (Float.isNaN(f1)) {
              f4 = motionPaths1.time;
              f5 = f3;
              easing1 = easing;
            } 
          } 
        } 
        easing = easing1;
        f1 = f4;
      } 
      if (easing != null) {
        f4 = f1;
        if (Float.isNaN(f1))
          f4 = 1.0F; 
        f1 = f4 - f3;
        d = ((float)easing.get(((f2 - f3) / f1)) * f1 + f3);
      } 
      this.mSpline[0].getPos(d, this.mInterpolateData);
      CurveFit curveFit = this.mArcSpline;
      if (curveFit != null) {
        double[] arrayOfDouble1 = this.mInterpolateData;
        if (arrayOfDouble1.length > 0)
          curveFit.getPos(d, arrayOfDouble1); 
      } 
      MotionPaths motionPaths = this.mStartMotionPath;
      int[] arrayOfInt = this.mInterpolateVariables;
      double[] arrayOfDouble = this.mInterpolateData;
      int j = i * 2;
      motionPaths.getCenter(arrayOfInt, arrayOfDouble, paramArrayOffloat, j);
      if (keyCycleOscillator1 != null) {
        paramArrayOffloat[j] = paramArrayOffloat[j] + keyCycleOscillator1.get(f2);
      } else if (splineSet1 != null) {
        paramArrayOffloat[j] = paramArrayOffloat[j] + splineSet1.get(f2);
      } 
      if (keyCycleOscillator2 != null) {
        paramArrayOffloat[++j] = paramArrayOffloat[j] + keyCycleOscillator2.get(f2);
      } else if (splineSet2 != null) {
        paramArrayOffloat[++j] = paramArrayOffloat[j] + splineSet2.get(f2);
      } 
    } 
  }
  
  void buildRect(float paramFloat, float[] paramArrayOffloat, int paramInt) {
    paramFloat = getAdjustedPosition(paramFloat, null);
    this.mSpline[0].getPos(paramFloat, this.mInterpolateData);
    this.mStartMotionPath.getRect(this.mInterpolateVariables, this.mInterpolateData, paramArrayOffloat, paramInt);
  }
  
  void buildRectangles(float[] paramArrayOffloat, int paramInt) {
    float f = 1.0F / (paramInt - 1);
    int i;
    for (i = 0; i < paramInt; i++) {
      float f1 = getAdjustedPosition(i * f, null);
      this.mSpline[0].getPos(f1, this.mInterpolateData);
      this.mStartMotionPath.getRect(this.mInterpolateVariables, this.mInterpolateData, paramArrayOffloat, i * 8);
    } 
  }
  
  int getAttributeValues(String paramString, float[] paramArrayOffloat, int paramInt) {
    SplineSet splineSet = this.mAttributesMap.get(paramString);
    if (splineSet == null)
      return -1; 
    for (paramInt = 0; paramInt < paramArrayOffloat.length; paramInt++)
      paramArrayOffloat[paramInt] = splineSet.get((paramInt / (paramArrayOffloat.length - 1))); 
    return paramArrayOffloat.length;
  }
  
  void getDpDt(float paramFloat1, float paramFloat2, float paramFloat3, float[] paramArrayOffloat) {
    paramFloat1 = getAdjustedPosition(paramFloat1, this.mVelocity);
    CurveFit[] arrayOfCurveFit = this.mSpline;
    int i = 0;
    if (arrayOfCurveFit != null) {
      CurveFit curveFit = arrayOfCurveFit[0];
      double d = paramFloat1;
      curveFit.getSlope(d, this.mInterpolateVelocity);
      this.mSpline[0].getPos(d, this.mInterpolateData);
      paramFloat1 = this.mVelocity[0];
      while (true) {
        double[] arrayOfDouble = this.mInterpolateVelocity;
        if (i < arrayOfDouble.length) {
          arrayOfDouble[i] = arrayOfDouble[i] * paramFloat1;
          i++;
          continue;
        } 
        curveFit = this.mArcSpline;
        if (curveFit != null) {
          arrayOfDouble = this.mInterpolateData;
          if (arrayOfDouble.length > 0) {
            curveFit.getPos(d, arrayOfDouble);
            this.mArcSpline.getSlope(d, this.mInterpolateVelocity);
            this.mStartMotionPath.setDpDt(paramFloat2, paramFloat3, paramArrayOffloat, this.mInterpolateVariables, this.mInterpolateVelocity, this.mInterpolateData);
          } 
          return;
        } 
        this.mStartMotionPath.setDpDt(paramFloat2, paramFloat3, paramArrayOffloat, this.mInterpolateVariables, arrayOfDouble, this.mInterpolateData);
        return;
      } 
    } 
    MotionPaths motionPaths1 = this.mEndMotionPath;
    paramFloat1 = motionPaths1.x;
    MotionPaths motionPaths2 = this.mStartMotionPath;
    paramFloat1 -= motionPaths2.x;
    float f1 = motionPaths1.y - motionPaths2.y;
    float f2 = motionPaths1.width;
    float f3 = motionPaths2.width;
    float f4 = motionPaths1.height;
    float f5 = motionPaths2.height;
    paramArrayOffloat[0] = paramFloat1 * (1.0F - paramFloat2) + (f2 - f3 + paramFloat1) * paramFloat2;
    paramArrayOffloat[1] = f1 * (1.0F - paramFloat3) + (f4 - f5 + f1) * paramFloat3;
  }
  
  public int getDrawPath() {
    int i = this.mStartMotionPath.mDrawPath;
    Iterator<MotionPaths> iterator = this.mMotionPaths.iterator();
    while (iterator.hasNext())
      i = Math.max(i, ((MotionPaths)iterator.next()).mDrawPath); 
    return Math.max(i, this.mEndMotionPath.mDrawPath);
  }
  
  float getFinalX() {
    return this.mEndMotionPath.x;
  }
  
  float getFinalY() {
    return this.mEndMotionPath.y;
  }
  
  MotionPaths getKeyFrame(int paramInt) {
    return this.mMotionPaths.get(paramInt);
  }
  
  public int getKeyFrameInfo(int paramInt, int[] paramArrayOfint) {
    float[] arrayOfFloat = new float[2];
    Iterator<Key> iterator = this.mKeyList.iterator();
    int i = 0;
    int j;
    for (j = 0; iterator.hasNext(); j = k) {
      Key key = iterator.next();
      int k = key.mType;
      if (k != paramInt && paramInt == -1)
        continue; 
      paramArrayOfint[j] = 0;
      int m = j + 1;
      paramArrayOfint[m] = k;
      k = m + 1;
      m = key.mFramePosition;
      paramArrayOfint[k] = m;
      float f = m / 100.0F;
      this.mSpline[0].getPos(f, this.mInterpolateData);
      this.mStartMotionPath.getCenter(this.mInterpolateVariables, this.mInterpolateData, arrayOfFloat, 0);
      paramArrayOfint[++k] = Float.floatToIntBits(arrayOfFloat[0]);
      m = k + 1;
      paramArrayOfint[m] = Float.floatToIntBits(arrayOfFloat[1]);
      k = m;
      if (key instanceof KeyPosition) {
        key = key;
        k = m + 1;
        paramArrayOfint[k] = ((KeyPosition)key).mPositionType;
        paramArrayOfint[++k] = Float.floatToIntBits(((KeyPosition)key).mPercentX);
        paramArrayOfint[++k] = Float.floatToIntBits(((KeyPosition)key).mPercentY);
      } 
      paramArrayOfint[j] = ++k - j;
      i++;
    } 
    return i;
  }
  
  float getKeyFrameParameter(int paramInt, float paramFloat1, float paramFloat2) {
    MotionPaths motionPaths1 = this.mEndMotionPath;
    float f1 = motionPaths1.x;
    MotionPaths motionPaths2 = this.mStartMotionPath;
    float f4 = motionPaths2.x;
    f1 -= f4;
    float f2 = motionPaths1.y;
    float f5 = motionPaths2.y;
    f2 -= f5;
    float f7 = motionPaths2.width / 2.0F;
    float f6 = motionPaths2.height / 2.0F;
    float f3 = (float)Math.hypot(f1, f2);
    if (f3 < 1.0E-7D)
      return Float.NaN; 
    paramFloat1 -= f4 + f7;
    paramFloat2 -= f5 + f6;
    if ((float)Math.hypot(paramFloat1, paramFloat2) == 0.0F)
      return 0.0F; 
    f4 = paramFloat1 * f1 + paramFloat2 * f2;
    return (paramInt != 0) ? ((paramInt != 1) ? ((paramInt != 2) ? ((paramInt != 3) ? ((paramInt != 4) ? ((paramInt != 5) ? 0.0F : (paramFloat2 / f2)) : (paramFloat1 / f2)) : (paramFloat2 / f1)) : (paramFloat1 / f1)) : (float)Math.sqrt((f3 * f3 - f4 * f4))) : (f4 / f3);
  }
  
  KeyPositionBase getPositionKeyframe(int paramInt1, int paramInt2, float paramFloat1, float paramFloat2) {
    RectF rectF1 = new RectF();
    MotionPaths motionPaths1 = this.mStartMotionPath;
    float f1 = motionPaths1.x;
    rectF1.left = f1;
    float f2 = motionPaths1.y;
    rectF1.top = f2;
    rectF1.right = f1 + motionPaths1.width;
    rectF1.bottom = f2 + motionPaths1.height;
    RectF rectF2 = new RectF();
    MotionPaths motionPaths2 = this.mEndMotionPath;
    f1 = motionPaths2.x;
    rectF2.left = f1;
    f2 = motionPaths2.y;
    rectF2.top = f2;
    rectF2.right = f1 + motionPaths2.width;
    rectF2.bottom = f2 + motionPaths2.height;
    for (Key key : this.mKeyList) {
      if (key instanceof KeyPositionBase) {
        key = key;
        if (key.intersects(paramInt1, paramInt2, rectF1, rectF2, paramFloat1, paramFloat2))
          return (KeyPositionBase)key; 
      } 
    } 
    return null;
  }
  
  void getPostLayoutDvDp(float paramFloat1, int paramInt1, int paramInt2, float paramFloat2, float paramFloat3, float[] paramArrayOffloat) {
    SplineSet splineSet1;
    double[] arrayOfDouble;
    SplineSet splineSet2;
    SplineSet splineSet3;
    SplineSet splineSet4;
    SplineSet splineSet5;
    KeyCycleOscillator keyCycleOscillator1;
    KeyCycleOscillator keyCycleOscillator2;
    KeyCycleOscillator keyCycleOscillator3;
    KeyCycleOscillator keyCycleOscillator4;
    paramFloat1 = getAdjustedPosition(paramFloat1, this.mVelocity);
    HashMap<String, SplineSet> hashMap1 = this.mAttributesMap;
    KeyCycleOscillator keyCycleOscillator5 = null;
    if (hashMap1 == null) {
      hashMap1 = null;
    } else {
      splineSet1 = hashMap1.get("translationX");
    } 
    HashMap<String, SplineSet> hashMap2 = this.mAttributesMap;
    if (hashMap2 == null) {
      hashMap2 = null;
    } else {
      splineSet2 = hashMap2.get("translationY");
    } 
    HashMap<String, SplineSet> hashMap3 = this.mAttributesMap;
    if (hashMap3 == null) {
      hashMap3 = null;
    } else {
      splineSet3 = hashMap3.get("rotation");
    } 
    HashMap<String, SplineSet> hashMap4 = this.mAttributesMap;
    if (hashMap4 == null) {
      hashMap4 = null;
    } else {
      splineSet4 = hashMap4.get("scaleX");
    } 
    HashMap<String, SplineSet> hashMap5 = this.mAttributesMap;
    if (hashMap5 == null) {
      hashMap5 = null;
    } else {
      splineSet5 = hashMap5.get("scaleY");
    } 
    HashMap<String, KeyCycleOscillator> hashMap6 = this.mCycleMap;
    if (hashMap6 == null) {
      hashMap6 = null;
    } else {
      keyCycleOscillator1 = hashMap6.get("translationX");
    } 
    HashMap<String, KeyCycleOscillator> hashMap7 = this.mCycleMap;
    if (hashMap7 == null) {
      hashMap7 = null;
    } else {
      keyCycleOscillator2 = hashMap7.get("translationY");
    } 
    HashMap<String, KeyCycleOscillator> hashMap8 = this.mCycleMap;
    if (hashMap8 == null) {
      hashMap8 = null;
    } else {
      keyCycleOscillator3 = hashMap8.get("rotation");
    } 
    HashMap<String, KeyCycleOscillator> hashMap9 = this.mCycleMap;
    if (hashMap9 == null) {
      hashMap9 = null;
    } else {
      keyCycleOscillator4 = hashMap9.get("scaleX");
    } 
    HashMap<String, KeyCycleOscillator> hashMap10 = this.mCycleMap;
    if (hashMap10 != null)
      keyCycleOscillator5 = hashMap10.get("scaleY"); 
    VelocityMatrix velocityMatrix = new VelocityMatrix();
    velocityMatrix.clear();
    velocityMatrix.setRotationVelocity(splineSet3, paramFloat1);
    velocityMatrix.setTranslationVelocity(splineSet1, splineSet2, paramFloat1);
    velocityMatrix.setScaleVelocity(splineSet4, splineSet5, paramFloat1);
    velocityMatrix.setRotationVelocity(keyCycleOscillator3, paramFloat1);
    velocityMatrix.setTranslationVelocity(keyCycleOscillator1, keyCycleOscillator2, paramFloat1);
    velocityMatrix.setScaleVelocity(keyCycleOscillator4, keyCycleOscillator5, paramFloat1);
    CurveFit curveFit = this.mArcSpline;
    if (curveFit != null) {
      arrayOfDouble = this.mInterpolateData;
      if (arrayOfDouble.length > 0) {
        double d = paramFloat1;
        curveFit.getPos(d, arrayOfDouble);
        this.mArcSpline.getSlope(d, this.mInterpolateVelocity);
        this.mStartMotionPath.setDpDt(paramFloat2, paramFloat3, paramArrayOffloat, this.mInterpolateVariables, this.mInterpolateVelocity, this.mInterpolateData);
      } 
      velocityMatrix.applyTransform(paramFloat2, paramFloat3, paramInt1, paramInt2, paramArrayOffloat);
      return;
    } 
    CurveFit[] arrayOfCurveFit = this.mSpline;
    int i = 0;
    if (arrayOfCurveFit != null) {
      paramFloat1 = getAdjustedPosition(paramFloat1, this.mVelocity);
      CurveFit curveFit1 = this.mSpline[0];
      double d = paramFloat1;
      curveFit1.getSlope(d, this.mInterpolateVelocity);
      this.mSpline[0].getPos(d, this.mInterpolateData);
      paramFloat1 = this.mVelocity[0];
      while (true) {
        arrayOfDouble = this.mInterpolateVelocity;
        if (i < arrayOfDouble.length) {
          arrayOfDouble[i] = arrayOfDouble[i] * paramFloat1;
          i++;
          continue;
        } 
        this.mStartMotionPath.setDpDt(paramFloat2, paramFloat3, paramArrayOffloat, this.mInterpolateVariables, arrayOfDouble, this.mInterpolateData);
        velocityMatrix.applyTransform(paramFloat2, paramFloat3, paramInt1, paramInt2, paramArrayOffloat);
        return;
      } 
    } 
    MotionPaths motionPaths1 = this.mEndMotionPath;
    float f1 = motionPaths1.x;
    MotionPaths motionPaths2 = this.mStartMotionPath;
    f1 -= motionPaths2.x;
    float f2 = motionPaths1.y - motionPaths2.y;
    float f3 = motionPaths1.width;
    float f4 = motionPaths2.width;
    float f5 = motionPaths1.height;
    float f6 = motionPaths2.height;
    paramArrayOffloat[0] = f1 * (1.0F - paramFloat2) + (f3 - f4 + f1) * paramFloat2;
    paramArrayOffloat[1] = f2 * (1.0F - paramFloat3) + (f5 - f6 + f2) * paramFloat3;
    velocityMatrix.clear();
    velocityMatrix.setRotationVelocity(splineSet3, paramFloat1);
    velocityMatrix.setTranslationVelocity((SplineSet)arrayOfDouble, splineSet2, paramFloat1);
    velocityMatrix.setScaleVelocity(splineSet4, splineSet5, paramFloat1);
    velocityMatrix.setRotationVelocity(keyCycleOscillator3, paramFloat1);
    velocityMatrix.setTranslationVelocity(keyCycleOscillator1, keyCycleOscillator2, paramFloat1);
    velocityMatrix.setScaleVelocity(keyCycleOscillator4, keyCycleOscillator5, paramFloat1);
    velocityMatrix.applyTransform(paramFloat2, paramFloat3, paramInt1, paramInt2, paramArrayOffloat);
  }
  
  float getStartX() {
    return this.mStartMotionPath.x;
  }
  
  float getStartY() {
    return this.mStartMotionPath.y;
  }
  
  public int getkeyFramePositions(int[] paramArrayOfint, float[] paramArrayOffloat) {
    Iterator<Key> iterator = this.mKeyList.iterator();
    int i = 0;
    int j = 0;
    while (iterator.hasNext()) {
      Key key = iterator.next();
      int k = key.mFramePosition;
      paramArrayOfint[i] = key.mType * 1000 + k;
      float f = k / 100.0F;
      this.mSpline[0].getPos(f, this.mInterpolateData);
      this.mStartMotionPath.getCenter(this.mInterpolateVariables, this.mInterpolateData, paramArrayOffloat, j);
      j += 2;
      i++;
    } 
    return i;
  }
  
  boolean interpolate(View paramView, float paramFloat, long paramLong, KeyCache paramKeyCache) {
    // Byte code:
    //   0: aload_0
    //   1: fload_2
    //   2: aconst_null
    //   3: invokespecial getAdjustedPosition : (F[F)F
    //   6: fstore_2
    //   7: aload_0
    //   8: getfield mAttributesMap : Ljava/util/HashMap;
    //   11: astore #22
    //   13: aload #22
    //   15: ifnull -> 58
    //   18: aload #22
    //   20: invokevirtual values : ()Ljava/util/Collection;
    //   23: invokeinterface iterator : ()Ljava/util/Iterator;
    //   28: astore #22
    //   30: aload #22
    //   32: invokeinterface hasNext : ()Z
    //   37: ifeq -> 58
    //   40: aload #22
    //   42: invokeinterface next : ()Ljava/lang/Object;
    //   47: checkcast androidx/constraintlayout/motion/widget/SplineSet
    //   50: aload_1
    //   51: fload_2
    //   52: invokevirtual setProperty : (Landroid/view/View;F)V
    //   55: goto -> 30
    //   58: aload_0
    //   59: getfield mTimeCycleAttributesMap : Ljava/util/HashMap;
    //   62: astore #22
    //   64: aload #22
    //   66: ifnull -> 148
    //   69: aload #22
    //   71: invokevirtual values : ()Ljava/util/Collection;
    //   74: invokeinterface iterator : ()Ljava/util/Iterator;
    //   79: astore #23
    //   81: aconst_null
    //   82: astore #22
    //   84: iconst_0
    //   85: istore #20
    //   87: aload #23
    //   89: invokeinterface hasNext : ()Z
    //   94: ifeq -> 145
    //   97: aload #23
    //   99: invokeinterface next : ()Ljava/lang/Object;
    //   104: checkcast androidx/constraintlayout/motion/widget/TimeCycleSplineSet
    //   107: astore #24
    //   109: aload #24
    //   111: instanceof androidx/constraintlayout/motion/widget/TimeCycleSplineSet$PathRotate
    //   114: ifeq -> 127
    //   117: aload #24
    //   119: checkcast androidx/constraintlayout/motion/widget/TimeCycleSplineSet$PathRotate
    //   122: astore #22
    //   124: goto -> 87
    //   127: iload #20
    //   129: aload #24
    //   131: aload_1
    //   132: fload_2
    //   133: lload_3
    //   134: aload #5
    //   136: invokevirtual setProperty : (Landroid/view/View;FJLandroidx/constraintlayout/motion/widget/KeyCache;)Z
    //   139: ior
    //   140: istore #20
    //   142: goto -> 87
    //   145: goto -> 154
    //   148: aconst_null
    //   149: astore #22
    //   151: iconst_0
    //   152: istore #20
    //   154: aload_0
    //   155: getfield mSpline : [Landroidx/constraintlayout/motion/utils/CurveFit;
    //   158: astore #23
    //   160: aload #23
    //   162: ifnull -> 581
    //   165: aload #23
    //   167: iconst_0
    //   168: aaload
    //   169: astore #23
    //   171: fload_2
    //   172: f2d
    //   173: dstore #6
    //   175: aload #23
    //   177: dload #6
    //   179: aload_0
    //   180: getfield mInterpolateData : [D
    //   183: invokevirtual getPos : (D[D)V
    //   186: aload_0
    //   187: getfield mSpline : [Landroidx/constraintlayout/motion/utils/CurveFit;
    //   190: iconst_0
    //   191: aaload
    //   192: dload #6
    //   194: aload_0
    //   195: getfield mInterpolateVelocity : [D
    //   198: invokevirtual getSlope : (D[D)V
    //   201: aload_0
    //   202: getfield mArcSpline : Landroidx/constraintlayout/motion/utils/CurveFit;
    //   205: astore #23
    //   207: aload #23
    //   209: ifnull -> 246
    //   212: aload_0
    //   213: getfield mInterpolateData : [D
    //   216: astore #24
    //   218: aload #24
    //   220: arraylength
    //   221: ifle -> 246
    //   224: aload #23
    //   226: dload #6
    //   228: aload #24
    //   230: invokevirtual getPos : (D[D)V
    //   233: aload_0
    //   234: getfield mArcSpline : Landroidx/constraintlayout/motion/utils/CurveFit;
    //   237: dload #6
    //   239: aload_0
    //   240: getfield mInterpolateVelocity : [D
    //   243: invokevirtual getSlope : (D[D)V
    //   246: aload_0
    //   247: getfield mStartMotionPath : Landroidx/constraintlayout/motion/widget/MotionPaths;
    //   250: aload_1
    //   251: aload_0
    //   252: getfield mInterpolateVariables : [I
    //   255: aload_0
    //   256: getfield mInterpolateData : [D
    //   259: aload_0
    //   260: getfield mInterpolateVelocity : [D
    //   263: aconst_null
    //   264: invokevirtual setView : (Landroid/view/View;[I[D[D[D)V
    //   267: aload_0
    //   268: getfield mAttributesMap : Ljava/util/HashMap;
    //   271: astore #23
    //   273: aload #23
    //   275: ifnull -> 351
    //   278: aload #23
    //   280: invokevirtual values : ()Ljava/util/Collection;
    //   283: invokeinterface iterator : ()Ljava/util/Iterator;
    //   288: astore #23
    //   290: aload #23
    //   292: invokeinterface hasNext : ()Z
    //   297: ifeq -> 351
    //   300: aload #23
    //   302: invokeinterface next : ()Ljava/lang/Object;
    //   307: checkcast androidx/constraintlayout/motion/widget/SplineSet
    //   310: astore #24
    //   312: aload #24
    //   314: instanceof androidx/constraintlayout/motion/widget/SplineSet$PathRotate
    //   317: ifeq -> 290
    //   320: aload #24
    //   322: checkcast androidx/constraintlayout/motion/widget/SplineSet$PathRotate
    //   325: astore #24
    //   327: aload_0
    //   328: getfield mInterpolateVelocity : [D
    //   331: astore #25
    //   333: aload #24
    //   335: aload_1
    //   336: fload_2
    //   337: aload #25
    //   339: iconst_0
    //   340: daload
    //   341: aload #25
    //   343: iconst_1
    //   344: daload
    //   345: invokevirtual setPathRotate : (Landroid/view/View;FDD)V
    //   348: goto -> 290
    //   351: aload #22
    //   353: ifnull -> 388
    //   356: aload_0
    //   357: getfield mInterpolateVelocity : [D
    //   360: astore #23
    //   362: aload #22
    //   364: aload_1
    //   365: aload #5
    //   367: fload_2
    //   368: lload_3
    //   369: aload #23
    //   371: iconst_0
    //   372: daload
    //   373: aload #23
    //   375: iconst_1
    //   376: daload
    //   377: invokevirtual setPathRotate : (Landroid/view/View;Landroidx/constraintlayout/motion/widget/KeyCache;FJDD)Z
    //   380: iload #20
    //   382: ior
    //   383: istore #20
    //   385: goto -> 388
    //   388: iconst_1
    //   389: istore #16
    //   391: aload_0
    //   392: getfield mSpline : [Landroidx/constraintlayout/motion/utils/CurveFit;
    //   395: astore #5
    //   397: iload #16
    //   399: aload #5
    //   401: arraylength
    //   402: if_icmpge -> 458
    //   405: aload #5
    //   407: iload #16
    //   409: aaload
    //   410: dload #6
    //   412: aload_0
    //   413: getfield mValuesBuff : [F
    //   416: invokevirtual getPos : (D[F)V
    //   419: aload_0
    //   420: getfield mStartMotionPath : Landroidx/constraintlayout/motion/widget/MotionPaths;
    //   423: getfield attributes : Ljava/util/LinkedHashMap;
    //   426: aload_0
    //   427: getfield mAttributeNames : [Ljava/lang/String;
    //   430: iload #16
    //   432: iconst_1
    //   433: isub
    //   434: aaload
    //   435: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   438: checkcast androidx/constraintlayout/widget/ConstraintAttribute
    //   441: aload_1
    //   442: aload_0
    //   443: getfield mValuesBuff : [F
    //   446: invokevirtual setInterpolatedValue : (Landroid/view/View;[F)V
    //   449: iload #16
    //   451: iconst_1
    //   452: iadd
    //   453: istore #16
    //   455: goto -> 391
    //   458: aload_0
    //   459: getfield mStartPoint : Landroidx/constraintlayout/motion/widget/MotionConstrainedPoint;
    //   462: astore #5
    //   464: aload #5
    //   466: getfield mVisibilityMode : I
    //   469: ifne -> 530
    //   472: fload_2
    //   473: fconst_0
    //   474: fcmpg
    //   475: ifgt -> 490
    //   478: aload_1
    //   479: aload #5
    //   481: getfield visibility : I
    //   484: invokevirtual setVisibility : (I)V
    //   487: goto -> 530
    //   490: fload_2
    //   491: fconst_1
    //   492: fcmpl
    //   493: iflt -> 510
    //   496: aload_1
    //   497: aload_0
    //   498: getfield mEndPoint : Landroidx/constraintlayout/motion/widget/MotionConstrainedPoint;
    //   501: getfield visibility : I
    //   504: invokevirtual setVisibility : (I)V
    //   507: goto -> 530
    //   510: aload_0
    //   511: getfield mEndPoint : Landroidx/constraintlayout/motion/widget/MotionConstrainedPoint;
    //   514: getfield visibility : I
    //   517: aload #5
    //   519: getfield visibility : I
    //   522: if_icmpeq -> 530
    //   525: aload_1
    //   526: iconst_0
    //   527: invokevirtual setVisibility : (I)V
    //   530: iload #20
    //   532: istore #21
    //   534: aload_0
    //   535: getfield mKeyTriggers : [Landroidx/constraintlayout/motion/widget/KeyTrigger;
    //   538: ifnull -> 781
    //   541: iconst_0
    //   542: istore #16
    //   544: aload_0
    //   545: getfield mKeyTriggers : [Landroidx/constraintlayout/motion/widget/KeyTrigger;
    //   548: astore #5
    //   550: iload #20
    //   552: istore #21
    //   554: iload #16
    //   556: aload #5
    //   558: arraylength
    //   559: if_icmpge -> 781
    //   562: aload #5
    //   564: iload #16
    //   566: aaload
    //   567: fload_2
    //   568: aload_1
    //   569: invokevirtual conditionallyFire : (FLandroid/view/View;)V
    //   572: iload #16
    //   574: iconst_1
    //   575: iadd
    //   576: istore #16
    //   578: goto -> 544
    //   581: aload_0
    //   582: getfield mStartMotionPath : Landroidx/constraintlayout/motion/widget/MotionPaths;
    //   585: astore #5
    //   587: aload #5
    //   589: getfield x : F
    //   592: fstore #14
    //   594: aload_0
    //   595: getfield mEndMotionPath : Landroidx/constraintlayout/motion/widget/MotionPaths;
    //   598: astore #22
    //   600: aload #22
    //   602: getfield x : F
    //   605: fstore #15
    //   607: aload #5
    //   609: getfield y : F
    //   612: fstore #12
    //   614: aload #22
    //   616: getfield y : F
    //   619: fstore #13
    //   621: aload #5
    //   623: getfield width : F
    //   626: fstore #8
    //   628: aload #22
    //   630: getfield width : F
    //   633: fstore #9
    //   635: aload #5
    //   637: getfield height : F
    //   640: fstore #10
    //   642: aload #22
    //   644: getfield height : F
    //   647: fstore #11
    //   649: fload #14
    //   651: fload #15
    //   653: fload #14
    //   655: fsub
    //   656: fload_2
    //   657: fmul
    //   658: fadd
    //   659: ldc_w 0.5
    //   662: fadd
    //   663: fstore #14
    //   665: fload #14
    //   667: f2i
    //   668: istore #16
    //   670: fload #12
    //   672: fload #13
    //   674: fload #12
    //   676: fsub
    //   677: fload_2
    //   678: fmul
    //   679: fadd
    //   680: ldc_w 0.5
    //   683: fadd
    //   684: fstore #12
    //   686: fload #12
    //   688: f2i
    //   689: istore #17
    //   691: fload #14
    //   693: fload #9
    //   695: fload #8
    //   697: fsub
    //   698: fload_2
    //   699: fmul
    //   700: fload #8
    //   702: fadd
    //   703: fadd
    //   704: f2i
    //   705: istore #18
    //   707: fload #12
    //   709: fload #11
    //   711: fload #10
    //   713: fsub
    //   714: fload_2
    //   715: fmul
    //   716: fload #10
    //   718: fadd
    //   719: fadd
    //   720: f2i
    //   721: istore #19
    //   723: fload #9
    //   725: fload #8
    //   727: fcmpl
    //   728: ifne -> 739
    //   731: fload #11
    //   733: fload #10
    //   735: fcmpl
    //   736: ifeq -> 765
    //   739: aload_1
    //   740: iload #18
    //   742: iload #16
    //   744: isub
    //   745: ldc_w 1073741824
    //   748: invokestatic makeMeasureSpec : (II)I
    //   751: iload #19
    //   753: iload #17
    //   755: isub
    //   756: ldc_w 1073741824
    //   759: invokestatic makeMeasureSpec : (II)I
    //   762: invokevirtual measure : (II)V
    //   765: aload_1
    //   766: iload #16
    //   768: iload #17
    //   770: iload #18
    //   772: iload #19
    //   774: invokevirtual layout : (IIII)V
    //   777: iload #20
    //   779: istore #21
    //   781: aload_0
    //   782: getfield mCycleMap : Ljava/util/HashMap;
    //   785: astore #5
    //   787: aload #5
    //   789: ifnull -> 875
    //   792: aload #5
    //   794: invokevirtual values : ()Ljava/util/Collection;
    //   797: invokeinterface iterator : ()Ljava/util/Iterator;
    //   802: astore #5
    //   804: aload #5
    //   806: invokeinterface hasNext : ()Z
    //   811: ifeq -> 875
    //   814: aload #5
    //   816: invokeinterface next : ()Ljava/lang/Object;
    //   821: checkcast androidx/constraintlayout/motion/widget/KeyCycleOscillator
    //   824: astore #22
    //   826: aload #22
    //   828: instanceof androidx/constraintlayout/motion/widget/KeyCycleOscillator$PathRotateSet
    //   831: ifeq -> 865
    //   834: aload #22
    //   836: checkcast androidx/constraintlayout/motion/widget/KeyCycleOscillator$PathRotateSet
    //   839: astore #22
    //   841: aload_0
    //   842: getfield mInterpolateVelocity : [D
    //   845: astore #23
    //   847: aload #22
    //   849: aload_1
    //   850: fload_2
    //   851: aload #23
    //   853: iconst_0
    //   854: daload
    //   855: aload #23
    //   857: iconst_1
    //   858: daload
    //   859: invokevirtual setPathRotate : (Landroid/view/View;FDD)V
    //   862: goto -> 804
    //   865: aload #22
    //   867: aload_1
    //   868: fload_2
    //   869: invokevirtual setProperty : (Landroid/view/View;F)V
    //   872: goto -> 804
    //   875: iload #21
    //   877: ireturn
  }
  
  String name() {
    return this.mView.getContext().getResources().getResourceEntryName(this.mView.getId());
  }
  
  void positionKeyframe(View paramView, KeyPositionBase paramKeyPositionBase, float paramFloat1, float paramFloat2, String[] paramArrayOfString, float[] paramArrayOffloat) {
    RectF rectF1 = new RectF();
    MotionPaths motionPaths1 = this.mStartMotionPath;
    float f1 = motionPaths1.x;
    rectF1.left = f1;
    float f2 = motionPaths1.y;
    rectF1.top = f2;
    rectF1.right = f1 + motionPaths1.width;
    rectF1.bottom = f2 + motionPaths1.height;
    RectF rectF2 = new RectF();
    MotionPaths motionPaths2 = this.mEndMotionPath;
    f1 = motionPaths2.x;
    rectF2.left = f1;
    f2 = motionPaths2.y;
    rectF2.top = f2;
    rectF2.right = f1 + motionPaths2.width;
    rectF2.bottom = f2 + motionPaths2.height;
    paramKeyPositionBase.positionAttributes(paramView, rectF1, rectF2, paramFloat1, paramFloat2, paramArrayOfString, paramArrayOffloat);
  }
  
  public void setDrawPath(int paramInt) {
    this.mStartMotionPath.mDrawPath = paramInt;
  }
  
  void setEndState(ConstraintWidget paramConstraintWidget, ConstraintSet paramConstraintSet) {
    MotionPaths motionPaths = this.mEndMotionPath;
    motionPaths.time = 1.0F;
    motionPaths.position = 1.0F;
    readView(motionPaths);
    this.mEndMotionPath.setBounds(paramConstraintWidget.getX(), paramConstraintWidget.getY(), paramConstraintWidget.getWidth(), paramConstraintWidget.getHeight());
    this.mEndMotionPath.applyParameters(paramConstraintSet.getParameters(this.mId));
    this.mEndPoint.setState(paramConstraintWidget, paramConstraintSet, this.mId);
  }
  
  public void setPathMotionArc(int paramInt) {
    this.mPathMotionArc = paramInt;
  }
  
  void setStartCurrentState(View paramView) {
    MotionPaths motionPaths = this.mStartMotionPath;
    motionPaths.time = 0.0F;
    motionPaths.position = 0.0F;
    motionPaths.setBounds(paramView.getX(), paramView.getY(), paramView.getWidth(), paramView.getHeight());
    this.mStartPoint.setState(paramView);
  }
  
  void setStartState(ConstraintWidget paramConstraintWidget, ConstraintSet paramConstraintSet) {
    MotionPaths motionPaths = this.mStartMotionPath;
    motionPaths.time = 0.0F;
    motionPaths.position = 0.0F;
    readView(motionPaths);
    this.mStartMotionPath.setBounds(paramConstraintWidget.getX(), paramConstraintWidget.getY(), paramConstraintWidget.getWidth(), paramConstraintWidget.getHeight());
    ConstraintSet.Constraint constraint = paramConstraintSet.getParameters(this.mId);
    this.mStartMotionPath.applyParameters(constraint);
    this.mMotionStagger = constraint.motion.mMotionStagger;
    this.mStartPoint.setState(paramConstraintWidget, paramConstraintSet, this.mId);
  }
  
  public void setView(View paramView) {
    this.mView = paramView;
    this.mId = paramView.getId();
    ViewGroup.LayoutParams layoutParams = paramView.getLayoutParams();
    if (layoutParams instanceof ConstraintLayout.LayoutParams)
      this.mConstraintTag = ((ConstraintLayout.LayoutParams)layoutParams).getConstraintTag(); 
  }
  
  public void setup(int paramInt1, int paramInt2, float paramFloat, long paramLong) {
    ArrayList arrayList1;
    new HashSet();
    HashSet<String> hashSet4 = new HashSet();
    HashSet<String> hashSet2 = new HashSet();
    HashSet<String> hashSet3 = new HashSet();
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
    int i = this.mPathMotionArc;
    if (i != Key.UNSET)
      this.mStartMotionPath.mPathMotionArc = i; 
    this.mStartPoint.different(this.mEndPoint, hashSet2);
    ArrayList<Key> arrayList = this.mKeyList;
    if (arrayList != null) {
      Iterator<Key> iterator1 = arrayList.iterator();
      arrayList = null;
      while (true) {
        arrayList1 = arrayList;
        if (iterator1.hasNext()) {
          Key key = iterator1.next();
          if (key instanceof KeyPosition) {
            KeyPosition keyPosition = (KeyPosition)key;
            insertKey(new MotionPaths(paramInt1, paramInt2, keyPosition, this.mStartMotionPath, this.mEndMotionPath));
            i = keyPosition.mCurveFit;
            if (i != Key.UNSET)
              this.mCurveFitType = i; 
            continue;
          } 
          if (key instanceof KeyCycle) {
            key.getAttributeNames(hashSet3);
            continue;
          } 
          if (key instanceof KeyTimeCycle) {
            key.getAttributeNames(hashSet4);
            continue;
          } 
          if (key instanceof KeyTrigger) {
            arrayList1 = arrayList;
            if (arrayList == null)
              arrayList1 = new ArrayList<Key>(); 
            arrayList1.add(key);
            arrayList = arrayList1;
            continue;
          } 
          key.setInterpolation((HashMap)hashMap);
          key.getAttributeNames(hashSet2);
          continue;
        } 
        break;
      } 
    } else {
      arrayList1 = null;
    } 
    if (arrayList1 != null)
      this.mKeyTriggers = (KeyTrigger[])arrayList1.toArray((Object[])new KeyTrigger[0]); 
    if (!hashSet2.isEmpty()) {
      this.mAttributesMap = new HashMap<String, SplineSet>();
      for (String str : hashSet2) {
        SplineSet splineSet;
        if (str.startsWith("CUSTOM,")) {
          SparseArray<ConstraintAttribute> sparseArray = new SparseArray();
          String str1 = str.split(",")[1];
          for (Key key : this.mKeyList) {
            HashMap<String, ConstraintAttribute> hashMap1 = key.mCustomConstraints;
            if (hashMap1 == null)
              continue; 
            ConstraintAttribute constraintAttribute = hashMap1.get(str1);
            if (constraintAttribute != null)
              sparseArray.append(key.mFramePosition, constraintAttribute); 
          } 
          splineSet = SplineSet.makeCustomSpline(str, sparseArray);
        } else {
          splineSet = SplineSet.makeSpline(str);
        } 
        if (splineSet == null)
          continue; 
        splineSet.setType(str);
        this.mAttributesMap.put(str, splineSet);
      } 
      arrayList = this.mKeyList;
      if (arrayList != null)
        for (Key key : arrayList) {
          if (key instanceof KeyAttributes)
            key.addValues(this.mAttributesMap); 
        }  
      this.mStartPoint.addValues(this.mAttributesMap, 0);
      this.mEndPoint.addValues(this.mAttributesMap, 100);
      for (String str : this.mAttributesMap.keySet()) {
        if (hashMap.containsKey(str)) {
          paramInt1 = ((Integer)hashMap.get(str)).intValue();
        } else {
          paramInt1 = 0;
        } 
        ((SplineSet)this.mAttributesMap.get(str)).setup(paramInt1);
      } 
    } 
    if (!hashSet4.isEmpty()) {
      if (this.mTimeCycleAttributesMap == null)
        this.mTimeCycleAttributesMap = new HashMap<String, TimeCycleSplineSet>(); 
      for (String str : hashSet4) {
        TimeCycleSplineSet timeCycleSplineSet;
        if (this.mTimeCycleAttributesMap.containsKey(str))
          continue; 
        if (str.startsWith("CUSTOM,")) {
          SparseArray<ConstraintAttribute> sparseArray = new SparseArray();
          String str1 = str.split(",")[1];
          for (Key key : this.mKeyList) {
            HashMap<String, ConstraintAttribute> hashMap1 = key.mCustomConstraints;
            if (hashMap1 == null)
              continue; 
            ConstraintAttribute constraintAttribute = hashMap1.get(str1);
            if (constraintAttribute != null)
              sparseArray.append(key.mFramePosition, constraintAttribute); 
          } 
          timeCycleSplineSet = TimeCycleSplineSet.makeCustomSpline(str, sparseArray);
        } else {
          timeCycleSplineSet = TimeCycleSplineSet.makeSpline(str, paramLong);
        } 
        if (timeCycleSplineSet == null)
          continue; 
        timeCycleSplineSet.setType(str);
        this.mTimeCycleAttributesMap.put(str, timeCycleSplineSet);
      } 
      arrayList = this.mKeyList;
      if (arrayList != null)
        for (Key key : arrayList) {
          if (key instanceof KeyTimeCycle)
            ((KeyTimeCycle)key).addTimeValues(this.mTimeCycleAttributesMap); 
        }  
      for (String str : this.mTimeCycleAttributesMap.keySet()) {
        if (hashMap.containsKey(str)) {
          paramInt1 = ((Integer)hashMap.get(str)).intValue();
        } else {
          paramInt1 = 0;
        } 
        ((TimeCycleSplineSet)this.mTimeCycleAttributesMap.get(str)).setup(paramInt1);
      } 
    } 
    int j = this.mMotionPaths.size() + 2;
    MotionPaths[] arrayOfMotionPaths = new MotionPaths[j];
    arrayOfMotionPaths[0] = this.mStartMotionPath;
    arrayOfMotionPaths[j - 1] = this.mEndMotionPath;
    if (this.mMotionPaths.size() > 0 && this.mCurveFitType == -1)
      this.mCurveFitType = 0; 
    Iterator<MotionPaths> iterator = this.mMotionPaths.iterator();
    for (paramInt1 = 1; iterator.hasNext(); paramInt1++)
      arrayOfMotionPaths[paramInt1] = iterator.next(); 
    HashSet<String> hashSet1 = new HashSet();
    for (String str : this.mEndMotionPath.attributes.keySet()) {
      if (this.mStartMotionPath.attributes.containsKey(str)) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("CUSTOM,");
        stringBuilder.append(str);
        if (!hashSet2.contains(stringBuilder.toString()))
          hashSet1.add(str); 
      } 
    } 
    String[] arrayOfString = hashSet1.<String>toArray(new String[0]);
    this.mAttributeNames = arrayOfString;
    this.mAttributeInterpCount = new int[arrayOfString.length];
    paramInt1 = 0;
    while (true) {
      boolean bool;
      String str;
      arrayOfString = this.mAttributeNames;
      if (paramInt1 < arrayOfString.length) {
        str = arrayOfString[paramInt1];
        this.mAttributeInterpCount[paramInt1] = 0;
        for (paramInt2 = 0; paramInt2 < j; paramInt2++) {
          if ((arrayOfMotionPaths[paramInt2]).attributes.containsKey(str)) {
            int[] arrayOfInt1 = this.mAttributeInterpCount;
            arrayOfInt1[paramInt1] = arrayOfInt1[paramInt1] + ((ConstraintAttribute)(arrayOfMotionPaths[paramInt2]).attributes.get(str)).noOfInterpValues();
            break;
          } 
        } 
        paramInt1++;
        continue;
      } 
      if ((arrayOfMotionPaths[0]).mPathMotionArc != Key.UNSET) {
        bool = true;
      } else {
        bool = false;
      } 
      int k = 18 + str.length;
      boolean[] arrayOfBoolean = new boolean[k];
      for (paramInt1 = 1; paramInt1 < j; paramInt1++)
        arrayOfMotionPaths[paramInt1].different(arrayOfMotionPaths[paramInt1 - 1], arrayOfBoolean, this.mAttributeNames, bool); 
      paramInt1 = 1;
      for (paramInt2 = 0; paramInt1 < k; paramInt2 = i) {
        i = paramInt2;
        if (arrayOfBoolean[paramInt1])
          i = paramInt2 + 1; 
        paramInt1++;
      } 
      int[] arrayOfInt = new int[paramInt2];
      this.mInterpolateVariables = arrayOfInt;
      this.mInterpolateData = new double[arrayOfInt.length];
      this.mInterpolateVelocity = new double[arrayOfInt.length];
      paramInt1 = 1;
      for (paramInt2 = 0; paramInt1 < k; paramInt2 = i) {
        i = paramInt2;
        if (arrayOfBoolean[paramInt1]) {
          this.mInterpolateVariables[paramInt2] = paramInt1;
          i = paramInt2 + 1;
        } 
        paramInt1++;
      } 
      double[][] arrayOfDouble = (double[][])Array.newInstance(double.class, new int[] { j, this.mInterpolateVariables.length });
      double[] arrayOfDouble1 = new double[j];
      for (paramInt1 = 0; paramInt1 < j; paramInt1++) {
        arrayOfMotionPaths[paramInt1].fillStandard(arrayOfDouble[paramInt1], this.mInterpolateVariables);
        arrayOfDouble1[paramInt1] = (arrayOfMotionPaths[paramInt1]).time;
      } 
      paramInt1 = 0;
      while (true) {
        int[] arrayOfInt1 = this.mInterpolateVariables;
        if (paramInt1 < arrayOfInt1.length) {
          if (arrayOfInt1[paramInt1] < MotionPaths.names.length) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(MotionPaths.names[this.mInterpolateVariables[paramInt1]]);
            stringBuilder.append(" [");
            String str1 = stringBuilder.toString();
            for (paramInt2 = 0; paramInt2 < j; paramInt2++) {
              StringBuilder stringBuilder1 = new StringBuilder();
              stringBuilder1.append(str1);
              stringBuilder1.append(arrayOfDouble[paramInt2][paramInt1]);
              str1 = stringBuilder1.toString();
            } 
          } 
          paramInt1++;
          continue;
        } 
        this.mSpline = new CurveFit[this.mAttributeNames.length + 1];
        paramInt1 = 0;
        while (true) {
          String[] arrayOfString1 = this.mAttributeNames;
          if (paramInt1 < arrayOfString1.length) {
            String str1 = arrayOfString1[paramInt1];
            paramInt2 = 0;
            arrayOfInt = null;
            i = 0;
            arrayOfString1 = null;
            while (paramInt2 < j) {
              double[][] arrayOfDouble4;
              double[] arrayOfDouble5;
              int[] arrayOfInt2 = arrayOfInt;
              k = i;
              String[] arrayOfString2 = arrayOfString1;
              if (arrayOfMotionPaths[paramInt2].hasCustomData(str1)) {
                double[] arrayOfDouble6;
                arrayOfString2 = arrayOfString1;
                if (arrayOfString1 == null) {
                  arrayOfDouble6 = new double[j];
                  arrayOfDouble4 = (double[][])Array.newInstance(double.class, new int[] { j, arrayOfMotionPaths[paramInt2].getCustomDataCount(str1) });
                } 
                arrayOfDouble6[i] = (arrayOfMotionPaths[paramInt2]).time;
                arrayOfMotionPaths[paramInt2].getCustomData(str1, arrayOfDouble4[i], 0);
                k = i + 1;
                arrayOfDouble5 = arrayOfDouble6;
              } 
              paramInt2++;
              arrayOfDouble3 = arrayOfDouble5;
              i = k;
              arrayOfDouble2 = arrayOfDouble4;
            } 
            double[] arrayOfDouble3 = Arrays.copyOf(arrayOfDouble3, i);
            double[][] arrayOfDouble2 = Arrays.<double[]>copyOf(arrayOfDouble2, i);
            CurveFit[] arrayOfCurveFit = this.mSpline;
            arrayOfCurveFit[++paramInt1] = CurveFit.get(this.mCurveFitType, arrayOfDouble3, arrayOfDouble2);
            continue;
          } 
          this.mSpline[0] = CurveFit.get(this.mCurveFitType, arrayOfDouble1, arrayOfDouble);
          if ((arrayOfMotionPaths[0]).mPathMotionArc != Key.UNSET) {
            int[] arrayOfInt2 = new int[j];
            double[] arrayOfDouble2 = new double[j];
            double[][] arrayOfDouble3 = (double[][])Array.newInstance(double.class, new int[] { j, 2 });
            for (paramInt1 = 0; paramInt1 < j; paramInt1++) {
              arrayOfInt2[paramInt1] = (arrayOfMotionPaths[paramInt1]).mPathMotionArc;
              arrayOfDouble2[paramInt1] = (arrayOfMotionPaths[paramInt1]).time;
              arrayOfDouble3[paramInt1][0] = (arrayOfMotionPaths[paramInt1]).x;
              arrayOfDouble3[paramInt1][1] = (arrayOfMotionPaths[paramInt1]).y;
            } 
            this.mArcSpline = CurveFit.getArc(arrayOfInt2, arrayOfDouble2, arrayOfDouble3);
          } 
          paramFloat = Float.NaN;
          this.mCycleMap = new HashMap<String, KeyCycleOscillator>();
          if (this.mKeyList != null) {
            for (String str1 : hashSet3) {
              KeyCycleOscillator keyCycleOscillator = KeyCycleOscillator.makeSpline(str1);
              if (keyCycleOscillator == null)
                continue; 
              float f = paramFloat;
              if (keyCycleOscillator.variesByPath()) {
                f = paramFloat;
                if (Float.isNaN(paramFloat))
                  f = getPreCycleDistance(); 
              } 
              keyCycleOscillator.setType(str1);
              this.mCycleMap.put(str1, keyCycleOscillator);
              paramFloat = f;
            } 
            for (Key key : this.mKeyList) {
              if (key instanceof KeyCycle)
                ((KeyCycle)key).addCycleValues(this.mCycleMap); 
            } 
            Iterator<KeyCycleOscillator> iterator1 = this.mCycleMap.values().iterator();
            while (iterator1.hasNext())
              ((KeyCycleOscillator)iterator1.next()).setup(paramFloat); 
          } 
          return;
        } 
        break;
      } 
      break;
    } 
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(" start: x: ");
    stringBuilder.append(this.mStartMotionPath.x);
    stringBuilder.append(" y: ");
    stringBuilder.append(this.mStartMotionPath.y);
    stringBuilder.append(" end: x: ");
    stringBuilder.append(this.mEndMotionPath.x);
    stringBuilder.append(" y: ");
    stringBuilder.append(this.mEndMotionPath.y);
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\BabyBus TV_Kids Videos & Games-dex2jar.jar!\androidx\constraintlayout\motion\widget\MotionController.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */