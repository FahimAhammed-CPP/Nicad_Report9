package androidx.appcompat.widget;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.AttributeSet;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RestrictTo;
import androidx.appcompat.R;
import androidx.core.content.res.ResourcesCompat;
import androidx.core.view.ViewCompat;
import androidx.core.view.inputmethod.EditorInfoCompat;
import androidx.core.widget.AutoSizeableTextView;
import java.lang.ref.WeakReference;

class AppCompatTextHelper {
  private static final int MONOSPACE = 3;
  
  private static final int SANS = 1;
  
  private static final int SERIF = 2;
  
  private static final int TEXT_FONT_WEIGHT_UNSPECIFIED = -1;
  
  private boolean mAsyncFontPending;
  
  @NonNull
  private final AppCompatTextViewAutoSizeHelper mAutoSizeTextHelper;
  
  private TintInfo mDrawableBottomTint;
  
  private TintInfo mDrawableEndTint;
  
  private TintInfo mDrawableLeftTint;
  
  private TintInfo mDrawableRightTint;
  
  private TintInfo mDrawableStartTint;
  
  private TintInfo mDrawableTint;
  
  private TintInfo mDrawableTopTint;
  
  private Typeface mFontTypeface;
  
  private int mFontWeight = -1;
  
  private int mStyle = 0;
  
  @NonNull
  private final TextView mView;
  
  AppCompatTextHelper(@NonNull TextView paramTextView) {
    this.mView = paramTextView;
    this.mAutoSizeTextHelper = new AppCompatTextViewAutoSizeHelper(paramTextView);
  }
  
  private void applyCompoundDrawableTint(Drawable paramDrawable, TintInfo paramTintInfo) {
    if (paramDrawable != null && paramTintInfo != null)
      AppCompatDrawableManager.tintDrawable(paramDrawable, paramTintInfo, this.mView.getDrawableState()); 
  }
  
  private static TintInfo createTintInfo(Context paramContext, AppCompatDrawableManager paramAppCompatDrawableManager, int paramInt) {
    ColorStateList colorStateList = paramAppCompatDrawableManager.getTintList(paramContext, paramInt);
    if (colorStateList != null) {
      TintInfo tintInfo = new TintInfo();
      tintInfo.mHasTintList = true;
      tintInfo.mTintList = colorStateList;
      return tintInfo;
    } 
    return null;
  }
  
  private void setCompoundDrawables(Drawable paramDrawable1, Drawable paramDrawable2, Drawable paramDrawable3, Drawable paramDrawable4, Drawable paramDrawable5, Drawable paramDrawable6) {
    TextView textView;
    Drawable[] arrayOfDrawable;
    if (paramDrawable5 != null || paramDrawable6 != null) {
      arrayOfDrawable = this.mView.getCompoundDrawablesRelative();
      textView = this.mView;
      if (paramDrawable5 == null)
        paramDrawable5 = arrayOfDrawable[0]; 
      if (paramDrawable2 == null)
        paramDrawable2 = arrayOfDrawable[1]; 
      if (paramDrawable6 == null)
        paramDrawable6 = arrayOfDrawable[2]; 
      if (paramDrawable4 == null)
        paramDrawable4 = arrayOfDrawable[3]; 
      textView.setCompoundDrawablesRelativeWithIntrinsicBounds(paramDrawable5, paramDrawable2, paramDrawable6, paramDrawable4);
      return;
    } 
    if (textView != null || paramDrawable2 != null || arrayOfDrawable != null || paramDrawable4 != null) {
      Drawable drawable1;
      Drawable drawable2;
      Drawable[] arrayOfDrawable1 = this.mView.getCompoundDrawablesRelative();
      if (arrayOfDrawable1[0] != null || arrayOfDrawable1[2] != null) {
        textView = this.mView;
        drawable2 = arrayOfDrawable1[0];
        if (paramDrawable2 == null)
          paramDrawable2 = arrayOfDrawable1[1]; 
        paramDrawable6 = arrayOfDrawable1[2];
        if (paramDrawable4 == null)
          paramDrawable4 = arrayOfDrawable1[3]; 
        textView.setCompoundDrawablesRelativeWithIntrinsicBounds(drawable2, paramDrawable2, paramDrawable6, paramDrawable4);
        return;
      } 
      Drawable[] arrayOfDrawable2 = this.mView.getCompoundDrawables();
      TextView textView1 = this.mView;
      if (textView == null)
        drawable1 = arrayOfDrawable2[0]; 
      if (paramDrawable2 == null)
        paramDrawable2 = arrayOfDrawable2[1]; 
      if (drawable2 == null)
        drawable2 = arrayOfDrawable2[2]; 
      if (paramDrawable4 == null)
        paramDrawable4 = arrayOfDrawable2[3]; 
      textView1.setCompoundDrawablesWithIntrinsicBounds(drawable1, paramDrawable2, drawable2, paramDrawable4);
      return;
    } 
  }
  
  private void setCompoundTints() {
    TintInfo tintInfo = this.mDrawableTint;
    this.mDrawableLeftTint = tintInfo;
    this.mDrawableTopTint = tintInfo;
    this.mDrawableRightTint = tintInfo;
    this.mDrawableBottomTint = tintInfo;
    this.mDrawableStartTint = tintInfo;
    this.mDrawableEndTint = tintInfo;
  }
  
  private void setTextSizeInternal(int paramInt, float paramFloat) {
    this.mAutoSizeTextHelper.setTextSizeInternal(paramInt, paramFloat);
  }
  
  private void updateTypefaceAndStyle(Context paramContext, TintTypedArray paramTintTypedArray) {
    this.mStyle = paramTintTypedArray.getInt(R.styleable.TextAppearance_android_textStyle, this.mStyle);
    int j = Build.VERSION.SDK_INT;
    boolean bool = false;
    if (j >= 28) {
      final int fontWeight = paramTintTypedArray.getInt(R.styleable.TextAppearance_android_textFontWeight, -1);
      this.mFontWeight = k;
      if (k != -1)
        this.mStyle = this.mStyle & 0x2 | 0x0; 
    } 
    int i = R.styleable.TextAppearance_android_fontFamily;
    if (paramTintTypedArray.hasValue(i) || paramTintTypedArray.hasValue(R.styleable.TextAppearance_fontFamily)) {
      this.mFontTypeface = null;
      final int fontWeight = R.styleable.TextAppearance_fontFamily;
      if (paramTintTypedArray.hasValue(k))
        i = k; 
      k = this.mFontWeight;
      final int style = this.mStyle;
      if (!paramContext.isRestricted()) {
        ResourcesCompat.FontCallback fontCallback = new ResourcesCompat.FontCallback() {
            public void onFontRetrievalFailed(int param1Int) {}
            
            public void onFontRetrieved(@NonNull Typeface param1Typeface) {
              Typeface typeface = param1Typeface;
              if (Build.VERSION.SDK_INT >= 28) {
                int i = fontWeight;
                typeface = param1Typeface;
                if (i != -1) {
                  boolean bool;
                  if ((style & 0x2) != 0) {
                    bool = true;
                  } else {
                    bool = false;
                  } 
                  typeface = Typeface.create(param1Typeface, i, bool);
                } 
              } 
              AppCompatTextHelper.this.onAsyncTypefaceReceived(textViewWeak, typeface);
            }
          };
        try {
          boolean bool1;
          Typeface typeface = paramTintTypedArray.getFont(i, this.mStyle, fontCallback);
          if (typeface != null)
            if (j >= 28 && this.mFontWeight != -1) {
              typeface = Typeface.create(typeface, 0);
              k = this.mFontWeight;
              if ((this.mStyle & 0x2) != 0) {
                bool1 = true;
              } else {
                bool1 = false;
              } 
              this.mFontTypeface = Typeface.create(typeface, k, bool1);
            } else {
              this.mFontTypeface = typeface;
            }  
          if (this.mFontTypeface == null) {
            bool1 = true;
          } else {
            bool1 = false;
          } 
          this.mAsyncFontPending = bool1;
        } catch (UnsupportedOperationException|android.content.res.Resources.NotFoundException unsupportedOperationException) {}
      } 
      if (this.mFontTypeface == null) {
        String str = paramTintTypedArray.getString(i);
        if (str != null) {
          Typeface typeface;
          if (Build.VERSION.SDK_INT >= 28 && this.mFontWeight != -1) {
            typeface = Typeface.create(str, 0);
            i = this.mFontWeight;
            boolean bool1 = bool;
            if ((this.mStyle & 0x2) != 0)
              bool1 = true; 
            this.mFontTypeface = Typeface.create(typeface, i, bool1);
            return;
          } 
          this.mFontTypeface = Typeface.create((String)typeface, this.mStyle);
        } 
      } 
      return;
    } 
    i = R.styleable.TextAppearance_android_typeface;
    if (paramTintTypedArray.hasValue(i)) {
      this.mAsyncFontPending = false;
      i = paramTintTypedArray.getInt(i, 1);
      if (i != 1) {
        if (i != 2) {
          if (i != 3)
            return; 
          this.mFontTypeface = Typeface.MONOSPACE;
          return;
        } 
        this.mFontTypeface = Typeface.SERIF;
        return;
      } 
      this.mFontTypeface = Typeface.SANS_SERIF;
    } 
  }
  
  void applyCompoundDrawablesTints() {
    if (this.mDrawableLeftTint != null || this.mDrawableTopTint != null || this.mDrawableRightTint != null || this.mDrawableBottomTint != null) {
      Drawable[] arrayOfDrawable = this.mView.getCompoundDrawables();
      applyCompoundDrawableTint(arrayOfDrawable[0], this.mDrawableLeftTint);
      applyCompoundDrawableTint(arrayOfDrawable[1], this.mDrawableTopTint);
      applyCompoundDrawableTint(arrayOfDrawable[2], this.mDrawableRightTint);
      applyCompoundDrawableTint(arrayOfDrawable[3], this.mDrawableBottomTint);
    } 
    if (this.mDrawableStartTint != null || this.mDrawableEndTint != null) {
      Drawable[] arrayOfDrawable = this.mView.getCompoundDrawablesRelative();
      applyCompoundDrawableTint(arrayOfDrawable[0], this.mDrawableStartTint);
      applyCompoundDrawableTint(arrayOfDrawable[2], this.mDrawableEndTint);
    } 
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP_PREFIX})
  void autoSizeText() {
    this.mAutoSizeTextHelper.autoSizeText();
  }
  
  int getAutoSizeMaxTextSize() {
    return this.mAutoSizeTextHelper.getAutoSizeMaxTextSize();
  }
  
  int getAutoSizeMinTextSize() {
    return this.mAutoSizeTextHelper.getAutoSizeMinTextSize();
  }
  
  int getAutoSizeStepGranularity() {
    return this.mAutoSizeTextHelper.getAutoSizeStepGranularity();
  }
  
  int[] getAutoSizeTextAvailableSizes() {
    return this.mAutoSizeTextHelper.getAutoSizeTextAvailableSizes();
  }
  
  int getAutoSizeTextType() {
    return this.mAutoSizeTextHelper.getAutoSizeTextType();
  }
  
  @Nullable
  ColorStateList getCompoundDrawableTintList() {
    TintInfo tintInfo = this.mDrawableTint;
    return (tintInfo != null) ? tintInfo.mTintList : null;
  }
  
  @Nullable
  PorterDuff.Mode getCompoundDrawableTintMode() {
    TintInfo tintInfo = this.mDrawableTint;
    return (tintInfo != null) ? tintInfo.mTintMode : null;
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP_PREFIX})
  boolean isAutoSizeEnabled() {
    return this.mAutoSizeTextHelper.isAutoSizeEnabled();
  }
  
  @SuppressLint({"NewApi"})
  void loadFromAttributes(@Nullable AttributeSet paramAttributeSet, int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: getfield mView : Landroid/widget/TextView;
    //   4: invokevirtual getContext : ()Landroid/content/Context;
    //   7: astore #17
    //   9: invokestatic get : ()Landroidx/appcompat/widget/AppCompatDrawableManager;
    //   12: astore #16
    //   14: getstatic androidx/appcompat/R$styleable.AppCompatTextHelper : [I
    //   17: astore #8
    //   19: aload #17
    //   21: aload_1
    //   22: aload #8
    //   24: iload_2
    //   25: iconst_0
    //   26: invokestatic obtainStyledAttributes : (Landroid/content/Context;Landroid/util/AttributeSet;[III)Landroidx/appcompat/widget/TintTypedArray;
    //   29: astore #9
    //   31: aload_0
    //   32: getfield mView : Landroid/widget/TextView;
    //   35: astore #10
    //   37: aload #10
    //   39: aload #10
    //   41: invokevirtual getContext : ()Landroid/content/Context;
    //   44: aload #8
    //   46: aload_1
    //   47: aload #9
    //   49: invokevirtual getWrappedTypeArray : ()Landroid/content/res/TypedArray;
    //   52: iload_2
    //   53: iconst_0
    //   54: invokestatic saveAttributeDataForStyleable : (Landroid/view/View;Landroid/content/Context;[ILandroid/util/AttributeSet;Landroid/content/res/TypedArray;II)V
    //   57: aload #9
    //   59: getstatic androidx/appcompat/R$styleable.AppCompatTextHelper_android_textAppearance : I
    //   62: iconst_m1
    //   63: invokevirtual getResourceId : (II)I
    //   66: istore_3
    //   67: getstatic androidx/appcompat/R$styleable.AppCompatTextHelper_android_drawableLeft : I
    //   70: istore #4
    //   72: aload #9
    //   74: iload #4
    //   76: invokevirtual hasValue : (I)Z
    //   79: ifeq -> 101
    //   82: aload_0
    //   83: aload #17
    //   85: aload #16
    //   87: aload #9
    //   89: iload #4
    //   91: iconst_0
    //   92: invokevirtual getResourceId : (II)I
    //   95: invokestatic createTintInfo : (Landroid/content/Context;Landroidx/appcompat/widget/AppCompatDrawableManager;I)Landroidx/appcompat/widget/TintInfo;
    //   98: putfield mDrawableLeftTint : Landroidx/appcompat/widget/TintInfo;
    //   101: getstatic androidx/appcompat/R$styleable.AppCompatTextHelper_android_drawableTop : I
    //   104: istore #4
    //   106: aload #9
    //   108: iload #4
    //   110: invokevirtual hasValue : (I)Z
    //   113: ifeq -> 135
    //   116: aload_0
    //   117: aload #17
    //   119: aload #16
    //   121: aload #9
    //   123: iload #4
    //   125: iconst_0
    //   126: invokevirtual getResourceId : (II)I
    //   129: invokestatic createTintInfo : (Landroid/content/Context;Landroidx/appcompat/widget/AppCompatDrawableManager;I)Landroidx/appcompat/widget/TintInfo;
    //   132: putfield mDrawableTopTint : Landroidx/appcompat/widget/TintInfo;
    //   135: getstatic androidx/appcompat/R$styleable.AppCompatTextHelper_android_drawableRight : I
    //   138: istore #4
    //   140: aload #9
    //   142: iload #4
    //   144: invokevirtual hasValue : (I)Z
    //   147: ifeq -> 169
    //   150: aload_0
    //   151: aload #17
    //   153: aload #16
    //   155: aload #9
    //   157: iload #4
    //   159: iconst_0
    //   160: invokevirtual getResourceId : (II)I
    //   163: invokestatic createTintInfo : (Landroid/content/Context;Landroidx/appcompat/widget/AppCompatDrawableManager;I)Landroidx/appcompat/widget/TintInfo;
    //   166: putfield mDrawableRightTint : Landroidx/appcompat/widget/TintInfo;
    //   169: getstatic androidx/appcompat/R$styleable.AppCompatTextHelper_android_drawableBottom : I
    //   172: istore #4
    //   174: aload #9
    //   176: iload #4
    //   178: invokevirtual hasValue : (I)Z
    //   181: ifeq -> 203
    //   184: aload_0
    //   185: aload #17
    //   187: aload #16
    //   189: aload #9
    //   191: iload #4
    //   193: iconst_0
    //   194: invokevirtual getResourceId : (II)I
    //   197: invokestatic createTintInfo : (Landroid/content/Context;Landroidx/appcompat/widget/AppCompatDrawableManager;I)Landroidx/appcompat/widget/TintInfo;
    //   200: putfield mDrawableBottomTint : Landroidx/appcompat/widget/TintInfo;
    //   203: getstatic android/os/Build$VERSION.SDK_INT : I
    //   206: istore #4
    //   208: getstatic androidx/appcompat/R$styleable.AppCompatTextHelper_android_drawableStart : I
    //   211: istore #5
    //   213: aload #9
    //   215: iload #5
    //   217: invokevirtual hasValue : (I)Z
    //   220: ifeq -> 242
    //   223: aload_0
    //   224: aload #17
    //   226: aload #16
    //   228: aload #9
    //   230: iload #5
    //   232: iconst_0
    //   233: invokevirtual getResourceId : (II)I
    //   236: invokestatic createTintInfo : (Landroid/content/Context;Landroidx/appcompat/widget/AppCompatDrawableManager;I)Landroidx/appcompat/widget/TintInfo;
    //   239: putfield mDrawableStartTint : Landroidx/appcompat/widget/TintInfo;
    //   242: getstatic androidx/appcompat/R$styleable.AppCompatTextHelper_android_drawableEnd : I
    //   245: istore #5
    //   247: aload #9
    //   249: iload #5
    //   251: invokevirtual hasValue : (I)Z
    //   254: ifeq -> 276
    //   257: aload_0
    //   258: aload #17
    //   260: aload #16
    //   262: aload #9
    //   264: iload #5
    //   266: iconst_0
    //   267: invokevirtual getResourceId : (II)I
    //   270: invokestatic createTintInfo : (Landroid/content/Context;Landroidx/appcompat/widget/AppCompatDrawableManager;I)Landroidx/appcompat/widget/TintInfo;
    //   273: putfield mDrawableEndTint : Landroidx/appcompat/widget/TintInfo;
    //   276: aload #9
    //   278: invokevirtual recycle : ()V
    //   281: aload_0
    //   282: getfield mView : Landroid/widget/TextView;
    //   285: invokevirtual getTransformationMethod : ()Landroid/text/method/TransformationMethod;
    //   288: instanceof android/text/method/PasswordTransformationMethod
    //   291: istore #7
    //   293: iload_3
    //   294: iconst_m1
    //   295: if_icmpeq -> 560
    //   298: aload #17
    //   300: iload_3
    //   301: getstatic androidx/appcompat/R$styleable.TextAppearance : [I
    //   304: invokestatic obtainStyledAttributes : (Landroid/content/Context;I[I)Landroidx/appcompat/widget/TintTypedArray;
    //   307: astore #14
    //   309: iload #7
    //   311: ifne -> 341
    //   314: getstatic androidx/appcompat/R$styleable.TextAppearance_textAllCaps : I
    //   317: istore_3
    //   318: aload #14
    //   320: iload_3
    //   321: invokevirtual hasValue : (I)Z
    //   324: ifeq -> 341
    //   327: aload #14
    //   329: iload_3
    //   330: iconst_0
    //   331: invokevirtual getBoolean : (IZ)Z
    //   334: istore #6
    //   336: iconst_1
    //   337: istore_3
    //   338: goto -> 346
    //   341: iconst_0
    //   342: istore #6
    //   344: iconst_0
    //   345: istore_3
    //   346: aload_0
    //   347: aload #17
    //   349: aload #14
    //   351: invokespecial updateTypefaceAndStyle : (Landroid/content/Context;Landroidx/appcompat/widget/TintTypedArray;)V
    //   354: iload #4
    //   356: bipush #23
    //   358: if_icmpge -> 464
    //   361: getstatic androidx/appcompat/R$styleable.TextAppearance_android_textColor : I
    //   364: istore #5
    //   366: aload #14
    //   368: iload #5
    //   370: invokevirtual hasValue : (I)Z
    //   373: ifeq -> 388
    //   376: aload #14
    //   378: iload #5
    //   380: invokevirtual getColorStateList : (I)Landroid/content/res/ColorStateList;
    //   383: astore #8
    //   385: goto -> 391
    //   388: aconst_null
    //   389: astore #8
    //   391: getstatic androidx/appcompat/R$styleable.TextAppearance_android_textColorHint : I
    //   394: istore #5
    //   396: aload #14
    //   398: iload #5
    //   400: invokevirtual hasValue : (I)Z
    //   403: ifeq -> 418
    //   406: aload #14
    //   408: iload #5
    //   410: invokevirtual getColorStateList : (I)Landroid/content/res/ColorStateList;
    //   413: astore #9
    //   415: goto -> 421
    //   418: aconst_null
    //   419: astore #9
    //   421: getstatic androidx/appcompat/R$styleable.TextAppearance_android_textColorLink : I
    //   424: istore #5
    //   426: aload #8
    //   428: astore #11
    //   430: aload #9
    //   432: astore #10
    //   434: aload #14
    //   436: iload #5
    //   438: invokevirtual hasValue : (I)Z
    //   441: ifeq -> 470
    //   444: aload #14
    //   446: iload #5
    //   448: invokevirtual getColorStateList : (I)Landroid/content/res/ColorStateList;
    //   451: astore #12
    //   453: aload #8
    //   455: astore #11
    //   457: aload #9
    //   459: astore #8
    //   461: goto -> 477
    //   464: aconst_null
    //   465: astore #11
    //   467: aconst_null
    //   468: astore #10
    //   470: aconst_null
    //   471: astore #12
    //   473: aload #10
    //   475: astore #8
    //   477: getstatic androidx/appcompat/R$styleable.TextAppearance_textLocale : I
    //   480: istore #5
    //   482: aload #14
    //   484: iload #5
    //   486: invokevirtual hasValue : (I)Z
    //   489: ifeq -> 504
    //   492: aload #14
    //   494: iload #5
    //   496: invokevirtual getString : (I)Ljava/lang/String;
    //   499: astore #13
    //   501: goto -> 507
    //   504: aconst_null
    //   505: astore #13
    //   507: iload #4
    //   509: bipush #26
    //   511: if_icmplt -> 541
    //   514: getstatic androidx/appcompat/R$styleable.TextAppearance_fontVariationSettings : I
    //   517: istore #5
    //   519: aload #14
    //   521: iload #5
    //   523: invokevirtual hasValue : (I)Z
    //   526: ifeq -> 541
    //   529: aload #14
    //   531: iload #5
    //   533: invokevirtual getString : (I)Ljava/lang/String;
    //   536: astore #10
    //   538: goto -> 544
    //   541: aconst_null
    //   542: astore #10
    //   544: aload #14
    //   546: invokevirtual recycle : ()V
    //   549: aload #11
    //   551: astore #9
    //   553: aload #13
    //   555: astore #11
    //   557: goto -> 580
    //   560: aconst_null
    //   561: astore #10
    //   563: aconst_null
    //   564: astore #9
    //   566: aconst_null
    //   567: astore #11
    //   569: iconst_0
    //   570: istore #6
    //   572: aconst_null
    //   573: astore #8
    //   575: aconst_null
    //   576: astore #12
    //   578: iconst_0
    //   579: istore_3
    //   580: aload #17
    //   582: aload_1
    //   583: getstatic androidx/appcompat/R$styleable.TextAppearance : [I
    //   586: iload_2
    //   587: iconst_0
    //   588: invokestatic obtainStyledAttributes : (Landroid/content/Context;Landroid/util/AttributeSet;[III)Landroidx/appcompat/widget/TintTypedArray;
    //   591: astore #18
    //   593: iload #7
    //   595: ifne -> 628
    //   598: getstatic androidx/appcompat/R$styleable.TextAppearance_textAllCaps : I
    //   601: istore #5
    //   603: aload #18
    //   605: iload #5
    //   607: invokevirtual hasValue : (I)Z
    //   610: ifeq -> 628
    //   613: aload #18
    //   615: iload #5
    //   617: iconst_0
    //   618: invokevirtual getBoolean : (IZ)Z
    //   621: istore #6
    //   623: iconst_1
    //   624: istore_3
    //   625: goto -> 628
    //   628: aload #9
    //   630: astore #13
    //   632: aload #8
    //   634: astore #14
    //   636: aload #12
    //   638: astore #15
    //   640: iload #4
    //   642: bipush #23
    //   644: if_icmpge -> 739
    //   647: getstatic androidx/appcompat/R$styleable.TextAppearance_android_textColor : I
    //   650: istore #5
    //   652: aload #18
    //   654: iload #5
    //   656: invokevirtual hasValue : (I)Z
    //   659: ifeq -> 671
    //   662: aload #18
    //   664: iload #5
    //   666: invokevirtual getColorStateList : (I)Landroid/content/res/ColorStateList;
    //   669: astore #9
    //   671: getstatic androidx/appcompat/R$styleable.TextAppearance_android_textColorHint : I
    //   674: istore #5
    //   676: aload #18
    //   678: iload #5
    //   680: invokevirtual hasValue : (I)Z
    //   683: ifeq -> 695
    //   686: aload #18
    //   688: iload #5
    //   690: invokevirtual getColorStateList : (I)Landroid/content/res/ColorStateList;
    //   693: astore #8
    //   695: getstatic androidx/appcompat/R$styleable.TextAppearance_android_textColorLink : I
    //   698: istore #5
    //   700: aload #9
    //   702: astore #13
    //   704: aload #8
    //   706: astore #14
    //   708: aload #12
    //   710: astore #15
    //   712: aload #18
    //   714: iload #5
    //   716: invokevirtual hasValue : (I)Z
    //   719: ifeq -> 739
    //   722: aload #18
    //   724: iload #5
    //   726: invokevirtual getColorStateList : (I)Landroid/content/res/ColorStateList;
    //   729: astore #15
    //   731: aload #8
    //   733: astore #14
    //   735: aload #9
    //   737: astore #13
    //   739: getstatic androidx/appcompat/R$styleable.TextAppearance_textLocale : I
    //   742: istore #5
    //   744: aload #18
    //   746: iload #5
    //   748: invokevirtual hasValue : (I)Z
    //   751: ifeq -> 763
    //   754: aload #18
    //   756: iload #5
    //   758: invokevirtual getString : (I)Ljava/lang/String;
    //   761: astore #11
    //   763: iload #4
    //   765: bipush #26
    //   767: if_icmplt -> 797
    //   770: getstatic androidx/appcompat/R$styleable.TextAppearance_fontVariationSettings : I
    //   773: istore #5
    //   775: aload #18
    //   777: iload #5
    //   779: invokevirtual hasValue : (I)Z
    //   782: ifeq -> 797
    //   785: aload #18
    //   787: iload #5
    //   789: invokevirtual getString : (I)Ljava/lang/String;
    //   792: astore #8
    //   794: goto -> 801
    //   797: aload #10
    //   799: astore #8
    //   801: iload #4
    //   803: bipush #28
    //   805: if_icmplt -> 846
    //   808: getstatic androidx/appcompat/R$styleable.TextAppearance_android_textSize : I
    //   811: istore #5
    //   813: aload #18
    //   815: iload #5
    //   817: invokevirtual hasValue : (I)Z
    //   820: ifeq -> 846
    //   823: aload #18
    //   825: iload #5
    //   827: iconst_m1
    //   828: invokevirtual getDimensionPixelSize : (II)I
    //   831: ifne -> 846
    //   834: aload_0
    //   835: getfield mView : Landroid/widget/TextView;
    //   838: iconst_0
    //   839: fconst_0
    //   840: invokevirtual setTextSize : (IF)V
    //   843: goto -> 846
    //   846: aload_0
    //   847: aload #17
    //   849: aload #18
    //   851: invokespecial updateTypefaceAndStyle : (Landroid/content/Context;Landroidx/appcompat/widget/TintTypedArray;)V
    //   854: aload #18
    //   856: invokevirtual recycle : ()V
    //   859: aload #13
    //   861: ifnull -> 873
    //   864: aload_0
    //   865: getfield mView : Landroid/widget/TextView;
    //   868: aload #13
    //   870: invokevirtual setTextColor : (Landroid/content/res/ColorStateList;)V
    //   873: aload #14
    //   875: ifnull -> 887
    //   878: aload_0
    //   879: getfield mView : Landroid/widget/TextView;
    //   882: aload #14
    //   884: invokevirtual setHintTextColor : (Landroid/content/res/ColorStateList;)V
    //   887: aload #15
    //   889: ifnull -> 901
    //   892: aload_0
    //   893: getfield mView : Landroid/widget/TextView;
    //   896: aload #15
    //   898: invokevirtual setLinkTextColor : (Landroid/content/res/ColorStateList;)V
    //   901: iload #7
    //   903: ifne -> 916
    //   906: iload_3
    //   907: ifeq -> 916
    //   910: aload_0
    //   911: iload #6
    //   913: invokevirtual setAllCaps : (Z)V
    //   916: aload_0
    //   917: getfield mFontTypeface : Landroid/graphics/Typeface;
    //   920: astore #9
    //   922: aload #9
    //   924: ifnull -> 960
    //   927: aload_0
    //   928: getfield mFontWeight : I
    //   931: iconst_m1
    //   932: if_icmpne -> 951
    //   935: aload_0
    //   936: getfield mView : Landroid/widget/TextView;
    //   939: aload #9
    //   941: aload_0
    //   942: getfield mStyle : I
    //   945: invokevirtual setTypeface : (Landroid/graphics/Typeface;I)V
    //   948: goto -> 960
    //   951: aload_0
    //   952: getfield mView : Landroid/widget/TextView;
    //   955: aload #9
    //   957: invokevirtual setTypeface : (Landroid/graphics/Typeface;)V
    //   960: aload #8
    //   962: ifnull -> 975
    //   965: aload_0
    //   966: getfield mView : Landroid/widget/TextView;
    //   969: aload #8
    //   971: invokevirtual setFontVariationSettings : (Ljava/lang/String;)Z
    //   974: pop
    //   975: aload #11
    //   977: ifnull -> 1029
    //   980: iload #4
    //   982: bipush #24
    //   984: if_icmplt -> 1002
    //   987: aload_0
    //   988: getfield mView : Landroid/widget/TextView;
    //   991: aload #11
    //   993: invokestatic forLanguageTags : (Ljava/lang/String;)Landroid/os/LocaleList;
    //   996: invokevirtual setTextLocales : (Landroid/os/LocaleList;)V
    //   999: goto -> 1029
    //   1002: aload #11
    //   1004: iconst_0
    //   1005: aload #11
    //   1007: bipush #44
    //   1009: invokevirtual indexOf : (I)I
    //   1012: invokevirtual substring : (II)Ljava/lang/String;
    //   1015: astore #8
    //   1017: aload_0
    //   1018: getfield mView : Landroid/widget/TextView;
    //   1021: aload #8
    //   1023: invokestatic forLanguageTag : (Ljava/lang/String;)Ljava/util/Locale;
    //   1026: invokevirtual setTextLocale : (Ljava/util/Locale;)V
    //   1029: aload_0
    //   1030: getfield mAutoSizeTextHelper : Landroidx/appcompat/widget/AppCompatTextViewAutoSizeHelper;
    //   1033: aload_1
    //   1034: iload_2
    //   1035: invokevirtual loadFromAttributes : (Landroid/util/AttributeSet;I)V
    //   1038: getstatic androidx/core/widget/AutoSizeableTextView.PLATFORM_SUPPORTS_AUTOSIZE : Z
    //   1041: ifeq -> 1126
    //   1044: aload_0
    //   1045: getfield mAutoSizeTextHelper : Landroidx/appcompat/widget/AppCompatTextViewAutoSizeHelper;
    //   1048: invokevirtual getAutoSizeTextType : ()I
    //   1051: ifeq -> 1126
    //   1054: aload_0
    //   1055: getfield mAutoSizeTextHelper : Landroidx/appcompat/widget/AppCompatTextViewAutoSizeHelper;
    //   1058: invokevirtual getAutoSizeTextAvailableSizes : ()[I
    //   1061: astore #8
    //   1063: aload #8
    //   1065: arraylength
    //   1066: ifle -> 1126
    //   1069: aload_0
    //   1070: getfield mView : Landroid/widget/TextView;
    //   1073: invokevirtual getAutoSizeStepGranularity : ()I
    //   1076: i2f
    //   1077: ldc_w -1.0
    //   1080: fcmpl
    //   1081: ifeq -> 1116
    //   1084: aload_0
    //   1085: getfield mView : Landroid/widget/TextView;
    //   1088: aload_0
    //   1089: getfield mAutoSizeTextHelper : Landroidx/appcompat/widget/AppCompatTextViewAutoSizeHelper;
    //   1092: invokevirtual getAutoSizeMinTextSize : ()I
    //   1095: aload_0
    //   1096: getfield mAutoSizeTextHelper : Landroidx/appcompat/widget/AppCompatTextViewAutoSizeHelper;
    //   1099: invokevirtual getAutoSizeMaxTextSize : ()I
    //   1102: aload_0
    //   1103: getfield mAutoSizeTextHelper : Landroidx/appcompat/widget/AppCompatTextViewAutoSizeHelper;
    //   1106: invokevirtual getAutoSizeStepGranularity : ()I
    //   1109: iconst_0
    //   1110: invokevirtual setAutoSizeTextTypeUniformWithConfiguration : (IIII)V
    //   1113: goto -> 1126
    //   1116: aload_0
    //   1117: getfield mView : Landroid/widget/TextView;
    //   1120: aload #8
    //   1122: iconst_0
    //   1123: invokevirtual setAutoSizeTextTypeUniformWithPresetSizes : ([II)V
    //   1126: aload #17
    //   1128: aload_1
    //   1129: getstatic androidx/appcompat/R$styleable.AppCompatTextView : [I
    //   1132: invokestatic obtainStyledAttributes : (Landroid/content/Context;Landroid/util/AttributeSet;[I)Landroidx/appcompat/widget/TintTypedArray;
    //   1135: astore #13
    //   1137: aload #13
    //   1139: getstatic androidx/appcompat/R$styleable.AppCompatTextView_drawableLeftCompat : I
    //   1142: iconst_m1
    //   1143: invokevirtual getResourceId : (II)I
    //   1146: istore_2
    //   1147: iload_2
    //   1148: iconst_m1
    //   1149: if_icmpeq -> 1164
    //   1152: aload #16
    //   1154: aload #17
    //   1156: iload_2
    //   1157: invokevirtual getDrawable : (Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;
    //   1160: astore_1
    //   1161: goto -> 1166
    //   1164: aconst_null
    //   1165: astore_1
    //   1166: aload #13
    //   1168: getstatic androidx/appcompat/R$styleable.AppCompatTextView_drawableTopCompat : I
    //   1171: iconst_m1
    //   1172: invokevirtual getResourceId : (II)I
    //   1175: istore_2
    //   1176: iload_2
    //   1177: iconst_m1
    //   1178: if_icmpeq -> 1194
    //   1181: aload #16
    //   1183: aload #17
    //   1185: iload_2
    //   1186: invokevirtual getDrawable : (Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;
    //   1189: astore #8
    //   1191: goto -> 1197
    //   1194: aconst_null
    //   1195: astore #8
    //   1197: aload #13
    //   1199: getstatic androidx/appcompat/R$styleable.AppCompatTextView_drawableRightCompat : I
    //   1202: iconst_m1
    //   1203: invokevirtual getResourceId : (II)I
    //   1206: istore_2
    //   1207: iload_2
    //   1208: iconst_m1
    //   1209: if_icmpeq -> 1225
    //   1212: aload #16
    //   1214: aload #17
    //   1216: iload_2
    //   1217: invokevirtual getDrawable : (Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;
    //   1220: astore #9
    //   1222: goto -> 1228
    //   1225: aconst_null
    //   1226: astore #9
    //   1228: aload #13
    //   1230: getstatic androidx/appcompat/R$styleable.AppCompatTextView_drawableBottomCompat : I
    //   1233: iconst_m1
    //   1234: invokevirtual getResourceId : (II)I
    //   1237: istore_2
    //   1238: iload_2
    //   1239: iconst_m1
    //   1240: if_icmpeq -> 1256
    //   1243: aload #16
    //   1245: aload #17
    //   1247: iload_2
    //   1248: invokevirtual getDrawable : (Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;
    //   1251: astore #10
    //   1253: goto -> 1259
    //   1256: aconst_null
    //   1257: astore #10
    //   1259: aload #13
    //   1261: getstatic androidx/appcompat/R$styleable.AppCompatTextView_drawableStartCompat : I
    //   1264: iconst_m1
    //   1265: invokevirtual getResourceId : (II)I
    //   1268: istore_2
    //   1269: iload_2
    //   1270: iconst_m1
    //   1271: if_icmpeq -> 1287
    //   1274: aload #16
    //   1276: aload #17
    //   1278: iload_2
    //   1279: invokevirtual getDrawable : (Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;
    //   1282: astore #11
    //   1284: goto -> 1290
    //   1287: aconst_null
    //   1288: astore #11
    //   1290: aload #13
    //   1292: getstatic androidx/appcompat/R$styleable.AppCompatTextView_drawableEndCompat : I
    //   1295: iconst_m1
    //   1296: invokevirtual getResourceId : (II)I
    //   1299: istore_2
    //   1300: iload_2
    //   1301: iconst_m1
    //   1302: if_icmpeq -> 1318
    //   1305: aload #16
    //   1307: aload #17
    //   1309: iload_2
    //   1310: invokevirtual getDrawable : (Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;
    //   1313: astore #12
    //   1315: goto -> 1321
    //   1318: aconst_null
    //   1319: astore #12
    //   1321: aload_0
    //   1322: aload_1
    //   1323: aload #8
    //   1325: aload #9
    //   1327: aload #10
    //   1329: aload #11
    //   1331: aload #12
    //   1333: invokespecial setCompoundDrawables : (Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V
    //   1336: getstatic androidx/appcompat/R$styleable.AppCompatTextView_drawableTint : I
    //   1339: istore_2
    //   1340: aload #13
    //   1342: iload_2
    //   1343: invokevirtual hasValue : (I)Z
    //   1346: ifeq -> 1364
    //   1349: aload #13
    //   1351: iload_2
    //   1352: invokevirtual getColorStateList : (I)Landroid/content/res/ColorStateList;
    //   1355: astore_1
    //   1356: aload_0
    //   1357: getfield mView : Landroid/widget/TextView;
    //   1360: aload_1
    //   1361: invokestatic setCompoundDrawableTintList : (Landroid/widget/TextView;Landroid/content/res/ColorStateList;)V
    //   1364: getstatic androidx/appcompat/R$styleable.AppCompatTextView_drawableTintMode : I
    //   1367: istore_2
    //   1368: aload #13
    //   1370: iload_2
    //   1371: invokevirtual hasValue : (I)Z
    //   1374: ifeq -> 1400
    //   1377: aload #13
    //   1379: iload_2
    //   1380: iconst_m1
    //   1381: invokevirtual getInt : (II)I
    //   1384: aconst_null
    //   1385: invokestatic parseTintMode : (ILandroid/graphics/PorterDuff$Mode;)Landroid/graphics/PorterDuff$Mode;
    //   1388: astore_1
    //   1389: aload_0
    //   1390: getfield mView : Landroid/widget/TextView;
    //   1393: aload_1
    //   1394: invokestatic setCompoundDrawableTintMode : (Landroid/widget/TextView;Landroid/graphics/PorterDuff$Mode;)V
    //   1397: goto -> 1400
    //   1400: aload #13
    //   1402: getstatic androidx/appcompat/R$styleable.AppCompatTextView_firstBaselineToTopHeight : I
    //   1405: iconst_m1
    //   1406: invokevirtual getDimensionPixelSize : (II)I
    //   1409: istore_2
    //   1410: aload #13
    //   1412: getstatic androidx/appcompat/R$styleable.AppCompatTextView_lastBaselineToBottomHeight : I
    //   1415: iconst_m1
    //   1416: invokevirtual getDimensionPixelSize : (II)I
    //   1419: istore_3
    //   1420: aload #13
    //   1422: getstatic androidx/appcompat/R$styleable.AppCompatTextView_lineHeight : I
    //   1425: iconst_m1
    //   1426: invokevirtual getDimensionPixelSize : (II)I
    //   1429: istore #4
    //   1431: aload #13
    //   1433: invokevirtual recycle : ()V
    //   1436: iload_2
    //   1437: iconst_m1
    //   1438: if_icmpeq -> 1449
    //   1441: aload_0
    //   1442: getfield mView : Landroid/widget/TextView;
    //   1445: iload_2
    //   1446: invokestatic setFirstBaselineToTopHeight : (Landroid/widget/TextView;I)V
    //   1449: iload_3
    //   1450: iconst_m1
    //   1451: if_icmpeq -> 1462
    //   1454: aload_0
    //   1455: getfield mView : Landroid/widget/TextView;
    //   1458: iload_3
    //   1459: invokestatic setLastBaselineToBottomHeight : (Landroid/widget/TextView;I)V
    //   1462: iload #4
    //   1464: iconst_m1
    //   1465: if_icmpeq -> 1477
    //   1468: aload_0
    //   1469: getfield mView : Landroid/widget/TextView;
    //   1472: iload #4
    //   1474: invokestatic setLineHeight : (Landroid/widget/TextView;I)V
    //   1477: return
  }
  
  void onAsyncTypefaceReceived(WeakReference<TextView> paramWeakReference, final Typeface typeface) {
    if (this.mAsyncFontPending) {
      this.mFontTypeface = typeface;
      final TextView textView = paramWeakReference.get();
      if (textView != null) {
        if (ViewCompat.isAttachedToWindow((View)textView)) {
          textView.post(new Runnable() {
                public void run() {
                  textView.setTypeface(typeface, style);
                }
              });
          return;
        } 
        textView.setTypeface(typeface, this.mStyle);
      } 
    } 
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP_PREFIX})
  void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    if (!AutoSizeableTextView.PLATFORM_SUPPORTS_AUTOSIZE)
      autoSizeText(); 
  }
  
  void onSetCompoundDrawables() {
    applyCompoundDrawablesTints();
  }
  
  void onSetTextAppearance(Context paramContext, int paramInt) {
    TintTypedArray tintTypedArray = TintTypedArray.obtainStyledAttributes(paramContext, paramInt, R.styleable.TextAppearance);
    paramInt = R.styleable.TextAppearance_textAllCaps;
    if (tintTypedArray.hasValue(paramInt))
      setAllCaps(tintTypedArray.getBoolean(paramInt, false)); 
    paramInt = Build.VERSION.SDK_INT;
    if (paramInt < 23) {
      int j = R.styleable.TextAppearance_android_textColor;
      if (tintTypedArray.hasValue(j)) {
        ColorStateList colorStateList = tintTypedArray.getColorStateList(j);
        if (colorStateList != null)
          this.mView.setTextColor(colorStateList); 
      } 
      j = R.styleable.TextAppearance_android_textColorLink;
      if (tintTypedArray.hasValue(j)) {
        ColorStateList colorStateList = tintTypedArray.getColorStateList(j);
        if (colorStateList != null)
          this.mView.setLinkTextColor(colorStateList); 
      } 
      j = R.styleable.TextAppearance_android_textColorHint;
      if (tintTypedArray.hasValue(j)) {
        ColorStateList colorStateList = tintTypedArray.getColorStateList(j);
        if (colorStateList != null)
          this.mView.setHintTextColor(colorStateList); 
      } 
    } 
    int i = R.styleable.TextAppearance_android_textSize;
    if (tintTypedArray.hasValue(i) && tintTypedArray.getDimensionPixelSize(i, -1) == 0)
      this.mView.setTextSize(0, 0.0F); 
    updateTypefaceAndStyle(paramContext, tintTypedArray);
    if (paramInt >= 26) {
      paramInt = R.styleable.TextAppearance_fontVariationSettings;
      if (tintTypedArray.hasValue(paramInt)) {
        String str = tintTypedArray.getString(paramInt);
        if (str != null)
          this.mView.setFontVariationSettings(str); 
      } 
    } 
    tintTypedArray.recycle();
    Typeface typeface = this.mFontTypeface;
    if (typeface != null)
      this.mView.setTypeface(typeface, this.mStyle); 
  }
  
  void populateSurroundingTextIfNeeded(@NonNull TextView paramTextView, @Nullable InputConnection paramInputConnection, @NonNull EditorInfo paramEditorInfo) {
    if (Build.VERSION.SDK_INT < 30 && paramInputConnection != null)
      EditorInfoCompat.setInitialSurroundingText(paramEditorInfo, paramTextView.getText()); 
  }
  
  void setAllCaps(boolean paramBoolean) {
    this.mView.setAllCaps(paramBoolean);
  }
  
  void setAutoSizeTextTypeUniformWithConfiguration(int paramInt1, int paramInt2, int paramInt3, int paramInt4) throws IllegalArgumentException {
    this.mAutoSizeTextHelper.setAutoSizeTextTypeUniformWithConfiguration(paramInt1, paramInt2, paramInt3, paramInt4);
  }
  
  void setAutoSizeTextTypeUniformWithPresetSizes(@NonNull int[] paramArrayOfint, int paramInt) throws IllegalArgumentException {
    this.mAutoSizeTextHelper.setAutoSizeTextTypeUniformWithPresetSizes(paramArrayOfint, paramInt);
  }
  
  void setAutoSizeTextTypeWithDefaults(int paramInt) {
    this.mAutoSizeTextHelper.setAutoSizeTextTypeWithDefaults(paramInt);
  }
  
  void setCompoundDrawableTintList(@Nullable ColorStateList paramColorStateList) {
    boolean bool;
    if (this.mDrawableTint == null)
      this.mDrawableTint = new TintInfo(); 
    TintInfo tintInfo = this.mDrawableTint;
    tintInfo.mTintList = paramColorStateList;
    if (paramColorStateList != null) {
      bool = true;
    } else {
      bool = false;
    } 
    tintInfo.mHasTintList = bool;
    setCompoundTints();
  }
  
  void setCompoundDrawableTintMode(@Nullable PorterDuff.Mode paramMode) {
    boolean bool;
    if (this.mDrawableTint == null)
      this.mDrawableTint = new TintInfo(); 
    TintInfo tintInfo = this.mDrawableTint;
    tintInfo.mTintMode = paramMode;
    if (paramMode != null) {
      bool = true;
    } else {
      bool = false;
    } 
    tintInfo.mHasTintMode = bool;
    setCompoundTints();
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP_PREFIX})
  void setTextSize(int paramInt, float paramFloat) {
    if (!AutoSizeableTextView.PLATFORM_SUPPORTS_AUTOSIZE && !isAutoSizeEnabled())
      setTextSizeInternal(paramInt, paramFloat); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\BabyBus TV_Kids Videos & Games-dex2jar.jar!\androidx\appcompat\widget\AppCompatTextHelper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */