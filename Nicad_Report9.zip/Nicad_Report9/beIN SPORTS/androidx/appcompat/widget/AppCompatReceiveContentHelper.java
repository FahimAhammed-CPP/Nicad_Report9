package androidx.appcompat.widget;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.ContextWrapper;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcelable;
import android.text.Selection;
import android.text.Spannable;
import android.util.Log;
import android.view.DragEvent;
import android.view.View;
import android.view.inputmethod.InputContentInfo;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.core.view.ContentInfoCompat;
import androidx.core.view.ViewCompat;
import androidx.core.view.inputmethod.InputConnectionCompat;
import androidx.core.view.inputmethod.InputContentInfoCompat;

final class AppCompatReceiveContentHelper {
  private static final String EXTRA_INPUT_CONTENT_INFO = "androidx.core.view.extra.INPUT_CONTENT_INFO";
  
  private static final String LOG_TAG = "ReceiveContent";
  
  @NonNull
  static InputConnectionCompat.OnCommitContentListener createOnCommitContentListener(@NonNull final View view) {
    return new InputConnectionCompat.OnCommitContentListener() {
        public boolean onCommitContent(InputContentInfoCompat param1InputContentInfoCompat, int param1Int, Bundle param1Bundle) {
          int i = Build.VERSION.SDK_INT;
          boolean bool = false;
          Bundle bundle = param1Bundle;
          if (i >= 25) {
            bundle = param1Bundle;
            if ((param1Int & 0x1) != 0)
              try {
                param1InputContentInfoCompat.requestPermission();
                InputContentInfo inputContentInfo = (InputContentInfo)param1InputContentInfoCompat.unwrap();
                if (param1Bundle == null) {
                  param1Bundle = new Bundle();
                } else {
                  param1Bundle = new Bundle(param1Bundle);
                } 
                param1Bundle.putParcelable("androidx.core.view.extra.INPUT_CONTENT_INFO", (Parcelable)inputContentInfo);
                bundle = param1Bundle;
              } catch (Exception exception) {
                Log.w("ReceiveContent", "Can't insert content from IME; requestPermission() failed", exception);
                return false;
              }  
          } 
          ContentInfoCompat contentInfoCompat = (new ContentInfoCompat.Builder(new ClipData(exception.getDescription(), new ClipData.Item(exception.getContentUri())), 2)).setLinkUri(exception.getLinkUri()).setExtras(bundle).build();
          if (ViewCompat.performReceiveContent(view, contentInfoCompat) == null)
            bool = true; 
          return bool;
        }
      };
  }
  
  static boolean maybeHandleDragEventViaPerformReceiveContent(@NonNull View paramView, @NonNull DragEvent paramDragEvent) {
    if (Build.VERSION.SDK_INT >= 24 && paramDragEvent.getLocalState() == null) {
      StringBuilder stringBuilder;
      if (ViewCompat.getOnReceiveContentMimeTypes(paramView) == null)
        return false; 
      Activity activity = tryGetActivity(paramView);
      if (activity == null) {
        stringBuilder = new StringBuilder();
        stringBuilder.append("Can't handle drop: no activity: view=");
        stringBuilder.append(paramView);
        Log.i("ReceiveContent", stringBuilder.toString());
        return false;
      } 
      if (stringBuilder.getAction() == 1)
        return paramView instanceof TextView ^ true; 
      if (stringBuilder.getAction() == 3)
        return (paramView instanceof TextView) ? OnDropApi24Impl.onDropForTextView((DragEvent)stringBuilder, (TextView)paramView, activity) : OnDropApi24Impl.onDropForView((DragEvent)stringBuilder, paramView, activity); 
    } 
    return false;
  }
  
  static boolean maybeHandleMenuActionViaPerformReceiveContent(@NonNull TextView paramTextView, int paramInt) {
    ClipData clipData;
    boolean bool = false;
    if ((paramInt != 16908322 && paramInt != 16908337) || ViewCompat.getOnReceiveContentMimeTypes((View)paramTextView) == null)
      return false; 
    ClipboardManager clipboardManager = (ClipboardManager)paramTextView.getContext().getSystemService("clipboard");
    if (clipboardManager == null) {
      clipboardManager = null;
    } else {
      clipData = clipboardManager.getPrimaryClip();
    } 
    if (clipData != null && clipData.getItemCount() > 0) {
      ContentInfoCompat.Builder builder = new ContentInfoCompat.Builder(clipData, 1);
      if (paramInt == 16908322) {
        paramInt = bool;
      } else {
        paramInt = 1;
      } 
      ViewCompat.performReceiveContent((View)paramTextView, builder.setFlags(paramInt).build());
    } 
    return true;
  }
  
  @Nullable
  static Activity tryGetActivity(@NonNull View paramView) {
    for (Context context = paramView.getContext(); context instanceof ContextWrapper; context = ((ContextWrapper)context).getBaseContext()) {
      if (context instanceof Activity)
        return (Activity)context; 
    } 
    return null;
  }
  
  @RequiresApi(24)
  private static final class OnDropApi24Impl {
    static boolean onDropForTextView(@NonNull DragEvent param1DragEvent, @NonNull TextView param1TextView, @NonNull Activity param1Activity) {
      param1Activity.requestDragAndDropPermissions(param1DragEvent);
      int i = param1TextView.getOffsetForPosition(param1DragEvent.getX(), param1DragEvent.getY());
      param1TextView.beginBatchEdit();
      try {
        Selection.setSelection((Spannable)param1TextView.getText(), i);
        ViewCompat.performReceiveContent((View)param1TextView, (new ContentInfoCompat.Builder(param1DragEvent.getClipData(), 3)).build());
        return true;
      } finally {
        param1TextView.endBatchEdit();
      } 
    }
    
    static boolean onDropForView(@NonNull DragEvent param1DragEvent, @NonNull View param1View, @NonNull Activity param1Activity) {
      param1Activity.requestDragAndDropPermissions(param1DragEvent);
      ViewCompat.performReceiveContent(param1View, (new ContentInfoCompat.Builder(param1DragEvent.getClipData(), 3)).build());
      return true;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\BabyBus TV_Kids Videos & Games-dex2jar.jar!\androidx\appcompat\widget\AppCompatReceiveContentHelper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */