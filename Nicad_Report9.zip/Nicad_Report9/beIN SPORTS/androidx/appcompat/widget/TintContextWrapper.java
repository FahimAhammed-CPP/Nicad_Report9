package androidx.appcompat.widget;

import android.content.Context;
import android.content.ContextWrapper;
import android.content.res.AssetManager;
import android.content.res.Resources;
import androidx.annotation.NonNull;
import androidx.annotation.RestrictTo;
import java.lang.ref.WeakReference;
import java.util.ArrayList;

@RestrictTo({RestrictTo.Scope.LIBRARY_GROUP_PREFIX})
public class TintContextWrapper extends ContextWrapper {
  private static final Object CACHE_LOCK = new Object();
  
  private static ArrayList<WeakReference<TintContextWrapper>> sCache;
  
  private final Resources mResources;
  
  private final Resources.Theme mTheme;
  
  private TintContextWrapper(@NonNull Context paramContext) {
    super(paramContext);
    if (VectorEnabledTintResources.shouldBeUsed()) {
      VectorEnabledTintResources vectorEnabledTintResources = new VectorEnabledTintResources((Context)this, paramContext.getResources());
      this.mResources = vectorEnabledTintResources;
      Resources.Theme theme = vectorEnabledTintResources.newTheme();
      this.mTheme = theme;
      theme.setTo(paramContext.getTheme());
      return;
    } 
    this.mResources = new TintResources((Context)this, paramContext.getResources());
    this.mTheme = null;
  }
  
  private static boolean shouldWrap(@NonNull Context paramContext) {
    boolean bool = paramContext instanceof TintContextWrapper;
    boolean bool2 = false;
    boolean bool1 = bool2;
    if (!bool) {
      bool1 = bool2;
      if (!(paramContext.getResources() instanceof TintResources)) {
        if (paramContext.getResources() instanceof VectorEnabledTintResources)
          return false; 
        bool1 = bool2;
        if (VectorEnabledTintResources.shouldBeUsed())
          bool1 = true; 
      } 
    } 
    return bool1;
  }
  
  public static Context wrap(@NonNull Context paramContext) {
    if (shouldWrap(paramContext))
      synchronized (CACHE_LOCK) {
        ArrayList<WeakReference<TintContextWrapper>> arrayList = sCache;
        if (arrayList == null) {
          sCache = new ArrayList<WeakReference<TintContextWrapper>>();
        } else {
          for (int i = arrayList.size() - 1;; i--) {
            if (i >= 0) {
              WeakReference weakReference = sCache.get(i);
              if (weakReference == null || weakReference.get() == null)
                sCache.remove(i); 
            } else {
              for (i = sCache.size() - 1;; i--) {
                if (i >= 0) {
                  WeakReference<TintContextWrapper> weakReference = sCache.get(i);
                  if (weakReference != null) {
                    TintContextWrapper tintContextWrapper1 = weakReference.get();
                  } else {
                    weakReference = null;
                  } 
                  if (weakReference != null && weakReference.getBaseContext() == paramContext)
                    return (Context)weakReference; 
                } else {
                  tintContextWrapper = new TintContextWrapper(paramContext);
                  sCache.add(new WeakReference<TintContextWrapper>(tintContextWrapper));
                  return (Context)tintContextWrapper;
                } 
              } 
            } 
          } 
          i--;
        } 
        TintContextWrapper tintContextWrapper = new TintContextWrapper((Context)tintContextWrapper);
        sCache.add(new WeakReference<TintContextWrapper>(tintContextWrapper));
        return (Context)tintContextWrapper;
      }  
    return paramContext;
  }
  
  public AssetManager getAssets() {
    return this.mResources.getAssets();
  }
  
  public Resources getResources() {
    return this.mResources;
  }
  
  public Resources.Theme getTheme() {
    Resources.Theme theme2 = this.mTheme;
    Resources.Theme theme1 = theme2;
    if (theme2 == null)
      theme1 = super.getTheme(); 
    return theme1;
  }
  
  public void setTheme(int paramInt) {
    Resources.Theme theme = this.mTheme;
    if (theme == null) {
      super.setTheme(paramInt);
      return;
    } 
    theme.applyStyle(paramInt, true);
  }
}


/* Location:              C:\soft\dex2jar-2.0\BabyBus TV_Kids Videos & Games-dex2jar.jar!\androidx\appcompat\widget\TintContextWrapper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */