package androidx.collection;

import fq.a;
import fq.p;
import java.util.Iterator;
import kotlin.collections.y;
import kotlin.jvm.internal.j;
import zp.x;

public final class SparseArrayKt {
  public static final <T> boolean contains(SparseArrayCompat<T> paramSparseArrayCompat, int paramInt) {
    j.g(paramSparseArrayCompat, "receiver$0");
    return paramSparseArrayCompat.containsKey(paramInt);
  }
  
  public static final <T> void forEach(SparseArrayCompat<T> paramSparseArrayCompat, p<? super Integer, ? super T, x> paramp) {
    j.g(paramSparseArrayCompat, "receiver$0");
    j.g(paramp, "action");
    int j = paramSparseArrayCompat.size();
    for (int i = 0; i < j; i++)
      paramp.invoke(Integer.valueOf(paramSparseArrayCompat.keyAt(i)), paramSparseArrayCompat.valueAt(i)); 
  }
  
  public static final <T> T getOrDefault(SparseArrayCompat<T> paramSparseArrayCompat, int paramInt, T paramT) {
    j.g(paramSparseArrayCompat, "receiver$0");
    return paramSparseArrayCompat.get(paramInt, paramT);
  }
  
  public static final <T> T getOrElse(SparseArrayCompat<T> paramSparseArrayCompat, int paramInt, a<? extends T> parama) {
    j.g(paramSparseArrayCompat, "receiver$0");
    j.g(parama, "defaultValue");
    paramSparseArrayCompat = (SparseArrayCompat<T>)paramSparseArrayCompat.get(paramInt);
    return (T)((paramSparseArrayCompat != null) ? paramSparseArrayCompat : parama.invoke());
  }
  
  public static final <T> int getSize(SparseArrayCompat<T> paramSparseArrayCompat) {
    j.g(paramSparseArrayCompat, "receiver$0");
    return paramSparseArrayCompat.size();
  }
  
  public static final <T> boolean isNotEmpty(SparseArrayCompat<T> paramSparseArrayCompat) {
    j.g(paramSparseArrayCompat, "receiver$0");
    return paramSparseArrayCompat.isEmpty() ^ true;
  }
  
  public static final <T> y keyIterator(SparseArrayCompat<T> paramSparseArrayCompat) {
    j.g(paramSparseArrayCompat, "receiver$0");
    return new SparseArrayKt$keyIterator$1(paramSparseArrayCompat);
  }
  
  public static final <T> SparseArrayCompat<T> plus(SparseArrayCompat<T> paramSparseArrayCompat1, SparseArrayCompat<T> paramSparseArrayCompat2) {
    j.g(paramSparseArrayCompat1, "receiver$0");
    j.g(paramSparseArrayCompat2, "other");
    SparseArrayCompat<T> sparseArrayCompat = new SparseArrayCompat(paramSparseArrayCompat1.size() + paramSparseArrayCompat2.size());
    sparseArrayCompat.putAll(paramSparseArrayCompat1);
    sparseArrayCompat.putAll(paramSparseArrayCompat2);
    return sparseArrayCompat;
  }
  
  public static final <T> boolean remove(SparseArrayCompat<T> paramSparseArrayCompat, int paramInt, T paramT) {
    j.g(paramSparseArrayCompat, "receiver$0");
    return paramSparseArrayCompat.remove(paramInt, paramT);
  }
  
  public static final <T> void set(SparseArrayCompat<T> paramSparseArrayCompat, int paramInt, T paramT) {
    j.g(paramSparseArrayCompat, "receiver$0");
    paramSparseArrayCompat.put(paramInt, paramT);
  }
  
  public static final <T> Iterator<T> valueIterator(SparseArrayCompat<T> paramSparseArrayCompat) {
    j.g(paramSparseArrayCompat, "receiver$0");
    return new SparseArrayKt$valueIterator$1(paramSparseArrayCompat);
  }
  
  public static final class SparseArrayKt$keyIterator$1 extends y {
    private int index;
    
    SparseArrayKt$keyIterator$1(SparseArrayCompat<T> param1SparseArrayCompat) {}
    
    public final int getIndex() {
      return this.index;
    }
    
    public boolean hasNext() {
      return (this.index < this.$this_keyIterator.size());
    }
    
    public int nextInt() {
      SparseArrayCompat sparseArrayCompat = this.$this_keyIterator;
      int i = this.index;
      this.index = i + 1;
      return sparseArrayCompat.keyAt(i);
    }
    
    public final void setIndex(int param1Int) {
      this.index = param1Int;
    }
  }
  
  public static final class SparseArrayKt$valueIterator$1 implements Iterator<T> {
    private int index;
    
    SparseArrayKt$valueIterator$1(SparseArrayCompat<T> param1SparseArrayCompat) {}
    
    public final int getIndex() {
      return this.index;
    }
    
    public boolean hasNext() {
      return (this.index < this.$this_valueIterator.size());
    }
    
    public T next() {
      SparseArrayCompat<T> sparseArrayCompat = this.$this_valueIterator;
      int i = this.index;
      this.index = i + 1;
      return sparseArrayCompat.valueAt(i);
    }
    
    public void remove() {
      throw new UnsupportedOperationException("Operation is not supported for read-only collection");
    }
    
    public final void setIndex(int param1Int) {
      this.index = param1Int;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\BabyBus TV_Kids Videos & Games-dex2jar.jar!\androidx\collection\SparseArrayKt.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */