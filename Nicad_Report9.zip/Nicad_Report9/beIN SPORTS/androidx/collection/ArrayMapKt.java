package androidx.collection;

import kotlin.jvm.internal.j;
import zp.o;

public final class ArrayMapKt {
  public static final <K, V> ArrayMap<K, V> arrayMapOf() {
    return new ArrayMap<K, V>();
  }
  
  public static final <K, V> ArrayMap<K, V> arrayMapOf(o<? extends K, ? extends V>... paramVarArgs) {
    j.g(paramVarArgs, "pairs");
    ArrayMap<Object, Object> arrayMap = new ArrayMap<Object, Object>(paramVarArgs.length);
    int j = paramVarArgs.length;
    for (int i = 0; i < j; i++) {
      o<? extends K, ? extends V> o1 = paramVarArgs[i];
      arrayMap.put(o1.getFirst(), o1.getSecond());
    } 
    return (ArrayMap)arrayMap;
  }
}


/* Location:              C:\soft\dex2jar-2.0\BabyBus TV_Kids Videos & Games-dex2jar.jar!\androidx\collection\ArrayMapKt.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */