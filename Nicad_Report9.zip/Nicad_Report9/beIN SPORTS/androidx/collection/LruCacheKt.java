package androidx.collection;

import fq.l;
import fq.p;
import fq.r;
import kotlin.jvm.internal.j;
import kotlin.jvm.internal.k;
import zp.x;

public final class LruCacheKt {
  public static final <K, V> LruCache<K, V> lruCache(int paramInt, p<? super K, ? super V, Integer> paramp, l<? super K, ? extends V> paraml, r<? super Boolean, ? super K, ? super V, ? super V, x> paramr) {
    j.g(paramp, "sizeOf");
    j.g(paraml, "create");
    j.g(paramr, "onEntryRemoved");
    return new LruCacheKt$lruCache$4(paramp, paraml, paramr, paramInt, paramInt);
  }
  
  public static final class LruCacheKt$lruCache$1 extends k implements p {
    public static final LruCacheKt$lruCache$1 INSTANCE = new LruCacheKt$lruCache$1();
    
    public LruCacheKt$lruCache$1() {
      super(2);
    }
    
    public final int invoke(Object param1Object1, Object param1Object2) {
      j.g(param1Object1, "<anonymous parameter 0>");
      j.g(param1Object2, "<anonymous parameter 1>");
      return 1;
    }
  }
  
  public static final class LruCacheKt$lruCache$2 extends k implements l {
    public static final LruCacheKt$lruCache$2 INSTANCE = new LruCacheKt$lruCache$2();
    
    public LruCacheKt$lruCache$2() {
      super(1);
    }
    
    public final Object invoke(Object param1Object) {
      j.g(param1Object, "it");
      return null;
    }
  }
  
  public static final class LruCacheKt$lruCache$3 extends k implements r {
    public static final LruCacheKt$lruCache$3 INSTANCE = new LruCacheKt$lruCache$3();
    
    public LruCacheKt$lruCache$3() {
      super(4);
    }
    
    public final void invoke(boolean param1Boolean, Object param1Object1, Object param1Object2, Object param1Object3) {
      j.g(param1Object1, "<anonymous parameter 1>");
      j.g(param1Object2, "<anonymous parameter 2>");
    }
  }
  
  public static final class LruCacheKt$lruCache$4 extends LruCache<K, V> {
    public LruCacheKt$lruCache$4(p param1p, l param1l, r param1r, int param1Int1, int param1Int2) {
      super(param1Int2);
    }
    
    protected V create(K param1K) {
      j.g(param1K, "key");
      return (V)this.$create.invoke(param1K);
    }
    
    protected void entryRemoved(boolean param1Boolean, K param1K, V param1V1, V param1V2) {
      j.g(param1K, "key");
      j.g(param1V1, "oldValue");
      this.$onEntryRemoved.invoke(Boolean.valueOf(param1Boolean), param1K, param1V1, param1V2);
    }
    
    protected int sizeOf(K param1K, V param1V) {
      j.g(param1K, "key");
      j.g(param1V, "value");
      return ((Number)this.$sizeOf.invoke(param1K, param1V)).intValue();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\BabyBus TV_Kids Videos & Games-dex2jar.jar!\androidx\collection\LruCacheKt.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */